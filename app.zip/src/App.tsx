import { useCallback, useEffect, useMemo, useRef, useState, type FormEvent } from "react";
import type { User } from "firebase/auth";
import { KeyRound, Loader2, Lock, LogOut } from "lucide-react";
import {
  DEFAULT_USER_AVATAR,
  createAiDefaultConversations,
  normalizeUserAvatar,
} from "./data/defaults";
import { normalizeCountryCode } from "./data/countries";
import type {
  ChatCallSignal,
  ChatMessage,
  ChatWallpaperId,
  Conversation,
  DisappearingTimerSeconds,
  MessageReplyRef,
  NotificationPrefs,
  PeerUserProfile,
  ScreenShareSignal,
  SoundPrefs,
  ThemeMode,
  TypographyPrefs,
  UserProfile,
  WatchHistoryItem,
  WatchSessionData,
} from "./types/chat";
import {
  DEFAULT_JOIN_MONTH_YEAR_AR,
  applyThemeClass,
  applyTypographyClasses,
  clearLocalSessionVersion,
  extractJoinMonthYearAr,
  hasAppLockPin,
  loadAiPinned,
  loadChatWallpaper,
  loadCustomChatWallpaper,
  loadLastReadByChat,
  loadLocalSessionVersion,
  loadNotificationPrefs,
  loadPendingSignupProfile,
  loadSoundPrefs,
  loadTheme,
  loadTypographyPrefs,
  loadUserProfile,
  saveAiPinned,
  saveChatWallpaper,
  saveCustomChatWallpaper,
  saveLastReadByChat,
  saveLocalSessionVersion,
  saveNotificationPrefs,
  savePendingSignupProfile,
  saveSoundPrefs,
  saveTheme,
  saveTypographyPrefs,
  saveUserProfile,
  sha256Hex,
  verifyAppLockPin,
  type PendingSignupProfile,
} from "./utils/storage";
import { encryptSecretMessage, ensureDeviceE2eeKeys } from "./services/e2ee";
import {
  addFriendCloud,
  addGroupMember,
  blockCloudUser,
  cleanupExpiredBlocks,
  clearAllUserDirectChats,
  createGroupChat,
  deleteExpiredChatMessages,
  deleteMessageForEveryone,
  deleteMessageForMe,
  deleteUserAccountCloud,
  deleteWatchHistoryLink,
  editDirectChatMessage,
  fetchUsersByUids,
  findUsersByExactNameOrEmail,
  getCallSignalDoc,
  hideChatForUser,
  isBlockActive,
  leaveGroupChat,
  listMyFriends,
  markChatMessagesAsRead,
  markViewOnceImageOpened,
  markWatchStartedDoc,
  openOrCreateDirectChat,
  registerWithEmailPin,
  removeFriendCloud,
  removeGroupMember,
  resendVerificationEmail,
  saveWatchHistoryLink,
  sendCallHistoryMessage,
  sendDirectChatMessage,
  sendPinResetEmail,
  setChatDisappearingTimer,
  setChatTypingStatus,
  setWatchGuestMicAllowedDoc,
  setWatchSessionDoc,
  signInWithEmailPin,
  signOutFirebase,
  startFacebookWatchCountdownDoc,
  stopWatchSessionDoc,
  subscribeToAuth,
  subscribeToChatMessages,
  subscribeToChatRingingCalls,
  subscribeToChatScreenShares,
  subscribeToUserDirectChats,
  subscribeToUserProfile,
  subscribeToWatchHistory,
  subscribeToWatchSession,
  toggleMessageReaction,
  togglePinChatCloud,
  unblockCloudUser,
  updateUserPresence,
  updateWatchPlaybackDoc,
  upsertCloudUserProfile,
  verifyEmailStatus,
} from "./services/firebase";
import {
  closeCallNotifications,
  consumeUrlCallAction,
  consumeUrlOpenChatId,
  notifyCallEndedPush,
  notifyIncomingCallPush,
  registerMirsalServiceWorker,
  requestImmediateNotificationPermission,
  showIncomingCallNotification,
  showIncomingMessageNotification,
  subscribeToServiceWorkerCallActions,
  subscribeToServiceWorkerOpenChat,
  syncWebPushSubscription,
  unsubscribeWebPush,
  updateAppIconBadge,
  type IncomingCallNotificationAction,
} from "./services/notifications";
import {
  initAudioUnlock,
  playMessageSentSound,
  playMessageTone,
  startRingtone,
  stopCallVibration,
  stopRingtone,
  unlockAudioContext,
} from "./services/sounds";
import {
  useScreenShare,
  useWatchPartyMic,
  useWebRtcCall,
  type EndedCallSummary,
} from "./services/webrtc";
import { LoginScreen } from "./components/LoginScreen";
import { Sidebar } from "./components/Sidebar";
import { ChatView } from "./components/ChatView";
import { NewChatModal } from "./components/NewChatModal";
import { SettingsModal } from "./components/SettingsModal";
import { MyProfileModal } from "./components/MyProfileModal";
import { ImageLightbox } from "./components/ImageLightbox";
import { CallOverlay } from "./components/CallOverlay";
import { OfflineIndicator } from "./components/OfflineIndicator";
import { UserProfileModal } from "./components/UserProfileModal";
import { CreateGroupModal } from "./components/CreateGroupModal";
import { GroupInfoModal } from "./components/GroupInfoModal";
import { MirsalLogo } from "./components/MirsalLogo";

interface ChatSendPayload {
  text: string;
  imageDataUrl?: string;
  videoDataUrl?: string;
  replyTo?: MessageReplyRef;
  encrypt?: boolean;
}

function createId(prefix: string): string {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

export default function App() {
  const [authReady, setAuthReady] = useState(false);
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [user, setUser] = useState<UserProfile | null>(() => loadUserProfile());
  const [pendingVerification, setPendingVerification] =
    useState<PendingSignupProfile | null>(null);

  const [theme, setTheme] = useState<ThemeMode>(() => loadTheme());
  const [wallpaperId, setWallpaperId] = useState<ChatWallpaperId>(() =>
    loadChatWallpaper()
  );
  const [customWallpaper, setCustomWallpaper] = useState<string | null>(() =>
    loadCustomChatWallpaper()
  );
  const [soundPrefs, setSoundPrefs] = useState<SoundPrefs>(() =>
    loadSoundPrefs()
  );
  const [typographyPrefs, setTypographyPrefs] = useState<TypographyPrefs>(() =>
    loadTypographyPrefs()
  );
  const [notificationPrefs, setNotificationPrefs] =
    useState<NotificationPrefs>(() => loadNotificationPrefs());
  const [lastReadByChat, setLastReadByChat] = useState<Record<string, number>>(
    () => loadLastReadByChat()
  );
  const [aiPinned, setAiPinned] = useState<boolean>(() => loadAiPinned());

  const [aiConversations, setAiConversations] = useState<Conversation[]>(() =>
    createAiDefaultConversations(loadUserProfile()?.name || "أنت")
  );

  const [cloudChats, setCloudChats] = useState<Conversation[]>([]);
  const [optimisticChats, setOptimisticChats] = useState<Conversation[]>([]);
  const [pinnedChatIds, setPinnedChatIds] = useState<string[]>([]);
  const [myFriends, setMyFriends] = useState<PeerUserProfile[]>([]);
  const [loadingFriends, setLoadingFriends] = useState(false);
  const [peerProfilesByUid, setPeerProfilesByUid] = useState<
    Record<string, PeerUserProfile>
  >({});
  const [messagesByChat, setMessagesByChat] = useState<
    Record<string, ChatMessage[]>
  >({});
  const [incomingCallByChat, setIncomingCallByChat] = useState<
    Record<string, ChatCallSignal | null>
  >({});
  const [incomingScreenShareByChat, setIncomingScreenShareByChat] = useState<
    Record<string, ScreenShareSignal | null>
  >({});
  const [watchSessionByChat, setWatchSessionByChat] = useState<
    Record<string, WatchSessionData | null>
  >({});
  const [watchHistoryByChat, setWatchHistoryByChat] = useState<
    Record<string, WatchHistoryItem[]>
  >({});

  const [activeChatId, setActiveChatId] = useState<string | null>(
    "gemini-ai-main"
  );
  const [mobileView, setMobileView] = useState<"list" | "chat">("list");
  const [isWindowVisible, setIsWindowVisible] = useState<boolean>(() =>
    typeof document === "undefined" ? true : document.visibilityState === "visible"
  );
  const [aiTypingChatIds, setAiTypingChatIds] = useState<
    Record<string, boolean>
  >({});

  const [newChatModalOpen, setNewChatModalOpen] = useState(false);
  const [createGroupOpen, setCreateGroupOpen] = useState(false);
  const [preselectedGroupMemberUids, setPreselectedGroupMemberUids] = useState<
    string[]
  >([]);
  const [groupInfoChatId, setGroupInfoChatId] = useState<string | null>(null);
  const [profileModalPeer, setProfileModalPeer] =
    useState<PeerUserProfile | null>(null);
  const [isMyProfileOpen, setIsMyProfileOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [lightboxImage, setLightboxImage] = useState<string | null>(null);
  const [viewOnceLightbox, setViewOnceLightbox] = useState<{
    chatId: string;
    messageId: string;
    src: string;
  } | null>(null);
  const [nowTick, setNowTick] = useState<number>(() => Date.now());
  const [isAppLocked, setIsAppLocked] = useState<boolean>(false);
  const [appLockPinInput, setAppLockPinInput] = useState("");
  const [appLockError, setAppLockError] = useState<string | null>(null);
  const [unlockingApp, setUnlockingApp] = useState(false);
  const [securityLogoutNotice, setSecurityLogoutNotice] = useState<string | null>(
    null
  );
  const unlockedUidRef = useRef<string | null>(null);
  const deletedExpiredIdsRef = useRef<Set<string>>(new Set());
  const markingReadIdsRef = useRef<Set<string>>(new Set());

  const userRef = useRef<UserProfile | null>(user);
  userRef.current = user;
  const soundPrefsRef = useRef<SoundPrefs>(soundPrefs);
  soundPrefsRef.current = soundPrefs;
  const notificationPrefsRef = useRef<NotificationPrefs>(notificationPrefs);
  notificationPrefsRef.current = notificationPrefs;
  const activeChatIdRef = useRef<string | null>(activeChatId);
  activeChatIdRef.current = activeChatId;
  const mobileViewRef = useRef<"list" | "chat">(mobileView);
  mobileViewRef.current = mobileView;
  const totalUnreadCountRef = useRef<number>(0);

  const initializedMsgChatsRef = useRef<Set<string>>(new Set());
  const lastSeenMsgIdByChatRef = useRef<Record<string, string>>({});

  const verifiedUid = firebaseUser?.emailVerified ? firebaseUser.uid : undefined;
  const resolvedDisplayName =
    user?.name || firebaseUser?.displayName || "مستخدم";

  const verifiedUidRef = useRef<string | undefined>(verifiedUid);
  verifiedUidRef.current = verifiedUid;
  const resolvedDisplayNameRef = useRef<string>(resolvedDisplayName);
  resolvedDisplayNameRef.current = resolvedDisplayName;
  const incomingCallByChatRef = useRef<Record<string, ChatCallSignal | null>>({});
  incomingCallByChatRef.current = incomingCallByChat;
  const peerProfilesByUidRef = useRef<Record<string, PeerUserProfile>>({});
  peerProfilesByUidRef.current = peerProfilesByUid;
  const outgoingCallPeerRef = useRef<{ callId: string; peerUid: string } | null>(
    null
  );
  const shownCallNotificationIdRef = useRef<string | null>(null);
  const pendingCallActionRef = useRef<IncomingCallNotificationAction | null>(
    null
  );

  const handleCallEndedRecord = useCallback((summary: EndedCallSummary) => {
    if (
      outgoingCallPeerRef.current &&
      outgoingCallPeerRef.current.callId === summary.callId
    ) {
      void notifyCallEndedPush({
        targetUid: outgoingCallPeerRef.current.peerUid,
        callId: summary.callId,
      });
      outgoingCallPeerRef.current = null;
    }

    const senderUid = verifiedUidRef.current;
    if (!senderUid) return;
    const senderName = resolvedDisplayNameRef.current || "مستخدم";

    if (summary.role === "caller") {
      void sendCallHistoryMessage({
        chatId: summary.chatId,
        callId: summary.callId,
        senderId: senderUid,
        senderName,
        callerId: summary.callerId,
        callType: summary.callType,
        outcome: summary.outcome,
        durationSeconds: summary.durationSeconds,
      });
      return;
    }

    setTimeout(() => {
      const latestUid = verifiedUidRef.current;
      if (!latestUid) return;
      void sendCallHistoryMessage({
        chatId: summary.chatId,
        callId: summary.callId,
        senderId: latestUid,
        senderName: resolvedDisplayNameRef.current || "مستخدم",
        callerId: summary.callerId,
        callType: summary.callType,
        outcome: summary.outcome,
        durationSeconds: summary.durationSeconds,
        checkExistsFirst: true,
      });
    }, 1500);
  }, []);

  const webrtc = useWebRtcCall({
    uid: verifiedUid,
    userName: resolvedDisplayName,
    onCallEnded: handleCallEndedRecord,
  });

  const screenShare = useScreenShare({
    uid: verifiedUid,
    userName: resolvedDisplayName,
  });

  const processNotificationCallAction = useCallback(
    async (actionPayload: IncomingCallNotificationAction) => {
      stopRingtone();
      stopCallVibration();
      void closeCallNotifications(actionPayload.callId);

      if (!verifiedUidRef.current) {
        pendingCallActionRef.current = actionPayload;
        return;
      }

      const cachedSignal =
        incomingCallByChatRef.current[actionPayload.chatId] || null;
      const callSignal =
        cachedSignal && cachedSignal.callId === actionPayload.callId
          ? cachedSignal
          : await getCallSignalDoc(actionPayload.chatId, actionPayload.callId);

      if (actionPayload.action === "decline") {
        if (callSignal) {
          await webrtc.declineIncomingCall(callSignal);
        } else {
          await webrtc.declineIncomingCall({
            callId: actionPayload.callId,
            chatId: actionPayload.chatId,
            callerId: actionPayload.callerId,
            callerName: actionPayload.callerName,
            callType: actionPayload.callType,
            status: "ringing",
            offer: { type: "offer", sdp: "" },
          });
        }
        return;
      }

      if (actionPayload.action === "accept") {
        if (!callSignal || callSignal.status !== "ringing") {
          return;
        }
        setActiveChatId(actionPayload.chatId);
        setMobileView("chat");
        const peerAvatar =
          peerProfilesByUidRef.current[callSignal.callerId]?.avatar;
        await webrtc.acceptIncomingCall(callSignal, peerAvatar);
      }
    },
    [webrtc.acceptIncomingCall, webrtc.declineIncomingCall]
  );

  // Unlock mobile Web Audio globally on first gesture + track tab visibility
  useEffect(() => {
    initAudioUnlock();
    const handleVisibility = () => {
      setIsWindowVisible(document.visibilityState === "visible");
    };
    document.addEventListener("visibilitychange", handleVisibility);
    return () => {
      document.removeEventListener("visibilitychange", handleVisibility);
    };
  }, []);

  // Immediately register SW, optionally request Notification permission, and subscribe to SW call/chat actions
  useEffect(() => {
    void registerMirsalServiceWorker();
    if (notificationPrefsRef.current.notificationsEnabled) {
      void requestImmediateNotificationPermission(() => {
        if (verifiedUidRef.current) {
          void syncWebPushSubscription(verifiedUidRef.current);
        }
      });
    }

    const initialAction = consumeUrlCallAction();
    if (initialAction) {
      void processNotificationCallAction(initialAction);
    }

    const initialOpenChatId = consumeUrlOpenChatId();
    if (initialOpenChatId) {
      setActiveChatId(initialOpenChatId);
      setMobileView("chat");
      setLastReadByChat((prev) => ({
        ...prev,
        [initialOpenChatId]: Date.now(),
      }));
    }

    const unsubscribeSw = subscribeToServiceWorkerCallActions((action) => {
      void processNotificationCallAction(action);
    });
    const unsubscribeOpenChat = subscribeToServiceWorkerOpenChat((chatId) => {
      setActiveChatId(chatId);
      setMobileView("chat");
      setLastReadByChat((prev) => ({
        ...prev,
        [chatId]: Date.now(),
      }));
    });

    return () => {
      unsubscribeSw();
      unsubscribeOpenChat();
    };
  }, [processNotificationCallAction]);

  // Sync Web Push subscription & run any deferred call notification action once signed in
  useEffect(() => {
    if (!verifiedUid) return;
    if (notificationPrefsRef.current.notificationsEnabled) {
      void syncWebPushSubscription(verifiedUid);
    }
    if (pendingCallActionRef.current) {
      const queued = pendingCallActionRef.current;
      pendingCallActionRef.current = null;
      void processNotificationCallAction(queued);
    }
  }, [verifiedUid, processNotificationCallAction]);

  useEffect(() => {
    applyThemeClass(theme);
    saveTheme(theme);
  }, [theme]);

  useEffect(() => {
    applyTypographyClasses(typographyPrefs);
    saveTypographyPrefs(typographyPrefs);
  }, [typographyPrefs]);

  useEffect(() => {
    saveSoundPrefs(soundPrefs);
  }, [soundPrefs]);

  useEffect(() => {
    saveNotificationPrefs(notificationPrefs);
  }, [notificationPrefs]);

  useEffect(() => {
    saveLastReadByChat(lastReadByChat);
  }, [lastReadByChat]);

  useEffect(() => {
    saveAiPinned(aiPinned);
  }, [aiPinned]);

  useEffect(() => {
    saveChatWallpaper(wallpaperId);
  }, [wallpaperId]);

  useEffect(() => {
    saveUserProfile(user);
  }, [user]);

  const finalizeVerifiedSession = useCallback(
    async (
      fbUser: User,
      override?: { name?: string; avatar?: string; countryCode?: string }
    ) => {
      const pending = loadPendingSignupProfile();
      const matchedPending = pending && pending.uid === fbUser.uid ? pending : null;
      const existingLocal = userRef.current;
      const sameLocal = existingLocal?.uid === fbUser.uid ? existingLocal : null;

      let cloudExisting: PeerUserProfile | null = null;
      if (!sameLocal) {
        const fetchedMap = await fetchUsersByUids([fbUser.uid]).catch(() => ({} as Record<string, PeerUserProfile>));
        cloudExisting = fetchedMap[fbUser.uid] || null;
      }

      const resolvedName =
        override?.name ||
        matchedPending?.name ||
        cloudExisting?.displayName ||
        sameLocal?.name ||
        fbUser.displayName ||
        "مستخدم مرسال";

      const resolvedAvatar = normalizeUserAvatar(
        override?.avatar ||
          matchedPending?.avatar ||
          cloudExisting?.photoURL ||
          cloudExisting?.avatar ||
          sameLocal?.photoURL ||
          sameLocal?.avatar ||
          DEFAULT_USER_AVATAR
      );

      const resolvedCountry =
        override?.countryCode ||
        matchedPending?.countryCode ||
        cloudExisting?.countryCode ||
        sameLocal?.countryCode;

      const resolvedJoinedAt =
        extractJoinMonthYearAr(cloudExisting?.joinedAt) ||
        extractJoinMonthYearAr(sameLocal?.joinedAt) ||
        extractJoinMonthYearAr(fbUser.metadata?.creationTime) ||
        DEFAULT_JOIN_MONTH_YEAR_AR;

      const resolvedIsProfileLocked =
        cloudExisting?.isProfileLocked ?? sameLocal?.isProfileLocked ?? false;
      const resolvedSessionVersion =
        cloudExisting?.sessionVersion ?? sameLocal?.sessionVersion ?? 1;
      const resolvedCoverPhoto =
        cloudExisting?.coverPhoto ?? sameLocal?.coverPhoto ?? "cover:emerald";
      const resolvedBio = cloudExisting?.bio ?? sameLocal?.bio ?? "";

      const devicePublicKey = await ensureDeviceE2eeKeys(fbUser.uid).catch(
        () => null
      );
      const resolvedPublicKey =
        devicePublicKey || cloudExisting?.publicKey || sameLocal?.publicKey;

      saveLocalSessionVersion(fbUser.uid, resolvedSessionVersion);

      const profile: UserProfile = {
        uid: fbUser.uid,
        name: resolvedName,
        avatar: resolvedAvatar,
        photoURL: resolvedAvatar,
        coverPhoto: resolvedCoverPhoto,
        bio: resolvedBio,
        publicKey: resolvedPublicKey,
        sessionVersion: resolvedSessionVersion,
        countryCode: resolvedCountry,
        age: cloudExisting?.age ?? sameLocal?.age ?? null,
        city: cloudExisting?.city ?? sameLocal?.city,
        maritalStatus:
          cloudExisting?.maritalStatus || sameLocal?.maritalStatus || "unspecified",
        workOrStudy: cloudExisting?.workOrStudy ?? sameLocal?.workOrStudy,
        joinedAt: resolvedJoinedAt,
        isProfileLocked: resolvedIsProfileLocked,
        showAgeCity: cloudExisting?.showAgeCity ?? sameLocal?.showAgeCity ?? true,
        showPersonalInfo:
          cloudExisting?.showPersonalInfo ?? sameLocal?.showPersonalInfo ?? true,
        showFriends: cloudExisting?.showFriends ?? sameLocal?.showFriends ?? true,
        showLastSeen: cloudExisting?.showLastSeen ?? sameLocal?.showLastSeen ?? true,
        friends: cloudExisting?.friends || sameLocal?.friends || [],
        pinnedChats: sameLocal?.pinnedChats || [],
        blockedUsers: cloudExisting?.blockedUsers || sameLocal?.blockedUsers || [],
        blockedUntil: cloudExisting?.blockedUntil || sameLocal?.blockedUntil || {},
      };

      setSecurityLogoutNotice(null);
      setUser(profile);
      if (
        hasAppLockPin(fbUser.uid) &&
        unlockedUidRef.current !== fbUser.uid
      ) {
        setIsAppLocked(true);
      }
      setPendingVerification(null);
      savePendingSignupProfile(null);
      setAiConversations((prev) =>
        prev.length > 0 ? prev : createAiDefaultConversations(resolvedName)
      );

      const emailHash = fbUser.email ? await sha256Hex(fbUser.email) : "";

      await upsertCloudUserProfile({
        uid: fbUser.uid,
        displayName: resolvedName,
        avatar: resolvedAvatar,
        coverPhoto: resolvedCoverPhoto,
        bio: resolvedBio,
        publicKey: resolvedPublicKey,
        sessionVersion: resolvedSessionVersion,
        countryCode: resolvedCountry,
        emailHash: emailHash || undefined,
        age: profile.age,
        city: profile.city,
        maritalStatus: profile.maritalStatus,
        workOrStudy: profile.workOrStudy,
        joinedAt: resolvedJoinedAt,
        isProfileLocked: resolvedIsProfileLocked,
        showAgeCity: profile.showAgeCity,
        showPersonalInfo: profile.showPersonalInfo,
        showFriends: profile.showFriends,
        showLastSeen: profile.showLastSeen,
        isOnline: true,
      }).catch(() => {});
    },
    []
  );

  // Listen to Firebase Auth state
  useEffect(() => {
    const unsubscribe = subscribeToAuth((fbUser) => {
      setFirebaseUser(fbUser);
      setAuthReady(true);

      if (!fbUser) {
        setUser(null);
        setPendingVerification(null);
        setCloudChats([]);
        setOptimisticChats([]);
        setPinnedChatIds([]);
        setMyFriends([]);
        setPeerProfilesByUid({});
        setMessagesByChat({});
        setIncomingCallByChat({});
        setIncomingScreenShareByChat({});
        setWatchSessionByChat({});
        initializedMsgChatsRef.current.clear();
        lastSeenMsgIdByChatRef.current = {};
        return;
      }

      if (!fbUser.emailVerified) {
        const pending = loadPendingSignupProfile();
        const fallbackName =
          pending?.uid === fbUser.uid
            ? pending.name
            : fbUser.displayName || "مستخدم مرسال";
        const fallbackAvatar = normalizeUserAvatar(
          pending?.uid === fbUser.uid ? pending.avatar : DEFAULT_USER_AVATAR
        );

        setPendingVerification({
          uid: fbUser.uid,
          name: fallbackName,
          email: fbUser.email || pending?.email || "",
          avatar: fallbackAvatar,
          countryCode:
            pending?.uid === fbUser.uid ? pending.countryCode : undefined,
        });
        setUser(null);
        return;
      }

      void finalizeVerifiedSession(fbUser);
    });

    return () => unsubscribe();
  }, [finalizeVerifiedSession]);

  // Sync own Firestore profile, pinned chats, friends, privacy, and timed block expiry
  useEffect(() => {
    if (!firebaseUser || !firebaseUser.emailVerified) return;

    const unsubscribe = subscribeToUserProfile(
      firebaseUser.uid,
      (cloudProf) => {
        if (!cloudProf) return;

        const remoteSessionVersion =
          typeof cloudProf.sessionVersion === "number" &&
          Number.isFinite(cloudProf.sessionVersion)
            ? Math.max(1, Math.round(cloudProf.sessionVersion))
            : 1;
        const localSessionVersion = loadLocalSessionVersion(firebaseUser.uid);
        if (remoteSessionVersion > localSessionVersion) {
          clearLocalSessionVersion(firebaseUser.uid);
          setSecurityLogoutNotice(
            "تم تسجيل الخروج من هذا الجهاز لأن الحساب أنهى جميع الجلسات من جهاز آخر."
          );
          void signOutFirebase().catch(() => {});
          return;
        }

        const rawBlocked = cloudProf.blockedUsers || [];
        const rawUntil = cloudProf.blockedUntil || {};
        const hasExpired = rawBlocked.some((bUid) => {
          const until = rawUntil[bUid];
          return typeof until === "number" && until > 0 && until <= Date.now();
        });

        if (hasExpired) {
          void cleanupExpiredBlocks(firebaseUser.uid, rawBlocked, rawUntil);
        }

        setUser((prev) => {
          const normalizedAvatar = normalizeUserAvatar(
            cloudProf.photoURL || cloudProf.avatar
          );
          const resolvedJoinedAt =
            extractJoinMonthYearAr(cloudProf.joinedAt) ||
            extractJoinMonthYearAr(firebaseUser.metadata?.creationTime) ||
            extractJoinMonthYearAr(prev?.joinedAt) ||
            DEFAULT_JOIN_MONTH_YEAR_AR;
          return {
            uid: cloudProf.uid,
            name: cloudProf.displayName,
            avatar: normalizedAvatar,
            photoURL: normalizedAvatar,
            coverPhoto: cloudProf.coverPhoto ?? prev?.coverPhoto ?? "cover:emerald",
            bio: cloudProf.bio ?? prev?.bio ?? "",
            publicKey: cloudProf.publicKey ?? prev?.publicKey,
            sessionVersion: remoteSessionVersion,
            countryCode: cloudProf.countryCode,
            age: cloudProf.age ?? null,
            city: cloudProf.city,
            maritalStatus: cloudProf.maritalStatus || "unspecified",
            workOrStudy: cloudProf.workOrStudy,
            joinedAt: resolvedJoinedAt,
            isProfileLocked: Boolean(cloudProf.isProfileLocked),
            showAgeCity: cloudProf.showAgeCity ?? true,
            showPersonalInfo: cloudProf.showPersonalInfo ?? true,
            showFriends: cloudProf.showFriends ?? true,
            showLastSeen: cloudProf.showLastSeen ?? true,
            friends: cloudProf.friends || [],
            pinnedChats: prev?.pinnedChats || [],
            blockedUsers: rawBlocked,
            blockedUntil: rawUntil,
          };
        });
      },
      undefined,
      (pinned) => {
        setPinnedChatIds(pinned);
        setUser((prev) => (prev ? { ...prev, pinnedChats: pinned } : prev));
      }
    );

    return () => unsubscribe();
  }, [firebaseUser]);

  // Periodic sweep to clear expired temporary blocks even while idle
  useEffect(() => {
    if (!firebaseUser || !firebaseUser.emailVerified || !user) return;
    const blocked = user.blockedUsers || [];
    const untilMap = user.blockedUntil || {};
    const hasTimed = blocked.some(
      (bUid) => typeof untilMap[bUid] === "number" && untilMap[bUid] > 0
    );
    if (!hasTimed) return;

    const checkExpiry = () => {
      const latest = userRef.current;
      if (!latest) return;
      const bList = latest.blockedUsers || [];
      const uMap = latest.blockedUntil || {};
      const expired = bList.some(
        (bUid) => typeof uMap[bUid] === "number" && uMap[bUid] > 0 && uMap[bUid] <= Date.now()
      );
      if (expired) {
        void cleanupExpiredBlocks(firebaseUser.uid, bList, uMap);
      }
    };

    const timer = setInterval(checkExpiry, 60_000);
    return () => clearInterval(timer);
  }, [firebaseUser, user?.blockedUsers?.join(","), JSON.stringify(user?.blockedUntil || {})]);

  // Online / Last Seen presence management
  useEffect(() => {
    if (!firebaseUser || !firebaseUser.emailVerified || !user) return;

    const pushPresence = (online: boolean) => {
      void updateUserPresence({
        uid: firebaseUser.uid,
        displayName: user.name,
        avatar: user.avatar,
        countryCode: user.countryCode,
        isOnline: online,
      }).catch(() => {});
    };

    pushPresence(true);

    const heartbeat = setInterval(() => {
      if (document.visibilityState === "visible") {
        pushPresence(true);
      }
    }, 120000);

    const handleVisibility = () => {
      pushPresence(document.visibilityState === "visible");
    };

    const handlePageHide = () => {
      pushPresence(false);
    };

    document.addEventListener("visibilitychange", handleVisibility);
    window.addEventListener("pagehide", handlePageHide);

    return () => {
      clearInterval(heartbeat);
      document.removeEventListener("visibilitychange", handleVisibility);
      window.removeEventListener("pagehide", handlePageHide);
    };
  }, [firebaseUser, user?.name, user?.avatar, user?.countryCode]);

  // Subscribe to user's direct & group cloud chats
  useEffect(() => {
    if (!firebaseUser || !firebaseUser.emailVerified) {
      setCloudChats([]);
      return;
    }

    const unsubscribe = subscribeToUserDirectChats(
      firebaseUser.uid,
      (chats) => {
        setCloudChats(chats);
      },
      (err) => {
        console.error("Cloud chats subscription error:", err);
      }
    );

    return () => unsubscribe();
  }, [firebaseUser]);

  const combinedCloudChats = useMemo(() => {
    const cloudIds = new Set(cloudChats.map((c) => c.id));
    const pending = optimisticChats.filter((c) => !cloudIds.has(c.id));
    return [...pending, ...cloudChats];
  }, [cloudChats, optimisticChats]);

  // Union of saved friends and existing 1-on-1 direct chat partners
  const myFriendUids = useMemo(() => {
    const set = new Set<string>(user?.friends || []);
    combinedCloudChats.forEach((c) => {
      if (c.type === "direct" && c.peerUid) {
        set.add(c.peerUid);
      }
    });
    if (firebaseUser?.uid) {
      set.delete(firebaseUser.uid);
    }
    return Array.from(set).sort();
  }, [user?.friends, combinedCloudChats, firebaseUser?.uid]);

  const refreshFriends = useCallback(async () => {
    if (!firebaseUser || !firebaseUser.emailVerified) {
      setMyFriends([]);
      return;
    }
    setLoadingFriends(true);
    try {
      const list = await listMyFriends(firebaseUser.uid, myFriendUids);
      setMyFriends(list);
      setPeerProfilesByUid((prev) => {
        const next = { ...prev };
        list.forEach((p) => {
          next[p.uid] = p;
        });
        return next;
      });
    } catch {
      // ignore non-fatal refresh error
    } finally {
      setLoadingFriends(false);
    }
  }, [firebaseUser, myFriendUids]);

  useEffect(() => {
    if (!firebaseUser || !firebaseUser.emailVerified) return;
    void refreshFriends();
  }, [firebaseUser, refreshFriends]);

  const peerUidsKey = useMemo(() => {
    const uids = Array.from(
      new Set(
        combinedCloudChats
          .map((c) => c.peerUid)
          .filter((id): id is string => Boolean(id))
      )
    ).sort();
    return uids.join(",");
  }, [combinedCloudChats]);

  // Subscribe to direct peer profiles for live Online / Last Seen / Privacy updates
  useEffect(() => {
    if (!firebaseUser || !firebaseUser.emailVerified || !peerUidsKey) return;
    const uids = peerUidsKey.split(",").filter(Boolean);
    const unsubscribers = uids.map((peerUid) =>
      subscribeToUserProfile(peerUid, (profile) => {
        if (!profile) return;
        setPeerProfilesByUid((prev) => ({
          ...prev,
          [peerUid]: profile,
        }));
      })
    );
    return () => {
      unsubscribers.forEach((unsub) => unsub());
    };
  }, [firebaseUser, peerUidsKey]);

  const chatIdsKey = useMemo(() => {
    return combinedCloudChats
      .map((c) => `${c.id}:${c.type}`)
      .sort()
      .join(",");
  }, [combinedCloudChats]);

  // Subscribe to messages, watch sessions, and (for direct chats ONLY) calls & screen shares
  useEffect(() => {
    if (!firebaseUser || !firebaseUser.emailVerified || !chatIdsKey) return;
    const entries = chatIdsKey
      .split(",")
      .filter(Boolean)
      .map((token) => {
        const [id, type] = token.split(":");
        return { id, type };
      });
    const unsubscribers: Array<() => void> = [];

    entries.forEach(({ id: chatId, type: chatType }) => {
      const chatObj = combinedCloudChats.find((c) => c.id === chatId);
      const chatTitle = chatObj?.title || "محادثة";

      unsubscribers.push(
        subscribeToChatMessages(
          chatId,
          firebaseUser.uid,
          (msgs) => {
            const newest = msgs[msgs.length - 1];
            if (!initializedMsgChatsRef.current.has(chatId)) {
              initializedMsgChatsRef.current.add(chatId);
              if (newest) {
                lastSeenMsgIdByChatRef.current[chatId] = newest.id;
              }
            } else if (newest && newest.id !== lastSeenMsgIdByChatRef.current[chatId]) {
              lastSeenMsgIdByChatRef.current[chatId] = newest.id;
              const u = userRef.current;
              const senderBlocked = Boolean(
                u &&
                  isBlockActive(
                    u.blockedUsers,
                    u.blockedUntil,
                    newest.senderId
                  )
              );
              if (
                newest.senderId !== "me" &&
                !senderBlocked &&
                newest.messageType !== "call"
              ) {
                playMessageTone();
                const isMobileListOpen =
                  typeof window !== "undefined" &&
                  window.innerWidth < 768 &&
                  mobileViewRef.current === "list";
                const isInBackgroundOrDifferentChat =
                  (typeof document !== "undefined" && document.hidden) ||
                  activeChatIdRef.current !== chatId ||
                  isMobileListOpen;
                if (
                  notificationPrefsRef.current.notificationsEnabled &&
                  isInBackgroundOrDifferentChat
                ) {
                  const previewBody = newest.text
                    ? newest.text
                    : newest.audioDataUrl
                    ? "🎤 رسالة صوتية"
                    : newest.imageDataUrl
                    ? "📷 صورة"
                    : newest.videoDataUrl
                    ? "🎬 فيديو"
                    : "رسالة جديدة";
                  void showIncomingMessageNotification({
                    chatId,
                    senderName: newest.senderName || chatTitle,
                    text: previewBody,
                    isGroup: chatObj?.type === "group",
                    chatTitle,
                    vibrationEnabled:
                      soundPrefsRef.current.callVibration !== false,
                    badgeCount: totalUnreadCountRef.current + 1,
                  });
                }
              }
            }

            setMessagesByChat((prev) => ({
              ...prev,
              [chatId]: msgs,
            }));
          },
          (err) => {
            console.error(`Messages error (${chatId}):`, err);
          }
        )
      );

      unsubscribers.push(
        subscribeToWatchSession(
          chatId,
          (watchData) => {
            setWatchSessionByChat((prev) => ({
              ...prev,
              [chatId]: watchData,
            }));
          },
          (err) => {
            console.error(`Watch session listener error (${chatId}):`, err);
          }
        )
      );

      if (chatType === "direct") {
        unsubscribers.push(
          subscribeToChatRingingCalls(
            chatId,
            chatTitle,
            firebaseUser.uid,
            (ringingCall) => {
              setIncomingCallByChat((prev) => ({
                ...prev,
                [chatId]: ringingCall,
              }));
            },
            (err) => {
              console.error(`Calls listener error (${chatId}):`, err);
            }
          )
        );

        unsubscribers.push(
          subscribeToChatScreenShares(
            chatId,
            firebaseUser.uid,
            (shareOffer) => {
              setIncomingScreenShareByChat((prev) => ({
                ...prev,
                [chatId]: shareOffer,
              }));
            },
            (err) => {
              console.error(`Screen share listener error (${chatId}):`, err);
            }
          )
        );
      }
    });

    return () => {
      unsubscribers.forEach((unsub) => unsub());
    };
  }, [firebaseUser, chatIdsKey]);

  const incomingCall = useMemo(() => {
    const list = Object.values(incomingCallByChat).filter(
      (call): call is ChatCallSignal =>
        Boolean(call) &&
        !isBlockActive(
          user?.blockedUsers,
          user?.blockedUntil,
          call!.callerId
        )
    );
    return list[0] || null;
  }, [incomingCallByChat, user?.blockedUsers, user?.blockedUntil]);

  // Display / auto-dismiss high-priority incoming call notification & ringtone
  useEffect(() => {
    if (incomingCall && !webrtc.activeCall) {
      startRingtone(soundPrefs.ringtone, soundPrefs.callVibration !== false);
      if (
        notificationPrefs.notificationsEnabled &&
        shownCallNotificationIdRef.current !== incomingCall.callId
      ) {
        shownCallNotificationIdRef.current = incomingCall.callId;
        void showIncomingCallNotification(
          incomingCall,
          soundPrefs.callVibration !== false
        );
      } else if (!notificationPrefs.notificationsEnabled && shownCallNotificationIdRef.current) {
        const prevCallId = shownCallNotificationIdRef.current;
        shownCallNotificationIdRef.current = null;
        void closeCallNotifications(prevCallId);
      }
      return () => {
        stopRingtone();
      };
    }

    stopRingtone();
    if (shownCallNotificationIdRef.current) {
      const prevCallId = shownCallNotificationIdRef.current;
      shownCallNotificationIdRef.current = null;
      void closeCallNotifications(prevCallId);
    }
  }, [
    incomingCall,
    webrtc.activeCall,
    soundPrefs.ringtone,
    soundPrefs.callVibration,
    soundPrefs.muted,
    soundPrefs.volume,
    notificationPrefs.notificationsEnabled,
  ]);

  // Automatically sweep and delete expired disappearing messages at exact next expiration (no polling loop)
  const nextMessageExpiryMs = useMemo(() => {
    let earliest: number | null = null;
    Object.values(messagesByChat).forEach((list) => {
      list.forEach((m) => {
        if (typeof m.expiresAt === "number" && m.expiresAt > 0) {
          if (earliest === null || m.expiresAt < earliest) {
            earliest = m.expiresAt;
          }
        }
      });
    });
    aiConversations.forEach((c) => {
      c.messages.forEach((m) => {
        if (typeof m.expiresAt === "number" && m.expiresAt > 0) {
          if (earliest === null || m.expiresAt < earliest) {
            earliest = m.expiresAt;
          }
        }
      });
    });
    return earliest;
  }, [messagesByChat, aiConversations]);

  const hasTimedMessages = nextMessageExpiryMs !== null;

  useEffect(() => {
    if (nextMessageExpiryMs === null) return;
    const now = Date.now();
    if (nextMessageExpiryMs <= now) {
      setNowTick(now);
      return;
    }
    const delayMs = Math.min(2_147_483_647, Math.max(250, nextMessageExpiryMs - now));
    const timer = setTimeout(() => {
      setNowTick(Date.now());
    }, delayMs);
    return () => clearTimeout(timer);
  }, [nextMessageExpiryMs]);

  useEffect(() => {
    if (!hasTimedMessages) return;

    // Delete expired cloud messages automatically from Firestore
    if (firebaseUser && firebaseUser.emailVerified) {
      Object.entries(messagesByChat).forEach(([chatId, msgs]) => {
        const expiredIds = msgs
          .filter(
            (m) =>
              typeof m.expiresAt === "number" &&
              m.expiresAt <= nowTick &&
              !deletedExpiredIdsRef.current.has(`${chatId}:${m.id}`)
          )
          .map((m) => m.id);
        if (expiredIds.length > 0) {
          expiredIds.forEach((msgId) =>
            deletedExpiredIdsRef.current.add(`${chatId}:${msgId}`)
          );
          void deleteExpiredChatMessages(chatId, expiredIds);
        }
      });
    }

    // Remove expired AI chat messages cleanly
    const aiNeedsPrune = aiConversations.some((c) =>
      c.messages.some(
        (m) => typeof m.expiresAt === "number" && m.expiresAt <= nowTick
      )
    );
    if (aiNeedsPrune) {
      setAiConversations((prev) =>
        prev.map((c) => ({
          ...c,
          messages: c.messages.filter(
            (m) => typeof m.expiresAt !== "number" || m.expiresAt > nowTick
          ),
        }))
      );
    }
  }, [hasTimedMessages, nowTick, messagesByChat, aiConversations, firebaseUser]);

  const conversations = useMemo(() => {
    const pinnedSet = new Set(pinnedChatIds);
    const enrichedCloud = combinedCloudChats.map((chat) => {
      const allMsgs = messagesByChat[chat.id] || [];
      const visibleMsgs = allMsgs.filter((m) => {
        if (chat.clearedAt && m.timestamp <= chat.clearedAt) return false;
        if (typeof m.expiresAt === "number" && m.expiresAt <= nowTick) {
          return false;
        }
        return true;
      });

      const uid = firebaseUser?.uid;
      const lastReadTs = lastReadByChat[chat.id] || 0;
      const unreadCount = visibleMsgs.filter((m) => {
        if (m.senderId === "me") return false;
        if (uid && m.readBy && typeof m.readBy[uid] === "number") return false;
        return m.timestamp > lastReadTs;
      }).length;

      if (chat.type === "group") {
        return {
          ...chat,
          pinned: pinnedSet.has(chat.id),
          unreadCount,
          messages: visibleMsgs,
        };
      }

      const peer = chat.peerUid ? peerProfilesByUid[chat.peerUid] : undefined;
      const peerApprovedMe = Boolean(
        firebaseUser?.uid && peer?.friends?.includes(firebaseUser.uid)
      );
      const peerLockedForMe = Boolean(peer?.isProfileLocked) && !peerApprovedMe;
      const peerShowLastSeen = peer ? peer.showLastSeen !== false : true;
      const peerShowPersonalInfo = peer
        ? !peerLockedForMe && peer.showPersonalInfo !== false
        : true;
      return {
        ...chat,
        title: peer?.displayName || chat.title,
        avatar: peer?.photoURL || peer?.avatar || chat.avatar,
        peerCountryCode: peerShowPersonalInfo
          ? peer?.countryCode || chat.peerCountryCode
          : undefined,
        peerOnline: peerShowLastSeen ? peer?.isOnline ?? chat.peerOnline ?? false : false,
        peerLastSeen: peerShowLastSeen ? peer?.lastSeen ?? chat.peerLastSeen ?? null : null,
        peerShowLastSeen,
        pinned: pinnedSet.has(chat.id),
        unreadCount,
        messages: visibleMsgs,
      };
    });

    const enrichedAi = aiConversations.map((c) => ({
      ...c,
      pinned: aiPinned,
      messages: c.messages.filter(
        (m) => typeof m.expiresAt !== "number" || m.expiresAt > nowTick
      ),
    }));

    return [...enrichedAi, ...enrichedCloud];
  }, [
    aiConversations,
    aiPinned,
    combinedCloudChats,
    peerProfilesByUid,
    messagesByChat,
    pinnedChatIds,
    lastReadByChat,
    nowTick,
    firebaseUser?.uid,
  ]);

  const totalUnreadCount = useMemo(
    () =>
      conversations.reduce(
        (sum, c) => sum + (c.type !== "ai" ? c.unreadCount || 0 : 0),
        0
      ),
    [conversations]
  );
  totalUnreadCountRef.current = totalUnreadCount;

  useEffect(() => {
    saveCustomChatWallpaper(customWallpaper);
  }, [customWallpaper]);

  useEffect(() => {
    if (!user || !firebaseUser?.emailVerified) {
      void updateAppIconBadge(0);
      return;
    }
    void updateAppIconBadge(totalUnreadCount);
  }, [totalUnreadCount, user, firebaseUser]);

  const combinedTypingChatIds = useMemo(() => {
    const merged: Record<string, boolean> = { ...aiTypingChatIds };
    combinedCloudChats.forEach((c) => {
      if (c.typingUids && c.typingUids.length > 0) {
        merged[c.id] = true;
      }
    });
    return merged;
  }, [aiTypingChatIds, combinedCloudChats]);

  const activeConversation =
    conversations.find((c) => c.id === activeChatId) || null;

  // Subscribe to saved Watch Together links history for the currently active chat
  useEffect(() => {
    if (
      !firebaseUser ||
      !firebaseUser.emailVerified ||
      !activeConversation ||
      activeConversation.type === "ai"
    ) {
      return;
    }
    const targetChatId = activeConversation.id;
    return subscribeToWatchHistory(
      targetChatId,
      (items) => {
        setWatchHistoryByChat((prev) => ({
          ...prev,
          [targetChatId]: items,
        }));
      },
      (err) => {
        console.error(`Watch history error (${targetChatId}):`, err);
      }
    );
  }, [firebaseUser, activeConversation?.id, activeConversation?.type]);

  // Automatically mark visible incoming messages as read in Firestore (updates gray -> blue ✓✓ & readAt)
  useEffect(() => {
    const uid = firebaseUser?.uid;
    if (
      !uid ||
      !firebaseUser.emailVerified ||
      !activeConversation ||
      activeConversation.type === "ai" ||
      !isWindowVisible
    ) {
      return;
    }

    const isChatCurrentlyOnScreen =
      typeof window === "undefined" ||
      window.innerWidth >= 768 ||
      mobileView === "chat";
    if (!isChatCurrentlyOnScreen) return;

    const chatId = activeConversation.id;
    const toMark = activeConversation.messages.filter(
      (m) =>
        m.senderId !== "me" &&
        !(m.readBy && typeof m.readBy[uid] === "number") &&
        !markingReadIdsRef.current.has(`${chatId}:${m.id}`)
    );

    if (toMark.length > 0) {
      toMark.forEach((m) => markingReadIdsRef.current.add(`${chatId}:${m.id}`));
      setLastReadByChat((prev) => ({
        ...prev,
        [chatId]: Math.max(prev[chatId] || 0, Date.now()),
      }));
      void markChatMessagesAsRead(
        chatId,
        uid,
        toMark.map((m) => ({ id: m.id, hasReadAt: Boolean(m.readAt) }))
      );
    }
  }, [
    firebaseUser,
    activeConversation,
    isWindowVisible,
    mobileView,
  ]);

  const groupInfoChat = useMemo(
    () =>
      groupInfoChatId
        ? conversations.find(
            (c) => c.id === groupInfoChatId && c.type === "group"
          ) || null
        : null,
    [conversations, groupInfoChatId]
  );

  const isActivePeerBlockedByMe = Boolean(
    activeConversation?.type === "direct" &&
      activeConversation.peerUid &&
      isBlockActive(
        user?.blockedUsers,
        user?.blockedUntil,
        activeConversation.peerUid
      )
  );

  const activePeerBlockedUntilMs =
    activeConversation?.peerUid && user?.blockedUntil
      ? user.blockedUntil[activeConversation.peerUid]
      : undefined;

  const isActivePeerBlockingMe = Boolean(
    activeConversation?.type === "direct" &&
      activeConversation.peerUid &&
      firebaseUser?.uid &&
      isBlockActive(
        peerProfilesByUid[activeConversation.peerUid]?.blockedUsers,
        peerProfilesByUid[activeConversation.peerUid]?.blockedUntil,
        firebaseUser.uid
      )
  );

  const activeIncomingScreenShareOffer = useMemo(() => {
    if (!activeConversation || activeConversation.type !== "direct") return null;
    const offer = incomingScreenShareByChat[activeConversation.id] || null;
    if (!offer) return null;
    if (
      isBlockActive(user?.blockedUsers, user?.blockedUntil, offer.sharerId)
    ) {
      return null;
    }
    return offer;
  }, [
    activeConversation,
    incomingScreenShareByChat,
    user?.blockedUsers,
    user?.blockedUntil,
  ]);

  const activeWatchSession = activeConversation
    ? watchSessionByChat[activeConversation.id] || null
    : null;

  const isActiveWatchHost = Boolean(
    activeWatchSession &&
      verifiedUid &&
      (activeWatchSession.hostId || activeWatchSession.startedByUid) ===
        verifiedUid
  );

  const watchPartyMic = useWatchPartyMic({
    uid: verifiedUid,
    userName: resolvedDisplayName,
    chatId: activeConversation?.id || null,
    isDirectChat: activeConversation?.type === "direct",
    isWatchActive: Boolean(
      activeWatchSession &&
        activeWatchSession.isActive &&
        !(
          screenShare.activeShare &&
          activeConversation &&
          screenShare.activeShare.chatId === activeConversation.id
        )
    ),
    isWatchHost: isActiveWatchHost,
    guestMicAllowed: activeWatchSession?.guestMicAllowed !== false,
    isChatBlocked: isActivePeerBlockedByMe || isActivePeerBlockingMe,
  });

  // Auto-join incoming screen share inside the open 1-on-1 direct chat
  useEffect(() => {
    if (
      !activeIncomingScreenShareOffer ||
      !activeConversation ||
      activeConversation.type !== "direct" ||
      isActivePeerBlockedByMe ||
      isActivePeerBlockingMe ||
      screenShare.activeShare
    ) {
      return;
    }

    void screenShare.joinIncomingScreenShare(activeIncomingScreenShareOffer);
  }, [
    activeIncomingScreenShareOffer,
    activeConversation,
    isActivePeerBlockedByMe,
    isActivePeerBlockingMe,
    screenShare.activeShare,
    screenShare.joinIncomingScreenShare,
  ]);

  const handleToggleTheme = useCallback(() => {
    setTheme((prev) => (prev === "dark" ? "light" : "dark"));
  }, []);

  const handleRegister = async (params: {
    name: string;
    email: string;
    pin: string;
    avatar: string;
    countryCode: string;
  }) => {
    const createdUser = await registerWithEmailPin({
      name: params.name,
      email: params.email,
      pin: params.pin,
    });
    const pending: PendingSignupProfile = {
      uid: createdUser.uid,
      name: params.name,
      email: createdUser.email || params.email,
      avatar: params.avatar,
      countryCode: normalizeCountryCode(params.countryCode),
    };
    savePendingSignupProfile(pending);
    setPendingVerification(pending);
  };

  const handleSignIn = async (params: { email: string; pin: string }) => {
    const signedUser = await signInWithEmailPin(params);
    if (!signedUser.emailVerified) {
      const pending: PendingSignupProfile = {
        uid: signedUser.uid,
        name: signedUser.displayName || "مستخدم مرسال",
        email: signedUser.email || params.email,
        avatar: DEFAULT_USER_AVATAR,
      };
      savePendingSignupProfile(pending);
      setPendingVerification(pending);
      return;
    }
    await finalizeVerifiedSession(signedUser);
  };

  const handleCheckVerified = async (): Promise<boolean> => {
    const { verified, user: refreshed } = await verifyEmailStatus();
    if (verified && refreshed) {
      await finalizeVerifiedSession(refreshed);
      return true;
    }
    return false;
  };

  const handleCancelVerification = async () => {
    savePendingSignupProfile(null);
    setPendingVerification(null);
    await signOutFirebase().catch(() => {});
  };

  const handleSelectChat = useCallback((chatId: string) => {
    setActiveChatId(chatId);
    setMobileView("chat");
    setLastReadByChat((prev) => ({
      ...prev,
      [chatId]: Date.now(),
    }));
  }, []);

  const handleSearchExactUser = useCallback(
    async (queryText: string) => {
      if (!firebaseUser) return [];
      return findUsersByExactNameOrEmail(firebaseUser.uid, queryText);
    },
    [firebaseUser]
  );

  const handleAddFriend = useCallback(
    async (friendUid: string) => {
      if (!firebaseUser || !friendUid || friendUid === firebaseUser.uid) return;
      await addFriendCloud(firebaseUser.uid, friendUid);
      setUser((prev) => {
        if (!prev) return prev;
        const nextFriends = Array.from(
          new Set([...(prev.friends || []), friendUid])
        );
        return { ...prev, friends: nextFriends };
      });
    },
    [firebaseUser]
  );

  const handleRemoveFriend = useCallback(
    async (friendUid: string) => {
      if (!firebaseUser || !friendUid) return;
      await removeFriendCloud(firebaseUser.uid, friendUid);
      setMyFriends((prev) => prev.filter((f) => f.uid !== friendUid));
      setUser((prev) => {
        if (!prev) return prev;
        return {
          ...prev,
          friends: (prev.friends || []).filter((id) => id !== friendUid),
        };
      });
    },
    [firebaseUser]
  );

  const handleStartDirectChat = async (peer: PeerUserProfile) => {
    if (!firebaseUser || !user) return;
    const chatConv = await openOrCreateDirectChat({
      currentUser: {
        uid: firebaseUser.uid,
        name: user.name,
        avatar: user.avatar,
      },
      peerUser: peer,
    });

    if (!user.friends?.includes(peer.uid)) {
      void addFriendCloud(firebaseUser.uid, peer.uid).catch(() => {});
    }

    setOptimisticChats((prev) => {
      if (prev.some((c) => c.id === chatConv.id)) return prev;
      return [chatConv, ...prev];
    });
    setPeerProfilesByUid((prev) => ({
      ...prev,
      [peer.uid]: peer,
    }));
    setActiveChatId(chatConv.id);
    setMobileView("chat");
    setLastReadByChat((prev) => ({ ...prev, [chatConv.id]: Date.now() }));
  };

  const handleCreateGroup = async (params: {
    groupName: string;
    groupAvatar: string;
    memberUids: string[];
  }) => {
    if (!firebaseUser) return;
    const groupConv = await createGroupChat({
      creatorUid: firebaseUser.uid,
      groupName: params.groupName,
      groupAvatar: params.groupAvatar,
      memberUids: params.memberUids,
    });
    setOptimisticChats((prev) => [groupConv, ...prev]);
    setActiveChatId(groupConv.id);
    setMobileView("chat");
  };

  const handleOpenPeerProfileByUid = async (peerUid: string) => {
    const cached =
      peerProfilesByUid[peerUid] ||
      myFriends.find((f) => f.uid === peerUid) ||
      null;
    if (cached) {
      setProfileModalPeer(cached);
    }
    try {
      const fetched = await fetchUsersByUids([peerUid]);
      if (fetched[peerUid]) {
        setPeerProfilesByUid((prev) => ({
          ...prev,
          [peerUid]: fetched[peerUid],
        }));
        setProfileModalPeer(fetched[peerUid]);
      }
    } catch {
      // keep cached if offline
    }
  };

  const requestGeminiReply = async (
    targetChat: Conversation,
    historyForApi: ChatMessage[],
    currentUserName: string
  ) => {
    const chatId = targetChat.id;
    setAiTypingChatIds((prev) => ({ ...prev, [chatId]: true }));

    const aiMessageId = createId("ai");
    let inserted = false;

    const appendOrUpdateAiMessage = (text: string, isError = false) => {
      setAiConversations((prev) =>
        prev.map((c) => {
          if (c.id !== chatId) return c;
          if (!inserted) {
            inserted = true;
            return {
              ...c,
              messages: [
                ...c.messages,
                {
                  id: aiMessageId,
                  senderId: "ai",
                  senderName: targetChat.title,
                  text,
                  timestamp: Date.now(),
                  status: "read",
                  isError,
                },
              ],
            };
          }
          return {
            ...c,
            messages: c.messages.map((m) =>
              m.id === aiMessageId ? { ...m, text, isError } : m
            ),
          };
        })
      );
    };

    try {
      const payloadMessages = historyForApi
        .filter((m) => !m.isError)
        .map((m) => ({
          role: m.senderId === "me" ? ("user" as const) : ("model" as const),
          text:
            m.text ||
            (m.videoDataUrl && !m.imageDataUrl && !m.audioDataUrl
              ? "أرسلت لك مقطع فيديو."
              : ""),
          imageDataUrl: m.imageDataUrl,
          audioDataUrl: m.audioDataUrl,
        }));

      const response = await fetch("/api/chat/stream", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: payloadMessages,
          systemInstruction: targetChat.systemInstruction,
          userName: currentUserName,
        }),
      });

      if (!response.ok || !response.body) {
        let errMessage = "تعذر الاتصال بالمساعد الذكي حالياً.";
        try {
          const errJson = (await response.json()) as { error?: string };
          if (errJson.error) errMessage = errJson.error;
        } catch {
          // ignore
        }
        appendOrUpdateAiMessage(errMessage, true);
        return;
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder("utf-8");
      let buffer = "";
      let accumulated = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });

        const lines = buffer.split("\n\n");
        buffer = lines.pop() || "";

        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed.startsWith("data:")) continue;
          const jsonStr = trimmed.slice(5).trim();
          if (!jsonStr) continue;

          try {
            const parsed = JSON.parse(jsonStr) as {
              chunk?: string;
              done?: boolean;
              error?: string;
            };
            if (parsed.error) {
              appendOrUpdateAiMessage(parsed.error, true);
              return;
            }
            if (parsed.chunk) {
              accumulated += parsed.chunk;
              appendOrUpdateAiMessage(accumulated, false);
            }
          } catch {
            // ignore
          }
        }
      }

      if (!accumulated.trim() && !inserted) {
        appendOrUpdateAiMessage("عذراً، لم يصل رد من المساعد الذكي.", true);
      }
    } catch {
      appendOrUpdateAiMessage(
        "حدث انقطاع في الشبكة أثناء التواصل مع المساعد الذكي.",
        true
      );
    } finally {
      setAiTypingChatIds((prev) => ({ ...prev, [chatId]: false }));
    }
  };

  const sendMessageToChat = async (
    targetChatId: string,
    payload: ChatSendPayload & {
      audioDataUrl?: string;
      audioDuration?: number;
      viewOnce?: boolean;
    }
  ) => {
    if (!user) return;
    const targetConv = conversations.find((c) => c.id === targetChatId);
    if (!targetConv) return;

    const chatId = targetConv.id;
    const timerSec = targetConv.disappearingTimer || 0;
    const expiresAt =
      timerSec > 0 ? Date.now() + timerSec * 1000 : undefined;

    if (targetConv.type !== "ai") {
      if (!firebaseUser) return;

      let encryptedPayload: { ciphertext: string; iv: string } | null = null;
      if (
        payload.encrypt &&
        targetConv.type === "direct" &&
        payload.text.trim()
      ) {
        const peerPub = targetConv.peerUid
          ? peerProfilesByUid[targetConv.peerUid]?.publicKey
          : undefined;
        if (!peerPub) {
          throw new Error(
            "مفتاح التشفير للطرف الآخر غير متاح بعد — اطلب منه فتح مرسال أولاً."
          );
        }
        encryptedPayload = await encryptSecretMessage(
          firebaseUser.uid,
          peerPub,
          payload.text.trim()
        );
        if (!encryptedPayload) {
          throw new Error("تعذر تشفير الرسالة على هذا المتصفح.");
        }
      }

      await sendDirectChatMessage({
        chatId,
        uid: firebaseUser.uid,
        senderName: user.name,
        text: payload.text,
        isEncrypted: Boolean(encryptedPayload),
        ciphertext: encryptedPayload?.ciphertext,
        iv: encryptedPayload?.iv,
        imageDataUrl: payload.imageDataUrl,
        videoDataUrl: payload.videoDataUrl,
        audioDataUrl: payload.audioDataUrl,
        audioDuration: payload.audioDuration,
        replyTo: payload.replyTo,
        viewOnce: payload.viewOnce,
        expiresAt,
      });
      playMessageSentSound();
      return;
    }

    const msgId = createId("msg");
    const isViewOnce = Boolean(payload.viewOnce && payload.imageDataUrl);
    const outgoing: ChatMessage = {
      id: msgId,
      senderId: "me",
      senderName: user.name,
      text: payload.text,
      imageDataUrl: payload.imageDataUrl,
      videoDataUrl: payload.videoDataUrl,
      audioDataUrl: payload.audioDataUrl,
      audioDuration: payload.audioDuration,
      replyTo: payload.replyTo,
      viewOnce: isViewOnce || undefined,
      viewOnceOpened: isViewOnce ? false : undefined,
      expiresAt,
      timestamp: Date.now(),
      status: "read",
    };

    const updatedMessages = [...targetConv.messages, outgoing];
    setAiConversations((prev) =>
      prev.map((c) =>
        c.id === chatId ? { ...c, messages: updatedMessages } : c
      )
    );
    playMessageSentSound();

    void requestGeminiReply(targetConv, updatedMessages, user.name);
  };

  const handleSendMessage = async (payload: {
    text: string;
    imageDataUrl?: string;
    videoDataUrl?: string;
    audioDataUrl?: string;
    audioDuration?: number;
    replyTo?: MessageReplyRef;
    viewOnce?: boolean;
    encrypt?: boolean;
  }) => {
    if (!activeConversation) return;
    await sendMessageToChat(activeConversation.id, payload);
  };

  const handleSetDisappearingTimer = async (
    chatId: string,
    seconds: DisappearingTimerSeconds
  ) => {
    const conv = conversations.find((c) => c.id === chatId);
    if (!conv) return;
    if (conv.type === "ai") {
      setAiConversations((prev) =>
        prev.map((c) =>
          c.id === chatId ? { ...c, disappearingTimer: seconds } : c
        )
      );
      return;
    }
    setOptimisticChats((prev) =>
      prev.map((c) =>
        c.id === chatId ? { ...c, disappearingTimer: seconds } : c
      )
    );
    await setChatDisappearingTimer(chatId, seconds);
  };

  const handleOpenCreateGroupWithPeer = (peerUid: string) => {
    if (!peerUid) return;
    setPreselectedGroupMemberUids([peerUid]);
    setCreateGroupOpen(true);
  };

  const handleOpenViewOnceImage = (chatId: string, message: ChatMessage) => {
    if (!message.viewOnce || message.viewOnceOpened || !message.imageDataUrl) {
      return;
    }
    setViewOnceLightbox({
      chatId,
      messageId: message.id,
      src: message.imageDataUrl,
    });
  };

  const handleCloseLightbox = () => {
    if (viewOnceLightbox) {
      const { chatId, messageId } = viewOnceLightbox;
      setViewOnceLightbox(null);
      const targetConv = conversations.find((c) => c.id === chatId);
      if (targetConv?.type === "ai") {
        setAiConversations((prev) =>
          prev.map((c) =>
            c.id === chatId
              ? {
                  ...c,
                  messages: c.messages.map((m) =>
                    m.id === messageId
                      ? { ...m, imageDataUrl: "", viewOnceOpened: true }
                      : m
                  ),
                }
              : c
          )
        );
      } else {
        setMessagesByChat((prev) => ({
          ...prev,
          [chatId]: (prev[chatId] || []).map((m) =>
            m.id === messageId
              ? { ...m, imageDataUrl: "", viewOnceOpened: true }
              : m
          ),
        }));
        void markViewOnceImageOpened(chatId, messageId).catch(() => {});
      }
      return;
    }
    setLightboxImage(null);
  };

  const handleReactMessage = async (
    chatId: string,
    messageId: string,
    emoji: string
  ) => {
    const conv = conversations.find((c) => c.id === chatId);
    if (!conv) return;

    if (conv.type === "ai") {
      const reactorKey = firebaseUser?.uid || "me";
      setAiConversations((prev) =>
        prev.map((c) => {
          if (c.id !== chatId) return c;
          return {
            ...c,
            messages: c.messages.map((m) => {
              if (m.id !== messageId) return m;
              const nextReactions = { ...(m.reactions || {}) };
              if (nextReactions[reactorKey] === emoji) {
                delete nextReactions[reactorKey];
              } else {
                nextReactions[reactorKey] = emoji;
              }
              return { ...m, reactions: nextReactions };
            }),
          };
        })
      );
      return;
    }

    if (!firebaseUser) return;
    await toggleMessageReaction(chatId, messageId, firebaseUser.uid, emoji);
  };

  const handleEditMessage = async (
    chatId: string,
    messageId: string,
    nextText: string,
    encrypt?: boolean
  ) => {
    const conv = conversations.find((c) => c.id === chatId);
    if (!conv || conv.type === "ai") return;
    let encryptedPayload: { ciphertext: string; iv: string } | undefined;
    if (encrypt && conv.type === "direct" && firebaseUser && conv.peerUid) {
      const peerPub = peerProfilesByUid[conv.peerUid]?.publicKey;
      if (!peerPub) {
        throw new Error("مفتاح التشفير للطرف الآخر غير متاح.");
      }
      const enc = await encryptSecretMessage(
        firebaseUser.uid,
        peerPub,
        nextText.trim()
      );
      if (!enc) {
        throw new Error("تعذر تشفير التعديل.");
      }
      encryptedPayload = enc;
    }
    await editDirectChatMessage(chatId, messageId, nextText, encryptedPayload);
  };

  const handleDeleteMessageForMe = async (
    chatId: string,
    messageId: string
  ) => {
    const conv = conversations.find((c) => c.id === chatId);
    if (!conv) return;
    if (conv.type === "ai") {
      setAiConversations((prev) =>
        prev.map((c) =>
          c.id === chatId
            ? { ...c, messages: c.messages.filter((m) => m.id !== messageId) }
            : c
        )
      );
      return;
    }
    if (!firebaseUser) return;
    await deleteMessageForMe(chatId, messageId, firebaseUser.uid);
  };

  const handleDeleteMessageForEveryone = async (
    chatId: string,
    messageId: string
  ) => {
    const conv = conversations.find((c) => c.id === chatId);
    if (!conv || conv.type === "ai") return;
    await deleteMessageForEveryone(chatId, messageId);
  };

  const handleTogglePin = async (chatId: string) => {
    const conv = conversations.find((c) => c.id === chatId);
    if (!conv) return;
    if (conv.type === "ai") {
      setAiPinned((prev) => !prev);
      return;
    }
    if (!firebaseUser) return;
    const currentlyPinned = pinnedChatIds.includes(chatId);
    setPinnedChatIds((prev) =>
      currentlyPinned
        ? prev.filter((id) => id !== chatId)
        : [...prev, chatId]
    );
    await togglePinChatCloud(
      firebaseUser.uid,
      chatId,
      !currentlyPinned
    ).catch(() => {});
  };

  const handleDeleteChatForMe = async (chatId: string) => {
    const conv = conversations.find((c) => c.id === chatId);
    if (!conv) return;

    if (conv.type === "ai") {
      setAiConversations((prev) =>
        prev.map((c) => (c.id === chatId ? { ...c, messages: [] } : c))
      );
      return;
    }

    if (!firebaseUser) return;
    await hideChatForUser(chatId, firebaseUser.uid);
    setOptimisticChats((prev) => prev.filter((c) => c.id !== chatId));
    if (activeChatId === chatId) {
      setActiveChatId("gemini-ai-main");
      setMobileView("list");
    }
  };

  const handleClearAllConversations = async () => {
    setAiConversations((prev) => prev.map((c) => ({ ...c, messages: [] })));
    setOptimisticChats([]);
    if (firebaseUser) {
      await clearAllUserDirectChats(firebaseUser.uid).catch(() => {});
    }
    setActiveChatId("gemini-ai-main");
  };

  const handleUpdateProfile = async (nextUser: UserProfile): Promise<void> => {
    const normalizedAvatar = normalizeUserAvatar(
      nextUser.photoURL || nextUser.avatar
    );
    const resolvedJoinedAt =
      extractJoinMonthYearAr(nextUser.joinedAt) ||
      extractJoinMonthYearAr(firebaseUser?.metadata?.creationTime) ||
      DEFAULT_JOIN_MONTH_YEAR_AR;

    const syncedUser: UserProfile = {
      ...nextUser,
      avatar: normalizedAvatar,
      photoURL: normalizedAvatar,
      joinedAt: resolvedJoinedAt,
      isProfileLocked: Boolean(nextUser.isProfileLocked),
    };
    setUser(syncedUser);

    if (firebaseUser && firebaseUser.emailVerified) {
      await upsertCloudUserProfile({
        uid: firebaseUser.uid,
        displayName: syncedUser.name,
        avatar: normalizedAvatar,
        coverPhoto: syncedUser.coverPhoto ?? "cover:emerald",
        bio: syncedUser.bio ?? "",
        publicKey: syncedUser.publicKey,
        sessionVersion: syncedUser.sessionVersion,
        countryCode: syncedUser.countryCode,
        age: syncedUser.age ?? null,
        city: syncedUser.city || "",
        maritalStatus: syncedUser.maritalStatus || "unspecified",
        workOrStudy: syncedUser.workOrStudy || "",
        joinedAt: resolvedJoinedAt,
        isProfileLocked: Boolean(syncedUser.isProfileLocked),
        showAgeCity: syncedUser.showAgeCity ?? true,
        showPersonalInfo: syncedUser.showPersonalInfo ?? true,
        showFriends: syncedUser.showFriends ?? true,
        showLastSeen: syncedUser.showLastSeen ?? true,
        isOnline: true,
      });
    }
  };

  const handleStartYouTubeWatch = async (
    chatId: string,
    videoId: string,
    youtubeUrl: string,
    title?: string
  ) => {
    const starterUid = firebaseUser?.uid || "local";
    const starterName = user?.name || "مستخدم";
    const conv = conversations.find((c) => c.id === chatId);

    if (conv && conv.type !== "ai" && firebaseUser) {
      await setWatchSessionDoc({
        chatId,
        mediaType: "youtube",
        videoId,
        mediaUrl: youtubeUrl,
        startedByUid: starterUid,
        startedByName: starterName,
      });
      void saveWatchHistoryLink({
        chatId,
        url: youtubeUrl,
        mediaType: "youtube",
        videoId,
        title,
        addedByUid: starterUid,
        addedByName: starterName,
      }).catch(() => {});
      return;
    }

    setWatchSessionByChat((prev) => ({
      ...prev,
      [chatId]: {
        chatId,
        videoId,
        youtubeUrl,
        mediaType: "youtube",
        mediaUrl: youtubeUrl,
        videoUrl: youtubeUrl,
        hostId: starterUid,
        isStarted: true,
        isPlaying: true,
        currentTime: 0,
        playbackState: "playing",
        playbackTime: 0,
        playbackRate: 1,
        startedByUid: starterUid,
        startedByName: starterName,
        isActive: true,
        updatedAtMs: Date.now(),
      },
    }));
  };

  const handleStartStreamWatch = async (
    chatId: string,
    mediaType: "mp4" | "m3u8",
    mediaUrl: string,
    title?: string
  ) => {
    const starterUid = firebaseUser?.uid || "local";
    const starterName = user?.name || "مستخدم";
    const conv = conversations.find((c) => c.id === chatId);
    const streamId = mediaType === "m3u8" ? "stream_m3u8" : "stream_mp4";

    if (conv && conv.type !== "ai" && firebaseUser) {
      await setWatchSessionDoc({
        chatId,
        mediaType,
        videoId: streamId,
        mediaUrl,
        startedByUid: starterUid,
        startedByName: starterName,
      });
      void saveWatchHistoryLink({
        chatId,
        url: mediaUrl,
        mediaType,
        videoId: streamId,
        title,
        addedByUid: starterUid,
        addedByName: starterName,
      }).catch(() => {});
      return;
    }

    setWatchSessionByChat((prev) => ({
      ...prev,
      [chatId]: {
        chatId,
        videoId: streamId,
        youtubeUrl: mediaUrl,
        mediaType,
        mediaUrl,
        videoUrl: mediaUrl,
        hostId: starterUid,
        isStarted: true,
        isPlaying: true,
        currentTime: 0,
        playbackState: "playing",
        playbackTime: 0,
        playbackRate: 1,
        startedByUid: starterUid,
        startedByName: starterName,
        isActive: true,
        updatedAtMs: Date.now(),
      },
    }));
  };

  const handleStartFacebookWatch = async (
    chatId: string,
    facebookUrl: string,
    title?: string
  ) => {
    const starterUid = firebaseUser?.uid || "local";
    const starterName = user?.name || "مستخدم";
    const conv = conversations.find((c) => c.id === chatId);

    if (conv && conv.type !== "ai" && firebaseUser) {
      await setWatchSessionDoc({
        chatId,
        mediaType: "facebook",
        videoId: "facebook_video",
        mediaUrl: facebookUrl,
        startedByUid: starterUid,
        startedByName: starterName,
      });
      void saveWatchHistoryLink({
        chatId,
        url: facebookUrl,
        mediaType: "facebook",
        videoId: "facebook_video",
        title,
        addedByUid: starterUid,
        addedByName: starterName,
      }).catch(() => {});
      return;
    }

    setWatchSessionByChat((prev) => ({
      ...prev,
      [chatId]: {
        chatId,
        videoId: "facebook_video",
        youtubeUrl: facebookUrl,
        mediaType: "facebook",
        mediaUrl: facebookUrl,
        videoUrl: facebookUrl,
        hostId: starterUid,
        isStarted: false,
        countdownStartAtMs: 0,
        startedAtMs: 0,
        isPlaying: false,
        currentTime: 0,
        playbackState: "paused",
        playbackTime: 0,
        playbackRate: 1,
        startedByUid: starterUid,
        startedByName: starterName,
        isActive: true,
        updatedAtMs: Date.now(),
      },
    }));
  };

  const handleStartTikTokWatch = async (
    chatId: string,
    videoId: string,
    tiktokUrl: string,
    title?: string
  ) => {
    const starterUid = firebaseUser?.uid || "local";
    const starterName = user?.name || "مستخدم";
    const conv = conversations.find((c) => c.id === chatId);
    const resolvedId = videoId || "tiktok_video";

    if (conv && conv.type !== "ai" && firebaseUser) {
      await setWatchSessionDoc({
        chatId,
        mediaType: "tiktok",
        videoId: resolvedId,
        mediaUrl: tiktokUrl,
        startedByUid: starterUid,
        startedByName: starterName,
      });
      void saveWatchHistoryLink({
        chatId,
        url: tiktokUrl,
        mediaType: "tiktok",
        videoId: resolvedId,
        title,
        addedByUid: starterUid,
        addedByName: starterName,
      }).catch(() => {});
      return;
    }

    setWatchSessionByChat((prev) => ({
      ...prev,
      [chatId]: {
        chatId,
        videoId: resolvedId,
        youtubeUrl: tiktokUrl,
        mediaType: "tiktok",
        mediaUrl: tiktokUrl,
        videoUrl: tiktokUrl,
        hostId: starterUid,
        isStarted: true,
        isPlaying: true,
        currentTime: 0,
        playbackState: "playing",
        playbackTime: 0,
        playbackRate: 1,
        startedByUid: starterUid,
        startedByName: starterName,
        isActive: true,
        updatedAtMs: Date.now(),
      },
    }));
  };

  const handleDeleteWatchHistory = useCallback(
    async (chatId: string, historyId: string) => {
      if (!firebaseUser) return;
      await deleteWatchHistoryLink(chatId, historyId);
    },
    [firebaseUser]
  );

  const handleTypingChange = useCallback(
    (chatId: string, isTyping: boolean) => {
      if (!firebaseUser) return;
      void setChatTypingStatus(chatId, firebaseUser.uid, isTyping);
    },
    [firebaseUser]
  );

  const handleStartFacebookWatchCountdown = async (chatId: string) => {
    const conv = conversations.find((c) => c.id === chatId);
    const countdownStartAtMs = Date.now();
    if (conv && conv.type !== "ai" && firebaseUser) {
      await startFacebookWatchCountdownDoc({
        chatId,
        countdownStartAtMs,
      });
      return;
    }
    setWatchSessionByChat((prev) => {
      const existing = prev[chatId];
      if (!existing) return prev;
      return {
        ...prev,
        [chatId]: {
          ...existing,
          isStarted: false,
          countdownStartAtMs,
        },
      };
    });
  };

  const handleMarkWatchStarted = async (chatId: string) => {
    const conv = conversations.find((c) => c.id === chatId);
    if (conv && conv.type !== "ai" && firebaseUser) {
      await markWatchStartedDoc(chatId);
      return;
    }
    setWatchSessionByChat((prev) => {
      const existing = prev[chatId];
      if (!existing) return prev;
      return {
        ...prev,
        [chatId]: {
          ...existing,
          isStarted: true,
          startedAtMs: Date.now(),
          isPlaying: true,
          playbackState: "playing",
        },
      };
    });
  };

  const handleSyncWatchPlayback = async (
    chatId: string,
    playbackState: "playing" | "paused",
    playbackTime: number,
    playbackRate = 1
  ) => {
    const conv = conversations.find((c) => c.id === chatId);
    if (conv && conv.type !== "ai" && firebaseUser) {
      await updateWatchPlaybackDoc({
        chatId,
        playbackState,
        playbackTime,
        playbackRate,
      });
      return;
    }

    setWatchSessionByChat((prev) => {
      const existing = prev[chatId];
      if (!existing) return prev;
      return {
        ...prev,
        [chatId]: {
          ...existing,
          isPlaying: playbackState === "playing",
          currentTime: playbackTime,
          playbackState,
          playbackTime,
          playbackRate,
          updatedAtMs: Date.now(),
        },
      };
    });
  };

  const handleStopWatchTogether = async (chatId: string) => {
    const conv = conversations.find((c) => c.id === chatId);
    const current = watchSessionByChat[chatId];
    watchPartyMic.stopWatchMic();
    setWatchSessionByChat((prev) => ({ ...prev, [chatId]: null }));

    if (conv && conv.type !== "ai" && firebaseUser) {
      await stopWatchSessionDoc({
        chatId,
        uid: firebaseUser.uid,
        userName: user?.name || "مستخدم",
        videoId: current?.videoId,
        youtubeUrl: current?.mediaUrl || current?.youtubeUrl,
      });
    }
  };

  const handleToggleWatchGuestMicAllowed = async (
    chatId: string,
    allowed: boolean
  ) => {
    const conv = conversations.find((c) => c.id === chatId);
    setWatchSessionByChat((prev) => {
      const existing = prev[chatId];
      if (!existing) return prev;
      return {
        ...prev,
        [chatId]: {
          ...existing,
          guestMicAllowed: allowed,
        },
      };
    });
    if (conv && conv.type !== "ai" && firebaseUser) {
      await setWatchGuestMicAllowedDoc(chatId, allowed);
    }
  };

  const handleBlockUser = async (
    targetUid: string,
    durationMs: number | null = null
  ) => {
    if (!firebaseUser || !targetUid) return;
    const nextUntil = await blockCloudUser(
      firebaseUser.uid,
      targetUid,
      durationMs
    );
    setUser((prev) => {
      if (!prev) return prev;
      const existing = prev.blockedUsers || [];
      const nextList = existing.includes(targetUid)
        ? existing
        : [...existing, targetUid];
      return {
        ...prev,
        blockedUsers: nextList,
        blockedUntil: nextUntil,
      };
    });
    if (webrtc.activeCall && activeConversation?.peerUid === targetUid) {
      await webrtc.endActiveCall();
    }
    if (
      screenShare.activeShare &&
      activeConversation?.peerUid === targetUid
    ) {
      await screenShare.stopScreenShare();
    }
    if (activeConversation?.peerUid === targetUid) {
      watchPartyMic.stopWatchMic();
    }
  };

  const handleUnblockUser = async (targetUid: string) => {
    if (!firebaseUser || !targetUid) return;
    const nextUntil = await unblockCloudUser(firebaseUser.uid, targetUid);
    setUser((prev) => {
      if (!prev) return prev;
      return {
        ...prev,
        blockedUsers: (prev.blockedUsers || []).filter((id) => id !== targetUid),
        blockedUntil: nextUntil,
      };
    });
  };

  const handleLogout = async () => {
    await webrtc.endActiveCall();
    await screenShare.stopScreenShare();
    watchPartyMic.stopWatchMic();
    void closeCallNotifications();
    if (firebaseUser && user) {
      await unsubscribeWebPush(firebaseUser.uid).catch(() => {});
      await signOutFirebase({
        uid: firebaseUser.uid,
        displayName: user.name,
        avatar: user.avatar,
      }).catch(() => {});
    } else {
      await signOutFirebase().catch(() => {});
    }
    savePendingSignupProfile(null);
    setPendingVerification(null);
    setUser(null);
    setCloudChats([]);
    setOptimisticChats([]);
    setPinnedChatIds([]);
    setMyFriends([]);
    setPeerProfilesByUid({});
    setMessagesByChat({});
    setIncomingCallByChat({});
    setIncomingScreenShareByChat({});
    setWatchSessionByChat({});
    setWatchHistoryByChat({});
    initializedMsgChatsRef.current.clear();
    lastSeenMsgIdByChatRef.current = {};
    markingReadIdsRef.current.clear();
    unlockedUidRef.current = null;
    setIsAppLocked(false);
    setAppLockPinInput("");
    setAppLockError(null);
    void updateAppIconBadge(0);
    setMobileView("list");
  };

  const handleUnlockApp = async (e: FormEvent) => {
    e.preventDefault();
    const targetUid = user?.uid || firebaseUser?.uid;
    if (!targetUid || unlockingApp) return;
    setAppLockError(null);
    const clean = appLockPinInput.trim();
    if (!/^\d{4}$/.test(clean)) {
      setAppLockError("أدخل رمز القفل المكوّن من 4 أرقام.");
      return;
    }
    setUnlockingApp(true);
    try {
      const ok = await verifyAppLockPin(targetUid, clean);
      if (!ok) {
        setAppLockError("رمز القفل غير صحيح. حاول مجدداً.");
        setAppLockPinInput("");
        return;
      }
      unlockedUidRef.current = targetUid;
      setIsAppLocked(false);
      setAppLockPinInput("");
      setAppLockError(null);
    } finally {
      setUnlockingApp(false);
    }
  };

  const handleDeleteAccount = async () => {
    if (!firebaseUser) return;
    await webrtc.endActiveCall().catch(() => {});
    await screenShare.stopScreenShare().catch(() => {});
    watchPartyMic.stopWatchMic();
    void closeCallNotifications();
    await unsubscribeWebPush(firebaseUser.uid).catch(() => {});
    await deleteUserAccountCloud(firebaseUser.uid);
    savePendingSignupProfile(null);
    setPendingVerification(null);
    setIsMyProfileOpen(false);
    setUser(null);
    setCloudChats([]);
    setOptimisticChats([]);
    setPinnedChatIds([]);
    setMyFriends([]);
    setPeerProfilesByUid({});
    setMessagesByChat({});
    setIncomingCallByChat({});
    setIncomingScreenShareByChat({});
    setWatchSessionByChat({});
    setWatchHistoryByChat({});
    initializedMsgChatsRef.current.clear();
    lastSeenMsgIdByChatRef.current = {};
    markingReadIdsRef.current.clear();
    void updateAppIconBadge(0);
    setMobileView("list");
  };

  const authLoading =
    !authReady || (Boolean(firebaseUser?.emailVerified) && !user);

  if (authLoading) {
    return (
      <div
        aria-label="جاري تحميل مرسال"
        className="min-h-screen w-full bg-[#f0f2f5] dark:bg-[#0b141a] flex flex-col items-center justify-center p-6 select-none"
      >
        <div className="flex flex-col items-center gap-4">
          <MirsalLogo className="w-24 h-24 drop-shadow-xl animate-pulse" />
          <div className="flex items-center gap-2 text-[#075E54] dark:text-[#25D366]">
            <Loader2 className="w-4 h-4 animate-spin" />
            <span className="font-display text-lg font-bold tracking-wide">
              مرسال
            </span>
          </div>
        </div>
      </div>
    );
  }

  if (!user || !firebaseUser || !firebaseUser.emailVerified) {
    return (
      <>
        {securityLogoutNotice && (
          <div
            role="alert"
            className="fixed top-3 inset-x-3 z-[70] max-w-md mx-auto bg-amber-50 dark:bg-amber-950/90 border border-amber-300 dark:border-amber-800 text-amber-900 dark:text-amber-100 rounded-2xl px-4 py-3 text-xs font-bold shadow-xl flex items-center justify-between gap-2"
          >
            <span>{securityLogoutNotice}</span>
            <button
              type="button"
              onClick={() => setSecurityLogoutNotice(null)}
              className="px-2 py-1 rounded-lg bg-amber-200/70 dark:bg-amber-800/70 text-[11px] cursor-pointer shrink-0"
            >
              حسناً
            </button>
          </div>
        )}
        <LoginScreen
          theme={theme}
          pendingVerification={pendingVerification}
          onToggleTheme={handleToggleTheme}
          onRegister={handleRegister}
          onSignIn={handleSignIn}
          onCheckVerified={handleCheckVerified}
          onResendVerification={resendVerificationEmail}
          onCancelVerification={handleCancelVerification}
          onResetPin={sendPinResetEmail}
        />
        <OfflineIndicator />
      </>
    );
  }

  if (isAppLocked) {
    return (
      <div className="min-h-[100dvh] w-full bg-[#f0f2f5] dark:bg-[#0b141a] flex items-center justify-center p-4">
        <form
          onSubmit={(e) => void handleUnlockApp(e)}
          className="w-full max-w-sm bg-white dark:bg-[#111b21] border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-2xl space-y-5 text-center"
        >
          <div className="w-16 h-16 mx-auto rounded-2xl bg-emerald-50 dark:bg-emerald-950/60 text-[#0d7a5f] dark:text-[#00a884] flex items-center justify-center">
            <Lock className="w-8 h-8" />
          </div>
          <div className="space-y-1">
            <h1 className="font-display font-bold text-lg text-slate-900 dark:text-white">
              مرسال مقفل
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              أدخل رمز القفل المكون من 4 أرقام لفتح المحادثات
            </p>
          </div>

          <input
            type="password"
            inputMode="numeric"
            maxLength={4}
            autoFocus
            value={appLockPinInput}
            onChange={(e) => {
              setAppLockError(null);
              setAppLockPinInput(e.target.value.replace(/\D/g, "").slice(0, 4));
            }}
            placeholder="••••"
            aria-label="رمز قفل التطبيق"
            className="w-full min-h-[52px] text-center tracking-[0.8em] text-xl font-bold px-4 rounded-2xl bg-slate-100 dark:bg-[#202c33] text-slate-900 dark:text-white border border-transparent focus:border-[#0d7a5f] focus:outline-none"
          />

          {appLockError && (
            <p className="text-xs font-semibold text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/40 px-3 py-2 rounded-xl">
              {appLockError}
            </p>
          )}

          <button
            type="submit"
            disabled={unlockingApp || appLockPinInput.length !== 4}
            className="w-full min-h-[46px] px-4 py-2.5 rounded-2xl bg-[#0d7a5f] hover:bg-[#0a634d] dark:bg-[#00a884] text-white text-sm font-bold flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
          >
            {unlockingApp ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <KeyRound className="w-4 h-4" />
            )}
            <span>فتح التطبيق</span>
          </button>

          <button
            type="button"
            onClick={() => void handleLogout()}
            className="w-full min-h-[38px] text-xs font-semibold text-slate-500 hover:text-rose-600 dark:text-slate-400 dark:hover:text-rose-400 flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>تسجيل الخروج من الحساب</span>
          </button>
        </form>
      </div>
    );
  }

  return (
    <div className="h-[100dvh] w-full overflow-hidden bg-slate-100 dark:bg-[#0b141a] text-slate-900 dark:text-slate-100 flex">
      {/* Sidebar */}
      <div
        className={`${
          mobileView === "list" ? "flex" : "hidden"
        } md:flex w-full md:w-[350px] lg:w-[390px] shrink-0 h-full`}
      >
        <Sidebar
          user={user}
          conversations={conversations}
          activeChatId={activeChatId}
          typingChatIds={combinedTypingChatIds}
          onSelectChat={handleSelectChat}
          onOpenNewChat={() => setNewChatModalOpen(true)}
          onOpenMyProfile={() => setIsMyProfileOpen(true)}
          onOpenSettings={() => setIsSettingsOpen(true)}
        />
      </div>

      {/* Main Active Chat View */}
      <main
        className={`${
          mobileView === "chat" ? "flex" : "hidden"
        } md:flex flex-1 min-w-0 h-full`}
      >
        <ChatView
          currentUid={firebaseUser.uid}
          conversation={activeConversation}
          peerPublicKey={
            activeConversation?.type === "direct" && activeConversation.peerUid
              ? peerProfilesByUid[activeConversation.peerUid]?.publicKey
              : undefined
          }
          isTyping={Boolean(
            activeChatId && combinedTypingChatIds[activeChatId]
          )}
          isBlockedByMe={isActivePeerBlockedByMe}
          blockedUntilMs={activePeerBlockedUntilMs}
          isBlockedByPeer={isActivePeerBlockingMe}
          wallpaperId={wallpaperId}
          customWallpaper={customWallpaper}
          activeScreenShare={screenShare.activeShare}
          screenStream={screenShare.screenStream}
          remoteShareAudioStream={screenShare.remoteAudioStream}
          isScreenShareMicActive={screenShare.isMicActive}
          screenShareError={screenShare.screenShareError}
          incomingScreenShareOffer={activeIncomingScreenShareOffer}
          isVideoPaused={screenShare.isVideoPaused}
          videoCurrentTime={screenShare.videoCurrentTime}
          videoDuration={screenShare.videoDuration}
          watchSession={activeWatchSession}
          watchMicActive={watchPartyMic.isMicActive}
          watchMicConnecting={watchPartyMic.isConnectingMic}
          watchMicLocked={watchPartyMic.isMicLockedForMe}
          watchRemoteAudioStream={watchPartyMic.remoteAudioStream}
          watchMicError={watchPartyMic.micError}
          watchHistory={
            activeConversation
              ? watchHistoryByChat[activeConversation.id] || []
              : []
          }
          onBackMobile={() => setMobileView("list")}
          onTypingChange={handleTypingChange}
          onSendMessage={handleSendMessage}
          onReactMessage={handleReactMessage}
          onEditMessage={handleEditMessage}
          onDeleteMessageForMe={handleDeleteMessageForMe}
          onDeleteMessageForEveryone={handleDeleteMessageForEveryone}
          onTogglePin={(id) => void handleTogglePin(id)}
          onOpenPeerProfile={(uid) => void handleOpenPeerProfileByUid(uid)}
          onOpenGroupInfo={(id) => setGroupInfoChatId(id)}
          onCreateGroupWithPeer={handleOpenCreateGroupWithPeer}
          onSetDisappearingTimer={handleSetDisappearingTimer}
          onOpenViewOnceImage={handleOpenViewOnceImage}
          onDeleteChatForMe={handleDeleteChatForMe}
          onBlockPeer={handleBlockUser}
          onUnblockPeer={handleUnblockUser}
          onStartCall={(chatId, chatTitle, callType) => {
            unlockAudioContext();
            const target = conversations.find((c) => c.id === chatId);
            if (!target || target.type !== "direct") return;
            void webrtc
              .startCall(chatId, chatTitle, callType, target.avatar)
              .then((startedCallId) => {
                if (startedCallId && target.peerUid && firebaseUser?.uid) {
                  outgoingCallPeerRef.current = {
                    callId: startedCallId,
                    peerUid: target.peerUid,
                  };
                  void notifyIncomingCallPush({
                    targetUid: target.peerUid,
                    callId: startedCallId,
                    chatId,
                    callerId: firebaseUser.uid,
                    callerName: resolvedDisplayName,
                    callType,
                  });
                }
              });
          }}
          onStartScreenShare={screenShare.startScreenShare}
          onStartVideoFileWatch={screenShare.startVideoFileShare}
          onJoinScreenShare={screenShare.joinIncomingScreenShare}
          onStopScreenShare={screenShare.stopScreenShare}
          onToggleScreenShareMic={screenShare.toggleMic}
          onToggleVideoPlayback={screenShare.toggleVideoPlayback}
          onSeekVideo={screenShare.seekVideo}
          onClearScreenShareError={screenShare.clearScreenShareError}
          onStartYouTubeWatch={handleStartYouTubeWatch}
          onStartFacebookWatch={handleStartFacebookWatch}
          onStartTikTokWatch={handleStartTikTokWatch}
          onStartFacebookWatchCountdown={handleStartFacebookWatchCountdown}
          onMarkWatchStarted={handleMarkWatchStarted}
          onStartStreamWatch={handleStartStreamWatch}
          onDeleteWatchHistory={handleDeleteWatchHistory}
          onSyncWatchPlayback={handleSyncWatchPlayback}
          onStopWatchTogether={handleStopWatchTogether}
          onToggleWatchMic={watchPartyMic.toggleWatchMic}
          onToggleWatchGuestMicAllowed={handleToggleWatchGuestMicAllowed}
          onStopWatchMic={watchPartyMic.stopWatchMic}
          onClearWatchMicError={watchPartyMic.clearMicError}
          onSelectWallpaper={setWallpaperId}
          onUploadCustomWallpaper={setCustomWallpaper}
          onOpenNewChat={() => setNewChatModalOpen(true)}
          onSelectAiChat={() => handleSelectChat("gemini-ai-main")}
          onPreviewImage={(src) => setLightboxImage(src)}
        />
      </main>

      {/* Modals */}
      <NewChatModal
        isOpen={newChatModalOpen}
        myFriends={myFriends}
        myFriendUids={myFriendUids}
        loadingFriends={loadingFriends}
        onClose={() => setNewChatModalOpen(false)}
        onRefreshFriends={refreshFriends}
        onSearchExactUser={handleSearchExactUser}
        onAddFriend={handleAddFriend}
        onStartDirectChat={handleStartDirectChat}
        onOpenCreateGroup={() => {
          setPreselectedGroupMemberUids([]);
          setCreateGroupOpen(true);
        }}
        onViewProfile={(peer) => setProfileModalPeer(peer)}
      />

      <CreateGroupModal
        isOpen={createGroupOpen}
        friends={myFriends}
        preselectedMemberUids={preselectedGroupMemberUids}
        onClose={() => {
          setCreateGroupOpen(false);
          setPreselectedGroupMemberUids([]);
        }}
        onCreateGroup={handleCreateGroup}
      />

      {groupInfoChat && (
        <GroupInfoModal
          isOpen={Boolean(groupInfoChat)}
          conversation={groupInfoChat}
          currentUid={firebaseUser.uid}
          myFriends={myFriends}
          onClose={() => setGroupInfoChatId(null)}
          onAddMember={(chatId, uid) => addGroupMember(chatId, uid)}
          onRemoveMember={(chatId, uid) => removeGroupMember(chatId, uid)}
          onLeaveGroup={async (chatId) => {
            await leaveGroupChat(chatId, firebaseUser.uid);
            setGroupInfoChatId(null);
            if (activeChatId === chatId) {
              setActiveChatId("gemini-ai-main");
              setMobileView("list");
            }
          }}
          onViewProfile={(peer) => {
            setGroupInfoChatId(null);
            setProfileModalPeer(peer);
          }}
        />
      )}

      <UserProfileModal
        isOpen={Boolean(profileModalPeer)}
        peer={profileModalPeer}
        currentUid={firebaseUser.uid}
        myFriendUids={myFriendUids}
        knownPeersByUid={peerProfilesByUid}
        onClose={() => setProfileModalPeer(null)}
        onAddFriend={handleAddFriend}
        onRemoveFriend={handleRemoveFriend}
        onStartChat={handleStartDirectChat}
        onSelectFriendProfile={(friendPeer) => setProfileModalPeer(friendPeer)}
        onStartCallWithPeer={async (peerTarget, callType) => {
          if (!firebaseUser || !user) return;
          const chatConv = await openOrCreateDirectChat({
            currentUser: {
              uid: firebaseUser.uid,
              name: user.name,
              avatar: user.avatar,
            },
            peerUser: peerTarget,
          });
          setOptimisticChats((prev) =>
            prev.some((c) => c.id === chatConv.id) ? prev : [chatConv, ...prev]
          );
          setActiveChatId(chatConv.id);
          setMobileView("chat");
          unlockAudioContext();
          void webrtc
            .startCall(chatConv.id, peerTarget.displayName, callType, peerTarget.avatar)
            .then((startedCallId) => {
              if (startedCallId && firebaseUser?.uid) {
                outgoingCallPeerRef.current = {
                  callId: startedCallId,
                  peerUid: peerTarget.uid,
                };
                void notifyIncomingCallPush({
                  targetUid: peerTarget.uid,
                  callId: startedCallId,
                  chatId: chatConv.id,
                  callerId: firebaseUser.uid,
                  callerName: resolvedDisplayName,
                  callType,
                });
              }
            });
        }}
      />

      <MyProfileModal
        isOpen={isMyProfileOpen}
        user={user}
        creationTime={firebaseUser.metadata?.creationTime || null}
        friends={myFriends}
        friendsCount={myFriendUids.length}
        onClose={() => setIsMyProfileOpen(false)}
        onSaveProfile={handleUpdateProfile}
        onRemoveFriend={handleRemoveFriend}
        onBlockUser={(targetUid) => handleBlockUser(targetUid, null)}
        onDeleteAccount={handleDeleteAccount}
      />

      <SettingsModal
        isOpen={isSettingsOpen}
        user={user}
        theme={theme}
        friendsCount={myFriendUids.length}
        knownPeersByUid={peerProfilesByUid}
        soundPrefs={soundPrefs}
        typographyPrefs={typographyPrefs}
        notificationPrefs={notificationPrefs}
        onClose={() => setIsSettingsOpen(false)}
        onUpdateProfile={handleUpdateProfile}
        onUnblockUser={handleUnblockUser}
        onSetTheme={setTheme}
        onChangeSoundPrefs={setSoundPrefs}
        onChangeTypographyPrefs={setTypographyPrefs}
        onChangeNotificationPrefs={setNotificationPrefs}
        onClearAllConversations={handleClearAllConversations}
        onDeleteAccount={handleDeleteAccount}
        onLogout={() => void handleLogout()}
      />

      <ImageLightbox
        src={viewOnceLightbox ? viewOnceLightbox.src : lightboxImage}
        viewOnceMode={Boolean(viewOnceLightbox)}
        onClose={handleCloseLightbox}
      />

      <CallOverlay
        activeCall={webrtc.activeCall}
        incomingCall={incomingCall}
        localStream={webrtc.localStream}
        remoteStream={webrtc.remoteStream}
        isMuted={webrtc.isMuted}
        isCameraOff={webrtc.isCameraOff}
        facingMode={webrtc.facingMode}
        elapsedSeconds={webrtc.elapsedSeconds}
        callError={webrtc.callError}
        onClearError={webrtc.clearCallError}
        onAcceptIncoming={(call) => {
          void closeCallNotifications(call.callId);
          const peerAvatar =
            peerProfilesByUid[call.callerId]?.avatar ||
            conversations.find((c) => c.id === call.chatId)?.avatar;
          void webrtc.acceptIncomingCall(call, peerAvatar);
        }}
        onDeclineIncoming={(call) => {
          void closeCallNotifications(call.callId);
          void webrtc.declineIncomingCall(call);
        }}
        onEndCall={() => {
          void closeCallNotifications(webrtc.activeCall?.callId);
          void webrtc.endActiveCall();
        }}
        onToggleMute={webrtc.toggleMute}
        onToggleCamera={webrtc.toggleCamera}
        onSwitchCamera={() => void webrtc.switchCamera()}
      />

      <OfflineIndicator />
    </div>
  );
}
