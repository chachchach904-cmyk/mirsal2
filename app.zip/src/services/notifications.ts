import type { CallType, ChatCallSignal } from "../types/chat";

export interface IncomingCallNotificationAction {
  action: "accept" | "decline";
  callId: string;
  chatId: string;
  callerId: string;
  callerName: string;
  callType: CallType;
}

export type NotificationPermissionState = NotificationPermission | "unsupported";

let swRegistrationPromise: Promise<ServiceWorkerRegistration | null> | null =
  null;

export function getNotificationPermissionState(): NotificationPermissionState {
  if (typeof window === "undefined" || !("Notification" in window)) {
    return "unsupported";
  }
  return Notification.permission;
}

export async function registerMirsalServiceWorker(): Promise<ServiceWorkerRegistration | null> {
  if (
    typeof window === "undefined" ||
    !("serviceWorker" in navigator)
  ) {
    return null;
  }
  if (!swRegistrationPromise) {
    swRegistrationPromise = navigator.serviceWorker
      .register("/sw.js")
      .then((reg) => reg)
      .catch(() => null);
  }
  return swRegistrationPromise;
}

export async function requestImmediateNotificationPermission(
  onGranted?: () => void
): Promise<NotificationPermissionState> {
  const current = getNotificationPermissionState();
  if (current === "unsupported") return "unsupported";
  if (current === "granted") {
    void registerMirsalServiceWorker();
    onGranted?.();
    return "granted";
  }
  if (current === "denied") {
    return "denied";
  }

  try {
    const result = await Notification.requestPermission();
    if (result === "granted") {
      await registerMirsalServiceWorker();
      onGranted?.();
    }
    return result;
  } catch {
    return getNotificationPermissionState();
  }
}

export async function syncWebPushSubscription(_uid: string): Promise<void> {
  if (
    typeof window === "undefined" ||
    !("serviceWorker" in navigator) ||
    getNotificationPermissionState() !== "granted"
  ) {
    return;
  }
  try {
    await registerMirsalServiceWorker();
  } catch {
    // non-fatal when Web Push VAPID keys are not configured
  }
}

export async function unsubscribeWebPush(_uid: string): Promise<void> {
  if (typeof window === "undefined" || !("serviceWorker" in navigator)) {
    return;
  }
  try {
    const reg = await navigator.serviceWorker.ready;
    const sub = await reg.pushManager?.getSubscription();
    if (sub) {
      await sub.unsubscribe().catch(() => {});
    }
  } catch {
    // non-fatal
  }
}

export async function showIncomingCallNotification(
  call: ChatCallSignal,
  vibrationEnabled = true
): Promise<void> {
  if (typeof window === "undefined" || !call.callId) return;
  if (getNotificationPermissionState() !== "granted") return;

  const payload = {
    callId: call.callId,
    chatId: call.chatId,
    callerId: call.callerId,
    callerName: call.callerName || "مستخدم مرسال",
    callType: call.callType,
    vibrationEnabled,
  };

  try {
    const reg = await registerMirsalServiceWorker();
    const target = reg?.active || navigator.serviceWorker?.controller;
    if (target) {
      target.postMessage({
        type: "SHOW_INCOMING_CALL_NOTIFICATION",
        payload,
      });
      return;
    }

    if (reg?.showNotification) {
      const isVideo = call.callType === "video";
      await reg.showNotification(
        isVideo
          ? `📹 مكالمة فيديو واردة — ${payload.callerName}`
          : `📞 مكالمة صوتية واردة — ${payload.callerName}`,
        {
          body: "افتح المحادثة للرد على المكالمة",
          icon: "/pwa-192x192.png",
          tag: `mirsal-call-${call.callId}`,
          requireInteraction: true,
          dir: "rtl",
          lang: "ar",
        }
      );
      return;
    }
  } catch {
    // fall back to window Notification below
  }

  try {
    const isVideo = call.callType === "video";
    new Notification(
      isVideo
        ? `📹 مكالمة فيديو واردة — ${payload.callerName}`
        : `📞 مكالمة صوتية واردة — ${payload.callerName}`,
      {
        body: "افتح مرسال للرد أو الرفض",
        icon: "/pwa-192x192.png",
        tag: `mirsal-call-${call.callId}`,
        requireInteraction: true,
      }
    );
  } catch {
    // ignore browser restrictions when Notification constructor is disabled
  }
}

export async function closeCallNotifications(callId?: string): Promise<void> {
  if (typeof window === "undefined" || !("serviceWorker" in navigator)) {
    return;
  }
  try {
    const reg = await navigator.serviceWorker.getRegistration();
    const target = reg?.active || navigator.serviceWorker.controller;
    if (target) {
      target.postMessage({
        type: "CLOSE_CALL_NOTIFICATION",
        callId: callId || "",
      });
    }
    if (reg?.getNotifications) {
      const notifications = await reg.getNotifications(
        callId ? { tag: `mirsal-call-${callId}` } : undefined
      );
      notifications.forEach((n) => {
        if (!callId && n.tag && !n.tag.startsWith("mirsal-call-")) return;
        n.close();
      });
    }
  } catch {
    // ignore
  }
}

export function consumeUrlCallAction(): IncomingCallNotificationAction | null {
  if (typeof window === "undefined") return null;
  try {
    const url = new URL(window.location.href);
    const callAction = url.searchParams.get("callAction");
    const callId = url.searchParams.get("callId");
    const chatId = url.searchParams.get("chatId");
    if (
      (callAction !== "accept" && callAction !== "decline") ||
      !callId ||
      !chatId
    ) {
      return null;
    }

    const actionPayload: IncomingCallNotificationAction = {
      action: callAction,
      callId,
      chatId,
      callerId: url.searchParams.get("callerId") || "",
      callerName: url.searchParams.get("callerName") || "مستخدم مرسال",
      callType:
        url.searchParams.get("callType") === "video" ? "video" : "audio",
    };

    url.searchParams.delete("callAction");
    url.searchParams.delete("callId");
    url.searchParams.delete("chatId");
    url.searchParams.delete("callerId");
    url.searchParams.delete("callerName");
    url.searchParams.delete("callType");
    window.history.replaceState({}, document.title, url.toString());

    return actionPayload;
  } catch {
    return null;
  }
}

export function subscribeToServiceWorkerCallActions(
  handler: (action: IncomingCallNotificationAction) => void
): () => void {
  if (typeof window === "undefined" || !("serviceWorker" in navigator)) {
    return () => {};
  }

  const onMessage = (event: MessageEvent) => {
    const data = event.data as Partial<IncomingCallNotificationAction> & {
      type?: string;
    };
    if (!data || data.type !== "MIRSAL_CALL_ACTION") return;
    if (
      (data.action !== "accept" && data.action !== "decline") ||
      !data.callId ||
      !data.chatId
    ) {
      return;
    }

    handler({
      action: data.action,
      callId: data.callId,
      chatId: data.chatId,
      callerId: data.callerId || "",
      callerName: data.callerName || "مستخدم مرسال",
      callType: data.callType === "video" ? "video" : "audio",
    });
  };

  navigator.serviceWorker.addEventListener("message", onMessage);
  return () => {
    navigator.serviceWorker.removeEventListener("message", onMessage);
  };
}

export async function showIncomingMessageNotification(params: {
  chatId: string;
  senderName: string;
  text: string;
  isGroup?: boolean;
  chatTitle?: string;
  vibrationEnabled?: boolean;
  badgeCount?: number;
}): Promise<void> {
  if (typeof window === "undefined" || !params.chatId) return;
  if (getNotificationPermissionState() !== "granted") return;

  const title = params.isGroup && params.chatTitle
    ? `${params.chatTitle} — ${params.senderName}`
    : params.senderName || "رسالة جديدة في مرسال";
  const body = params.text.trim() || "أرسل إليك مرفقاً جديداً";

  try {
    const reg = await registerMirsalServiceWorker();
    const target = reg?.active || navigator.serviceWorker?.controller;
    if (target) {
      target.postMessage({
        type: "SHOW_MESSAGE_NOTIFICATION",
        payload: {
          chatId: params.chatId,
          title,
          body,
          vibrationEnabled: params.vibrationEnabled !== false,
          badgeCount: params.badgeCount,
        },
      });
      return;
    }

    if (reg?.showNotification) {
      await reg.showNotification(title, {
        body,
        icon: "/pwa-192x192.png",
        badge: "/pwa-192x192.png",
        tag: `mirsal-msg-${params.chatId}`,
        dir: "rtl",
        lang: "ar",
        data: { kind: "message", chatId: params.chatId },
      });
      return;
    }
  } catch {
    // fallback to Notification constructor
  }

  try {
    const n = new Notification(title, {
      body,
      icon: "/pwa-192x192.png",
      tag: `mirsal-msg-${params.chatId}`,
    });
    n.onclick = () => {
      window.focus();
      n.close();
    };
  } catch {
    // ignore browser restrictions
  }
}

export function updateAppIconBadge(unreadCount: number): void {
  if (typeof window === "undefined" || typeof navigator === "undefined") return;
  const safeCount = Math.max(0, Math.floor(unreadCount));
  const nav = navigator as Navigator & {
    setAppBadge?: (contents?: number) => Promise<void>;
    clearAppBadge?: () => Promise<void>;
  };

  try {
    if (safeCount > 0 && typeof nav.setAppBadge === "function") {
      void nav.setAppBadge(safeCount).catch(() => {});
    } else if (safeCount === 0 && typeof nav.clearAppBadge === "function") {
      void nav.clearAppBadge().catch(() => {});
    }
  } catch {
    // ignore unsupported environments
  }

  if ("serviceWorker" in navigator) {
    void navigator.serviceWorker
      .getRegistration()
      .then((reg) => {
        const target = reg?.active || navigator.serviceWorker?.controller;
        target?.postMessage({
          type: "UPDATE_APP_BADGE",
          count: safeCount,
        });
      })
      .catch(() => {});
  }
}

export function consumeUrlOpenChatId(): string | null {
  if (typeof window === "undefined") return null;
  try {
    const url = new URL(window.location.href);
    const chatId = url.searchParams.get("openChatId");
    if (!chatId) return null;
    url.searchParams.delete("openChatId");
    window.history.replaceState({}, document.title, url.toString());
    return chatId;
  } catch {
    return null;
  }
}

export function subscribeToServiceWorkerOpenChat(
  handler: (chatId: string) => void
): () => void {
  if (typeof window === "undefined" || !("serviceWorker" in navigator)) {
    return () => {};
  }

  const onMessage = (event: MessageEvent) => {
    const data = event.data as { type?: string; chatId?: string } | undefined;
    if (!data || data.type !== "MIRSAL_OPEN_CHAT" || !data.chatId) return;
    handler(data.chatId);
  };

  navigator.serviceWorker.addEventListener("message", onMessage);
  return () => {
    navigator.serviceWorker.removeEventListener("message", onMessage);
  };
}

export async function notifyIncomingCallPush(_params: {
  targetUid: string;
  callId: string;
  chatId: string;
  callerId: string;
  callerName: string;
  callType: CallType;
}): Promise<void> {
  // Incoming calls are delivered in real time via Firestore listeners & active SW notification bridge
}

export async function notifyCallEndedPush(_params: {
  targetUid: string;
  callId: string;
}): Promise<void> {
  // Call end state is synced in real time via Firestore listeners & local SW notification cleanup
}
