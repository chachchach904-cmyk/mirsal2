// End-to-End Encryption (E2EE) Secret Chat Service using native Web Crypto API
// ECDH (P-256) key exchange + AES-GCM (256-bit) symmetric encryption

const E2EE_DB_NAME = "mirsal_e2ee_keys_v1";
const E2EE_STORE_NAME = "keypairs";
const E2EE_LS_PREFIX = "mirsal_e2ee_jwk_v1_";

interface StoredKeyPairRecord {
  uid: string;
  publicJwk: JsonWebKey;
  privateJwk: JsonWebKey;
  createdAt: number;
}

const memoryKeyCache = new Map<string, StoredKeyPairRecord>();
const derivedAesCache = new Map<string, CryptoKey>();

function openKeyDb(): Promise<IDBDatabase | null> {
  if (typeof indexedDB === "undefined") return Promise.resolve(null);
  return new Promise((resolve) => {
    try {
      const req = indexedDB.open(E2EE_DB_NAME, 1);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains(E2EE_STORE_NAME)) {
          db.createObjectStore(E2EE_STORE_NAME, { keyPath: "uid" });
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => resolve(null);
    } catch {
      resolve(null);
    }
  });
}

async function readRecordFromDb(uid: string): Promise<StoredKeyPairRecord | null> {
  const db = await openKeyDb();
  if (!db) return null;
  return new Promise((resolve) => {
    try {
      const tx = db.transaction(E2EE_STORE_NAME, "readonly");
      const store = tx.objectStore(E2EE_STORE_NAME);
      const req = store.get(uid);
      req.onsuccess = () => {
        const res = req.result as StoredKeyPairRecord | undefined;
        resolve(res && res.publicJwk && res.privateJwk ? res : null);
      };
      req.onerror = () => resolve(null);
    } catch {
      resolve(null);
    }
  });
}

async function writeRecordToDb(record: StoredKeyPairRecord): Promise<void> {
  const db = await openKeyDb();
  if (!db) return;
  await new Promise<void>((resolve) => {
    try {
      const tx = db.transaction(E2EE_STORE_NAME, "readwrite");
      const store = tx.objectStore(E2EE_STORE_NAME);
      store.put(record);
      tx.oncomplete = () => resolve();
      tx.onerror = () => resolve();
    } catch {
      resolve();
    }
  });
}

function readRecordFromLocalStorage(uid: string): StoredKeyPairRecord | null {
  try {
    const raw = localStorage.getItem(`${E2EE_LS_PREFIX}${uid}`);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as StoredKeyPairRecord;
    if (parsed && parsed.publicJwk && parsed.privateJwk) {
      return parsed;
    }
    return null;
  } catch {
    return null;
  }
}

function writeRecordToLocalStorage(record: StoredKeyPairRecord): void {
  try {
    localStorage.setItem(`${E2EE_LS_PREFIX}${record.uid}`, JSON.stringify(record));
  } catch {
    // ignore storage quota errors
  }
}

function arrayBufferToBase64(buf: ArrayBuffer): string {
  const bytes = new Uint8Array(buf);
  let binary = "";
  for (let i = 0; i < bytes.length; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function base64ToUint8Array(b64: string): Uint8Array {
  const binary = atob(b64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}

export function isWebCryptoAvailable(): boolean {
  return (
    typeof window !== "undefined" &&
    typeof crypto !== "undefined" &&
    Boolean(crypto.subtle)
  );
}

/**
 * Ensures the current user has a persistent ECDH P-256 keypair stored locally
 * (IndexedDB + localStorage backup) and returns the serialized public JWK string.
 */
export async function ensureDeviceE2eeKeys(uid: string): Promise<string | null> {
  if (!uid || !isWebCryptoAvailable()) return null;

  let record =
    memoryKeyCache.get(uid) ||
    (await readRecordFromDb(uid)) ||
    readRecordFromLocalStorage(uid);

  if (record) {
    memoryKeyCache.set(uid, record);
    writeRecordToLocalStorage(record);
    return JSON.stringify(record.publicJwk);
  }

  try {
    const keyPair = await crypto.subtle.generateKey(
      { name: "ECDH", namedCurve: "P-256" },
      true,
      ["deriveKey"]
    );

    const publicJwk = await crypto.subtle.exportKey("jwk", keyPair.publicKey);
    const privateJwk = await crypto.subtle.exportKey("jwk", keyPair.privateKey);

    record = {
      uid,
      publicJwk,
      privateJwk,
      createdAt: Date.now(),
    };

    memoryKeyCache.set(uid, record);
    writeRecordToLocalStorage(record);
    await writeRecordToDb(record);

    return JSON.stringify(publicJwk);
  } catch (err) {
    console.warn("E2EE key generation failed:", err);
    return null;
  }
}

async function getPrivateKeyForUid(uid: string): Promise<CryptoKey | null> {
  if (!uid || !isWebCryptoAvailable()) return null;
  let record =
    memoryKeyCache.get(uid) ||
    (await readRecordFromDb(uid)) ||
    readRecordFromLocalStorage(uid);

  if (!record) return null;
  memoryKeyCache.set(uid, record);

  try {
    return await crypto.subtle.importKey(
      "jwk",
      record.privateJwk,
      { name: "ECDH", namedCurve: "P-256" },
      false,
      ["deriveKey"]
    );
  } catch {
    return null;
  }
}

async function deriveSharedAesKey(
  myUid: string,
  peerPublicKeyJson: string
): Promise<CryptoKey | null> {
  if (!myUid || !peerPublicKeyJson || !isWebCryptoAvailable()) return null;

  const cacheKey = `${myUid}::${peerPublicKeyJson}`;
  const cached = derivedAesCache.get(cacheKey);
  if (cached) return cached;

  const myPrivateKey = await getPrivateKeyForUid(myUid);
  if (!myPrivateKey) return null;

  try {
    const peerJwk = JSON.parse(peerPublicKeyJson) as JsonWebKey;
    const peerPublicKey = await crypto.subtle.importKey(
      "jwk",
      peerJwk,
      { name: "ECDH", namedCurve: "P-256" },
      false,
      []
    );

    const aesKey = await crypto.subtle.deriveKey(
      { name: "ECDH", public: peerPublicKey },
      myPrivateKey,
      { name: "AES-GCM", length: 256 },
      false,
      ["encrypt", "decrypt"]
    );

    derivedAesCache.set(cacheKey, aesKey);
    return aesKey;
  } catch {
    return null;
  }
}

export interface EncryptedPayload {
  ciphertext: string;
  iv: string;
}

export async function encryptSecretMessage(
  myUid: string,
  peerPublicKeyJson: string,
  plaintext: string
): Promise<EncryptedPayload | null> {
  if (!plaintext || !peerPublicKeyJson || !isWebCryptoAvailable()) return null;

  const aesKey = await deriveSharedAesKey(myUid, peerPublicKeyJson);
  if (!aesKey) return null;

  try {
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const encoded = new TextEncoder().encode(plaintext);
    const cipherBuf = await crypto.subtle.encrypt(
      { name: "AES-GCM", iv },
      aesKey,
      encoded
    );

    return {
      ciphertext: arrayBufferToBase64(cipherBuf),
      iv: arrayBufferToBase64(iv.buffer),
    };
  } catch {
    return null;
  }
}

export const E2EE_FALLBACK_UNDECRYPTABLE =
  "🔒 تعذر فك التشفير — هذه الرسالة مشفرة بمفتاح جهاز آخر";

export async function decryptSecretMessage(
  myUid: string,
  peerPublicKeyJson: string | undefined,
  ciphertext: string | undefined,
  ivB64: string | undefined
): Promise<string> {
  if (!ciphertext || !ivB64 || !peerPublicKeyJson || !isWebCryptoAvailable()) {
    return E2EE_FALLBACK_UNDECRYPTABLE;
  }

  const aesKey = await deriveSharedAesKey(myUid, peerPublicKeyJson);
  if (!aesKey) {
    return E2EE_FALLBACK_UNDECRYPTABLE;
  }

  try {
    const ivBytes = base64ToUint8Array(ivB64);
    const cipherBytes = base64ToUint8Array(ciphertext);
    const plainBuf = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv: new Uint8Array(ivBytes) },
      aesKey,
      new Uint8Array(cipherBytes)
    );
    return new TextDecoder().decode(plainBuf);
  } catch {
    return E2EE_FALLBACK_UNDECRYPTABLE;
  }
}
