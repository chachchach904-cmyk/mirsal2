import {
  buildTranslationCacheKey,
  loadTranslationCache,
  saveTranslationCache,
} from "../utils/storage";

function detectSourceLangForMyMemory(
  text: string,
  targetLanguage: string
): string {
  const sample = text.trim();
  if (/[\u0600-\u06FF]/.test(sample)) {
    return targetLanguage === "ar" ? "fa" : "ar";
  }
  if (/[\u0400-\u04FF]/.test(sample)) {
    return targetLanguage === "ru" ? "en" : "ru";
  }
  if (/[\u4E00-\u9FFF]/.test(sample)) {
    return targetLanguage === "zh" ? "en" : "zh";
  }
  if (/[\u3040-\u30FF]/.test(sample)) {
    return targetLanguage === "ja" ? "en" : "ja";
  }
  if (/[\uAC00-\uD7AF]/.test(sample)) {
    return targetLanguage === "ko" ? "en" : "ko";
  }
  if (/[\u0900-\u097F]/.test(sample)) {
    return targetLanguage === "hi" ? "en" : "hi";
  }
  if (/[çğıöşüÇĞİÖŞÜ]/.test(sample)) {
    return targetLanguage === "tr" ? "en" : "tr";
  }
  if (/[àâæçéèêëîïôœùûüÿ]/i.test(sample)) {
    return targetLanguage === "fr" ? "en" : "fr";
  }
  if (/[ñáéíóúü¿¡]/i.test(sample)) {
    return targetLanguage === "es" ? "en" : "es";
  }
  if (/[äöüß]/i.test(sample)) {
    return targetLanguage === "de" ? "en" : "de";
  }
  return targetLanguage === "en" ? "ar" : "en";
}

async function fetchWithTimeout(
  url: string,
  init: RequestInit | undefined,
  timeoutMs: number
): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, {
      ...init,
      signal: controller.signal,
    });
  } finally {
    clearTimeout(timer);
  }
}

async function translateViaGooglePublic(
  text: string,
  targetLanguage: string
): Promise<string | null> {
  try {
    const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=${encodeURIComponent(
      targetLanguage
    )}&dt=t&q=${encodeURIComponent(text)}`;

    const res = await fetchWithTimeout(url, { method: "GET" }, 4500);
    if (!res.ok) return null;

    const data = (await res.json()) as unknown;
    if (!Array.isArray(data) || !Array.isArray(data[0])) return null;

    const chunks = (data[0] as unknown[])
      .map((entry) =>
        Array.isArray(entry) && typeof entry[0] === "string" ? entry[0] : ""
      )
      .filter(Boolean);

    const joined = chunks.join("").trim();
    return joined.length > 0 ? joined : null;
  } catch {
    return null;
  }
}

async function translateViaMyMemory(
  text: string,
  targetLanguage: string
): Promise<string | null> {
  try {
    const sourceLang = detectSourceLangForMyMemory(text, targetLanguage);
    const snippet = text.trim().slice(0, 500);
    const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(
      snippet
    )}&langpair=${encodeURIComponent(`${sourceLang}|${targetLanguage}`)}`;

    const res = await fetchWithTimeout(url, { method: "GET" }, 4500);
    if (!res.ok) return null;

    const data = (await res.json()) as {
      responseStatus?: number;
      responseData?: { translatedText?: string };
    };

    const translated = data?.responseData?.translatedText?.trim();
    if (!translated || data.responseStatus === 403 || data.responseStatus === 429) {
      return null;
    }
    if (translated.toUpperCase().includes("MYMEMORY WARNING")) {
      return null;
    }
    return translated;
  } catch {
    return null;
  }
}

async function translateViaServerFallback(
  text: string,
  targetLanguage: string
): Promise<string | null> {
  try {
    const res = await fetchWithTimeout(
      "/api/translate",
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text, targetLanguage }),
      },
      5500
    );
    if (!res.ok) return null;
    const data = (await res.json()) as { translatedText?: string };
    return data.translatedText?.trim() || null;
  } catch {
    return null;
  }
}

/**
 * Translates text directly from the browser using Google Translate's fast public API,
 * automatically falling back to MyMemory API (and then /api/translate if needed).
 * Never rejects with UI-breaking translation errors.
 */
export async function translateTextFast(
  text: string,
  targetLanguage: string
): Promise<string> {
  const cleanText = text.trim();
  if (!cleanText) return "";

  const cacheKey = buildTranslationCacheKey(cleanText, targetLanguage);
  const existingCache = loadTranslationCache();
  if (existingCache[cacheKey]) {
    return existingCache[cacheKey];
  }

  // 1. Primary: Direct browser call to translate.googleapis.com
  let translated = await translateViaGooglePublic(cleanText, targetLanguage);

  // 2. Automatic fallback: MyMemory API
  if (!translated) {
    translated = await translateViaMyMemory(cleanText, targetLanguage);
  }

  // 3. Final fallback: Server translation endpoint
  if (!translated) {
    translated = await translateViaServerFallback(cleanText, targetLanguage);
  }

  const finalText = (translated || cleanText).trim();
  if (translated) {
    const nextCache = { ...loadTranslationCache(), [cacheKey]: finalText };
    saveTranslationCache(nextCache);
  }

  return finalText;
}
