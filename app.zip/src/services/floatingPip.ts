export interface FloatingPipMessageItem {
  id: string;
  senderName: string;
  isMine: boolean;
  text: string;
  timeLabel: string;
}

export interface FloatingPipSnapshot {
  chatId: string | null;
  chatTitle: string;
  peerOnline?: boolean;
  unreadCount: number;
  messages: FloatingPipMessageItem[];
  onFocusChat?: (chatId: string) => void;
}

interface DocumentPictureInPictureApi {
  requestWindow: (options?: {
    width?: number;
    height?: number;
    disallowReturnToOpener?: boolean;
  }) => Promise<Window>;
  window?: Window | null;
}

let activeDocPipWin: Window | null = null;
let helperVideoEl: HTMLVideoElement | null = null;
let helperStream: MediaStream | null = null;
let helperCanvas: HTMLCanvasElement | null = null;
let latestSnapshot: FloatingPipSnapshot | null = null;

export function isFloatingPipSupported(): boolean {
  if (typeof window === "undefined" || typeof document === "undefined") {
    return false;
  }
  const hasDocPip =
    "documentPictureInPicture" in window &&
    typeof (
      window as Window & {
        documentPictureInPicture?: DocumentPictureInPictureApi;
      }
    ).documentPictureInPicture?.requestWindow === "function";
  const hasVideoPip = Boolean(document.pictureInPictureEnabled);
  return hasDocPip || hasVideoPip;
}

function renderDocumentPipDom(pipWin: Window, snapshot: FloatingPipSnapshot): void {
  const doc = pipWin.document;
  doc.documentElement.lang = "ar";
  doc.documentElement.dir = "rtl";
  doc.title = snapshot.unreadCount > 0
    ? `(${snapshot.unreadCount}) مرسال — ${snapshot.chatTitle}`
    : `مرسال — ${snapshot.chatTitle}`;

  doc.head.replaceChildren();
  const styleEl = doc.createElement("style");
  styleEl.textContent = `
    * { box-sizing: border-box; font-family: system-ui, -apple-system, sans-serif; }
    body { margin: 0; background: #0b141a; color: #e2e8f0; display: flex; flex-direction: column; height: 100vh; overflow: hidden; }
    .hdr { background: linear-gradient(135deg, #075E54, #0d7a5f); padding: 10px 12px; display: flex; align-items: center; justify-content: space-between; gap: 8px; }
    .title { font-size: 13px; font-weight: 700; color: #fff; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .sub { font-size: 11px; color: #d1fae5; }
    .badge { background: #ef4444; color: #fff; font-size: 11px; font-weight: 800; border-radius: 999px; padding: 2px 7px; }
    .msgs { flex: 1; overflow-y: auto; padding: 10px; display: flex; flex-direction: column; gap: 6px; }
    .msg { max-width: 86%; padding: 7px 10px; border-radius: 12px; font-size: 12px; line-height: 1.45; word-break: break-word; }
    .mine { align-self: flex-start; background: #005c4b; color: #fff; }
    .peer { align-self: flex-end; background: #202c33; color: #f1f5f9; }
    .meta { font-size: 9.5px; opacity: 0.72; margin-top: 2px; }
    .ftr { padding: 8px 10px; border-top: 1px solid #1f2c34; background: #111b21; display: flex; justify-content: center; }
    .btn { width: 100%; border: 0; border-radius: 10px; background: #00a884; color: #fff; font-size: 12px; font-weight: 700; padding: 8px 12px; cursor: pointer; }
  `;
  doc.head.appendChild(styleEl);

  doc.body.replaceChildren();

  const header = doc.createElement("div");
  header.className = "hdr";

  const info = doc.createElement("div");
  const titleEl = doc.createElement("div");
  titleEl.className = "title";
  titleEl.textContent = snapshot.chatTitle || "مرسال";
  const subEl = doc.createElement("div");
  subEl.className = "sub";
  subEl.textContent = snapshot.peerOnline ? "متصل الآن" : "مرسال — الوضع العائم";
  info.appendChild(titleEl);
  info.appendChild(subEl);
  header.appendChild(info);

  if (snapshot.unreadCount > 0) {
    const badge = doc.createElement("span");
    badge.className = "badge";
    badge.textContent = String(snapshot.unreadCount);
    header.appendChild(badge);
  }

  const msgsWrap = doc.createElement("div");
  msgsWrap.className = "msgs";
  const recent = snapshot.messages.slice(-8);
  if (recent.length === 0) {
    const empty = doc.createElement("div");
    empty.className = "msg peer";
    empty.textContent = "جاهز لاستقبال الرسائل الفورية في مرسال.";
    msgsWrap.appendChild(empty);
  } else {
    recent.forEach((m) => {
      const bubble = doc.createElement("div");
      bubble.className = `msg ${m.isMine ? "mine" : "peer"}`;
      const textDiv = doc.createElement("div");
      textDiv.textContent = m.text;
      const metaDiv = doc.createElement("div");
      metaDiv.className = "meta";
      metaDiv.textContent = `${m.isMine ? "أنت" : m.senderName} · ${m.timeLabel}`;
      bubble.appendChild(textDiv);
      bubble.appendChild(metaDiv);
      msgsWrap.appendChild(bubble);
    });
  }

  const footer = doc.createElement("div");
  footer.className = "ftr";
  const openBtn = doc.createElement("button");
  openBtn.type = "button";
  openBtn.className = "btn";
  openBtn.textContent = "العودة إلى تطبيق مرسال";
  openBtn.onclick = () => {
    try {
      window.focus();
      if (snapshot.chatId && snapshot.onFocusChat) {
        snapshot.onFocusChat(snapshot.chatId);
      }
      pipWin.close();
    } catch {
      // ignore
    }
  };
  footer.appendChild(openBtn);

  doc.body.appendChild(header);
  doc.body.appendChild(msgsWrap);
  doc.body.appendChild(footer);
  msgsWrap.scrollTop = msgsWrap.scrollHeight;
}

function drawCanvasCard(snapshot: FloatingPipSnapshot): void {
  if (!helperCanvas) return;
  const ctx = helperCanvas.getContext("2d");
  if (!ctx) return;

  const w = helperCanvas.width;
  const h = helperCanvas.height;

  ctx.fillStyle = "#0b141a";
  ctx.fillRect(0, 0, w, h);

  const grad = ctx.createLinearGradient(0, 0, w, 62);
  grad.addColorStop(0, "#075E54");
  grad.addColorStop(1, "#0d7a5f");
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, w, 62);

  ctx.fillStyle = "#ffffff";
  ctx.font = "bold 20px sans-serif";
  ctx.textAlign = "right";
  ctx.fillText(snapshot.chatTitle || "مرسال", w - 18, 38);

  if (snapshot.unreadCount > 0) {
    ctx.fillStyle = "#ef4444";
    ctx.beginPath();
    ctx.arc(32, 31, 16, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 15px sans-serif";
    ctx.textAlign = "center";
    ctx.fillText(String(snapshot.unreadCount), 32, 36);
  }

  const last = snapshot.messages[snapshot.messages.length - 1];
  ctx.fillStyle = "#e2e8f0";
  ctx.font = "16px sans-serif";
  ctx.textAlign = "right";
  const previewLine = last
    ? `${last.isMine ? "أنت" : last.senderName}: ${last.text}`.slice(0, 48)
    : "الوضع العائم مفعّل — مرسال";
  ctx.fillText(previewLine, w - 18, 118);

  ctx.fillStyle = "#00a884";
  ctx.font = "bold 13px sans-serif";
  ctx.fillText("اضغط للعودة إلى المحادثة", w - 18, h - 22);
}

export function updateFloatingPipContent(snapshot: FloatingPipSnapshot): void {
  latestSnapshot = snapshot;
  if (activeDocPipWin && !activeDocPipWin.closed) {
    try {
      renderDocumentPipDom(activeDocPipWin, snapshot);
    } catch {
      // ignore
    }
  }
  if (helperCanvas) {
    drawCanvasCard(snapshot);
  }
}

export async function enterAutoFloatingPip(
  snapshot: FloatingPipSnapshot
): Promise<boolean> {
  if (typeof window === "undefined" || typeof document === "undefined") {
    return false;
  }
  latestSnapshot = snapshot;

  // 1. Prefer Document Picture-in-Picture API if supported
  const docPip = (
    window as Window & {
      documentPictureInPicture?: DocumentPictureInPictureApi;
    }
  ).documentPictureInPicture;

  if (docPip && typeof docPip.requestWindow === "function") {
    if (activeDocPipWin && !activeDocPipWin.closed) {
      renderDocumentPipDom(activeDocPipWin, snapshot);
      return true;
    }
    try {
      const pipWin = await docPip.requestWindow({
        width: 340,
        height: 410,
      });
      activeDocPipWin = pipWin;
      renderDocumentPipDom(pipWin, latestSnapshot || snapshot);
      pipWin.addEventListener("pagehide", () => {
        if (activeDocPipWin === pipWin) {
          activeDocPipWin = null;
        }
      });
      return true;
    } catch {
      // Fall back to standard video PiP below if Document PiP was blocked/unavailable
    }
  }

  // 2. Fall back to Video Picture-in-Picture API
  if (!document.pictureInPictureEnabled) {
    return false;
  }

  if (document.pictureInPictureElement) {
    return true;
  }

  try {
    const candidateVideos = Array.from(document.querySelectorAll("video"));
    const playingVideo = candidateVideos.find(
      (v) =>
        v !== helperVideoEl &&
        !v.disablePictureInPicture &&
        v.readyState >= 2 &&
        typeof v.requestPictureInPicture === "function"
    );
    if (playingVideo) {
      await playingVideo.requestPictureInPicture();
      return true;
    }

    if (!helperCanvas) {
      helperCanvas = document.createElement("canvas");
      helperCanvas.width = 420;
      helperCanvas.height = 200;
    }
    drawCanvasCard(snapshot);

    if (
      typeof helperCanvas.captureStream === "function" &&
      (!helperVideoEl || !helperStream)
    ) {
      helperStream = helperCanvas.captureStream(1);
      helperVideoEl = document.createElement("video");
      helperVideoEl.muted = true;
      helperVideoEl.playsInline = true;
      helperVideoEl.srcObject = helperStream;
      helperVideoEl.className = "sr-only fixed -left-[9999px] w-px h-px pointer-events-none";
      document.body.appendChild(helperVideoEl);
    }

    if (helperVideoEl && typeof helperVideoEl.requestPictureInPicture === "function") {
      await helperVideoEl.play().catch(() => {});
      await helperVideoEl.requestPictureInPicture();
      return true;
    }
  } catch {
    // Graceful no-op when browser policy requires explicit gesture or disables background PiP
  }

  return false;
}

export async function exitAutoFloatingPip(): Promise<void> {
  if (activeDocPipWin) {
    try {
      if (!activeDocPipWin.closed) {
        activeDocPipWin.close();
      }
    } catch {
      // ignore
    }
    activeDocPipWin = null;
  }

  if (typeof document !== "undefined" && document.pictureInPictureElement) {
    try {
      await document.exitPictureInPicture();
    } catch {
      // ignore
    }
  }

  if (helperVideoEl) {
    try {
      helperVideoEl.pause();
    } catch {
      // ignore
    }
  }
}
