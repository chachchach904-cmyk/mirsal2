import type { MessageToneId, RingtoneId, SoundPrefs } from "../types/chat";
import { loadSoundPrefs } from "../utils/storage";

export const MESSAGE_TONE_OPTIONS: Array<{ id: MessageToneId; label: string }> = [
  { id: "soft-bell", label: "جرس ناعم (افتراضي)" },
  { id: "crystal-drop", label: "قطرة كريستال" },
  { id: "modern-chime", label: "نغمة حديثة دافئة" },
];

export const RINGTONE_OPTIONS: Array<{ id: RingtoneId; label: string }> = [
  { id: "mirsal-classic", label: "مرسال الكلاسيكية (افتراضي)" },
  { id: "crystal-calm", label: "صفاء الكريستال" },
  { id: "modern-marimba", label: "ماريمبا عصرية" },
  { id: "fast-digital", label: "رنين رقمي حيوي" },
  { id: "warm-strings", label: "أوتار دافئة" },
  { id: "royal-rhythm", label: "إيقاع ملكي" },
  { id: "double-alert", label: "تنبيه هاتفي مزدوج" },
];

let sharedAudioCtx: AudioContext | null = null;
let unlockInitialized = false;
let incomingRingTimer: ReturnType<typeof setInterval> | null = null;
let outgoingRingTimer: ReturnType<typeof setInterval> | null = null;
let previewRingTimer: ReturnType<typeof setTimeout> | null = null;
let activeRingMasterGain: GainNode | null = null;
let activeRingbackMasterGain: GainNode | null = null;

function createOrGetAudioContext(): AudioContext | null {
  if (typeof window === "undefined") return null;
  if (!sharedAudioCtx) {
    const AudioCtx =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext?: typeof AudioContext })
        .webkitAudioContext;
    if (!AudioCtx) return null;
    sharedAudioCtx = new AudioCtx();
  }
  return sharedAudioCtx;
}

function playSilentUnlockSample(ctx: AudioContext): void {
  try {
    const buffer = ctx.createBuffer(1, 1, 22050);
    const source = ctx.createBufferSource();
    source.buffer = buffer;
    source.connect(ctx.destination);
    source.start(0);
  } catch {
    // ignore
  }
}

export function unlockAudioContext(): void {
  const ctx = createOrGetAudioContext();
  if (!ctx) return;
  if (ctx.state === "suspended") {
    void ctx
      .resume()
      .then(() => {
        playSilentUnlockSample(ctx);
      })
      .catch(() => {});
  } else if (ctx.state === "running") {
    playSilentUnlockSample(ctx);
  }
}

export function initAudioUnlock(): void {
  if (typeof window === "undefined" || unlockInitialized) return;
  unlockInitialized = true;

  const removeListeners = () => {
    window.removeEventListener("touchstart", unlock, true);
    window.removeEventListener("pointerdown", unlock, true);
    window.removeEventListener("keydown", unlock, true);
  };

  const unlock = () => {
    const ctx = createOrGetAudioContext();
    if (!ctx) return;
    if (ctx.state === "running") {
      playSilentUnlockSample(ctx);
      removeListeners();
      return;
    }
    void ctx
      .resume()
      .then(() => {
        playSilentUnlockSample(ctx);
        if (ctx.state === "running") {
          removeListeners();
        }
      })
      .catch(() => {});
  };

  window.addEventListener("touchstart", unlock, { passive: true, capture: true });
  window.addEventListener("pointerdown", unlock, { passive: true, capture: true });
  window.addEventListener("keydown", unlock, { passive: true, capture: true });
}

function withRunningAudioContext(fn: (ctx: AudioContext) => void): void {
  const ctx = createOrGetAudioContext();
  if (!ctx) return;
  if (ctx.state === "running") {
    fn(ctx);
    return;
  }
  if (ctx.state === "suspended") {
    void ctx
      .resume()
      .then(() => {
        if (ctx.state === "running") {
          fn(ctx);
        }
      })
      .catch(() => {});
  }
}

function getEffectivePrefs(): SoundPrefs {
  return loadSoundPrefs();
}

function getVolumeScale(prefs: SoundPrefs): number {
  if (prefs.muted || prefs.volume <= 0) return 0;
  return Math.max(0.05, Math.min(1, prefs.volume / 100));
}

function playToneBurst(params: {
  ctx: AudioContext;
  frequencies: number[];
  startTime: number;
  duration: number;
  peakGain: number;
  type?: OscillatorType;
  destination?: AudioNode;
}) {
  const {
    ctx,
    frequencies,
    startTime,
    duration,
    peakGain,
    type = "sine",
    destination,
  } = params;
  if (peakGain <= 0.0002) return;

  const master = ctx.createGain();
  master.gain.setValueAtTime(0.0001, startTime);
  master.gain.exponentialRampToValueAtTime(peakGain, startTime + 0.016);
  master.gain.setValueAtTime(
    peakGain,
    Math.max(startTime + 0.02, startTime + duration - 0.04)
  );
  master.gain.exponentialRampToValueAtTime(0.0001, startTime + duration);
  master.connect(destination || ctx.destination);

  const perOscGain = 1 / Math.max(1, frequencies.length);
  frequencies.forEach((freq) => {
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, startTime);
    g.gain.setValueAtTime(perOscGain, startTime);
    osc.connect(g);
    g.connect(master);
    osc.start(startTime);
    osc.stop(startTime + duration + 0.025);
  });
}

function renderMessageTone(toneId: MessageToneId, scale: number): void {
  if (scale <= 0) return;
  withRunningAudioContext((ctx) => {
    const now = ctx.currentTime + 0.01;

    if (toneId === "crystal-drop") {
      playToneBurst({
        ctx,
        frequencies: [987.77],
        startTime: now,
        duration: 0.08,
        peakGain: 0.12 * scale,
        type: "sine",
      });
      playToneBurst({
        ctx,
        frequencies: [1318.51],
        startTime: now + 0.075,
        duration: 0.17,
        peakGain: 0.13 * scale,
        type: "sine",
      });
      return;
    }

    if (toneId === "modern-chime") {
      playToneBurst({
        ctx,
        frequencies: [587.33, 880],
        startTime: now,
        duration: 0.11,
        peakGain: 0.11 * scale,
        type: "triangle",
      });
      playToneBurst({
        ctx,
        frequencies: [783.99, 1174.66],
        startTime: now + 0.09,
        duration: 0.18,
        peakGain: 0.12 * scale,
        type: "sine",
      });
      return;
    }

    // Default: soft-bell (G5 -> C6)
    playToneBurst({
      ctx,
      frequencies: [783.99],
      startTime: now,
      duration: 0.09,
      peakGain: 0.12 * scale,
      type: "sine",
    });
    playToneBurst({
      ctx,
      frequencies: [1046.5],
      startTime: now + 0.085,
      duration: 0.18,
      peakGain: 0.13 * scale,
      type: "sine",
    });
  });
}

export function playMessageTone(toneId?: MessageToneId): void {
  const prefs = getEffectivePrefs();
  const scale = getVolumeScale(prefs);
  if (scale <= 0) return;
  renderMessageTone(toneId || prefs.messageTone || "soft-bell", scale);
}

export function previewMessageTone(toneId: MessageToneId): void {
  unlockAudioContext();
  const prefs = getEffectivePrefs();
  const scale = prefs.muted ? 0.75 : getVolumeScale(prefs) || 0.75;
  renderMessageTone(toneId, scale);
}

export function playMessageReceivedSound(): void {
  playMessageTone();
}

export function playMessageSentSound(): void {
  const prefs = getEffectivePrefs();
  const scale = getVolumeScale(prefs);
  if (scale <= 0) return;

  withRunningAudioContext((ctx) => {
    const now = ctx.currentTime + 0.01;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "sine";
    osc.frequency.setValueAtTime(520, now);
    osc.frequency.exponentialRampToValueAtTime(780, now + 0.09);

    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(0.09 * scale, now + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.12);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.14);
  });
}

export function playSaveClickSound(): void {
  const prefs = getEffectivePrefs();
  const scale = getVolumeScale(prefs);
  if (scale <= 0) return;

  withRunningAudioContext((ctx) => {
    const now = ctx.currentTime + 0.01;
    playToneBurst({
      ctx,
      frequencies: [880],
      startTime: now,
      duration: 0.06,
      peakGain: 0.075 * scale,
      type: "sine",
    });
  });
}

function silenceGainNode(node: GainNode | null): void {
  if (!node) return;
  try {
    const ctx = node.context;
    const now = ctx.currentTime;
    node.gain.cancelScheduledValues(now);
    node.gain.setValueAtTime(Math.max(0.0001, node.gain.value), now);
    node.gain.exponentialRampToValueAtTime(0.0001, now + 0.02);
    setTimeout(() => {
      try {
        node.disconnect();
      } catch {
        // ignore
      }
    }, 35);
  } catch {
    // ignore
  }
}

function renderRingtoneCycle(ringtoneId: RingtoneId, scale: number): void {
  if (scale <= 0) return;
  withRunningAudioContext((ctx) => {
    silenceGainNode(activeRingMasterGain);
    const bus = ctx.createGain();
    bus.gain.setValueAtTime(1, ctx.currentTime);
    bus.connect(ctx.destination);
    activeRingMasterGain = bus;

    const now = ctx.currentTime + 0.02;

    switch (ringtoneId) {
      case "crystal-calm": {
        const notes = [659.25, 783.99, 987.77, 1318.51];
        notes.forEach((f, idx) => {
          playToneBurst({
            ctx,
            frequencies: [f],
            startTime: now + idx * 0.16,
            duration: 0.24,
            peakGain: 0.18 * scale,
            type: "sine",
            destination: bus,
          });
        });
        break;
      }
      case "modern-marimba": {
        const pattern = [523.25, 659.25, 783.99, 659.25, 1046.5];
        pattern.forEach((f, idx) => {
          playToneBurst({
            ctx,
            frequencies: [f],
            startTime: now + idx * 0.13,
            duration: 0.18,
            peakGain: 0.2 * scale,
            type: "triangle",
            destination: bus,
          });
        });
        break;
      }
      case "fast-digital": {
        for (let i = 0; i < 4; i++) {
          playToneBurst({
            ctx,
            frequencies: [880, 1174.66],
            startTime: now + i * 0.18,
            duration: 0.11,
            peakGain: 0.18 * scale,
            type: "sine",
            destination: bus,
          });
        }
        break;
      }
      case "warm-strings": {
        playToneBurst({
          ctx,
          frequencies: [392.0, 493.88, 587.33],
          startTime: now,
          duration: 0.45,
          peakGain: 0.18 * scale,
          type: "triangle",
          destination: bus,
        });
        playToneBurst({
          ctx,
          frequencies: [440.0, 554.37, 659.25],
          startTime: now + 0.5,
          duration: 0.52,
          peakGain: 0.19 * scale,
          type: "triangle",
          destination: bus,
        });
        break;
      }
      case "royal-rhythm": {
        const seq = [
          { freqs: [523.25, 659.25], t: 0, d: 0.22 },
          { freqs: [659.25, 783.99], t: 0.24, d: 0.22 },
          { freqs: [783.99, 1046.5], t: 0.48, d: 0.42 },
        ];
        seq.forEach((s) =>
          playToneBurst({
            ctx,
            frequencies: s.freqs,
            startTime: now + s.t,
            duration: s.d,
            peakGain: 0.19 * scale,
            type: "sine",
            destination: bus,
          })
        );
        break;
      }
      case "double-alert": {
        playToneBurst({
          ctx,
          frequencies: [740, 932.33],
          startTime: now,
          duration: 0.22,
          peakGain: 0.2 * scale,
          type: "sine",
          destination: bus,
        });
        playToneBurst({
          ctx,
          frequencies: [740, 932.33],
          startTime: now + 0.3,
          duration: 0.22,
          peakGain: 0.2 * scale,
          type: "sine",
          destination: bus,
        });
        playToneBurst({
          ctx,
          frequencies: [740, 932.33],
          startTime: now + 0.62,
          duration: 0.32,
          peakGain: 0.21 * scale,
          type: "sine",
          destination: bus,
        });
        break;
      }
      case "mirsal-classic":
      default: {
        playToneBurst({
          ctx,
          frequencies: [659.25, 830.61, 987.77],
          startTime: now,
          duration: 0.28,
          peakGain: 0.2 * scale,
          type: "sine",
          destination: bus,
        });
        playToneBurst({
          ctx,
          frequencies: [659.25, 830.61, 987.77],
          startTime: now + 0.36,
          duration: 0.36,
          peakGain: 0.22 * scale,
          type: "sine",
          destination: bus,
        });
        break;
      }
    }
  });
}

export function stopCallVibration(): void {
  if (typeof navigator !== "undefined" && typeof navigator.vibrate === "function") {
    try {
      navigator.vibrate(0);
    } catch {
      // ignore
    }
  }
}

export function stopRingtone(): void {
  if (incomingRingTimer) {
    clearInterval(incomingRingTimer);
    incomingRingTimer = null;
  }
  if (previewRingTimer) {
    clearTimeout(previewRingTimer);
    previewRingTimer = null;
  }
  silenceGainNode(activeRingMasterGain);
  activeRingMasterGain = null;
  stopCallVibration();
}

export function stopIncomingRingtone(): void {
  stopRingtone();
}

export function startRingtone(
  customRingtone?: RingtoneId,
  vibrate?: boolean
): void {
  stopOutgoingRingback();
  if (incomingRingTimer) return;
  const prefs = getEffectivePrefs();
  const scale = getVolumeScale(prefs);
  const ringtoneId = customRingtone || prefs.ringtone || "mirsal-classic";
  const shouldVibrate =
    typeof vibrate === "boolean" ? vibrate : prefs.callVibration !== false;

  const fire = () => {
    const latestPrefs = getEffectivePrefs();
    const latestScale = getVolumeScale(latestPrefs);
    if (latestScale > 0) {
      renderRingtoneCycle(
        customRingtone || latestPrefs.ringtone || ringtoneId,
        latestScale
      );
    }
    if (
      shouldVibrate &&
      latestPrefs.callVibration !== false &&
      typeof navigator !== "undefined" &&
      typeof navigator.vibrate === "function"
    ) {
      try {
        navigator.vibrate([260, 120, 320]);
      } catch {
        // ignore
      }
    }
  };

  if (scale <= 0 && !shouldVibrate) return;
  fire();
  incomingRingTimer = setInterval(fire, 2300);
}

export function startIncomingRingtone(): void {
  startRingtone();
}

export function previewRingtone(ringtoneId: RingtoneId): void {
  unlockAudioContext();
  if (previewRingTimer) {
    clearTimeout(previewRingTimer);
    previewRingTimer = null;
  }
  const prefs = getEffectivePrefs();
  const scale = prefs.muted ? 0.75 : getVolumeScale(prefs) || 0.75;
  renderRingtoneCycle(ringtoneId, scale);
  previewRingTimer = setTimeout(() => {
    previewRingTimer = null;
  }, 1500);
}

function triggerOutgoingRingbackCycle(): void {
  const prefs = getEffectivePrefs();
  const scale = getVolumeScale(prefs);
  if (scale <= 0) return;

  withRunningAudioContext((ctx) => {
    silenceGainNode(activeRingbackMasterGain);
    const bus = ctx.createGain();
    bus.gain.setValueAtTime(1, ctx.currentTime);
    bus.connect(ctx.destination);
    activeRingbackMasterGain = bus;

    const now = ctx.currentTime + 0.02;
    // Clear dual-pulse ringback ("طوط.. طوط") audible on both earpieces & mobile speakers
    playToneBurst({
      ctx,
      frequencies: [425, 850],
      startTime: now,
      duration: 0.42,
      peakGain: 0.13 * scale,
      type: "sine",
      destination: bus,
    });
    playToneBurst({
      ctx,
      frequencies: [425, 850],
      startTime: now + 0.56,
      duration: 0.42,
      peakGain: 0.13 * scale,
      type: "sine",
      destination: bus,
    });
  });
}

export function startOutgoingRingback(): void {
  stopRingtone();
  if (outgoingRingTimer) return;
  const prefs = getEffectivePrefs();
  if (getVolumeScale(prefs) <= 0) return;
  triggerOutgoingRingbackCycle();
  outgoingRingTimer = setInterval(() => {
    triggerOutgoingRingbackCycle();
  }, 2900);
}

export function stopOutgoingRingback(): void {
  if (outgoingRingTimer) {
    clearInterval(outgoingRingTimer);
    outgoingRingTimer = null;
  }
  silenceGainNode(activeRingbackMasterGain);
  activeRingbackMasterGain = null;
}

export function stopAllCallTones(): void {
  stopRingtone();
  stopOutgoingRingback();
}
