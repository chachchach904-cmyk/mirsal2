import { useCallback, useEffect, useRef, useState } from "react";
import type {
  CallOutcome,
  CallStatus,
  CallType,
  ChatCallSignal,
  ScreenShareMode,
  ScreenShareSignal,
  ScreenShareStatus,
  WatchAudioSignal,
} from "../types/chat";
import {
  addIceCandidateDoc,
  addScreenShareCandidateDoc,
  addWatchAudioCandidateDoc,
  answerCallSignalDoc,
  answerScreenShareDoc,
  answerWatchAudioDoc,
  cleanupStaleWatchAudio,
  createCallSignalDoc,
  createScreenShareDoc,
  createWatchAudioDoc,
  endCallSignalDoc,
  endScreenShareDoc,
  endWatchAudioDoc,
  subscribeToCallCandidates,
  subscribeToCallDoc,
  subscribeToChatWatchAudio,
  subscribeToScreenShareCandidates,
  subscribeToScreenShareDoc,
  subscribeToWatchAudioCandidates,
  subscribeToWatchAudioDoc,
} from "./firebase";
import {
  startOutgoingRingback,
  stopCallVibration,
  stopOutgoingRingback,
  stopRingtone,
} from "./sounds";

const DEFAULT_ICE_CONFIG: RTCConfiguration = {
  iceServers: [
    {
      urls: [
        "stun:stun.l.google.com:19302",
        "stun:stun1.l.google.com:19302",
      ],
    },
  ],
};

const COMPATIBLE_AUDIO_CONSTRAINTS: MediaTrackConstraints = {
  echoCancellation: true,
  noiseSuppression: true,
  autoGainControl: true,
};

async function acquireCallMediaStream(
  callType: CallType,
  facingMode: "user" | "environment" = "user"
): Promise<MediaStream> {
  return navigator.mediaDevices.getUserMedia({
    audio: COMPATIBLE_AUDIO_CONSTRAINTS,
    video: callType === "video" ? { facingMode } : false,
  });
}

export interface EndedCallSummary {
  callId: string;
  chatId: string;
  callerId: string;
  callType: CallType;
  outcome: CallOutcome;
  durationSeconds: number;
  role: "caller" | "callee";
}

export interface ActiveCallSession {
  callId: string;
  chatId: string;
  chatTitle: string;
  callerId: string;
  peerName: string;
  peerAvatar?: string;
  callType: CallType;
  status: CallStatus;
  role: "caller" | "callee";
}

export function useWebRtcCall(params: {
  uid: string | undefined;
  userName: string;
  onCallEnded?: (summary: EndedCallSummary) => void;
}) {
  const { uid, userName, onCallEnded } = params;

  const [activeCall, setActiveCall] = useState<ActiveCallSession | null>(null);
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [remoteStream, setRemoteStream] = useState<MediaStream | null>(null);
  const [isMuted, setIsMuted] = useState(false);
  const [isCameraOff, setIsCameraOff] = useState(false);
  const [facingMode, setFacingMode] = useState<"user" | "environment">("user");
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [callError, setCallError] = useState<string | null>(null);

  const pcRef = useRef<RTCPeerConnection | null>(null);
  const localStreamRef = useRef<MediaStream | null>(null);
  const activeCallRef = useRef<ActiveCallSession | null>(null);
  const callUnsubRef = useRef<(() => void) | null>(null);
  const candUnsubRef = useRef<(() => void) | null>(null);
  const pendingCandidatesRef = useRef<RTCIceCandidateInit[]>([]);
  const connectedAtRef = useRef<number | null>(null);
  const endedCallIdsRef = useRef<Set<string>>(new Set());
  const onCallEndedRef = useRef(onCallEnded);

  activeCallRef.current = activeCall;
  onCallEndedRef.current = onCallEnded;

  const dispatchCallEndedOnce = useCallback(
    (
      session: ActiveCallSession | null,
      explicitOutcome?: CallOutcome
    ) => {
      if (!session || endedCallIdsRef.current.has(session.callId)) return;
      endedCallIdsRef.current.add(session.callId);

      const durationSeconds = connectedAtRef.current
        ? Math.max(1, Math.round((Date.now() - connectedAtRef.current) / 1000))
        : 0;
      const outcome: CallOutcome =
        explicitOutcome ||
        (connectedAtRef.current ? "completed" : "missed");

      onCallEndedRef.current?.({
        callId: session.callId,
        chatId: session.chatId,
        callerId: session.callerId,
        callType: session.callType,
        outcome,
        durationSeconds,
        role: session.role,
      });
    },
    []
  );

  // Manage outgoing ringback & duration timer
  useEffect(() => {
    if (!activeCall) {
      stopOutgoingRingback();
      setElapsedSeconds(0);
      return;
    }

    if (activeCall.status === "ringing" && activeCall.role === "caller") {
      startOutgoingRingback();
      setElapsedSeconds(0);
      return () => {
        stopOutgoingRingback();
      };
    }

    stopOutgoingRingback();

    if (activeCall.status !== "connected") {
      setElapsedSeconds(0);
      return;
    }

    if (!connectedAtRef.current) {
      connectedAtRef.current = Date.now();
    }
    const timer = setInterval(() => {
      setElapsedSeconds((s) => s + 1);
    }, 1000);
    return () => clearInterval(timer);
  }, [activeCall?.callId, activeCall?.status, activeCall?.role]);

  const cleanupCallResources = useCallback(() => {
    stopOutgoingRingback();
    callUnsubRef.current?.();
    callUnsubRef.current = null;
    candUnsubRef.current?.();
    candUnsubRef.current = null;

    if (pcRef.current) {
      pcRef.current.onicecandidate = null;
      pcRef.current.ontrack = null;
      pcRef.current.onconnectionstatechange = null;
      pcRef.current.close();
      pcRef.current = null;
    }

    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach((t) => t.stop());
      localStreamRef.current = null;
    }

    pendingCandidatesRef.current = [];
    connectedAtRef.current = null;
    setLocalStream(null);
    setRemoteStream(null);
    setActiveCall(null);
    setIsMuted(false);
    setIsCameraOff(false);
    setFacingMode("user");
    setElapsedSeconds(0);
  }, []);

  useEffect(() => {
    return () => {
      cleanupCallResources();
    };
  }, [cleanupCallResources]);

  const flushPendingCandidates = async (pc: RTCPeerConnection) => {
    const queued = [...pendingCandidatesRef.current];
    pendingCandidatesRef.current = [];
    for (const c of queued) {
      try {
        await pc.addIceCandidate(new RTCIceCandidate(c));
      } catch {
        // ignore stale ICE candidates
      }
    }
  };

  const setupPeerConnection = (
    chatId: string,
    callId: string,
    role: "caller" | "callee",
    stream: MediaStream,
    currentUid: string
  ) => {
    const pc = new RTCPeerConnection(DEFAULT_ICE_CONFIG);
    pcRef.current = pc;

    stream.getTracks().forEach((track) => {
      pc.addTrack(track, stream);
    });

    const remote = new MediaStream();
    setRemoteStream(remote);

    pc.ontrack = (event) => {
      const incomingTracks =
        event.streams[0]?.getTracks().length
          ? event.streams[0].getTracks()
          : [event.track];
      incomingTracks.forEach((track) => {
        if (!remote.getTracks().some((t) => t.id === track.id)) {
          remote.addTrack(track);
        }
      });
      setRemoteStream(new MediaStream(remote.getTracks()));
    };

    pc.onicecandidate = (event) => {
      if (event.candidate) {
        void addIceCandidateDoc({
          chatId,
          callId,
          role,
          senderId: currentUid,
          candidate: event.candidate.toJSON(),
        }).catch(() => {});
      }
    };

    pc.oniceconnectionstatechange = () => {
      if (
        pc.iceConnectionState === "disconnected" ||
        pc.iceConnectionState === "failed"
      ) {
        try {
          pc.restartIce?.();
        } catch {
          // ignore
        }
      } else if (pc.iceConnectionState === "connected" || pc.iceConnectionState === "completed") {
        setCallError(null);
      }
    };

    pc.onconnectionstatechange = () => {
      if (pc.connectionState === "connected") {
        setCallError(null);
      } else if (pc.connectionState === "failed") {
        try {
          pc.restartIce?.();
        } catch {
          // ignore
        }
        setTimeout(() => {
          if (pcRef.current === pc && pc.connectionState === "failed") {
            setCallError("انقطع الاتصال بالشبكة. تحقق من جودة الإنترنت وحاول مجدداً.");
          }
        }, 3500);
      }
    };

    return pc;
  };

  const startCall = useCallback(
    async (
      chatId: string,
      chatTitle: string,
      callType: CallType,
      peerAvatar?: string
    ): Promise<string | null> => {
      if (!uid) {
        setCallError("يرجى تسجيل الدخول أولاً لإجراء المكالمات.");
        return null;
      }

      setCallError(null);
      let stream: MediaStream;
      try {
        stream = await acquireCallMediaStream(callType, "user");
      } catch {
        setCallError(
          callType === "video"
            ? "تعذر الوصول إلى الكاميرا والميكروفون. تأكد من منح الإذن في المتصفح."
            : "تعذر الوصول إلى الميكروفون. تأكد من منح الإذن في المتصفح."
        );
        return null;
      }

      const callId = `call_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
      localStreamRef.current = stream;
      connectedAtRef.current = null;
      setLocalStream(stream);
      setIsMuted(false);
      setIsCameraOff(false);
      setFacingMode("user");

      const pc = setupPeerConnection(chatId, callId, "caller", stream, uid);

      const sessionObj: ActiveCallSession = {
        callId,
        chatId,
        chatTitle,
        callerId: uid,
        peerName: chatTitle,
        peerAvatar,
        callType,
        status: "ringing",
        role: "caller",
      };
      setActiveCall(sessionObj);

      try {
        const offer = await pc.createOffer();
        await pc.setLocalDescription(offer);

        await createCallSignalDoc({
          chatId,
          callId,
          callerId: uid,
          callerName: userName,
          callType,
          offer: {
            type: offer.type,
            sdp: offer.sdp || "",
          },
        });

        callUnsubRef.current = subscribeToCallDoc(chatId, callId, (callData) => {
          if (!callData || callData.status === "ended") {
            const latest = activeCallRef.current || sessionObj;
            const outcome: CallOutcome = connectedAtRef.current
              ? "completed"
              : "declined";
            dispatchCallEndedOnce(latest, outcome);
            cleanupCallResources();
            return;
          }

          if (callData.status === "connected") {
            if (!connectedAtRef.current) {
              connectedAtRef.current = Date.now();
            }
            setActiveCall((prev) =>
              prev
                ? {
                    ...prev,
                    status: "connected",
                    peerName: callData.calleeName || prev.peerName,
                  }
                : null
            );
          }

          if (callData.answer && !pc.currentRemoteDescription) {
            void pc
              .setRemoteDescription(new RTCSessionDescription(callData.answer))
              .then(() => flushPendingCandidates(pc))
              .catch(() => {});
          }
        });

        candUnsubRef.current = subscribeToCallCandidates(
          chatId,
          callId,
          "callee",
          (cand) => {
            if (pc.remoteDescription) {
              void pc.addIceCandidate(new RTCIceCandidate(cand)).catch(() => {});
            } else {
              pendingCandidatesRef.current.push(cand);
            }
          }
        );

        return callId;
      } catch (err) {
        cleanupCallResources();
        setCallError(
          err instanceof Error
            ? err.message
            : "تعذر بدء المكالمة عبر الشبكة."
        );
        return null;
      }
    },
    [uid, userName, cleanupCallResources, dispatchCallEndedOnce]
  );

  const acceptIncomingCall = useCallback(
    async (incoming: ChatCallSignal, peerAvatar?: string) => {
      if (!uid) return;
      stopRingtone();
      stopCallVibration();
      setCallError(null);

      let stream: MediaStream;
      try {
        stream = await acquireCallMediaStream(incoming.callType, "user");
      } catch {
        setCallError(
          incoming.callType === "video"
            ? "تعذر الوصول إلى الكاميرا والميكروفون للرد على المكالمة."
            : "تعذر الوصول إلى الميكروفون للرد على المكالمة."
        );
        return;
      }

      localStreamRef.current = stream;
      connectedAtRef.current = Date.now();
      setLocalStream(stream);
      setIsMuted(false);
      setIsCameraOff(false);
      setFacingMode("user");

      const pc = setupPeerConnection(
        incoming.chatId,
        incoming.callId,
        "callee",
        stream,
        uid
      );

      const sessionObj: ActiveCallSession = {
        callId: incoming.callId,
        chatId: incoming.chatId,
        chatTitle: incoming.chatTitle || incoming.callerName,
        callerId: incoming.callerId,
        peerName: incoming.callerName,
        peerAvatar,
        callType: incoming.callType,
        status: "connected",
        role: "callee",
      };
      setActiveCall(sessionObj);

      try {
        await pc.setRemoteDescription(new RTCSessionDescription(incoming.offer));
        await flushPendingCandidates(pc);

        const answer = await pc.createAnswer();
        await pc.setLocalDescription(answer);

        await answerCallSignalDoc({
          chatId: incoming.chatId,
          callId: incoming.callId,
          calleeId: uid,
          calleeName: userName,
          answer: {
            type: answer.type,
            sdp: answer.sdp || "",
          },
        });

        callUnsubRef.current = subscribeToCallDoc(
          incoming.chatId,
          incoming.callId,
          (callData) => {
            if (!callData || callData.status === "ended") {
              dispatchCallEndedOnce(
                activeCallRef.current || sessionObj,
                "completed"
              );
              cleanupCallResources();
            }
          }
        );

        candUnsubRef.current = subscribeToCallCandidates(
          incoming.chatId,
          incoming.callId,
          "caller",
          (cand) => {
            if (pc.remoteDescription) {
              void pc.addIceCandidate(new RTCIceCandidate(cand)).catch(() => {});
            } else {
              pendingCandidatesRef.current.push(cand);
            }
          }
        );
      } catch (err) {
        cleanupCallResources();
        setCallError(
          err instanceof Error
            ? err.message
            : "حدث خطأ أثناء قبول المكالمة."
        );
      }
    },
    [uid, userName, cleanupCallResources, dispatchCallEndedOnce]
  );

  const declineIncomingCall = useCallback(
    async (incoming: ChatCallSignal) => {
      stopRingtone();
      stopCallVibration();
      dispatchCallEndedOnce(
        {
          callId: incoming.callId,
          chatId: incoming.chatId,
          chatTitle: incoming.chatTitle || incoming.callerName,
          callerId: incoming.callerId,
          peerName: incoming.callerName,
          callType: incoming.callType,
          status: "ended",
          role: "callee",
        },
        "declined"
      );
      await endCallSignalDoc({
        chatId: incoming.chatId,
        callId: incoming.callId,
      });
    },
    [dispatchCallEndedOnce]
  );

  const endActiveCall = useCallback(async () => {
    stopRingtone();
    stopCallVibration();
    const current = activeCallRef.current;
    if (current) {
      dispatchCallEndedOnce(
        current,
        connectedAtRef.current ? "completed" : "missed"
      );
    }
    cleanupCallResources();
    if (current) {
      await endCallSignalDoc({
        chatId: current.chatId,
        callId: current.callId,
      });
    }
  }, [cleanupCallResources, dispatchCallEndedOnce]);

  const toggleMute = useCallback(() => {
    const stream = localStreamRef.current;
    if (!stream) return;
    const nextMuted = !isMuted;
    stream.getAudioTracks().forEach((track) => {
      track.enabled = !nextMuted;
    });
    setIsMuted(nextMuted);
  }, [isMuted]);

  const toggleCamera = useCallback(() => {
    const stream = localStreamRef.current;
    if (!stream) return;
    const nextOff = !isCameraOff;
    stream.getVideoTracks().forEach((track) => {
      track.enabled = !nextOff;
    });
    setIsCameraOff(nextOff);
  }, [isCameraOff]);

  const switchCamera = useCallback(async () => {
    const pc = pcRef.current;
    const stream = localStreamRef.current;
    const current = activeCallRef.current;
    if (!pc || !stream || !current || current.callType !== "video") return;

    const nextFacing = facingMode === "user" ? "environment" : "user";
    try {
      const newVideoStream = await navigator.mediaDevices
        .getUserMedia({
          video: { facingMode: { exact: nextFacing } },
        })
        .catch(() =>
          navigator.mediaDevices.getUserMedia({
            video: { facingMode: nextFacing },
          })
        );

      const newVideoTrack = newVideoStream.getVideoTracks()[0];
      if (!newVideoTrack) return;

      newVideoTrack.enabled = !isCameraOff;

      const sender = pc
        .getSenders()
        .find((s) => s.track && s.track.kind === "video");
      if (sender) {
        await sender.replaceTrack(newVideoTrack);
      }

      stream.getVideoTracks().forEach((t) => {
        t.stop();
        stream.removeTrack(t);
      });
      stream.addTrack(newVideoTrack);

      setLocalStream(new MediaStream(stream.getTracks()));
      setFacingMode(nextFacing);
      setCallError(null);
    } catch {
      setCallError("تعذر تبديل الكاميرا على هذا الجهاز.");
    }
  }, [facingMode, isCameraOff]);

  return {
    activeCall,
    localStream,
    remoteStream,
    isMuted,
    isCameraOff,
    facingMode,
    elapsedSeconds,
    callError,
    clearCallError: () => setCallError(null),
    startCall,
    acceptIncomingCall,
    declineIncomingCall,
    endActiveCall,
    toggleMute,
    toggleCamera,
    switchCamera,
  };
}

export interface ActiveScreenShareSession {
  shareId: string;
  chatId: string;
  peerName: string;
  sharerId: string;
  shareMode: ScreenShareMode;
  status: ScreenShareStatus;
  role: "sharer" | "viewer";
}

export function useScreenShare(params: {
  uid: string | undefined;
  userName: string;
}) {
  const { uid, userName } = params;

  const [activeShare, setActiveShare] =
    useState<ActiveScreenShareSession | null>(null);
  const [screenStream, setScreenStream] = useState<MediaStream | null>(null);
  const [remoteAudioStream, setRemoteAudioStream] =
    useState<MediaStream | null>(null);
  const [isMicActive, setIsMicActive] = useState(false);
  const [screenShareError, setScreenShareError] = useState<string | null>(null);

  // Playback state when host streams a local video file from device
  const [isVideoPaused, setIsVideoPaused] = useState(false);
  const [videoCurrentTime, setVideoCurrentTime] = useState(0);
  const [videoDuration, setVideoDuration] = useState(0);

  const pcRef = useRef<RTCPeerConnection | null>(null);
  const displayStreamRef = useRef<MediaStream | null>(null);
  const micStreamRef = useRef<MediaStream | null>(null);
  const micSenderRef = useRef<RTCRtpSender | null>(null);
  const activeShareRef = useRef<ActiveScreenShareSession | null>(null);
  const shareUnsubRef = useRef<(() => void) | null>(null);
  const candUnsubRef = useRef<(() => void) | null>(null);
  const pendingCandidatesRef = useRef<RTCIceCandidateInit[]>([]);

  const sourceVideoElRef = useRef<HTMLVideoElement | null>(null);
  const sourceObjectUrlRef = useRef<string | null>(null);
  const canvasRafRef = useRef<number | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);

  activeShareRef.current = activeShare;

  const cleanupShareResources = useCallback(() => {
    shareUnsubRef.current?.();
    shareUnsubRef.current = null;
    candUnsubRef.current?.();
    candUnsubRef.current = null;

    if (canvasRafRef.current !== null) {
      cancelAnimationFrame(canvasRafRef.current);
      canvasRafRef.current = null;
    }

    if (sourceVideoElRef.current) {
      const vid = sourceVideoElRef.current;
      vid.pause();
      vid.ontimeupdate = null;
      vid.onplay = null;
      vid.onpause = null;
      vid.onended = null;
      vid.removeAttribute("src");
      vid.load();
      sourceVideoElRef.current = null;
    }

    if (sourceObjectUrlRef.current) {
      URL.revokeObjectURL(sourceObjectUrlRef.current);
      sourceObjectUrlRef.current = null;
    }

    if (audioCtxRef.current) {
      void audioCtxRef.current.close().catch(() => {});
      audioCtxRef.current = null;
    }

    if (pcRef.current) {
      pcRef.current.onicecandidate = null;
      pcRef.current.ontrack = null;
      pcRef.current.onconnectionstatechange = null;
      pcRef.current.close();
      pcRef.current = null;
    }

    micSenderRef.current = null;

    if (displayStreamRef.current) {
      displayStreamRef.current.getTracks().forEach((t) => {
        t.onended = null;
        t.stop();
      });
      displayStreamRef.current = null;
    }

    if (micStreamRef.current) {
      micStreamRef.current.getTracks().forEach((t) => t.stop());
      micStreamRef.current = null;
    }

    pendingCandidatesRef.current = [];
    setScreenStream(null);
    setRemoteAudioStream(null);
    setActiveShare(null);
    setIsMicActive(false);
    setIsVideoPaused(false);
    setVideoCurrentTime(0);
    setVideoDuration(0);
  }, []);

  useEffect(() => {
    return () => {
      cleanupShareResources();
    };
  }, [cleanupShareResources]);

  const flushPendingCandidates = async (pc: RTCPeerConnection) => {
    const queued = [...pendingCandidatesRef.current];
    pendingCandidatesRef.current = [];
    for (const c of queued) {
      try {
        await pc.addIceCandidate(new RTCIceCandidate(c));
      } catch {
        // ignore stale ICE candidates
      }
    }
  };

  const stopScreenShare = useCallback(async () => {
    const current = activeShareRef.current;
    cleanupShareResources();
    if (current) {
      await endScreenShareDoc({
        chatId: current.chatId,
        shareId: current.shareId,
      });
    }
  }, [cleanupShareResources]);

  const createPeerConnection = (
    chatId: string,
    shareId: string,
    role: "caller" | "callee",
    currentUid: string
  ) => {
    const pc = new RTCPeerConnection(DEFAULT_ICE_CONFIG);
    pcRef.current = pc;

    // Pre-negotiate an audio transceiver for independent two-way mic toggling without SDP renegotiation
    const micTransceiver = pc.addTransceiver("audio", {
      direction: "sendrecv",
    });
    micSenderRef.current = micTransceiver.sender;

    const remoteDisplay = new MediaStream();
    const remoteVoice = new MediaStream();

    pc.ontrack = (event) => {
      if (event.streams[0]) {
        event.streams[0].getTracks().forEach((track) => {
          if (!remoteDisplay.getTracks().some((t) => t.id === track.id)) {
            remoteDisplay.addTrack(track);
          }
        });
        setScreenStream(new MediaStream(remoteDisplay.getTracks()));
      } else if (event.track.kind === "video") {
        remoteDisplay.addTrack(event.track);
        setScreenStream(new MediaStream(remoteDisplay.getTracks()));
      } else if (event.track.kind === "audio") {
        if (!remoteVoice.getTracks().some((t) => t.id === event.track.id)) {
          remoteVoice.addTrack(event.track);
        }
        setRemoteAudioStream(new MediaStream(remoteVoice.getTracks()));
      }
    };

    pc.onicecandidate = (event) => {
      if (event.candidate) {
        void addScreenShareCandidateDoc({
          chatId,
          shareId,
          role,
          senderId: currentUid,
          candidate: event.candidate.toJSON(),
        }).catch(() => {});
      }
    };

    pc.oniceconnectionstatechange = () => {
      if (
        pc.iceConnectionState === "disconnected" ||
        pc.iceConnectionState === "failed"
      ) {
        try {
          pc.restartIce?.();
        } catch {
          // ignore
        }
      }
    };

    pc.onconnectionstatechange = () => {
      if (pc.connectionState === "failed") {
        try {
          pc.restartIce?.();
        } catch {
          // ignore
        }
        setTimeout(() => {
          if (pcRef.current === pc && pc.connectionState === "failed") {
            setScreenShareError("انقطع اتصال البث المباشر. حاول بدء البث مجدداً.");
          }
        }, 3500);
      }
    };

    return pc;
  };

  const startScreenShare = useCallback(
    async (chatId: string, peerName: string) => {
      if (!uid) {
        setScreenShareError("يرجى تسجيل الدخول أولاً لبدء بث الشاشة.");
        return;
      }

      if (!navigator.mediaDevices?.getDisplayMedia) {
        setScreenShareError(
          "متصفحك الحالي أو جهازك لا يدعم ميزة مشاركة الشاشة."
        );
        return;
      }

      setScreenShareError(null);
      let displayStream: MediaStream;
      try {
        displayStream = await navigator.mediaDevices.getDisplayMedia({
          video: {
            frameRate: { ideal: 30, max: 30 },
          },
          audio: true,
        });
      } catch (err) {
        if (err instanceof DOMException && err.name === "NotAllowedError") {
          setScreenShareError("تم إلغاء إذن مشاركة الشاشة.");
        } else {
          setScreenShareError("تعذر بدء مشاركة الشاشة على هذا الجهاز.");
        }
        return;
      }

      if (activeShareRef.current) {
        await stopScreenShare();
      }

      const shareId = `share_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
      displayStreamRef.current = displayStream;
      setScreenStream(displayStream);
      setRemoteAudioStream(null);
      setIsMicActive(false);

      const videoTrack = displayStream.getVideoTracks()[0];
      if (videoTrack) {
        if ("contentHint" in videoTrack) {
          videoTrack.contentHint = "motion";
        }
        videoTrack.onended = () => {
          void stopScreenShare();
        };
      }

      const pc = createPeerConnection(chatId, shareId, "caller", uid);

      displayStream.getTracks().forEach((track) => {
        pc.addTrack(track, displayStream);
      });

      setActiveShare({
        shareId,
        chatId,
        peerName,
        sharerId: uid,
        shareMode: "screen",
        status: "offering",
        role: "sharer",
      });

      try {
        const offer = await pc.createOffer();
        await pc.setLocalDescription(offer);

        await createScreenShareDoc({
          chatId,
          shareId,
          sharerId: uid,
          sharerName: userName,
          shareMode: "screen",
          offer: {
            type: offer.type,
            sdp: offer.sdp || "",
          },
        });

        shareUnsubRef.current = subscribeToScreenShareDoc(
          chatId,
          shareId,
          (shareData) => {
            if (!shareData || shareData.status === "ended") {
              cleanupShareResources();
              return;
            }

            if (shareData.status === "connected") {
              setActiveShare((prev) =>
                prev
                  ? {
                      ...prev,
                      status: "connected",
                      peerName: shareData.viewerName || prev.peerName,
                    }
                  : null
              );
            }

            if (shareData.answer && !pc.currentRemoteDescription) {
              void pc
                .setRemoteDescription(new RTCSessionDescription(shareData.answer))
                .then(() => flushPendingCandidates(pc))
                .catch(() => {});
            }
          }
        );

        candUnsubRef.current = subscribeToScreenShareCandidates(
          chatId,
          shareId,
          "callee",
          (cand) => {
            if (pc.remoteDescription) {
              void pc.addIceCandidate(new RTCIceCandidate(cand)).catch(() => {});
            } else {
              pendingCandidatesRef.current.push(cand);
            }
          }
        );
      } catch (err) {
        cleanupShareResources();
        setScreenShareError(
          err instanceof Error
            ? err.message
            : "تعذر إنشاء اتصال بث الشاشة."
        );
      }
    },
    [uid, userName, cleanupShareResources, stopScreenShare]
  );

  const startVideoFileShare = useCallback(
    async (chatId: string, peerName: string, file: File) => {
      if (!uid) {
        setScreenShareError("يرجى تسجيل الدخول أولاً لبدء المشاهدة معاً.");
        return;
      }

      if (activeShareRef.current) {
        await stopScreenShare();
      }

      setScreenShareError(null);

      const objectUrl = URL.createObjectURL(file);
      const srcVideo = document.createElement("video");
      srcVideo.src = objectUrl;
      srcVideo.playsInline = true;
      srcVideo.preload = "auto";
      srcVideo.muted = false;

      try {
        await new Promise<void>((resolve, reject) => {
          srcVideo.onloadedmetadata = () => resolve();
          srcVideo.onerror = () =>
            reject(new Error("ملف الفيديو غير مدعوم أو تالف."));
        });

        await srcVideo.play();
      } catch (err) {
        URL.revokeObjectURL(objectUrl);
        srcVideo.removeAttribute("src");
        srcVideo.load();
        setScreenShareError(
          err instanceof Error
            ? err.message
            : "تعذر تشغيل ملف الفيديو على هذا المتصفح."
        );
        return;
      }

      sourceVideoElRef.current = srcVideo;
      sourceObjectUrlRef.current = objectUrl;
      setVideoDuration(
        Number.isFinite(srcVideo.duration) ? srcVideo.duration : 0
      );
      setVideoCurrentTime(0);
      setIsVideoPaused(false);

      srcVideo.ontimeupdate = () => {
        setVideoCurrentTime(srcVideo.currentTime || 0);
      };
      srcVideo.onplay = () => setIsVideoPaused(false);
      srcVideo.onpause = () => setIsVideoPaused(true);

      let captureStream: MediaStream | null = null;
      const extendedVideo = srcVideo as HTMLVideoElement & {
        captureStream?: (fps?: number) => MediaStream;
        mozCaptureStream?: (fps?: number) => MediaStream;
      };

      if (typeof extendedVideo.captureStream === "function") {
        captureStream = extendedVideo.captureStream(30);
      } else if (typeof extendedVideo.mozCaptureStream === "function") {
        captureStream = extendedVideo.mozCaptureStream(30);
      }

      if (!captureStream || captureStream.getVideoTracks().length === 0) {
        // Canvas + WebAudio fallback for mobile Safari / WebKit
        const vw = srcVideo.videoWidth || 640;
        const vh = srcVideo.videoHeight || 360;
        const scale = Math.min(1, 960 / Math.max(vw, vh));
        const canvas = document.createElement("canvas");
        canvas.width = Math.max(240, Math.round((vw * scale) / 2) * 2);
        canvas.height = Math.max(180, Math.round((vh * scale) / 2) * 2);
        const ctx = canvas.getContext("2d");

        if (!ctx || typeof canvas.captureStream !== "function") {
          cleanupShareResources();
          setScreenShareError(
            "المتصفح الحالي لا يدعم بث ملف فيديو مباشرة عبر الشبكة."
          );
          return;
        }

        const drawLoop = () => {
          if (!sourceVideoElRef.current) return;
          if (!srcVideo.paused && !srcVideo.ended) {
            ctx.drawImage(srcVideo, 0, 0, canvas.width, canvas.height);
          }
          canvasRafRef.current = requestAnimationFrame(drawLoop);
        };
        ctx.drawImage(srcVideo, 0, 0, canvas.width, canvas.height);
        canvasRafRef.current = requestAnimationFrame(drawLoop);

        captureStream = canvas.captureStream(24);

        try {
          const AudioCtx =
            window.AudioContext ||
            (window as unknown as { webkitAudioContext: typeof AudioContext })
              .webkitAudioContext;
          if (AudioCtx) {
            const audioCtx = new AudioCtx();
            audioCtxRef.current = audioCtx;
            const mediaSource = audioCtx.createMediaElementSource(srcVideo);
            const dest = audioCtx.createMediaStreamDestination();
            mediaSource.connect(dest);
            mediaSource.connect(audioCtx.destination);
            dest.stream.getAudioTracks().forEach((track) => {
              captureStream!.addTrack(track);
            });
          }
        } catch {
          // continue video-only if audio capture is restricted
        }
      }

      const shareId = `share_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
      displayStreamRef.current = captureStream;
      setScreenStream(captureStream);
      setRemoteAudioStream(null);
      setIsMicActive(false);

      const videoTrack = captureStream.getVideoTracks()[0];
      if (videoTrack && "contentHint" in videoTrack) {
        videoTrack.contentHint = "motion";
      }

      const pc = createPeerConnection(chatId, shareId, "caller", uid);

      captureStream.getTracks().forEach((track) => {
        pc.addTrack(track, captureStream!);
      });

      setActiveShare({
        shareId,
        chatId,
        peerName,
        sharerId: uid,
        shareMode: "video",
        status: "offering",
        role: "sharer",
      });

      try {
        const offer = await pc.createOffer();
        await pc.setLocalDescription(offer);

        await createScreenShareDoc({
          chatId,
          shareId,
          sharerId: uid,
          sharerName: userName,
          shareMode: "video",
          offer: {
            type: offer.type,
            sdp: offer.sdp || "",
          },
        });

        shareUnsubRef.current = subscribeToScreenShareDoc(
          chatId,
          shareId,
          (shareData) => {
            if (!shareData || shareData.status === "ended") {
              cleanupShareResources();
              return;
            }

            if (shareData.status === "connected") {
              setActiveShare((prev) =>
                prev
                  ? {
                      ...prev,
                      status: "connected",
                      peerName: shareData.viewerName || prev.peerName,
                    }
                  : null
              );
            }

            if (shareData.answer && !pc.currentRemoteDescription) {
              void pc
                .setRemoteDescription(new RTCSessionDescription(shareData.answer))
                .then(() => flushPendingCandidates(pc))
                .catch(() => {});
            }
          }
        );

        candUnsubRef.current = subscribeToScreenShareCandidates(
          chatId,
          shareId,
          "callee",
          (cand) => {
            if (pc.remoteDescription) {
              void pc.addIceCandidate(new RTCIceCandidate(cand)).catch(() => {});
            } else {
              pendingCandidatesRef.current.push(cand);
            }
          }
        );
      } catch (err) {
        cleanupShareResources();
        setScreenShareError(
          err instanceof Error
            ? err.message
            : "تعذر إنشاء اتصال بث الفيديو."
        );
      }
    },
    [uid, userName, cleanupShareResources, stopScreenShare]
  );

  const toggleVideoPlayback = useCallback(async () => {
    const vid = sourceVideoElRef.current;
    if (!vid) return;
    if (vid.paused) {
      await vid.play().catch(() => {});
    } else {
      vid.pause();
    }
  }, []);

  const seekVideo = useCallback((seconds: number) => {
    const vid = sourceVideoElRef.current;
    if (!vid || !Number.isFinite(seconds)) return;
    const clamped = Math.max(0, Math.min(vid.duration || seconds, seconds));
    vid.currentTime = clamped;
    setVideoCurrentTime(clamped);
  }, []);

  const joinIncomingScreenShare = useCallback(
    async (incoming: ScreenShareSignal) => {
      if (!uid) return;
      if (activeShareRef.current?.shareId === incoming.shareId) return;

      if (activeShareRef.current) {
        cleanupShareResources();
      }

      setScreenShareError(null);
      setIsMicActive(false);

      const pc = createPeerConnection(
        incoming.chatId,
        incoming.shareId,
        "callee",
        uid
      );

      setActiveShare({
        shareId: incoming.shareId,
        chatId: incoming.chatId,
        peerName: incoming.sharerName,
        sharerId: incoming.sharerId,
        shareMode: incoming.shareMode || "screen",
        status: "connected",
        role: "viewer",
      });

      try {
        await pc.setRemoteDescription(new RTCSessionDescription(incoming.offer));
        await flushPendingCandidates(pc);

        const answer = await pc.createAnswer();
        await pc.setLocalDescription(answer);

        await answerScreenShareDoc({
          chatId: incoming.chatId,
          shareId: incoming.shareId,
          viewerId: uid,
          viewerName: userName,
          answer: {
            type: answer.type,
            sdp: answer.sdp || "",
          },
        });

        shareUnsubRef.current = subscribeToScreenShareDoc(
          incoming.chatId,
          incoming.shareId,
          (shareData) => {
            if (!shareData || shareData.status === "ended") {
              cleanupShareResources();
            }
          }
        );

        candUnsubRef.current = subscribeToScreenShareCandidates(
          incoming.chatId,
          incoming.shareId,
          "caller",
          (cand) => {
            if (pc.remoteDescription) {
              void pc.addIceCandidate(new RTCIceCandidate(cand)).catch(() => {});
            } else {
              pendingCandidatesRef.current.push(cand);
            }
          }
        );
      } catch (err) {
        cleanupShareResources();
        setScreenShareError(
          err instanceof Error
            ? err.message
            : "تعذر الاتصال ببث الصديق."
        );
      }
    },
    [uid, userName, cleanupShareResources]
  );

  const toggleMic = useCallback(async () => {
    const sender = micSenderRef.current;
    if (!sender) return;

    if (!micStreamRef.current) {
      try {
        const micStream = await navigator.mediaDevices.getUserMedia({
          audio: COMPATIBLE_AUDIO_CONSTRAINTS,
        });
        const micTrack = micStream.getAudioTracks()[0];
        if (!micTrack) return;
        micStreamRef.current = micStream;
        await sender.replaceTrack(micTrack);
        setIsMicActive(true);
        setScreenShareError(null);
      } catch {
        setScreenShareError(
          "تعذر فتح الميكروفون. تأكد من منح الإذن في المتصفح."
        );
      }
      return;
    }

    const nextActive = !isMicActive;
    micStreamRef.current.getAudioTracks().forEach((track) => {
      track.enabled = nextActive;
    });
    setIsMicActive(nextActive);
  }, [isMicActive]);

  return {
    activeShare,
    screenStream,
    remoteAudioStream,
    isMicActive,
    screenShareError,
    isVideoPaused,
    videoCurrentTime,
    videoDuration,
    clearScreenShareError: () => setScreenShareError(null),
    startScreenShare,
    startVideoFileShare,
    toggleVideoPlayback,
    seekVideo,
    joinIncomingScreenShare,
    stopScreenShare,
    toggleMic,
  };
}

export function useWatchPartyMic(params: {
  uid: string | undefined;
  userName: string;
  chatId: string | null;
  isDirectChat: boolean;
  isWatchActive: boolean;
  isWatchHost: boolean;
  guestMicAllowed: boolean;
  isChatBlocked: boolean;
}) {
  const {
    uid,
    userName,
    chatId,
    isDirectChat,
    isWatchActive,
    isWatchHost,
    guestMicAllowed,
    isChatBlocked,
  } = params;

  const [isMicActive, setIsMicActive] = useState(false);
  const [isConnectingMic, setIsConnectingMic] = useState(false);
  const [remoteAudioStream, setRemoteAudioStream] =
    useState<MediaStream | null>(null);
  const [micError, setMicError] = useState<string | null>(null);

  const pcRef = useRef<RTCPeerConnection | null>(null);
  const localStreamRef = useRef<MediaStream | null>(null);
  const audioSenderRef = useRef<RTCRtpSender | null>(null);
  const activeAudioIdRef = useRef<string | null>(null);
  const activeChatIdRef = useRef<string | null>(null);
  const docUnsubRef = useRef<(() => void) | null>(null);
  const candUnsubRef = useRef<(() => void) | null>(null);
  const pendingCandsRef = useRef<RTCIceCandidateInit[]>([]);

  const isMicLockedForMe = !isWatchHost && !guestMicAllowed;

  const cleanupWatchMic = useCallback((endRemoteDoc = false) => {
    const prevAudioId = activeAudioIdRef.current;
    const prevChatId = activeChatIdRef.current;

    docUnsubRef.current?.();
    docUnsubRef.current = null;
    candUnsubRef.current?.();
    candUnsubRef.current = null;

    if (pcRef.current) {
      pcRef.current.onicecandidate = null;
      pcRef.current.ontrack = null;
      pcRef.current.onconnectionstatechange = null;
      pcRef.current.close();
      pcRef.current = null;
    }

    audioSenderRef.current = null;

    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach((t) => t.stop());
      localStreamRef.current = null;
    }

    pendingCandsRef.current = [];
    activeAudioIdRef.current = null;
    activeChatIdRef.current = null;
    setIsMicActive(false);
    setIsConnectingMic(false);
    setRemoteAudioStream(null);

    if (endRemoteDoc && prevChatId && prevAudioId) {
      void endWatchAudioDoc({ chatId: prevChatId, audioId: prevAudioId });
    }
  }, []);

  const stopWatchMic = useCallback(() => {
    cleanupWatchMic(true);
  }, [cleanupWatchMic]);

  // Enforce mute if host revokes guest mic permission
  useEffect(() => {
    if (isMicLockedForMe && isMicActive && localStreamRef.current) {
      localStreamRef.current.getAudioTracks().forEach((t) => {
        t.enabled = false;
      });
      setIsMicActive(false);
    }
  }, [isMicLockedForMe, isMicActive]);

  // Stop mic when watch ends or chat changes or becomes blocked
  useEffect(() => {
    if (!isWatchActive || !isDirectChat || !chatId || isChatBlocked) {
      if (activeAudioIdRef.current || localStreamRef.current || pcRef.current) {
        cleanupWatchMic(true);
      }
      return;
    }
  }, [isWatchActive, isDirectChat, chatId, isChatBlocked, cleanupWatchMic]);

  useEffect(() => {
    return () => {
      cleanupWatchMic(false);
    };
  }, [cleanupWatchMic]);

  const flushPending = async (pc: RTCPeerConnection) => {
    const list = [...pendingCandsRef.current];
    pendingCandsRef.current = [];
    for (const c of list) {
      try {
        await pc.addIceCandidate(new RTCIceCandidate(c));
      } catch {
        // ignore stale ICE
      }
    }
  };

  const createWatchPc = async (
    targetChatId: string,
    audioId: string,
    role: "caller" | "callee",
    currentUid: string
  ) => {
    const pc = new RTCPeerConnection(DEFAULT_ICE_CONFIG);
    pcRef.current = pc;

    const transceiver = pc.addTransceiver("audio", { direction: "sendrecv" });
    audioSenderRef.current = transceiver.sender;

    const remote = new MediaStream();
    pc.ontrack = (event) => {
      const tracks = event.streams[0]?.getTracks().length
        ? event.streams[0].getTracks()
        : [event.track];
      tracks.forEach((track) => {
        if (!remote.getTracks().some((t) => t.id === track.id)) {
          remote.addTrack(track);
        }
      });
      setRemoteAudioStream(new MediaStream(remote.getTracks()));
    };

    pc.onicecandidate = (event) => {
      if (event.candidate) {
        void addWatchAudioCandidateDoc({
          chatId: targetChatId,
          audioId,
          role,
          senderId: currentUid,
          candidate: event.candidate.toJSON(),
        }).catch(() => {});
      }
    };

    return pc;
  };

  // Auto-answer incoming watch party audio channel from peer
  useEffect(() => {
    if (!uid || !chatId || !isWatchActive || !isDirectChat || isChatBlocked) {
      return;
    }

    const unsub = subscribeToChatWatchAudio(
      chatId,
      uid,
      (signal: WatchAudioSignal | null) => {
        if (!signal || activeAudioIdRef.current === signal.audioId) return;
        if (pcRef.current) return;

        void (async () => {
          try {
            activeAudioIdRef.current = signal.audioId;
            activeChatIdRef.current = chatId;
            const pc = await createWatchPc(chatId, signal.audioId, "callee", uid);
            await pc.setRemoteDescription(new RTCSessionDescription(signal.offer));
            await flushPending(pc);
            const answer = await pc.createAnswer();
            await pc.setLocalDescription(answer);

            await answerWatchAudioDoc({
              chatId,
              audioId: signal.audioId,
              peerId: uid,
              peerName: userName,
              answer: {
                type: answer.type,
                sdp: answer.sdp || "",
              },
            });

            docUnsubRef.current = subscribeToWatchAudioDoc(
              chatId,
              signal.audioId,
              (updated) => {
                if (!updated || updated.status === "ended") {
                  cleanupWatchMic(false);
                }
              }
            );

            candUnsubRef.current = subscribeToWatchAudioCandidates(
              chatId,
              signal.audioId,
              "caller",
              (cand) => {
                if (pc.remoteDescription) {
                  void pc.addIceCandidate(new RTCIceCandidate(cand)).catch(() => {});
                } else {
                  pendingCandsRef.current.push(cand);
                }
              }
            );
          } catch {
            cleanupWatchMic(false);
          }
        })();
      }
    );

    return () => {
      unsub();
    };
  }, [uid, userName, chatId, isWatchActive, isDirectChat, isChatBlocked, cleanupWatchMic]);

  const toggleWatchMic = useCallback(async () => {
    if (!uid || !chatId || !isWatchActive || !isDirectChat || isChatBlocked) {
      return;
    }
    if (isMicLockedForMe) {
      setMicError("صاحب البث أغلق المايك عن الضيف حالياً.");
      return;
    }

    setMicError(null);

    if (localStreamRef.current) {
      const next = !isMicActive;
      localStreamRef.current.getAudioTracks().forEach((t) => {
        t.enabled = next;
      });
      setIsMicActive(next);
      return;
    }

    setIsConnectingMic(true);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: COMPATIBLE_AUDIO_CONSTRAINTS,
      });
      const track = stream.getAudioTracks()[0];
      if (!track) {
        setIsConnectingMic(false);
        return;
      }
      localStreamRef.current = stream;

      if (pcRef.current && audioSenderRef.current) {
        await audioSenderRef.current.replaceTrack(track);
        setIsMicActive(true);
        setIsConnectingMic(false);
        return;
      }

      await cleanupStaleWatchAudio(chatId);
      const audioId = `wa_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
      activeAudioIdRef.current = audioId;
      activeChatIdRef.current = chatId;

      const pc = await createWatchPc(chatId, audioId, "caller", uid);
      if (audioSenderRef.current) {
        await audioSenderRef.current.replaceTrack(track);
      } else {
        pc.addTrack(track, stream);
      }

      const offer = await pc.createOffer();
      await pc.setLocalDescription(offer);

      await createWatchAudioDoc({
        chatId,
        audioId,
        initiatorId: uid,
        initiatorName: userName,
        offer: {
          type: offer.type,
          sdp: offer.sdp || "",
        },
      });

      docUnsubRef.current = subscribeToWatchAudioDoc(chatId, audioId, (docData) => {
        if (!docData || docData.status === "ended") {
          cleanupWatchMic(false);
          return;
        }
        if (docData.answer && !pc.currentRemoteDescription) {
          void pc
            .setRemoteDescription(new RTCSessionDescription(docData.answer))
            .then(() => flushPending(pc))
            .catch(() => {});
        }
      });

      candUnsubRef.current = subscribeToWatchAudioCandidates(
        chatId,
        audioId,
        "callee",
        (cand) => {
          if (pc.remoteDescription) {
            void pc.addIceCandidate(new RTCIceCandidate(cand)).catch(() => {});
          } else {
            pendingCandsRef.current.push(cand);
          }
        }
      );

      setIsMicActive(true);
    } catch {
      setMicError("تعذر تشغيل المايكروفون. تأكد من منح إذن المايك في المتصفح.");
    } finally {
      setIsConnectingMic(false);
    }
  }, [
    uid,
    userName,
    chatId,
    isWatchActive,
    isDirectChat,
    isChatBlocked,
    isMicLockedForMe,
    isMicActive,
    cleanupWatchMic,
  ]);

  return {
    isMicActive,
    isConnectingMic,
    isMicLockedForMe,
    remoteAudioStream,
    micError,
    toggleWatchMic,
    stopWatchMic,
    clearMicError: () => setMicError(null),
  };
}


