import { initializeApp } from "firebase/app";
import {
  createUserWithEmailAndPassword,
  deleteUser,
  EmailAuthProvider,
  getAuth,
  onAuthStateChanged,
  reauthenticateWithCredential,
  reload,
  sendEmailVerification,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signOut,
  updatePassword,
  updateProfile,
  type User,
} from "firebase/auth";
import {
  addDoc,
  arrayRemove,
  arrayUnion,
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocFromServer,
  getDocs,
  getFirestore,
  limit,
  limitToLast,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  Timestamp,
  updateDoc,
  where,
  writeBatch,
  type Unsubscribe,
} from "firebase/firestore";
import firebaseConfig from "../../firebase-applet-config.json";
import type {
  CallOutcome,
  CallRecordInfo,
  CallType,
  ChatCallSignal,
  ChatMessage,
  Conversation,
  DisappearingTimerSeconds,
  MaritalStatus,
  MessageReplyRef,
  PeerUserProfile,
  ScreenShareMode,
  ScreenShareSignal,
  WatchAudioSignal,
  WatchHistoryItem,
  WatchMediaType,
  WatchSessionData,
} from "../types/chat";
import { DEFAULT_USER_AVATAR, normalizeUserAvatar } from "../data/defaults";
import { normalizeCountryCode } from "../data/countries";
import { normalizeArabicSearch, sha256Hex } from "../utils/storage";

export enum OperationType {
  CREATE = "create",
  UPDATE = "update",
  DELETE = "delete",
  LIST = "list",
  GET = "get",
  WRITE = "write",
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

const app = initializeApp(firebaseConfig);
export const db = firebaseConfig.firestoreDatabaseId
  ? getFirestore(app, firebaseConfig.firestoreDatabaseId)
  : getFirestore(app);
export const auth = getAuth(app);

async function testConnection() {
  try {
    await getDocFromServer(doc(db, "test", "connection"));
  } catch (error) {
    if (
      error instanceof Error &&
      error.message.includes("the client is offline")
    ) {
      console.error("Please check your Firebase configuration.");
    }
  }
}
void testConnection();

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error("Firestore Error: ", JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

function mapAuthErrorToArabic(error: unknown): string {
  const code =
    typeof error === "object" && error !== null && "code" in error
      ? String((error as { code: unknown }).code)
      : "";

  switch (code) {
    case "auth/email-already-in-use":
      return "هذا البريد الإلكتروني مسجل مسبقاً. انتقل إلى تبويب «تسجيل الدخول».";
    case "auth/invalid-email":
      return "صيغة البريد الإلكتروني غير صحيحة.";
    case "auth/weak-password":
      return "يجب أن يتكون رمز PIN من 6 أرقام على الأقل.";
    case "auth/user-not-found":
    case "auth/wrong-password":
    case "auth/invalid-credential":
      return "البريد الإلكتروني أو رمز PIN غير صحيح.";
    case "auth/too-many-requests":
      return "تم إجراء محاولات كثيرة. يرجى الانتظار قليلاً ثم المحاولة مجدداً.";
    case "auth/user-disabled":
      return "تم تعطيل هذا الحساب مؤقتاً.";
    case "auth/operation-not-allowed":
      return "خدمة التسجيل بالبريد الإلكتروني غير مفعّلة حالياً في إعدادات النظام.";
    case "auth/network-request-failed":
      return "تعذر الاتصال بالشبكة. تحقق من اتصال الإنترنت وحاول مجدداً.";
    default:
      return error instanceof Error && error.message
        ? error.message
        : "حدث خطأ غير متوقع أثناء المصادقة.";
  }
}

export function subscribeToAuth(
  callback: (user: User | null) => void
): Unsubscribe {
  return onAuthStateChanged(auth, callback);
}

export async function registerWithEmailPin(params: {
  name: string;
  email: string;
  pin: string;
}): Promise<User> {
  const cleanName = params.name.trim().slice(0, 50);
  const cleanEmail = params.email.trim().toLowerCase();
  const cleanPin = params.pin.trim();

  if (cleanName.length < 2) {
    throw new Error("يرجى إدخال اسم لا يقل عن حرفين.");
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
    throw new Error("يرجى إدخال بريد إلكتروني صحيح.");
  }
  if (!/^[0-9]{6}$/.test(cleanPin)) {
    throw new Error("يجب أن يتكون رمز PIN من 6 أرقام بالضبط.");
  }

  try {
    const cred = await createUserWithEmailAndPassword(auth, cleanEmail, cleanPin);
    await updateProfile(cred.user, { displayName: cleanName }).catch(() => {});
    await sendEmailVerification(cred.user);
    return cred.user;
  } catch (error) {
    throw new Error(mapAuthErrorToArabic(error));
  }
}

export async function signInWithEmailPin(params: {
  email: string;
  pin: string;
}): Promise<User> {
  const cleanEmail = params.email.trim().toLowerCase();
  const cleanPin = params.pin.trim();

  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
    throw new Error("يرجى إدخال بريد إلكتروني صحيح.");
  }
  if (!/^[0-9]{6}$/.test(cleanPin)) {
    throw new Error("يرجى إدخال رمز PIN المكوّن من 6 أرقام.");
  }

  try {
    const cred = await signInWithEmailAndPassword(auth, cleanEmail, cleanPin);
    if (!cred.user.emailVerified) {
      await sendEmailVerification(cred.user).catch(() => {});
    }
    return cred.user;
  } catch (error) {
    throw new Error(mapAuthErrorToArabic(error));
  }
}

export async function resendVerificationEmail(): Promise<void> {
  const current = auth.currentUser;
  if (!current) {
    throw new Error("لا توجد جلسة نشطة حالياً.");
  }
  try {
    await sendEmailVerification(current);
  } catch (error) {
    throw new Error(mapAuthErrorToArabic(error));
  }
}

export async function verifyEmailStatus(): Promise<{
  verified: boolean;
  user: User | null;
}> {
  const current = auth.currentUser;
  if (!current) {
    return { verified: false, user: null };
  }
  try {
    await reload(current);
    if (current.emailVerified) {
      await current.getIdToken(true).catch(() => {});
    }
    return { verified: current.emailVerified, user: current };
  } catch (error) {
    throw new Error(mapAuthErrorToArabic(error));
  }
}

export async function sendPinResetEmail(email: string): Promise<void> {
  const cleanEmail = email.trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
    throw new Error("أدخل بريدك الإلكتروني أولاً لاستلام رابط إعادة تعيين رمز PIN.");
  }
  try {
    await sendPasswordResetEmail(auth, cleanEmail);
  } catch (error) {
    throw new Error(mapAuthErrorToArabic(error));
  }
}

export async function changeAccountPassword(
  currentPassword: string,
  nextPassword: string
): Promise<void> {
  const current = auth.currentUser;
  if (!current || !current.email) {
    throw new Error("لا توجد جلسة نشطة لتغيير كلمة المرور.");
  }
  const cleanCurrent = currentPassword.trim();
  const cleanNext = nextPassword.trim();
  if (!cleanCurrent) {
    throw new Error("يرجى إدخال كلمة المرور أو رمز PIN الحالي.");
  }
  if (cleanNext.length < 6) {
    throw new Error("يجب أن تكون كلمة المرور الجديدة 6 أحرف أو أرقام على الأقل.");
  }
  try {
    const credential = EmailAuthProvider.credential(current.email, cleanCurrent);
    await reauthenticateWithCredential(current, credential);
    await updatePassword(current, cleanNext);
  } catch (error) {
    const code =
      typeof error === "object" && error !== null && "code" in error
        ? String((error as { code: unknown }).code)
        : "";
    if (
      code === "auth/wrong-password" ||
      code === "auth/invalid-credential"
    ) {
      throw new Error("كلمة المرور أو رمز PIN الحالي غير صحيح.");
    }
    if (code === "auth/requires-recent-login") {
      throw new Error("يرجى إعادة تسجيل الدخول ثم محاولة تغيير كلمة المرور.");
    }
    throw new Error(mapAuthErrorToArabic(error));
  }
}

export async function revokeAllUserSessions(uid: string): Promise<number> {
  if (!uid || auth.currentUser?.uid !== uid) {
    throw new Error("لا توجد جلسة نشطة.");
  }
  const userRef = doc(db, "users", uid);
  const path = `users/${uid}`;
  try {
    const snap = await getDoc(userRef);
    const currentVersion =
      snap.exists() &&
      typeof snap.data()?.sessionVersion === "number" &&
      Number.isFinite(snap.data()?.sessionVersion)
        ? Math.max(1, Math.round(Number(snap.data()?.sessionVersion)))
        : 1;
    const nextVersion = currentVersion + 1;
    await updateDoc(userRef, {
      sessionVersion: nextVersion,
      lastSeen: serverTimestamp(),
    });
    invalidatePeerCache(uid);
    return nextVersion;
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function signOutFirebase(profile?: {
  uid: string;
  displayName: string;
  avatar: string;
}): Promise<void> {
  if (profile?.uid) {
    await updateUserPresence({
      uid: profile.uid,
      displayName: profile.displayName,
      avatar: profile.avatar,
      isOnline: false,
    }).catch(() => {});
  }
  await signOut(auth);
}

export async function deleteUserAccountCloud(uid: string): Promise<void> {
  const current = auth.currentUser;
  if (!current || current.uid !== uid) {
    throw new Error("لا توجد جلسة صالحة لحذف الحساب.");
  }

  const userRef = doc(db, "users", uid);
  let backupData: Record<string, unknown> | null = null;
  try {
    const snap = await getDoc(userRef);
    if (snap.exists()) {
      backupData = snap.data() as Record<string, unknown>;
    }
  } catch {
    // ignore backup read failure
  }

  // Delete user's Firestore profile document (which also holds their reserved displayName)
  try {
    await deleteDoc(userRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `users/${uid}`);
  }

  // Delete Firebase Auth account
  try {
    await deleteUser(current);
  } catch (error) {
    if (backupData) {
      await setDoc(userRef, backupData).catch(() => {});
    }
    const code =
      typeof error === "object" && error !== null && "code" in error
        ? String((error as { code: unknown }).code)
        : "";
    if (code === "auth/requires-recent-login") {
      throw new Error(
        "لأسباب أمنية، يرجى تسجيل الخروج وإعادة تسجيل الدخول ثم الضغط على «حذف حسابي نهائياً» فوراً."
      );
    }
    throw new Error(mapAuthErrorToArabic(error));
  }

  await signOut(auth).catch(() => {});
}

function sanitizeAvatarForFirestore(avatar: string): string {
  return normalizeUserAvatar(avatar);
}

export function isBlockActive(
  blockedUsers: string[] | undefined,
  blockedUntil: Record<string, number> | undefined,
  targetUid: string
): boolean {
  if (!blockedUsers || !blockedUsers.includes(targetUid)) return false;
  const until = blockedUntil?.[targetUid];
  if (typeof until === "number" && until > 0 && until <= Date.now()) {
    return false;
  }
  return true;
}

function buildSanitizedLegacyUserDoc(
  existingData: Record<string, unknown>,
  overridePayload: Record<string, unknown>,
  uid: string
): Record<string, unknown> {
  const cleanDoc: Record<string, unknown> = {
    uid,
    isOnline: true,
    lastSeen: serverTimestamp(),
  };

  if (
    typeof existingData.displayName === "string" &&
    existingData.displayName.trim()
  ) {
    const cleanExistingName = existingData.displayName.trim().slice(0, 50);
    cleanDoc.displayName = cleanExistingName;
    cleanDoc.displayNameLower = normalizeArabicSearch(cleanExistingName).slice(
      0,
      50
    );
    cleanDoc.displayNameExactLower = cleanExistingName.toLowerCase().slice(0, 50);
  }

  const existingAvatar = sanitizeAvatarForFirestore(
    typeof existingData.photoURL === "string" && existingData.photoURL.trim()
      ? existingData.photoURL
      : typeof existingData.avatar === "string" && existingData.avatar.trim()
      ? existingData.avatar
      : DEFAULT_USER_AVATAR
  );
  cleanDoc.avatar = existingAvatar;
  cleanDoc.photoURL = existingAvatar;

  if (typeof existingData.email === "string" && existingData.email.length <= 120) {
    cleanDoc.email = existingData.email;
  }
  if (
    typeof existingData.emailLower === "string" &&
    existingData.emailLower.length <= 120
  ) {
    cleanDoc.emailLower = existingData.emailLower;
  }
  if (
    typeof existingData.emailHash === "string" &&
    existingData.emailHash.length <= 128
  ) {
    cleanDoc.emailHash = existingData.emailHash;
  }
  if (typeof existingData.countryCode === "string" && existingData.countryCode.trim()) {
    cleanDoc.countryCode = normalizeCountryCode(existingData.countryCode);
  }
  if (typeof existingData.coverPhoto === "string") {
    cleanDoc.coverPhoto = existingData.coverPhoto.slice(0, 85000);
  }
  if (typeof existingData.bio === "string") {
    cleanDoc.bio = existingData.bio.trim().slice(0, 160);
  }
  if (typeof existingData.publicKey === "string") {
    cleanDoc.publicKey = existingData.publicKey.slice(0, 1024);
  }
  if (
    typeof existingData.sessionVersion === "number" &&
    Number.isFinite(existingData.sessionVersion) &&
    existingData.sessionVersion >= 1
  ) {
    cleanDoc.sessionVersion = Math.round(existingData.sessionVersion);
  }
  if (
    typeof existingData.age === "number" &&
    Number.isFinite(existingData.age) &&
    existingData.age >= 5 &&
    existingData.age <= 120
  ) {
    cleanDoc.age = Math.round(existingData.age);
  } else if (existingData.age === null) {
    cleanDoc.age = null;
  }
  if (typeof existingData.city === "string") {
    cleanDoc.city = existingData.city.trim().slice(0, 60);
  }
  if (
    existingData.maritalStatus === "unspecified" ||
    existingData.maritalStatus === "single" ||
    existingData.maritalStatus === "engaged" ||
    existingData.maritalStatus === "married"
  ) {
    cleanDoc.maritalStatus = existingData.maritalStatus;
  }
  if (typeof existingData.workOrStudy === "string") {
    cleanDoc.workOrStudy = existingData.workOrStudy.trim().slice(0, 100);
  }
  if (
    typeof existingData.joinedAt === "string" &&
    existingData.joinedAt.trim()
  ) {
    cleanDoc.joinedAt = existingData.joinedAt.trim().slice(0, 40);
  } else if (
    typeof existingData.joinedAt === "number" &&
    Number.isFinite(existingData.joinedAt) &&
    existingData.joinedAt >= 0
  ) {
    cleanDoc.joinedAt = Math.round(existingData.joinedAt);
  }
  if (typeof existingData.isProfileLocked === "boolean") {
    cleanDoc.isProfileLocked = existingData.isProfileLocked;
  }
  if (typeof existingData.showAgeCity === "boolean") {
    cleanDoc.showAgeCity = existingData.showAgeCity;
  }
  if (typeof existingData.showPersonalInfo === "boolean") {
    cleanDoc.showPersonalInfo = existingData.showPersonalInfo;
  }
  if (typeof existingData.showFriends === "boolean") {
    cleanDoc.showFriends = existingData.showFriends;
  }
  if (typeof existingData.showLastSeen === "boolean") {
    cleanDoc.showLastSeen = existingData.showLastSeen;
  }

  if (Array.isArray(existingData.friends)) {
    cleanDoc.friends = existingData.friends
      .filter((id): id is string => typeof id === "string" && id.length > 0)
      .slice(0, 500);
  }
  if (Array.isArray(existingData.pinnedChats)) {
    cleanDoc.pinnedChats = existingData.pinnedChats
      .filter((id): id is string => typeof id === "string" && id.length > 0)
      .slice(0, 200);
  }
  if (Array.isArray(existingData.blockedUsers)) {
    cleanDoc.blockedUsers = existingData.blockedUsers
      .filter((id): id is string => typeof id === "string" && id.length > 0)
      .slice(0, 200);
  }
  if (
    existingData.blockedUntil &&
    typeof existingData.blockedUntil === "object" &&
    !Array.isArray(existingData.blockedUntil)
  ) {
    const cleanUntil: Record<string, number> = {};
    Object.entries(existingData.blockedUntil as Record<string, unknown>)
      .slice(0, 200)
      .forEach(([k, v]) => {
        if (typeof k === "string" && typeof v === "number" && Number.isFinite(v)) {
          cleanUntil[k] = v;
        }
      });
    cleanDoc.blockedUntil = cleanUntil;
  }

  return {
    ...cleanDoc,
    ...overridePayload,
    uid,
    lastSeen: serverTimestamp(),
  };
}

export async function upsertCloudUserProfile(params: {
  uid: string;
  displayName: string;
  avatar: string;
  coverPhoto?: string;
  bio?: string;
  publicKey?: string;
  sessionVersion?: number;
  countryCode?: string;
  emailHash?: string;
  age?: number | null;
  city?: string;
  maritalStatus?: MaritalStatus;
  workOrStudy?: string;
  joinedAt?: string | number | null;
  isProfileLocked?: boolean;
  showAgeCity?: boolean;
  showPersonalInfo?: boolean;
  showFriends?: boolean;
  showLastSeen?: boolean;
  isOnline: boolean;
}): Promise<void> {
  if (!params.uid || auth.currentUser?.uid !== params.uid) {
    return;
  }

  const safeName = params.displayName.trim().slice(0, 50) || "مستخدم";
  const safeAvatar = sanitizeAvatarForFirestore(params.avatar);
  const path = `users/${params.uid}`;

  const payload: Record<string, unknown> = {
    uid: params.uid,
    displayName: safeName,
    displayNameLower: normalizeArabicSearch(safeName).slice(0, 50),
    displayNameExactLower: safeName.toLowerCase().slice(0, 50),
    avatar: safeAvatar,
    photoURL: safeAvatar,
    isOnline: Boolean(params.isOnline),
    lastSeen: serverTimestamp(),
  };

  if (params.coverPhoto !== undefined) {
    payload.coverPhoto = String(params.coverPhoto || "").slice(0, 85000);
  }
  if (params.bio !== undefined) {
    payload.bio = params.bio.trim().slice(0, 160);
  }
  if (params.publicKey !== undefined && params.publicKey) {
    payload.publicKey = params.publicKey.slice(0, 1024);
  }
  if (
    typeof params.sessionVersion === "number" &&
    Number.isFinite(params.sessionVersion) &&
    params.sessionVersion >= 1
  ) {
    payload.sessionVersion = Math.round(params.sessionVersion);
  }
  if (params.countryCode) {
    payload.countryCode = normalizeCountryCode(params.countryCode);
  }
  if (params.emailHash) {
    payload.emailHash = params.emailHash.slice(0, 128);
  }
  if (params.age !== undefined) {
    payload.age =
      typeof params.age === "number" &&
      Number.isFinite(params.age) &&
      params.age >= 5 &&
      params.age <= 120
        ? Math.round(params.age)
        : null;
  }
  if (params.city !== undefined) {
    payload.city = params.city.trim().slice(0, 60);
  }
  if (
    params.maritalStatus === "unspecified" ||
    params.maritalStatus === "single" ||
    params.maritalStatus === "engaged" ||
    params.maritalStatus === "married"
  ) {
    payload.maritalStatus = params.maritalStatus;
  }
  if (params.workOrStudy !== undefined) {
    payload.workOrStudy = params.workOrStudy.trim().slice(0, 100);
  }
  if (typeof params.joinedAt === "string" && params.joinedAt.trim()) {
    payload.joinedAt = params.joinedAt.trim().slice(0, 40);
  } else if (
    typeof params.joinedAt === "number" &&
    Number.isFinite(params.joinedAt) &&
    params.joinedAt > 0
  ) {
    payload.joinedAt = Math.round(params.joinedAt);
  }
  if (typeof params.isProfileLocked === "boolean") {
    payload.isProfileLocked = params.isProfileLocked;
  }
  if (typeof params.showAgeCity === "boolean") {
    payload.showAgeCity = params.showAgeCity;
  }
  if (typeof params.showPersonalInfo === "boolean") {
    payload.showPersonalInfo = params.showPersonalInfo;
  }
  if (typeof params.showFriends === "boolean") {
    payload.showFriends = params.showFriends;
  }
  if (typeof params.showLastSeen === "boolean") {
    payload.showLastSeen = params.showLastSeen;
  }

  const userRef = doc(db, "users", params.uid);

  try {
    await setDoc(userRef, payload, { merge: true });
    invalidatePeerCache(params.uid);
  } catch (error) {
    try {
      const existingSnap = await getDoc(userRef);
      if (existingSnap.exists()) {
        const cleanDoc = buildSanitizedLegacyUserDoc(
          existingSnap.data() as Record<string, unknown>,
          payload,
          params.uid
        );
        await setDoc(userRef, cleanDoc);
        invalidatePeerCache(params.uid);
        return;
      }
    } catch {
      // Fall through to report structured error
    }
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function updateUserPresence(params: {
  uid: string;
  displayName: string;
  avatar: string;
  countryCode?: string;
  isOnline: boolean;
}): Promise<void> {
  if (!params.uid || auth.currentUser?.uid !== params.uid) {
    return;
  }

  const safeName = params.displayName.trim().slice(0, 50) || "مستخدم";
  const safeAvatar = sanitizeAvatarForFirestore(params.avatar);

  const payload: Record<string, unknown> = {
    displayName: safeName,
    displayNameLower: normalizeArabicSearch(safeName).slice(0, 50),
    displayNameExactLower: safeName.toLowerCase().slice(0, 50),
    avatar: safeAvatar,
    photoURL: safeAvatar,
    isOnline: Boolean(params.isOnline),
    lastSeen: serverTimestamp(),
  };

  if (params.countryCode) {
    payload.countryCode = normalizeCountryCode(params.countryCode);
  }

  try {
    await updateDoc(doc(db, "users", params.uid), payload);
  } catch {
    await upsertCloudUserProfile(params);
  }
}

export async function blockCloudUser(
  currentUid: string,
  targetUid: string,
  durationMs: number | null = null
): Promise<Record<string, number>> {
  if (!currentUid || !targetUid || currentUid === targetUid) return {};
  const path = `users/${currentUid}`;
  try {
    const snap = await getDoc(doc(db, "users", currentUid));
    const existingUntil =
      (snap.exists() &&
        typeof snap.data()?.blockedUntil === "object" &&
        snap.data()?.blockedUntil !== null
        ? (snap.data()?.blockedUntil as Record<string, number>)
        : {}) || {};
    const expiresAt =
      durationMs && durationMs > 0 ? Date.now() + durationMs : 0;
    const nextUntil: Record<string, number> = {
      ...existingUntil,
      [targetUid]: expiresAt,
    };

    await updateDoc(doc(db, "users", currentUid), {
      blockedUsers: arrayUnion(targetUid),
      blockedUntil: nextUntil,
      lastSeen: serverTimestamp(),
    });
    return nextUntil;
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function unblockCloudUser(
  currentUid: string,
  targetUid: string
): Promise<Record<string, number>> {
  if (!currentUid || !targetUid) return {};
  const path = `users/${currentUid}`;
  try {
    const snap = await getDoc(doc(db, "users", currentUid));
    const existingUntil =
      (snap.exists() &&
        typeof snap.data()?.blockedUntil === "object" &&
        snap.data()?.blockedUntil !== null
        ? (snap.data()?.blockedUntil as Record<string, number>)
        : {}) || {};
    const nextUntil: Record<string, number> = { ...existingUntil };
    delete nextUntil[targetUid];

    await updateDoc(doc(db, "users", currentUid), {
      blockedUsers: arrayRemove(targetUid),
      blockedUntil: nextUntil,
      lastSeen: serverTimestamp(),
    });
    return nextUntil;
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function cleanupExpiredBlocks(
  currentUid: string,
  blockedUsers: string[],
  blockedUntil: Record<string, number>
): Promise<{ blockedUsers: string[]; blockedUntil: Record<string, number> }> {
  const now = Date.now();
  const expiredUids = blockedUsers.filter((uid) => {
    const until = blockedUntil[uid];
    return typeof until === "number" && until > 0 && until <= now;
  });

  if (expiredUids.length === 0) {
    return { blockedUsers, blockedUntil };
  }

  const nextBlocked = blockedUsers.filter((uid) => !expiredUids.includes(uid));
  const nextUntil = { ...blockedUntil };
  expiredUids.forEach((uid) => {
    delete nextUntil[uid];
  });

  await updateDoc(doc(db, "users", currentUid), {
    blockedUsers: nextBlocked,
    blockedUntil: nextUntil,
    lastSeen: serverTimestamp(),
  }).catch(() => {});

  return { blockedUsers: nextBlocked, blockedUntil: nextUntil };
}

export async function addFriendCloud(
  currentUid: string,
  friendUid: string
): Promise<void> {
  if (!currentUid || !friendUid || currentUid === friendUid) return;
  try {
    await updateDoc(doc(db, "users", currentUid), {
      friends: arrayUnion(friendUid),
      lastSeen: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `users/${currentUid}`);
  }
}

export async function removeFriendCloud(
  currentUid: string,
  friendUid: string
): Promise<void> {
  if (!currentUid || !friendUid) return;
  try {
    await updateDoc(doc(db, "users", currentUid), {
      friends: arrayRemove(friendUid),
      lastSeen: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `users/${currentUid}`);
  }

  // Also remove currentUid from the peer's friends list so friendship is removed for both
  try {
    await updateDoc(doc(db, "users", friendUid), {
      friends: arrayRemove(currentUid),
    });
  } catch {
    // non-fatal if peer didn't list currentUid or account no longer exists
  }
}

export async function togglePinChatCloud(
  currentUid: string,
  chatId: string,
  pin: boolean
): Promise<void> {
  if (!currentUid || !chatId) return;
  try {
    await updateDoc(doc(db, "users", currentUid), {
      pinnedChats: pin ? arrayUnion(chatId) : arrayRemove(chatId),
      lastSeen: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `users/${currentUid}`);
  }
}

const PEER_CACHE_LS_KEY = "mirsal_peer_profile_cache_v1";
const PEER_CACHE_TTL_MS = 5 * 60 * 1000;
const peerProfileMemoryCache = new Map<
  string,
  { profile: PeerUserProfile; cachedAt: number }
>();

function hydratePeerCacheFromStorage(): void {
  if (peerProfileMemoryCache.size > 0 || typeof localStorage === "undefined") return;
  try {
    const raw = localStorage.getItem(PEER_CACHE_LS_KEY);
    if (!raw) return;
    const parsed = JSON.parse(raw) as Record<
      string,
      { profile: PeerUserProfile; cachedAt: number }
    >;
    const now = Date.now();
    if (parsed && typeof parsed === "object") {
      Object.entries(parsed).forEach(([uid, entry]) => {
        if (
          entry &&
          entry.profile &&
          typeof entry.cachedAt === "number" &&
          now - entry.cachedAt < PEER_CACHE_TTL_MS
        ) {
          peerProfileMemoryCache.set(uid, entry);
        }
      });
    }
  } catch {
    // ignore cache hydration failure
  }
}

function persistPeerCacheToStorage(): void {
  if (typeof localStorage === "undefined") return;
  try {
    const entries = Array.from(peerProfileMemoryCache.entries()).slice(-120);
    const obj: Record<string, { profile: PeerUserProfile; cachedAt: number }> = {};
    entries.forEach(([uid, entry]) => {
      // Avoid blowing localStorage quota with large custom base64 cover/avatar images
      const slimProfile: PeerUserProfile = {
        ...entry.profile,
        avatar:
          entry.profile.avatar.length > 2000 ? DEFAULT_USER_AVATAR : entry.profile.avatar,
        photoURL:
          entry.profile.photoURL && entry.profile.photoURL.length > 2000
            ? undefined
            : entry.profile.photoURL,
        coverPhoto:
          entry.profile.coverPhoto && entry.profile.coverPhoto.length > 2000
            ? undefined
            : entry.profile.coverPhoto,
      };
      obj[uid] = { profile: slimProfile, cachedAt: entry.cachedAt };
    });
    localStorage.setItem(PEER_CACHE_LS_KEY, JSON.stringify(obj));
  } catch {
    // ignore quota errors
  }
}

export function primePeerCache(profile: PeerUserProfile): void {
  if (!profile?.uid) return;
  peerProfileMemoryCache.set(profile.uid, {
    profile,
    cachedAt: Date.now(),
  });
}

export function invalidatePeerCache(uid?: string): void {
  if (!uid) {
    peerProfileMemoryCache.clear();
    return;
  }
  peerProfileMemoryCache.delete(uid);
}

function mapDocToPeerUser(data: Record<string, unknown>): PeerUserProfile {
  const lastSeenRaw = data.lastSeen as Timestamp | null | undefined;
  const lastSeenMs =
    lastSeenRaw && typeof lastSeenRaw.toMillis === "function"
      ? lastSeenRaw.toMillis()
      : null;

  const blockedRaw = Array.isArray(data.blockedUsers)
    ? data.blockedUsers.filter((id): id is string => typeof id === "string")
    : [];

  const blockedUntilRaw: Record<string, number> = {};
  if (data.blockedUntil && typeof data.blockedUntil === "object") {
    Object.entries(data.blockedUntil as Record<string, unknown>).forEach(
      ([k, v]) => {
        if (typeof v === "number" && Number.isFinite(v)) {
          blockedUntilRaw[k] = v;
        }
      }
    );
  }

  const friendsRaw = Array.isArray(data.friends)
    ? data.friends.filter((id): id is string => typeof id === "string")
    : [];

  const rawMarital = data.maritalStatus;
  const maritalStatus: MaritalStatus =
    rawMarital === "single" ||
    rawMarital === "engaged" ||
    rawMarital === "married"
      ? rawMarital
      : "unspecified";

  const resolvedAvatar = normalizeUserAvatar(
    typeof data.photoURL === "string" && data.photoURL.trim()
      ? data.photoURL
      : typeof data.avatar === "string" && data.avatar.trim()
      ? data.avatar
      : DEFAULT_USER_AVATAR
  );

  return {
    uid: String(data.uid || ""),
    displayName: String(data.displayName || "مستخدم"),
    avatar: resolvedAvatar,
    photoURL: resolvedAvatar,
    coverPhoto:
      typeof data.coverPhoto === "string" && data.coverPhoto.trim()
        ? data.coverPhoto.trim()
        : undefined,
    bio:
      typeof data.bio === "string" && data.bio.trim()
        ? data.bio.trim().slice(0, 160)
        : undefined,
    publicKey:
      typeof data.publicKey === "string" && data.publicKey.trim()
        ? data.publicKey.trim()
        : undefined,
    sessionVersion:
      typeof data.sessionVersion === "number" && Number.isFinite(data.sessionVersion)
        ? Math.max(1, Math.round(data.sessionVersion))
        : 1,
    countryCode:
      typeof data.countryCode === "string" && data.countryCode.trim()
        ? data.countryCode.trim().toUpperCase()
        : undefined,
    age:
      typeof data.age === "number" && Number.isFinite(data.age)
        ? data.age
        : null,
    city:
      typeof data.city === "string" && data.city.trim()
        ? data.city.trim()
        : undefined,
    maritalStatus,
    workOrStudy:
      typeof data.workOrStudy === "string" && data.workOrStudy.trim()
        ? data.workOrStudy.trim()
        : undefined,
    joinedAt:
      typeof data.joinedAt === "string" && data.joinedAt.trim()
        ? data.joinedAt.trim().slice(0, 40)
        : typeof data.joinedAt === "number" && Number.isFinite(data.joinedAt)
        ? data.joinedAt
        : null,
    isProfileLocked: Boolean(data.isProfileLocked),
    showAgeCity: data.showAgeCity !== false,
    showPersonalInfo: data.showPersonalInfo !== false,
    showFriends: data.showFriends !== false,
    showLastSeen: data.showLastSeen !== false,
    friends: friendsRaw,
    blockedUsers: blockedRaw,
    blockedUntil: blockedUntilRaw,
    isOnline: Boolean(data.isOnline),
    lastSeen: lastSeenMs,
  };
}

export async function fetchUsersByUids(
  uids: string[],
  options?: { bypassCache?: boolean }
): Promise<Record<string, PeerUserProfile>> {
  const unique = Array.from(new Set(uids.filter(Boolean)));
  if (unique.length === 0) return {};

  hydratePeerCacheFromStorage();
  const now = Date.now();
  const result: Record<string, PeerUserProfile> = {};
  const toFetch: string[] = [];

  unique.forEach((uid) => {
    if (!options?.bypassCache) {
      const cached = peerProfileMemoryCache.get(uid);
      if (cached && now - cached.cachedAt < PEER_CACHE_TTL_MS) {
        result[uid] = cached.profile;
        return;
      }
    }
    toFetch.push(uid);
  });

  if (toFetch.length === 0) {
    return result;
  }

  const entries = await Promise.all(
    toFetch.map(async (uid) => {
      try {
        const snap = await getDoc(doc(db, "users", uid));
        if (!snap.exists()) return null;
        const mapped = mapDocToPeerUser(snap.data() as Record<string, unknown>);
        primePeerCache(mapped);
        return [uid, mapped] as const;
      } catch {
        return null;
      }
    })
  );

  entries.forEach((entry) => {
    if (entry) {
      result[entry[0]] = entry[1];
    }
  });
  persistPeerCacheToStorage();
  return result;
}

export async function findUsersByExactNameOrEmail(
  currentUid: string,
  rawQuery: string
): Promise<PeerUserProfile[]> {
  const clean = rawQuery.trim();
  if (!clean) return [];

  try {
    const resultsByUid = new Map<string, PeerUserProfile>();

    if (clean.includes("@")) {
      const hash = await sha256Hex(clean.toLowerCase());
      if (hash) {
        const emailSnap = await getDocs(
          query(
            collection(db, "users"),
            where("emailHash", "==", hash),
            limit(5)
          )
        );
        emailSnap.docs.forEach((docSnap) => {
          const mapped = mapDocToPeerUser(docSnap.data() as Record<string, unknown>);
          if (mapped.uid && mapped.uid !== currentUid) {
            resultsByUid.set(mapped.uid, mapped);
          }
        });
      }
    }

    const exactLower = clean.toLowerCase();
    const normAr = normalizeArabicSearch(clean);

    const [exactSnap, normSnap] = await Promise.all([
      getDocs(
        query(
          collection(db, "users"),
          where("displayNameExactLower", "==", exactLower),
          limit(10)
        )
      ),
      getDocs(
        query(
          collection(db, "users"),
          where("displayNameLower", "==", normAr),
          limit(10)
        )
      ),
    ]);

    [...exactSnap.docs, ...normSnap.docs].forEach((docSnap) => {
      const mapped = mapDocToPeerUser(docSnap.data() as Record<string, unknown>);
      if (mapped.uid && mapped.uid !== currentUid) {
        resultsByUid.set(mapped.uid, mapped);
      }
    });

    return Array.from(resultsByUid.values());
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, "users");
  }
}

export async function listMyFriends(
  currentUid: string,
  friendUids: string[]
): Promise<PeerUserProfile[]> {
  const cleanUids = Array.from(
    new Set(friendUids.filter((id) => Boolean(id) && id !== currentUid))
  );
  if (cleanUids.length === 0) return [];
  const fetched = await fetchUsersByUids(cleanUids);
  return Object.values(fetched).sort((a, b) => {
    const aOnline = a.showLastSeen !== false && a.isOnline;
    const bOnline = b.showLastSeen !== false && b.isOnline;
    if (aOnline !== bOnline) return aOnline ? -1 : 1;
    return a.displayName.localeCompare(b.displayName, "ar");
  });
}

export interface OwnCloudProfileSync {
  peer: PeerUserProfile;
  pinnedChats: string[];
}

export function subscribeToUserProfile(
  uid: string,
  onProfileChange: (profile: PeerUserProfile | null) => void,
  onError?: (err: Error) => void,
  onPinnedChange?: (pinnedChats: string[]) => void
): Unsubscribe {
  const path = `users/${uid}`;
  return onSnapshot(
    doc(db, "users", uid),
    (snapshot) => {
      if (!snapshot.exists()) {
        onProfileChange(null);
        return;
      }
      const raw = snapshot.data() as Record<string, unknown>;
      if (onPinnedChange) {
        const pinned = Array.isArray(raw.pinnedChats)
          ? raw.pinnedChats.filter((id): id is string => typeof id === "string")
          : [];
        onPinnedChange(pinned);
      }
      onProfileChange(mapDocToPeerUser(raw));
    },
    (error) => {
      try {
        handleFirestoreError(error, OperationType.GET, path);
      } catch (wrapped) {
        onError?.(wrapped as Error);
      }
    }
  );
}

// ---------- Direct 1-on-1 Chats ----------

export function buildDirectChatId(uidA: string, uidB: string): string {
  const [first, second] = [uidA, uidB].sort();
  return `${first}_${second}`;
}

export async function openOrCreateDirectChat(params: {
  currentUser: { uid: string; name: string; avatar: string };
  peerUser: PeerUserProfile;
}): Promise<Conversation> {
  if (params.currentUser.uid === params.peerUser.uid) {
    throw new Error("لا يمكنك بدء محادثة مع نفسك.");
  }

  const chatId = buildDirectChatId(params.currentUser.uid, params.peerUser.uid);
  const chatRef = doc(db, "chats", chatId);

  let existingSnap;
  try {
    existingSnap = await getDoc(chatRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, `chats/${chatId}`);
  }

  const isCurrentUser1 = params.currentUser.uid < params.peerUser.uid;
  const user1Uid = isCurrentUser1 ? params.currentUser.uid : params.peerUser.uid;
  const user1Name = isCurrentUser1
    ? params.currentUser.name.trim().slice(0, 50) || "مستخدم"
    : params.peerUser.displayName.trim().slice(0, 50) || "مستخدم";
  const user1Avatar = sanitizeAvatarForFirestore(
    isCurrentUser1 ? params.currentUser.avatar : params.peerUser.avatar
  );

  const user2Uid = isCurrentUser1 ? params.peerUser.uid : params.currentUser.uid;
  const user2Name = isCurrentUser1
    ? params.peerUser.displayName.trim().slice(0, 50) || "مستخدم"
    : params.currentUser.name.trim().slice(0, 50) || "مستخدم";
  const user2Avatar = sanitizeAvatarForFirestore(
    isCurrentUser1 ? params.peerUser.avatar : params.currentUser.avatar
  );

  if (!existingSnap.exists()) {
    try {
      await setDoc(chatRef, {
        chatId,
        participantIds: [user1Uid, user2Uid],
        user1Uid,
        user1Name,
        user1Avatar,
        user2Uid,
        user2Name,
        user2Avatar,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, `chats/${chatId}`);
    }
  }

  return {
    id: chatId,
    title: params.peerUser.displayName,
    subtitle:
      params.peerUser.showLastSeen !== false && params.peerUser.isOnline
        ? "متصل الآن"
        : "محادثة خاصة",
    type: "direct",
    avatar: normalizeUserAvatar(params.peerUser.avatar),
    peerUid: params.peerUser.uid,
    peerCountryCode: params.peerUser.countryCode,
    peerOnline:
      params.peerUser.showLastSeen !== false ? params.peerUser.isOnline : false,
    peerLastSeen:
      params.peerUser.showLastSeen !== false ? params.peerUser.lastSeen : null,
    peerShowLastSeen: params.peerUser.showLastSeen !== false,
    unreadCount: 0,
    messages: [],
  };
}

export async function createGroupChat(params: {
  creatorUid: string;
  groupName: string;
  groupAvatar: string;
  memberUids: string[];
}): Promise<Conversation> {
  const cleanName = params.groupName.trim().slice(0, 60) || "مجموعة مرسال";
  const safeAvatar = sanitizeAvatarForFirestore(params.groupAvatar);
  const participantIds = Array.from(
    new Set([params.creatorUid, ...params.memberUids.filter(Boolean)])
  ).slice(0, 50);

  const chatId = `grp_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
  const chatRef = doc(db, "chats", chatId);

  try {
    await setDoc(chatRef, {
      chatId,
      chatType: "group",
      participantIds,
      groupName: cleanName,
      groupAvatar: safeAvatar,
      adminIds: [params.creatorUid],
      createdBy: params.creatorUid,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, `chats/${chatId}`);
  }

  return {
    id: chatId,
    title: cleanName,
    subtitle: `${participantIds.length} أعضاء`,
    type: "group",
    avatar: safeAvatar,
    groupName: cleanName,
    adminIds: [params.creatorUid],
    memberIds: participantIds,
    createdBy: params.creatorUid,
    unreadCount: 0,
    messages: [],
  };
}

export async function addGroupMember(
  chatId: string,
  memberUid: string
): Promise<void> {
  if (!chatId || !memberUid) return;
  try {
    await updateDoc(doc(db, "chats", chatId), {
      participantIds: arrayUnion(memberUid),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `chats/${chatId}`);
  }
}

export async function removeGroupMember(
  chatId: string,
  memberUid: string
): Promise<void> {
  if (!chatId || !memberUid) return;
  try {
    await updateDoc(doc(db, "chats", chatId), {
      participantIds: arrayRemove(memberUid),
      adminIds: arrayRemove(memberUid),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `chats/${chatId}`);
  }
}

export async function leaveGroupChat(
  chatId: string,
  uid: string
): Promise<void> {
  if (!chatId || !uid) return;
  try {
    await updateDoc(doc(db, "chats", chatId), {
      participantIds: arrayRemove(uid),
      adminIds: arrayRemove(uid),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `chats/${chatId}`);
  }
}

export async function setChatTypingStatus(
  chatId: string,
  uid: string,
  isTyping: boolean
): Promise<void> {
  if (!chatId || !uid) return;
  try {
    await updateDoc(doc(db, "chats", chatId), {
      [`typing.${uid}`]: isTyping ? Date.now() : 0,
    });
  } catch {
    // non-blocking typing signal
  }
}

export async function hideChatForUser(
  chatId: string,
  uid: string
): Promise<void> {
  if (!chatId || !uid) return;
  const path = `chats/${chatId}`;
  try {
    const snap = await getDoc(doc(db, "chats", chatId));
    if (!snap.exists()) return;
    const raw = snap.data() as Record<string, unknown>;
    const existingDeleted =
      raw.deletedBy && typeof raw.deletedBy === "object"
        ? (raw.deletedBy as Record<string, number>)
        : {};
    const existingCleared =
      raw.clearedAt && typeof raw.clearedAt === "object"
        ? (raw.clearedAt as Record<string, number>)
        : {};
    const now = Date.now();
    await updateDoc(doc(db, "chats", chatId), {
      deletedBy: { ...existingDeleted, [uid]: now },
      clearedAt: { ...existingCleared, [uid]: now },
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export function subscribeToUserDirectChats(
  uid: string,
  onChatsChange: (chats: Conversation[]) => void,
  onError?: (err: Error) => void
): Unsubscribe {
  const path = "chats";
  const chatsQuery = query(
    collection(db, "chats"),
    where("participantIds", "array-contains", uid)
  );

  return onSnapshot(
    chatsQuery,
    (snapshot) => {
      const now = Date.now();
      const list: Conversation[] = [];

      snapshot.docs.forEach((docSnap) => {
        const data = docSnap.data({ serverTimestamps: "estimate" }) as {
          chatId: string;
          chatType?: "direct" | "group";
          participantIds?: string[];
          user1Uid?: string;
          user1Name?: string;
          user1Avatar?: string;
          user2Uid?: string;
          user2Name?: string;
          user2Avatar?: string;
          groupName?: string;
          groupAvatar?: string;
          adminIds?: string[];
          createdBy?: string;
          typing?: Record<string, number>;
          deletedBy?: Record<string, number>;
          clearedAt?: Record<string, number>;
          disappearingTimer?: number;
          lastMessageText?: string;
          lastMessageSenderId?: string;
          lastMessageType?: "text" | "image" | "video" | "audio" | "call";
          updatedAt?: Timestamp | null;
        };

        const disappearingTimer: DisappearingTimerSeconds =
          data.disappearingTimer === 86400 ||
          data.disappearingTimer === 604800 ||
          data.disappearingTimer === 7776000
            ? data.disappearingTimer
            : 0;

        const updatedMs =
          data.updatedAt && typeof data.updatedAt.toMillis === "function"
            ? data.updatedAt.toMillis()
            : undefined;

        const deletedAt = data.deletedBy?.[uid] || 0;
        const clearedAt = Math.max(deletedAt, data.clearedAt?.[uid] || 0);

        // Hide chat strictly for this user if they hid/deleted it and no newer message has arrived since
        if (deletedAt > 0 && (!updatedMs || updatedMs <= deletedAt + 1200)) {
          return;
        }

        const typingUids = data.typing
          ? Object.entries(data.typing)
              .filter(
                ([tUid, ts]) =>
                  tUid !== uid && typeof ts === "number" && now - ts <= 4500
              )
              .map(([tUid]) => tUid)
          : [];

        if (data.chatType === "group") {
          const members = Array.isArray(data.participantIds)
            ? data.participantIds
            : [];
          list.push({
            id: data.chatId || docSnap.id,
            title: data.groupName || "مجموعة مرسال",
            subtitle: `${members.length} أعضاء`,
            type: "group",
            avatar: normalizeUserAvatar(data.groupAvatar || DEFAULT_USER_AVATAR),
            groupName: data.groupName || "مجموعة مرسال",
            adminIds: Array.isArray(data.adminIds) ? data.adminIds : [],
            memberIds: members,
            createdBy: data.createdBy,
            typingUids,
            clearedAt: clearedAt > 0 ? clearedAt : undefined,
            disappearingTimer,
            lastMessagePreview:
              clearedAt > 0 && updatedMs && updatedMs <= clearedAt + 1200
                ? ""
                : data.lastMessageText,
            lastMessageTimestamp: updatedMs,
            lastMessageSenderId: data.lastMessageSenderId,
            lastMessageType: data.lastMessageType,
            unreadCount: 0,
            messages: [],
          });
          return;
        }

        const peerIsUser2 = data.user1Uid === uid;
        const peerUid = peerIsUser2 ? data.user2Uid : data.user1Uid;
        const peerName = peerIsUser2 ? data.user2Name : data.user1Name;
        const peerAvatar = peerIsUser2 ? data.user2Avatar : data.user1Avatar;

        list.push({
          id: data.chatId || docSnap.id,
          title: peerName || "صديق",
          subtitle: "محادثة خاصة",
          type: "direct",
          avatar: normalizeUserAvatar(peerAvatar),
          peerUid,
          typingUids,
          clearedAt: clearedAt > 0 ? clearedAt : undefined,
          disappearingTimer,
          lastMessagePreview:
            clearedAt > 0 && updatedMs && updatedMs <= clearedAt + 1200
              ? ""
              : data.lastMessageText,
          lastMessageTimestamp: updatedMs,
          lastMessageSenderId: data.lastMessageSenderId,
          lastMessageType: data.lastMessageType,
          unreadCount: 0,
          messages: [],
        });
      });

      onChatsChange(list);
    },
    (error) => {
      try {
        handleFirestoreError(error, OperationType.LIST, path);
      } catch (wrapped) {
        onError?.(wrapped as Error);
      }
    }
  );
}

export function subscribeToChatMessages(
  chatId: string,
  currentUid: string,
  onMessagesChange: (messages: ChatMessage[]) => void,
  onError?: (err: Error) => void
): Unsubscribe {
  const path = `chats/${chatId}/messages`;
  const msgQuery = query(
    collection(db, "chats", chatId, "messages"),
    orderBy("createdAt", "asc"),
    limitToLast(30)
  );

  return onSnapshot(
    msgQuery,
    (snapshot) => {
      const msgs: ChatMessage[] = [];
      snapshot.docs.forEach((docSnap) => {
        const data = docSnap.data({ serverTimestamps: "estimate" }) as {
          senderId: string;
          senderName: string;
          text: string;
          isEncrypted?: boolean;
          ciphertext?: string;
          iv?: string;
          imageDataUrl?: string;
          videoDataUrl?: string;
          audioDataUrl?: string;
          audioDuration?: number;
          messageType?: "text" | "call";
          callInfo?: CallRecordInfo;
          replyTo?: MessageReplyRef;
          reactions?: Record<string, string>;
          edited?: boolean;
          editedAt?: Timestamp | null;
          deletedFor?: string[];
          expiresAt?: number;
          viewOnce?: boolean;
          viewOnceOpened?: boolean;
          readAt?: Timestamp | null;
          readBy?: Record<string, number>;
          createdAt?: Timestamp | null;
        };

        if (
          Array.isArray(data.deletedFor) &&
          data.deletedFor.includes(currentUid)
        ) {
          return;
        }

        const ts =
          data.createdAt && typeof data.createdAt.toMillis === "function"
            ? data.createdAt.toMillis()
            : Date.now();
        const editedAtMs =
          data.editedAt && typeof data.editedAt.toMillis === "function"
            ? data.editedAt.toMillis()
            : undefined;
        const readAtMs =
          data.readAt && typeof data.readAt.toMillis === "function"
            ? data.readAt.toMillis()
            : undefined;
        const readByMap =
          data.readBy && typeof data.readBy === "object"
            ? data.readBy
            : undefined;
        const isReadByPeer =
          Boolean(readAtMs) ||
          Boolean(
            readByMap &&
              Object.keys(readByMap).some((readerUid) => readerUid !== data.senderId)
          );

        msgs.push({
          id: docSnap.id,
          senderId: data.senderId === currentUid ? "me" : data.senderId,
          senderName: data.senderName,
          text: data.text || "",
          isEncrypted: Boolean(data.isEncrypted),
          ciphertext: typeof data.ciphertext === "string" ? data.ciphertext : undefined,
          iv: typeof data.iv === "string" ? data.iv : undefined,
          imageDataUrl: data.imageDataUrl,
          videoDataUrl: data.videoDataUrl,
          audioDataUrl: data.audioDataUrl,
          audioDuration: data.audioDuration,
          messageType: data.messageType,
          callInfo: data.callInfo,
          replyTo: data.replyTo,
          reactions:
            data.reactions && typeof data.reactions === "object"
              ? data.reactions
              : undefined,
          edited: Boolean(data.edited),
          editedAt: editedAtMs,
          deletedFor: Array.isArray(data.deletedFor)
            ? data.deletedFor
            : undefined,
          expiresAt:
            typeof data.expiresAt === "number" && Number.isFinite(data.expiresAt)
              ? data.expiresAt
              : undefined,
          viewOnce: Boolean(data.viewOnce),
          viewOnceOpened: Boolean(data.viewOnceOpened),
          readAt: readAtMs,
          readBy: readByMap,
          timestamp: ts,
          status: isReadByPeer ? "read" : "delivered",
        });
      });
      onMessagesChange(msgs);
    },
    (error) => {
      try {
        handleFirestoreError(error, OperationType.LIST, path);
      } catch (wrapped) {
        onError?.(wrapped as Error);
      }
    }
  );
}

export async function sendDirectChatMessage(params: {
  chatId: string;
  uid: string;
  senderName: string;
  text: string;
  isEncrypted?: boolean;
  ciphertext?: string;
  iv?: string;
  imageDataUrl?: string;
  videoDataUrl?: string;
  audioDataUrl?: string;
  audioDuration?: number;
  replyTo?: MessageReplyRef;
  viewOnce?: boolean;
  expiresAt?: number;
}): Promise<void> {
  const cleanText = params.text.trim().slice(0, 4000);
  const safeSender = params.senderName.trim().slice(0, 50) || "مستخدم";

  if (
    !cleanText &&
    !params.isEncrypted &&
    !params.imageDataUrl &&
    !params.videoDataUrl &&
    !params.audioDataUrl
  ) {
    return;
  }

  if (params.imageDataUrl && params.imageDataUrl.length > 350000) {
    throw new Error("حجم الصورة كبير جداً للإرسال. يرجى اختيار صورة أصغر.");
  }

  if (params.videoDataUrl && params.videoDataUrl.length > 950000) {
    throw new Error("حجم الفيديو كبير جداً للإرسال. يرجى اختيار مقطع أقصر.");
  }

  if (params.audioDataUrl && params.audioDataUrl.length > 350000) {
    throw new Error("مدة الرسالة الصوتية طويلة جداً للإرسال. حاول تسجيل مقطع أقصر.");
  }

  const msgRef = doc(collection(db, "chats", params.chatId, "messages"));
  const chatRef = doc(db, "chats", params.chatId);

  const payload: Record<string, unknown> = {
    chatId: params.chatId,
    senderId: params.uid,
    senderName: safeSender,
    text: params.isEncrypted ? "🔒 رسالة مشفرة" : cleanText,
    createdAt: serverTimestamp(),
  };

  if (params.isEncrypted && params.ciphertext && params.iv) {
    payload.isEncrypted = true;
    payload.ciphertext = params.ciphertext.slice(0, 8000);
    payload.iv = params.iv.slice(0, 64);
  }

  const isViewOnce = Boolean(params.viewOnce && params.imageDataUrl);
  if (params.imageDataUrl) {
    payload.imageDataUrl = params.imageDataUrl;
    if (isViewOnce) {
      payload.viewOnce = true;
      payload.viewOnceOpened = false;
    }
  }
  if (
    typeof params.expiresAt === "number" &&
    Number.isFinite(params.expiresAt) &&
    params.expiresAt > Date.now()
  ) {
    payload.expiresAt = Math.round(params.expiresAt);
  }
  if (params.videoDataUrl) {
    payload.videoDataUrl = params.videoDataUrl;
  }
  if (params.audioDataUrl) {
    payload.audioDataUrl = params.audioDataUrl;
    if (typeof params.audioDuration === "number") {
      payload.audioDuration = Math.min(
        180,
        Math.max(0, Math.round(params.audioDuration))
      );
    }
  }
  if (params.replyTo) {
    payload.replyTo = {
      id: params.replyTo.id,
      senderName: params.replyTo.senderName.slice(0, 60),
      text: params.replyTo.text.slice(0, 500),
      ...(params.replyTo.mediaType ? { mediaType: params.replyTo.mediaType } : {}),
    };
  }

  const lastMessageType: "text" | "image" | "video" | "audio" =
    params.videoDataUrl
      ? "video"
      : params.audioDataUrl
      ? "audio"
      : params.imageDataUrl
      ? "image"
      : "text";

  const previewText = params.isEncrypted
    ? "🔒 رسالة مشفرة"
    : isViewOnce
    ? "① صورة"
    : cleanText
    ? cleanText.slice(0, 450)
    : params.videoDataUrl
    ? "فيديو"
    : params.audioDataUrl
    ? "رسالة صوتية"
    : "صورة";

  const batch = writeBatch(db);
  batch.set(msgRef, payload);
  batch.update(chatRef, {
    lastMessageText: previewText,
    lastMessageSenderId: params.uid,
    lastMessageType,
    [`typing.${params.uid}`]: 0,
    updatedAt: serverTimestamp(),
  });

  try {
    await batch.commit();
  } catch (error) {
    handleFirestoreError(
      error,
      OperationType.CREATE,
      `chats/${params.chatId}/messages/${msgRef.id}`
    );
  }
}

export async function setChatDisappearingTimer(
  chatId: string,
  seconds: DisappearingTimerSeconds
): Promise<void> {
  if (!chatId) return;
  try {
    await updateDoc(doc(db, "chats", chatId), {
      disappearingTimer: seconds,
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `chats/${chatId}`);
  }
}

export async function markViewOnceImageOpened(
  chatId: string,
  messageId: string
): Promise<void> {
  if (!chatId || !messageId) return;
  const msgRef = doc(db, "chats", chatId, "messages", messageId);
  try {
    await updateDoc(msgRef, {
      imageDataUrl: "",
      viewOnceOpened: true,
    });
  } catch (error) {
    handleFirestoreError(
      error,
      OperationType.UPDATE,
      `chats/${chatId}/messages/${messageId}`
    );
  }
}

export async function deleteExpiredChatMessages(
  chatId: string,
  messageIds: string[]
): Promise<void> {
  if (!chatId || messageIds.length === 0) return;
  await Promise.all(
    messageIds.map((messageId) =>
      deleteDoc(doc(db, "chats", chatId, "messages", messageId)).catch(
        () => {}
      )
    )
  );
}

export async function sendCallHistoryMessage(params: {
  chatId: string;
  callId: string;
  senderId: string;
  senderName: string;
  callerId: string;
  callType: CallType;
  outcome: CallOutcome;
  durationSeconds: number;
  checkExistsFirst?: boolean;
}): Promise<void> {
  if (!params.chatId || !params.callId || !params.senderId) return;

  const msgRef = doc(db, "chats", params.chatId, "messages", params.callId);
  const chatRef = doc(db, "chats", params.chatId);

  try {
    if (params.checkExistsFirst) {
      const existing = await getDoc(msgRef);
      if (existing.exists()) return;
    }

    const safeSender = params.senderName.trim().slice(0, 50) || "مستخدم";
    const safeDuration = Math.min(
      86400,
      Math.max(0, Math.round(params.durationSeconds))
    );
    const isMissedOrDeclined =
      params.outcome === "missed" || params.outcome === "declined";
    const summaryText = isMissedOrDeclined
      ? params.callType === "video"
        ? "مكالمة فيديو فائتة"
        : "مكالمة صوتية فائتة"
      : params.callType === "video"
      ? "مكالمة فيديو"
      : "مكالمة صوتية";

    const callInfo: CallRecordInfo = {
      callId: params.callId,
      callType: params.callType,
      outcome: params.outcome,
      durationSeconds: safeDuration,
      callerId: params.callerId,
    };

    const batch = writeBatch(db);
    batch.set(msgRef, {
      chatId: params.chatId,
      senderId: params.senderId,
      senderName: safeSender,
      text: summaryText,
      messageType: "call",
      callInfo,
      createdAt: serverTimestamp(),
    });
    batch.update(chatRef, {
      lastMessageText: summaryText,
      lastMessageSenderId: params.senderId,
      lastMessageType: "call",
      updatedAt: serverTimestamp(),
    });

    await batch.commit();
  } catch (error) {
    console.warn("Could not save call history message:", error);
  }
}

export async function toggleMessageReaction(
  chatId: string,
  messageId: string,
  uid: string,
  emoji: string
): Promise<void> {
  if (!chatId || !messageId || !uid || !emoji) return;
  const msgRef = doc(db, "chats", chatId, "messages", messageId);
  try {
    const snap = await getDoc(msgRef);
    if (!snap.exists()) return;
    const raw = snap.data() as { reactions?: Record<string, string> };
    const nextReactions: Record<string, string> =
      raw.reactions && typeof raw.reactions === "object"
        ? { ...raw.reactions }
        : {};
    if (nextReactions[uid] === emoji) {
      delete nextReactions[uid];
    } else {
      nextReactions[uid] = emoji;
    }
    await updateDoc(msgRef, { reactions: nextReactions });
  } catch (error) {
    handleFirestoreError(
      error,
      OperationType.UPDATE,
      `chats/${chatId}/messages/${messageId}`
    );
  }
}

export async function editDirectChatMessage(
  chatId: string,
  messageId: string,
  nextText: string,
  encrypted?: { ciphertext: string; iv: string }
): Promise<void> {
  const cleanText = nextText.trim().slice(0, 4000);
  if (!chatId || !messageId || (!cleanText && !encrypted)) return;
  const msgRef = doc(db, "chats", chatId, "messages", messageId);
  try {
    if (encrypted && encrypted.ciphertext && encrypted.iv) {
      await updateDoc(msgRef, {
        text: "🔒 رسالة مشفرة",
        isEncrypted: true,
        ciphertext: encrypted.ciphertext.slice(0, 8000),
        iv: encrypted.iv.slice(0, 64),
        edited: true,
        editedAt: serverTimestamp(),
      });
    } else {
      await updateDoc(msgRef, {
        text: cleanText,
        edited: true,
        editedAt: serverTimestamp(),
      });
    }
  } catch (error) {
    handleFirestoreError(
      error,
      OperationType.UPDATE,
      `chats/${chatId}/messages/${messageId}`
    );
  }
}

export async function deleteMessageForMe(
  chatId: string,
  messageId: string,
  uid: string
): Promise<void> {
  if (!chatId || !messageId || !uid) return;
  const msgRef = doc(db, "chats", chatId, "messages", messageId);
  try {
    await updateDoc(msgRef, {
      deletedFor: arrayUnion(uid),
    });
  } catch (error) {
    handleFirestoreError(
      error,
      OperationType.UPDATE,
      `chats/${chatId}/messages/${messageId}`
    );
  }
}

export async function deleteMessageForEveryone(
  chatId: string,
  messageId: string
): Promise<void> {
  if (!chatId || !messageId) return;
  const msgRef = doc(db, "chats", chatId, "messages", messageId);
  try {
    await deleteDoc(msgRef);
  } catch (error) {
    handleFirestoreError(
      error,
      OperationType.DELETE,
      `chats/${chatId}/messages/${messageId}`
    );
  }
}

export async function clearSingleDirectChatMessages(
  chatId: string
): Promise<void> {
  const path = `chats/${chatId}/messages`;
  try {
    const snap = await getDocs(collection(db, "chats", chatId, "messages"));
    const docs = snap.docs;
    for (let i = 0; i < docs.length; i += 400) {
      const batch = writeBatch(db);
      docs.slice(i, i + 400).forEach((d) => batch.delete(d.ref));
      if (i + 400 >= docs.length) {
        batch.update(doc(db, "chats", chatId), {
          lastMessageText: "",
          lastMessageSenderId: "",
          lastMessageType: "text",
          updatedAt: serverTimestamp(),
        });
      }
      await batch.commit();
    }
    if (docs.length === 0) {
      await updateDoc(doc(db, "chats", chatId), {
        lastMessageText: "",
        lastMessageSenderId: "",
        lastMessageType: "text",
        updatedAt: serverTimestamp(),
      });
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

export async function clearAllUserDirectChats(uid: string): Promise<void> {
  try {
    const chatsSnap = await getDocs(
      query(
        collection(db, "chats"),
        where("participantIds", "array-contains", uid)
      )
    );
    await Promise.all(
      chatsSnap.docs.map((d) => hideChatForUser(d.id, uid))
    );
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, "chats");
  }
}

// ---------- WebRTC Firestore Signaling Helpers ----------

export async function cleanupStaleChatCalls(chatId: string): Promise<void> {
  if (!chatId) return;
  try {
    const activeSnap = await getDocs(
      query(
        collection(db, "chats", chatId, "calls"),
        where("status", "in", ["ringing", "connected"])
      )
    );
    if (activeSnap.empty) return;
    await Promise.all(
      activeSnap.docs.map((d) =>
        updateDoc(d.ref, {
          status: "ended",
          updatedAt: serverTimestamp(),
        }).catch(() => {})
      )
    );
  } catch {
    // non-fatal stale cleanup
  }
}

export async function createCallSignalDoc(params: {
  chatId: string;
  callId: string;
  callerId: string;
  callerName: string;
  callType: CallType;
  offer: { type: RTCSdpType; sdp: string };
}): Promise<void> {
  const path = `chats/${params.chatId}/calls/${params.callId}`;
  try {
    await setDoc(doc(db, "chats", params.chatId, "calls", params.callId), {
      chatId: params.chatId,
      callId: params.callId,
      callerId: params.callerId,
      callerName: params.callerName.trim().slice(0, 50) || "مستخدم",
      callType: params.callType,
      status: "ringing",
      offer: {
        type: params.offer.type,
        sdp: params.offer.sdp,
      },
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function answerCallSignalDoc(params: {
  chatId: string;
  callId: string;
  calleeId: string;
  calleeName: string;
  answer: { type: RTCSdpType; sdp: string };
}): Promise<void> {
  const path = `chats/${params.chatId}/calls/${params.callId}`;
  try {
    await updateDoc(doc(db, "chats", params.chatId, "calls", params.callId), {
      calleeId: params.calleeId,
      calleeName: params.calleeName.trim().slice(0, 50) || "مستخدم",
      status: "connected",
      answer: {
        type: params.answer.type,
        sdp: params.answer.sdp,
      },
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function renegotiateCallOfferDoc(params: {
  chatId: string;
  callId: string;
  offer: { type: RTCSdpType; sdp: string };
  iceRestartSeq: number;
}): Promise<void> {
  const path = `chats/${params.chatId}/calls/${params.callId}`;
  try {
    await updateDoc(doc(db, "chats", params.chatId, "calls", params.callId), {
      offer: {
        type: params.offer.type,
        sdp: params.offer.sdp,
      },
      iceRestartSeq: params.iceRestartSeq,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function renegotiateCallAnswerDoc(params: {
  chatId: string;
  callId: string;
  answer: { type: RTCSdpType; sdp: string };
  answerRestartSeq: number;
}): Promise<void> {
  const path = `chats/${params.chatId}/calls/${params.callId}`;
  try {
    await updateDoc(doc(db, "chats", params.chatId, "calls", params.callId), {
      answer: {
        type: params.answer.type,
        sdp: params.answer.sdp,
      },
      answerRestartSeq: params.answerRestartSeq,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function requestCallIceRestartDoc(params: {
  chatId: string;
  callId: string;
  restartRequestedAt: number;
}): Promise<void> {
  const path = `chats/${params.chatId}/calls/${params.callId}`;
  try {
    await updateDoc(doc(db, "chats", params.chatId, "calls", params.callId), {
      restartRequestedAt: params.restartRequestedAt,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function endCallSignalDoc(params: {
  chatId: string;
  callId: string;
}): Promise<void> {
  const path = `chats/${params.chatId}/calls/${params.callId}`;
  try {
    await updateDoc(doc(db, "chats", params.chatId, "calls", params.callId), {
      status: "ended",
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    console.warn(`Could not end call doc ${path}:`, error);
  }
}

export async function getCallSignalDoc(
  chatId: string,
  callId: string
): Promise<ChatCallSignal | null> {
  if (!chatId || !callId) return null;
  try {
    const snap = await getDoc(doc(db, "chats", chatId, "calls", callId));
    if (!snap.exists()) return null;
    return snap.data() as ChatCallSignal;
  } catch {
    return null;
  }
}

export async function addIceCandidateDoc(params: {
  chatId: string;
  callId: string;
  role: "caller" | "callee";
  senderId: string;
  candidate: RTCIceCandidateInit;
}): Promise<void> {
  const sub = params.role === "caller" ? "callerCandidates" : "calleeCandidates";
  const path = `chats/${params.chatId}/calls/${params.callId}/${sub}`;
  try {
    await addDoc(
      collection(db, "chats", params.chatId, "calls", params.callId, sub),
      {
        senderId: params.senderId,
        candidate: params.candidate.candidate || "",
        sdpMid: params.candidate.sdpMid ?? null,
        sdpMLineIndex: params.candidate.sdpMLineIndex ?? null,
        createdAt: serverTimestamp(),
      }
    );
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export function subscribeToChatRingingCalls(
  chatId: string,
  chatTitle: string,
  currentUid: string,
  onIncomingCall: (call: ChatCallSignal | null) => void,
  onError?: (err: Error) => void
): Unsubscribe {
  const path = `chats/${chatId}/calls`;
  const callsQuery = query(
    collection(db, "chats", chatId, "calls"),
    where("status", "==", "ringing")
  );

  return onSnapshot(
    callsQuery,
    (snapshot) => {
      const nowMs = Date.now();
      const freshDocs = snapshot.docs
        .map((d) => {
          const raw = d.data() as ChatCallSignal & {
            createdAt?: Timestamp | null;
          };
          const createdMs =
            raw.createdAt && typeof raw.createdAt.toMillis === "function"
              ? raw.createdAt.toMillis()
              : nowMs;
          return { raw, createdMs };
        })
        .filter(
          ({ raw, createdMs }) =>
            raw.callerId !== currentUid && nowMs - createdMs <= 120_000
        )
        .sort((a, b) => b.createdMs - a.createdMs);

      const newest = freshDocs[0];
      if (!newest) {
        onIncomingCall(null);
        return;
      }
      onIncomingCall({
        ...newest.raw,
        chatTitle,
      });
    },
    (error) => {
      try {
        handleFirestoreError(error, OperationType.LIST, path);
      } catch (wrapped) {
        onError?.(wrapped as Error);
      }
    }
  );
}

export function subscribeToCallDoc(
  chatId: string,
  callId: string,
  onCallUpdate: (call: ChatCallSignal | null) => void,
  onError?: (err: Error) => void
): Unsubscribe {
  const path = `chats/${chatId}/calls/${callId}`;
  return onSnapshot(
    doc(db, "chats", chatId, "calls", callId),
    (snapshot) => {
      if (!snapshot.exists()) {
        onCallUpdate(null);
        return;
      }
      onCallUpdate(snapshot.data() as ChatCallSignal);
    },
    (error) => {
      try {
        handleFirestoreError(error, OperationType.GET, path);
      } catch (wrapped) {
        onError?.(wrapped as Error);
      }
    }
  );
}

export function subscribeToCallCandidates(
  chatId: string,
  callId: string,
  targetRole: "caller" | "callee",
  onCandidate: (candidate: RTCIceCandidateInit) => void,
  onError?: (err: Error) => void
): Unsubscribe {
  const sub = targetRole === "caller" ? "callerCandidates" : "calleeCandidates";
  const path = `chats/${chatId}/calls/${callId}/${sub}`;
  const candQuery = query(
    collection(db, "chats", chatId, "calls", callId, sub)
  );

  return onSnapshot(
    candQuery,
    (snapshot) => {
      snapshot.docChanges().forEach((change) => {
        if (change.type === "added") {
          const data = change.doc.data() as {
            candidate: string;
            sdpMid?: string | null;
            sdpMLineIndex?: number | null;
          };
          if (data.candidate) {
            onCandidate({
              candidate: data.candidate,
              sdpMid: data.sdpMid ?? undefined,
              sdpMLineIndex: data.sdpMLineIndex ?? undefined,
            });
          }
        }
      });
    },
    (error) => {
      try {
        handleFirestoreError(error, OperationType.LIST, path);
      } catch (wrapped) {
        onError?.(wrapped as Error);
      }
    }
  );
}

// ---------- WebRTC Screen Share Signaling Helpers ----------

export async function createScreenShareDoc(params: {
  chatId: string;
  shareId: string;
  sharerId: string;
  sharerName: string;
  shareMode?: ScreenShareMode;
  offer: { type: RTCSdpType; sdp: string };
}): Promise<void> {
  const path = `chats/${params.chatId}/screenShares/${params.shareId}`;
  try {
    await setDoc(doc(db, "chats", params.chatId, "screenShares", params.shareId), {
      chatId: params.chatId,
      shareId: params.shareId,
      sharerId: params.sharerId,
      sharerName: params.sharerName.trim().slice(0, 50) || "مستخدم",
      shareMode: params.shareMode || "screen",
      status: "offering",
      offer: {
        type: params.offer.type,
        sdp: params.offer.sdp,
      },
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function answerScreenShareDoc(params: {
  chatId: string;
  shareId: string;
  viewerId: string;
  viewerName: string;
  answer: { type: RTCSdpType; sdp: string };
}): Promise<void> {
  const path = `chats/${params.chatId}/screenShares/${params.shareId}`;
  try {
    await updateDoc(
      doc(db, "chats", params.chatId, "screenShares", params.shareId),
      {
        viewerId: params.viewerId,
        viewerName: params.viewerName.trim().slice(0, 50) || "مستخدم",
        status: "connected",
        answer: {
          type: params.answer.type,
          sdp: params.answer.sdp,
        },
        updatedAt: serverTimestamp(),
      }
    );
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function endScreenShareDoc(params: {
  chatId: string;
  shareId: string;
}): Promise<void> {
  const path = `chats/${params.chatId}/screenShares/${params.shareId}`;
  try {
    await updateDoc(
      doc(db, "chats", params.chatId, "screenShares", params.shareId),
      {
        status: "ended",
        updatedAt: serverTimestamp(),
      }
    );
  } catch (error) {
    console.warn(`Could not end screen share doc ${path}:`, error);
  }
}

export async function addScreenShareCandidateDoc(params: {
  chatId: string;
  shareId: string;
  role: "caller" | "callee";
  senderId: string;
  candidate: RTCIceCandidateInit;
}): Promise<void> {
  const sub = params.role === "caller" ? "callerCandidates" : "calleeCandidates";
  const path = `chats/${params.chatId}/screenShares/${params.shareId}/${sub}`;
  try {
    await addDoc(
      collection(
        db,
        "chats",
        params.chatId,
        "screenShares",
        params.shareId,
        sub
      ),
      {
        senderId: params.senderId,
        candidate: params.candidate.candidate || "",
        sdpMid: params.candidate.sdpMid ?? null,
        sdpMLineIndex: params.candidate.sdpMLineIndex ?? null,
        createdAt: serverTimestamp(),
      }
    );
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export function subscribeToChatScreenShares(
  chatId: string,
  currentUid: string,
  onIncomingShare: (share: ScreenShareSignal | null) => void,
  onError?: (err: Error) => void
): Unsubscribe {
  const path = `chats/${chatId}/screenShares`;
  const sharesQuery = query(
    collection(db, "chats", chatId, "screenShares"),
    where("status", "==", "offering")
  );

  return onSnapshot(
    sharesQuery,
    (snapshot) => {
      const nowMs = Date.now();
      const fresh = snapshot.docs
        .map((d) => {
          const raw = d.data() as ScreenShareSignal & {
            createdAt?: Timestamp | null;
          };
          const createdMs =
            raw.createdAt && typeof raw.createdAt.toMillis === "function"
              ? raw.createdAt.toMillis()
              : nowMs;
          return { raw, createdMs };
        })
        .filter(
          ({ raw, createdMs }) =>
            raw.sharerId !== currentUid && nowMs - createdMs <= 180_000
        )
        .sort((a, b) => b.createdMs - a.createdMs);

      onIncomingShare(fresh[0]?.raw || null);
    },
    (error) => {
      try {
        handleFirestoreError(error, OperationType.LIST, path);
      } catch (wrapped) {
        onError?.(wrapped as Error);
      }
    }
  );
}

export function subscribeToScreenShareDoc(
  chatId: string,
  shareId: string,
  onUpdate: (share: ScreenShareSignal | null) => void,
  onError?: (err: Error) => void
): Unsubscribe {
  const path = `chats/${chatId}/screenShares/${shareId}`;
  return onSnapshot(
    doc(db, "chats", chatId, "screenShares", shareId),
    (snapshot) => {
      if (!snapshot.exists()) {
        onUpdate(null);
        return;
      }
      onUpdate(snapshot.data() as ScreenShareSignal);
    },
    (error) => {
      try {
        handleFirestoreError(error, OperationType.GET, path);
      } catch (wrapped) {
        onError?.(wrapped as Error);
      }
    }
  );
}

export function subscribeToScreenShareCandidates(
  chatId: string,
  shareId: string,
  targetRole: "caller" | "callee",
  onCandidate: (candidate: RTCIceCandidateInit) => void,
  onError?: (err: Error) => void
): Unsubscribe {
  const sub = targetRole === "caller" ? "callerCandidates" : "calleeCandidates";
  const path = `chats/${chatId}/screenShares/${shareId}/${sub}`;
  const candQuery = query(
    collection(db, "chats", chatId, "screenShares", shareId, sub)
  );

  return onSnapshot(
    candQuery,
    (snapshot) => {
      snapshot.docChanges().forEach((change) => {
        if (change.type === "added") {
          const data = change.doc.data() as {
            candidate: string;
            sdpMid?: string | null;
            sdpMLineIndex?: number | null;
          };
          if (data.candidate) {
            onCandidate({
              candidate: data.candidate,
              sdpMid: data.sdpMid ?? undefined,
              sdpMLineIndex: data.sdpMLineIndex ?? undefined,
            });
          }
        }
      });
    },
    (error) => {
      try {
        handleFirestoreError(error, OperationType.LIST, path);
      } catch (wrapped) {
        onError?.(wrapped as Error);
      }
    }
  );
}

// ---------- Host-Controlled Watch Party Session ----------

export async function setWatchSessionDoc(params: {
  chatId: string;
  mediaType: WatchMediaType;
  videoId: string;
  mediaUrl: string;
  startedByUid: string;
  startedByName: string;
}): Promise<void> {
  const path = `chats/${params.chatId}/watchSession/current`;
  const cleanUrl = params.mediaUrl.trim().slice(0, 1500) || "https://youtube.com";
  const isFacebook = params.mediaType === "facebook";
  try {
    await setDoc(doc(db, "chats", params.chatId, "watchSession", "current"), {
      chatId: params.chatId,
      videoId: params.videoId,
      youtubeUrl: cleanUrl,
      mediaType: params.mediaType,
      mediaUrl: cleanUrl,
      videoUrl: cleanUrl,
      hostId: params.startedByUid,
      guestMicAllowed: true,
      isStarted: !isFacebook,
      countdownStartAtMs: 0,
      startedAtMs: !isFacebook ? Date.now() : 0,
      isPlaying: !isFacebook,
      currentTime: 0,
      playbackState: !isFacebook ? "playing" : "paused",
      playbackTime: 0,
      playbackRate: 1,
      startedByUid: params.startedByUid,
      startedByName: params.startedByName.trim().slice(0, 50) || "مستخدم",
      isActive: true,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function setWatchGuestMicAllowedDoc(
  chatId: string,
  guestMicAllowed: boolean
): Promise<void> {
  const path = `chats/${chatId}/watchSession/current`;
  try {
    await updateDoc(doc(db, "chats", chatId, "watchSession", "current"), {
      guestMicAllowed,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    console.warn(`Could not update watch guest mic setting ${path}:`, error);
  }
}

export async function startFacebookWatchCountdownDoc(params: {
  chatId: string;
  countdownStartAtMs: number;
}): Promise<void> {
  const path = `chats/${params.chatId}/watchSession/current`;
  try {
    await updateDoc(doc(db, "chats", params.chatId, "watchSession", "current"), {
      isStarted: false,
      countdownStartAtMs: params.countdownStartAtMs,
      startedAtMs: 0,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    console.warn(`Could not start Facebook watch countdown ${path}:`, error);
  }
}

export async function markWatchStartedDoc(chatId: string): Promise<void> {
  const path = `chats/${chatId}/watchSession/current`;
  try {
    await updateDoc(doc(db, "chats", chatId, "watchSession", "current"), {
      isStarted: true,
      startedAtMs: Date.now(),
      isPlaying: true,
      playbackState: "playing",
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    console.warn(`Could not mark watch started ${path}:`, error);
  }
}

export async function updateWatchPlaybackDoc(params: {
  chatId: string;
  playbackState: "playing" | "paused";
  playbackTime: number;
  playbackRate?: number;
}): Promise<void> {
  const path = `chats/${params.chatId}/watchSession/current`;
  const safeTime = Math.min(
    86400,
    Math.max(0, Math.round(params.playbackTime * 10) / 10)
  );
  const safeRate =
    typeof params.playbackRate === "number" &&
    Number.isFinite(params.playbackRate)
      ? Math.min(4, Math.max(0.25, params.playbackRate))
      : 1;
  try {
    await updateDoc(doc(db, "chats", params.chatId, "watchSession", "current"), {
      isPlaying: params.playbackState === "playing",
      currentTime: safeTime,
      playbackState: params.playbackState,
      playbackTime: safeTime,
      playbackRate: safeRate,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    console.warn(`Could not update watch playback ${path}:`, error);
  }
}

export async function stopWatchSessionDoc(params: {
  chatId: string;
  uid: string;
  userName: string;
  videoId?: string;
  youtubeUrl?: string;
}): Promise<void> {
  const path = `chats/${params.chatId}/watchSession/current`;
  const cleanUrl = (params.youtubeUrl || "https://youtube.com").slice(0, 1500);
  try {
    await setDoc(doc(db, "chats", params.chatId, "watchSession", "current"), {
      chatId: params.chatId,
      videoId: params.videoId || "ended",
      youtubeUrl: cleanUrl,
      mediaType: "youtube",
      mediaUrl: cleanUrl,
      videoUrl: cleanUrl,
      hostId: params.uid,
      guestMicAllowed: false,
      isStarted: false,
      countdownStartAtMs: 0,
      startedAtMs: 0,
      isPlaying: false,
      currentTime: 0,
      playbackState: "paused",
      playbackTime: 0,
      playbackRate: 1,
      startedByUid: params.uid,
      startedByName: params.userName.trim().slice(0, 50) || "مستخدم",
      isActive: false,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    console.warn(`Could not stop watch session ${path}:`, error);
  }
}

export function subscribeToWatchSession(
  chatId: string,
  onWatchChange: (session: WatchSessionData | null) => void,
  onError?: (err: Error) => void
): Unsubscribe {
  const path = `chats/${chatId}/watchSession/current`;
  return onSnapshot(
    doc(db, "chats", chatId, "watchSession", "current"),
    (snapshot) => {
      if (!snapshot.exists()) {
        onWatchChange(null);
        return;
      }
      const raw = snapshot.data() as WatchSessionData & {
        updatedAt?: Timestamp | null;
      };
      if (!raw.isActive) {
        onWatchChange(null);
        return;
      }
      const updatedAtMs =
        raw.updatedAt && typeof raw.updatedAt.toMillis === "function"
          ? raw.updatedAt.toMillis()
          : Date.now();
      onWatchChange({
        ...raw,
        updatedAtMs,
      });
    },
    (error) => {
      try {
        handleFirestoreError(error, OperationType.GET, path);
      } catch (wrapped) {
        onError?.(wrapped as Error);
      }
    }
  );
}

// ---------- Watch Together Voice Audio Signaling Helpers ----------

export async function cleanupStaleWatchAudio(chatId: string): Promise<void> {
  if (!chatId) return;
  try {
    const activeSnap = await getDocs(
      query(
        collection(db, "chats", chatId, "watchAudio"),
        where("status", "in", ["offering", "connected"])
      )
    );
    if (activeSnap.empty) return;
    await Promise.all(
      activeSnap.docs.map((d) =>
        updateDoc(d.ref, {
          status: "ended",
          updatedAt: serverTimestamp(),
        }).catch(() => {})
      )
    );
  } catch {
    // non-fatal cleanup
  }
}

export async function createWatchAudioDoc(params: {
  chatId: string;
  audioId: string;
  initiatorId: string;
  initiatorName: string;
  offer: { type: RTCSdpType; sdp: string };
}): Promise<void> {
  const path = `chats/${params.chatId}/watchAudio/${params.audioId}`;
  try {
    await setDoc(doc(db, "chats", params.chatId, "watchAudio", params.audioId), {
      chatId: params.chatId,
      audioId: params.audioId,
      initiatorId: params.initiatorId,
      initiatorName: params.initiatorName.trim().slice(0, 50) || "مستخدم",
      status: "offering",
      offer: {
        type: params.offer.type,
        sdp: params.offer.sdp,
      },
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function answerWatchAudioDoc(params: {
  chatId: string;
  audioId: string;
  peerId: string;
  peerName: string;
  answer: { type: RTCSdpType; sdp: string };
}): Promise<void> {
  const path = `chats/${params.chatId}/watchAudio/${params.audioId}`;
  try {
    await updateDoc(doc(db, "chats", params.chatId, "watchAudio", params.audioId), {
      peerId: params.peerId,
      peerName: params.peerName.trim().slice(0, 50) || "مستخدم",
      status: "connected",
      answer: {
        type: params.answer.type,
        sdp: params.answer.sdp,
      },
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function endWatchAudioDoc(params: {
  chatId: string;
  audioId: string;
}): Promise<void> {
  const path = `chats/${params.chatId}/watchAudio/${params.audioId}`;
  try {
    await updateDoc(doc(db, "chats", params.chatId, "watchAudio", params.audioId), {
      status: "ended",
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    console.warn(`Could not end watch audio doc ${path}:`, error);
  }
}

export async function addWatchAudioCandidateDoc(params: {
  chatId: string;
  audioId: string;
  role: "caller" | "callee";
  senderId: string;
  candidate: RTCIceCandidateInit;
}): Promise<void> {
  const sub = params.role === "caller" ? "callerCandidates" : "calleeCandidates";
  const path = `chats/${params.chatId}/watchAudio/${params.audioId}/${sub}`;
  try {
    await addDoc(
      collection(
        db,
        "chats",
        params.chatId,
        "watchAudio",
        params.audioId,
        sub
      ),
      {
        senderId: params.senderId,
        candidate: params.candidate.candidate || "",
        sdpMid: params.candidate.sdpMid ?? null,
        sdpMLineIndex: params.candidate.sdpMLineIndex ?? null,
        createdAt: serverTimestamp(),
      }
    );
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export function subscribeToChatWatchAudio(
  chatId: string,
  currentUid: string,
  onIncomingAudio: (signal: WatchAudioSignal | null) => void,
  onError?: (err: Error) => void
): Unsubscribe {
  const path = `chats/${chatId}/watchAudio`;
  const audioQuery = query(
    collection(db, "chats", chatId, "watchAudio"),
    where("status", "==", "offering")
  );

  return onSnapshot(
    audioQuery,
    (snapshot) => {
      const nowMs = Date.now();
      const fresh = snapshot.docs
        .map((d) => {
          const raw = d.data() as WatchAudioSignal & {
            createdAt?: Timestamp | null;
          };
          const createdMs =
            raw.createdAt && typeof raw.createdAt.toMillis === "function"
              ? raw.createdAt.toMillis()
              : nowMs;
          return { raw, createdMs };
        })
        .filter(
          ({ raw, createdMs }) =>
            raw.initiatorId !== currentUid && nowMs - createdMs <= 180_000
        )
        .sort((a, b) => b.createdMs - a.createdMs);

      onIncomingAudio(fresh[0]?.raw || null);
    },
    (error) => {
      try {
        handleFirestoreError(error, OperationType.LIST, path);
      } catch (wrapped) {
        onError?.(wrapped as Error);
      }
    }
  );
}

export function subscribeToWatchAudioDoc(
  chatId: string,
  audioId: string,
  onUpdate: (signal: WatchAudioSignal | null) => void,
  onError?: (err: Error) => void
): Unsubscribe {
  const path = `chats/${chatId}/watchAudio/${audioId}`;
  return onSnapshot(
    doc(db, "chats", chatId, "watchAudio", audioId),
    (snapshot) => {
      if (!snapshot.exists()) {
        onUpdate(null);
        return;
      }
      onUpdate(snapshot.data() as WatchAudioSignal);
    },
    (error) => {
      try {
        handleFirestoreError(error, OperationType.GET, path);
      } catch (wrapped) {
        onError?.(wrapped as Error);
      }
    }
  );
}

export function subscribeToWatchAudioCandidates(
  chatId: string,
  audioId: string,
  targetRole: "caller" | "callee",
  onCandidate: (candidate: RTCIceCandidateInit) => void,
  onError?: (err: Error) => void
): Unsubscribe {
  const sub = targetRole === "caller" ? "callerCandidates" : "calleeCandidates";
  const path = `chats/${chatId}/watchAudio/${audioId}/${sub}`;
  const candQuery = query(
    collection(db, "chats", chatId, "watchAudio", audioId, sub)
  );

  return onSnapshot(
    candQuery,
    (snapshot) => {
      snapshot.docChanges().forEach((change) => {
        if (change.type === "added") {
          const data = change.doc.data() as {
            candidate: string;
            sdpMid?: string | null;
            sdpMLineIndex?: number | null;
          };
          if (data.candidate) {
            onCandidate({
              candidate: data.candidate,
              sdpMid: data.sdpMid ?? undefined,
              sdpMLineIndex: data.sdpMLineIndex ?? undefined,
            });
          }
        }
      });
    },
    (error) => {
      try {
        handleFirestoreError(error, OperationType.LIST, path);
      } catch (wrapped) {
        onError?.(wrapped as Error);
      }
    }
  );
}

export async function markChatMessagesAsRead(
  chatId: string,
  uid: string,
  items: Array<{ id: string; hasReadAt: boolean }>
): Promise<void> {
  if (!chatId || !uid || items.length === 0) return;

  const nowMs = Date.now();
  // Commit in chunks safely well under Firestore's 500 batch limit
  for (let i = 0; i < items.length; i += 400) {
    const chunk = items.slice(i, i + 400);
    const batch = writeBatch(db);
    chunk.forEach((item) => {
      const msgRef = doc(db, "chats", chatId, "messages", item.id);
      const payload: Record<string, unknown> = {
        [`readBy.${uid}`]: nowMs,
      };
      if (!item.hasReadAt) {
        payload.readAt = serverTimestamp();
      }
      batch.update(msgRef, payload);
    });
    await batch.commit().catch(() => {
      // Fall back to per-message update if a concurrent reader updated readAt first
      return Promise.all(
        chunk.map((item) =>
          updateDoc(doc(db, "chats", chatId, "messages", item.id), {
            [`readBy.${uid}`]: nowMs,
          }).catch(() => {})
        )
      );
    });
  }
}

async function buildWatchHistoryDocId(url: string): Promise<string> {
  const hash = await sha256Hex(url.trim().toLowerCase());
  return `wh-${hash.slice(0, 28)}`;
}

export async function saveWatchHistoryLink(params: {
  chatId: string;
  url: string;
  mediaType: WatchMediaType;
  videoId: string;
  title?: string;
  addedByUid: string;
  addedByName: string;
}): Promise<void> {
  const cleanUrl = params.url.trim().slice(0, 1500);
  if (!params.chatId || !cleanUrl || !params.addedByUid) return;

  const historyId = await buildWatchHistoryDocId(`${params.mediaType}:${cleanUrl}`);
  const safeVideoId =
    (params.videoId || "video").trim().slice(0, 128) || "video";
  const defaultTitle =
    params.mediaType === "youtube"
      ? "فيديو يوتيوب"
      : params.mediaType === "facebook"
      ? "فيديو فيسبوك"
      : params.mediaType === "tiktok"
      ? "فيديو تيك توك"
      : params.mediaType === "m3u8"
      ? "بث مباشر (M3U8)"
      : "فيديو مباشر (MP4)";
  const cleanTitle = (params.title || defaultTitle).trim().slice(0, 180);
  const safeName = params.addedByName.trim().slice(0, 50) || "مستخدم";

  const path = `chats/${params.chatId}/watchHistory/${historyId}`;
  try {
    await setDoc(doc(db, "chats", params.chatId, "watchHistory", historyId), {
      chatId: params.chatId,
      url: cleanUrl,
      mediaType: params.mediaType,
      videoId: safeVideoId,
      title: cleanTitle,
      addedByUid: params.addedByUid,
      addedByName: safeName,
      savedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export function subscribeToWatchHistory(
  chatId: string,
  onChange: (items: WatchHistoryItem[]) => void,
  onError?: (err: Error) => void
): Unsubscribe {
  const path = `chats/${chatId}/watchHistory`;
  const historyQuery = query(
    collection(db, "chats", chatId, "watchHistory"),
    orderBy("savedAt", "desc"),
    limit(30)
  );

  return onSnapshot(
    historyQuery,
    (snapshot) => {
      const list: WatchHistoryItem[] = [];
      snapshot.docs.forEach((docSnap) => {
        const data = docSnap.data({ serverTimestamps: "estimate" }) as {
          chatId?: string;
          url?: string;
          mediaType?: WatchMediaType;
          videoId?: string;
          title?: string;
          addedByUid?: string;
          addedByName?: string;
          savedAt?: Timestamp | null;
        };
        if (!data.url || !data.mediaType) return;
        const savedAtMs =
          data.savedAt && typeof data.savedAt.toMillis === "function"
            ? data.savedAt.toMillis()
            : Date.now();
        list.push({
          id: docSnap.id,
          chatId: data.chatId || chatId,
          url: data.url,
          mediaType: data.mediaType,
          videoId: data.videoId || "video",
          title: data.title || data.url,
          addedByUid: data.addedByUid || "",
          addedByName: data.addedByName || "مستخدم",
          savedAt: savedAtMs,
        });
      });
      onChange(list);
    },
    (error) => {
      try {
        handleFirestoreError(error, OperationType.LIST, path);
      } catch (wrapped) {
        onError?.(wrapped as Error);
      }
    }
  );
}

export async function deleteWatchHistoryLink(
  chatId: string,
  historyId: string
): Promise<void> {
  if (!chatId || !historyId) return;
  const path = `chats/${chatId}/watchHistory/${historyId}`;
  try {
    await deleteDoc(doc(db, "chats", chatId, "watchHistory", historyId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}
