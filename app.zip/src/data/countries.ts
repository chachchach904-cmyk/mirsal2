export interface CountryOption {
  code: string;
  nameAr: string;
  flag: string;
}

export const DEFAULT_COUNTRY_CODE = "SA";

export const COUNTRIES: CountryOption[] = [
  { code: "SA", nameAr: "السعودية", flag: "🇸🇦" },
  { code: "AE", nameAr: "الإمارات", flag: "🇦🇪" },
  { code: "EG", nameAr: "مصر", flag: "🇪🇬" },
  { code: "KW", nameAr: "الكويت", flag: "🇰🇼" },
  { code: "QA", nameAr: "قطر", flag: "🇶🇦" },
  { code: "BH", nameAr: "البحرين", flag: "🇧🇭" },
  { code: "OM", nameAr: "عُمان", flag: "🇴🇲" },
  { code: "JO", nameAr: "الأردن", flag: "🇯🇴" },
  { code: "LB", nameAr: "لبنان", flag: "🇱🇧" },
  { code: "PS", nameAr: "فلسطين", flag: "🇵🇸" },
  { code: "IQ", nameAr: "العراق", flag: "🇮🇶" },
  { code: "SY", nameAr: "سوريا", flag: "🇸🇾" },
  { code: "YE", nameAr: "اليمن", flag: "🇾🇪" },
  { code: "SD", nameAr: "السودان", flag: "🇸🇩" },
  { code: "LY", nameAr: "ليبيا", flag: "🇱🇾" },
  { code: "TN", nameAr: "تونس", flag: "🇹🇳" },
  { code: "DZ", nameAr: "الجزائر", flag: "🇩🇿" },
  { code: "MA", nameAr: "المغرب", flag: "🇲🇦" },
  { code: "MR", nameAr: "موريتانيا", flag: "🇲🇷" },
  { code: "SO", nameAr: "الصومال", flag: "🇸🇴" },
  { code: "DJ", nameAr: "جيبوتي", flag: "🇩🇯" },
  { code: "KM", nameAr: "جزر القمر", flag: "🇰🇲" },
  { code: "TR", nameAr: "تركيا", flag: "🇹🇷" },
  { code: "US", nameAr: "الولايات المتحدة", flag: "🇺🇸" },
  { code: "GB", nameAr: "المملكة المتحدة", flag: "🇬🇧" },
  { code: "FR", nameAr: "فرنسا", flag: "🇫🇷" },
  { code: "DE", nameAr: "ألمانيا", flag: "🇩🇪" },
  { code: "ES", nameAr: "إسبانيا", flag: "🇪🇸" },
  { code: "IT", nameAr: "إيطاليا", flag: "🇮🇹" },
  { code: "CA", nameAr: "كندا", flag: "🇨🇦" },
  { code: "AU", nameAr: "أستراليا", flag: "🇦🇺" },
  { code: "NL", nameAr: "هولندا", flag: "🇳🇱" },
  { code: "SE", nameAr: "السويد", flag: "🇸🇪" },
  { code: "CH", nameAr: "سويسرا", flag: "🇨🇭" },
  { code: "MY", nameAr: "ماليزيا", flag: "🇲🇾" },
  { code: "ID", nameAr: "إندونيسيا", flag: "🇮🇩" },
  { code: "PK", nameAr: "باكستان", flag: "🇵🇰" },
  { code: "IN", nameAr: "الهند", flag: "🇮🇳" },
  { code: "JP", nameAr: "اليابان", flag: "🇯🇵" },
  { code: "KR", nameAr: "كوريا الجنوبية", flag: "🇰🇷" },
  { code: "CN", nameAr: "الصين", flag: "🇨🇳" },
  { code: "RU", nameAr: "روسيا", flag: "🇷🇺" },
  { code: "BR", nameAr: "البرازيل", flag: "🇧🇷" },
];

const COUNTRY_BY_CODE = new Map(COUNTRIES.map((c) => [c.code, c]));

export function getCountryByCode(
  code?: string | null
): CountryOption | null {
  if (!code || typeof code !== "string") return null;
  return COUNTRY_BY_CODE.get(code.trim().toUpperCase()) || null;
}

export function normalizeCountryCode(code?: string | null): string {
  if (!code || typeof code !== "string") return DEFAULT_COUNTRY_CODE;
  const upper = code.trim().toUpperCase();
  return COUNTRY_BY_CODE.has(upper) ? upper : DEFAULT_COUNTRY_CODE;
}
