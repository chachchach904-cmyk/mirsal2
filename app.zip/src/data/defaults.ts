import type {
  ChatWallpaperOption,
  Conversation,
  TranslationLanguageOption,
} from "../types/chat";

export const CHAT_WALLPAPERS: ChatWallpaperOption[] = [
  {
    id: "default",
    label: "الافتراضي الكلاسيكي",
    previewClass: "chat-wallpaper-default",
    canvasClass: "chat-wallpaper-default",
  },
  {
    id: "midnight",
    label: "ليل هادئ",
    previewClass: "chat-wallpaper-midnight",
    canvasClass: "chat-wallpaper-midnight",
  },
  {
    id: "emerald-dusk",
    label: "زمردي عميق",
    previewClass: "chat-wallpaper-emerald-dusk",
    canvasClass: "chat-wallpaper-emerald-dusk",
  },
  {
    id: "ocean-mist",
    label: "نسيم المحيط",
    previewClass: "chat-wallpaper-ocean-mist",
    canvasClass: "chat-wallpaper-ocean-mist",
  },
  {
    id: "warm-sand",
    label: "رمال هادئة",
    previewClass: "chat-wallpaper-warm-sand",
    canvasClass: "chat-wallpaper-warm-sand",
  },
  {
    id: "islamic-olive",
    label: "نقش إسلامي زيتوني",
    previewClass: "chat-wallpaper-islamic-olive",
    canvasClass: "chat-wallpaper-islamic-olive",
  },
  {
    id: "islamic-indigo",
    label: "نقش إسلامي ليلي",
    previewClass: "chat-wallpaper-islamic-indigo",
    canvasClass: "chat-wallpaper-islamic-indigo",
  },
  {
    id: "plum-silk",
    label: "مخملي داكن",
    previewClass: "chat-wallpaper-plum-silk",
    canvasClass: "chat-wallpaper-plum-silk",
  },
];

export const TRANSLATION_LANGUAGES: TranslationLanguageOption[] = [
  { code: "ar", labelAr: "العربية", nativeLabel: "العربية" },
  { code: "en", labelAr: "الإنجليزية", nativeLabel: "English" },
  { code: "fr", labelAr: "الفرنسية", nativeLabel: "Français" },
  { code: "es", labelAr: "الإسبانية", nativeLabel: "Español" },
  { code: "tr", labelAr: "التركية", nativeLabel: "Türkçe" },
  { code: "de", labelAr: "الألمانية", nativeLabel: "Deutsch" },
  { code: "it", labelAr: "الإيطالية", nativeLabel: "Italiano" },
  { code: "ru", labelAr: "الروسية", nativeLabel: "Русский" },
  { code: "ur", labelAr: "الأردية", nativeLabel: "اردو" },
  { code: "id", labelAr: "الإندونيسية", nativeLabel: "Bahasa Indonesia" },
  { code: "zh", labelAr: "الصينية", nativeLabel: "中文" },
  { code: "ja", labelAr: "اليابانية", nativeLabel: "日本語" },
];

export const GEMINI_AVATAR = "ai:gemini-sparkle";

export const DEFAULT_USER_AVATAR = "";

const DATA_IMAGE_AVATAR_REGEX =
  /^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/;
const HTTP_IMAGE_AVATAR_REGEX = /^https?:\/\/[^\s<>"']{6,1500}$/i;

export function isAiAvatarSrc(src: string | undefined | null): boolean {
  if (!src) return false;
  return (
    src === GEMINI_AVATAR ||
    src === "ai:gemini-sparkle" ||
    src.includes("avatar_gemini_")
  );
}

export function isDataUrlAvatar(src: string | undefined | null): boolean {
  return Boolean(
    src && src.length <= 80000 && DATA_IMAGE_AVATAR_REGEX.test(src)
  );
}

export function isImageUrlAvatar(src: string | undefined | null): boolean {
  if (!src) return false;
  const trimmed = src.trim();
  return HTTP_IMAGE_AVATAR_REGEX.test(trimmed);
}

export function normalizeUserAvatar(src: string | undefined | null): string {
  if (isDataUrlAvatar(src)) {
    return src!;
  }
  if (isImageUrlAvatar(src)) {
    return src!.trim();
  }
  return DEFAULT_USER_AVATAR;
}

export const AI_QUICK_PROMPTS = [
  "لخّص لي أهم عادات الإنتاجية اليومية",
  "اكتب لي رسالة ترحيب احترافية لفريق العمل",
  "اقترح أفكاراً لمشاريع تقنية عربية حديثة",
  "ساعدني في ترجمة نص وتدقيقه لغوياً",
];

export const EMOJI_CATEGORIES = [
  {
    id: "faces",
    label: "الوجوه",
    emojis: [
      "😊", "😄", "😁", "🥰", "😍", "🤩", "😎", "🤔",
      "😅", "😂", "🥹", "😌", "😉", "😇", "🫡", "🤗",
      "😮", "😴", "🥳", "🤯", "😢", "😤", "🙏", "🤝",
    ],
  },
  {
    id: "gestures",
    label: "الإيماءات",
    emojis: [
      "👍", "👎", "👏", "🙌", "🫶", "✌️", "👌", "🤞",
      "💪", "☝️", "👋", "✍️", "👀", "🧠", "☕", "🍵",
    ],
  },
  {
    id: "symbols",
    label: "القلوب والرموز",
    emojis: [
      "❤️", "💚", "🩵", "🤍", "✨", "🌟", "🔥", "⚡",
      "💡", "🎯", "📌", "🎉", "🏆", "📚", "🎨", "🚀",
    ],
  },
  {
    id: "nature",
    label: "الطبيعة والأشياء",
    emojis: [
      "🌙", "☀️", "🌴", "🌊", "🏔️", "🌸", "🌿", "🕊️",
      "📱", "💻", "📷", "🎧", "🗓️", "📝", "✉️", "🔒",
    ],
  },
];

export function createAiDefaultConversations(userName = "أنت"): Conversation[] {
  return [
    {
      id: "gemini-ai-main",
      title: "مساعد مرسال الذكي",
      subtitle: "مساعد ذكي متاح دائماً للإجابة على أسئلتك",
      type: "ai",
      avatar: GEMINI_AVATAR,
      pinned: true,
      unreadCount: 0,
      systemInstruction: `أنت المساعد الذكي الرسمي لتطبيق "مرسال". تتحدث بالعربية الواضحة بأسلوب مهذب، ذكي، ومباشر. اسم المستخدم هو ${userName}. يمكنك تحليل الصور التي يرسلها المستخدم والاستماع للرسائل الصوتية والإجابة عن الأسئلة المتنوعة وتلخيص النصوص وكتابة الرسائل.`,
      messages: [
        {
          id: "ai-welcome-1",
          senderId: "ai",
          senderName: "مساعد مرسال الذكي",
          text: `أهلاً بك يا ${userName} في مرسال! أنا مساعدك الذكي المدمج.\n\nيمكنك التحدث معي هنا بالكتابة أو الصوت أو الصور، كما يمكنك الضغط على زر «+ محادثة جديدة» للبحث عن أصدقائك بالاسم وبدء محادثات ومكالمات صوتية ومرئية مباشرة.`,
          timestamp: Date.now(),
          status: "read",
        },
      ],
    },
  ];
}
