export type ThemeMode = "light" | "dark";

export type MessageStatus = "sending" | "sent" | "delivered" | "read";

export type ConversationType = "ai" | "direct" | "group";

export type ConversationFilter = "all" | "direct" | "group" | "ai";

export type CallType = "audio" | "video";

export type CallStatus = "ringing" | "connected" | "ended";

export type CallOutcome = "missed" | "completed" | "declined";

export interface CallRecordInfo {
  callId: string;
  callType: CallType;
  outcome: CallOutcome;
  durationSeconds: number;
  callerId: string;
}

export type MessageToneId = "soft-bell" | "crystal-drop" | "modern-chime";
export type RingtoneId =
  | "mirsal-classic"
  | "crystal-calm"
  | "modern-marimba"
  | "fast-digital"
  | "warm-strings"
  | "royal-rhythm"
  | "double-alert";
export type DisappearingTimerSeconds = 0 | 86400 | 604800 | 7776000;
export type FontFamilyId =
  | "whatsapp"
  | "cairo"
  | "tajawal"
  | "almarai"
  | "amiri";
export type FontSizeId = "sm" | "md" | "lg" | "xl";

export interface SoundPrefs {
  muted: boolean;
  volume: number; // 0 to 100
  messageTone: MessageToneId;
  ringtone: RingtoneId;
  callVibration: boolean;
}

export interface TypographyPrefs {
  fontFamily: FontFamilyId;
  fontSize: FontSizeId;
}

export interface NotificationPrefs {
  notificationsEnabled: boolean;
  floatingBubbleEnabled: boolean;
}

export type MaritalStatus = "unspecified" | "single" | "engaged" | "married";

export interface UserProfile {
  name: string;
  avatar: string;
  photoURL?: string;
  coverPhoto?: string;
  bio?: string;
  publicKey?: string;
  sessionVersion?: number;
  uid?: string;
  countryCode?: string;
  age?: number | null;
  city?: string;
  maritalStatus?: MaritalStatus;
  workOrStudy?: string;
  joinedAt?: string | number | null;
  isProfileLocked?: boolean;
  showAgeCity?: boolean;
  showPersonalInfo?: boolean;
  showFriends?: boolean;
  showLastSeen?: boolean;
  friends?: string[];
  pinnedChats?: string[];
  blockedUsers?: string[];
  blockedUntil?: Record<string, number>;
}

export interface PeerUserProfile {
  uid: string;
  displayName: string;
  avatar: string;
  photoURL?: string;
  coverPhoto?: string;
  bio?: string;
  publicKey?: string;
  sessionVersion?: number;
  countryCode?: string;
  age?: number | null;
  city?: string;
  maritalStatus?: MaritalStatus;
  workOrStudy?: string;
  joinedAt?: string | number | null;
  isProfileLocked?: boolean;
  showAgeCity?: boolean;
  showPersonalInfo?: boolean;
  showFriends?: boolean;
  showLastSeen?: boolean;
  friends?: string[];
  blockedUsers?: string[];
  blockedUntil?: Record<string, number>;
  isOnline: boolean;
  lastSeen: number | null;
}

export interface MessageReplyRef {
  id: string;
  senderName: string;
  text: string;
  mediaType?: "text" | "image" | "video" | "audio";
}

export interface ChatMessage {
  id: string;
  senderId: string; // 'me' | 'ai' | Firebase uid
  senderName: string;
  text: string;
  isEncrypted?: boolean;
  ciphertext?: string;
  iv?: string;
  imageDataUrl?: string;
  videoDataUrl?: string;
  audioDataUrl?: string;
  audioDuration?: number;
  messageType?: "text" | "call";
  callInfo?: CallRecordInfo;
  replyTo?: MessageReplyRef;
  reactions?: Record<string, string>;
  edited?: boolean;
  editedAt?: number;
  deletedFor?: string[];
  expiresAt?: number;
  viewOnce?: boolean;
  viewOnceOpened?: boolean;
  readAt?: number;
  readBy?: Record<string, number>;
  timestamp: number;
  status: MessageStatus;
  isError?: boolean;
}

export interface Conversation {
  id: string;
  title: string;
  subtitle: string;
  type: ConversationType;
  avatar: string;
  peerUid?: string;
  peerCountryCode?: string;
  peerOnline?: boolean;
  peerLastSeen?: number | null;
  peerShowLastSeen?: boolean;
  groupName?: string;
  adminIds?: string[];
  memberIds?: string[];
  createdBy?: string;
  typingUids?: string[];
  clearedAt?: number;
  disappearingTimer?: DisappearingTimerSeconds;
  lastMessagePreview?: string;
  lastMessageTimestamp?: number;
  lastMessageSenderId?: string;
  lastMessageType?: "text" | "image" | "video" | "audio" | "call";
  pinned?: boolean;
  unreadCount: number;
  systemInstruction?: string;
  messages: ChatMessage[];
}

export interface TranslationLanguageOption {
  code: string;
  labelAr: string;
  nativeLabel: string;
}

export interface ChatCallSignal {
  callId: string;
  chatId: string;
  chatTitle?: string;
  callerId: string;
  callerName: string;
  calleeId?: string;
  calleeName?: string;
  callType: CallType;
  status: CallStatus;
  offer: {
    type: RTCSdpType;
    sdp: string;
  };
  answer?: {
    type: RTCSdpType;
    sdp: string;
  };
  iceRestartSeq?: number;
  answerRestartSeq?: number;
  restartRequestedAt?: number;
}

export type ScreenShareStatus = "offering" | "connected" | "ended";
export type ScreenShareMode = "screen" | "video";

export interface ScreenShareSignal {
  shareId: string;
  chatId: string;
  sharerId: string;
  sharerName: string;
  viewerId?: string;
  viewerName?: string;
  shareMode?: ScreenShareMode;
  status: ScreenShareStatus;
  offer: {
    type: RTCSdpType;
    sdp: string;
  };
  answer?: {
    type: RTCSdpType;
    sdp: string;
  };
}

export interface WatchAudioSignal {
  audioId: string;
  chatId: string;
  initiatorId: string;
  initiatorName: string;
  peerId?: string;
  peerName?: string;
  status: ScreenShareStatus;
  offer: {
    type: RTCSdpType;
    sdp: string;
  };
  answer?: {
    type: RTCSdpType;
    sdp: string;
  };
}

export type WatchMediaType =
  | "youtube"
  | "mp4"
  | "m3u8"
  | "facebook"
  | "tiktok"
  | "instagram"
  | "web";

export interface WatchSessionData {
  chatId: string;
  videoId: string;
  youtubeUrl: string;
  mediaType?: WatchMediaType;
  mediaUrl?: string;
  videoUrl?: string;
  hostId?: string;
  guestMicAllowed?: boolean;
  isStarted?: boolean;
  countdownStartAtMs?: number;
  startedAtMs?: number;
  isPlaying?: boolean;
  currentTime?: number;
  playbackState?: "playing" | "paused";
  playbackTime?: number;
  playbackRate?: number;
  startedByUid: string;
  startedByName: string;
  isActive: boolean;
  updatedAtMs?: number;
}

export interface WatchHistoryItem {
  id: string;
  chatId: string;
  url: string;
  mediaType: WatchMediaType;
  videoId: string;
  title: string;
  siteName?: string;
  addedByUid: string;
  addedByName: string;
  savedAt: number;
}

export type UniversalSearchCategory =
  | "all"
  | "web"
  | "videos"
  | "images"
  | "news";

export interface UniversalSearchResult {
  id: string;
  title: string;
  url: string;
  description?: string;
  thumbnail?: string;
  duration?: string;
  siteName?: string;
  publishedAt?: string;
  category: UniversalSearchCategory;
  platform?: WatchMediaType | string;
  watchable?: boolean;
}

export interface MediaResolveResult {
  url: string;
  resolvedUrl: string;
  platform: WatchMediaType | string;
  siteName: string;
  title: string;
  description: string;
  thumbnail: string;
  directVideoUrl: string | null;
  embedUrl: string | null;
  videoId: string | null;
  canEmbed: boolean;
  isVideo: boolean;
  blockReason?: string | null;
}

export type ChatWallpaperId =
  | "default"
  | "midnight"
  | "emerald-dusk"
  | "ocean-mist"
  | "warm-sand"
  | "islamic-olive"
  | "islamic-indigo"
  | "plum-silk";

export interface ChatWallpaperOption {
  id: ChatWallpaperId;
  label: string;
  previewClass: string;
  canvasClass: string;
}
