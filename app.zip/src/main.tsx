import { createRoot } from "react-dom/client";
import App from "./App.tsx";
import "./index.css";
import { registerMirsalServiceWorker } from "./services/notifications";
import { unlockAudioContext } from "./services/sounds";

void registerMirsalServiceWorker();

if (typeof window !== "undefined") {
  const unlockOnce = () => {
    unlockAudioContext();
  };
  window.addEventListener("pointerdown", unlockOnce, {
    capture: true,
    passive: true,
  });
  window.addEventListener("keydown", unlockOnce, {
    capture: true,
    passive: true,
  });
}

createRoot(document.getElementById("root")!).render(<App />);
