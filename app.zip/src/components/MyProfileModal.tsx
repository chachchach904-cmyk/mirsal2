import { useEffect, useRef, useState, type ChangeEvent, type FormEvent } from "react";
import {
  AlertTriangle,
  ArrowRight,
  Ban,
  Briefcase,
  Calendar,
  Camera,
  Check,
  Edit3,
  Eye,
  Heart,
  ImagePlus,
  Loader2,
  Lock,
  MapPin,
  Shield,
  Trash2,
  Unlock,
  User as UserIcon,
  UserMinus,
  Users,
  X,
} from "lucide-react";
import { COUNTRIES, DEFAULT_COUNTRY_CODE, getCountryByCode } from "../data/countries";
import { isDataUrlAvatar, isImageUrlAvatar } from "../data/defaults";
import type { MaritalStatus, PeerUserProfile, UserProfile } from "../types/chat";
import {
  MARITAL_STATUS_OPTIONS,
  compressImageToDataUrl,
  formatJoinMonthYearAr,
  formatMaritalStatusAr,
  normalizeCustomImageUrl,
  resolveCoverPresetClass,
} from "../utils/storage";
import { Avatar } from "./Avatar";
import { ProfilePhotoLightbox } from "./ProfilePhotoLightbox";

interface MyProfileModalProps {
  isOpen: boolean;
  user: UserProfile;
  creationTime: string | null;
  friends: PeerUserProfile[];
  friendsCount: number;
  onClose: () => void;
  onSaveProfile: (nextUser: UserProfile) => Promise<void>;
  onRemoveFriend: (friendUid: string) => Promise<void>;
  onBlockUser: (targetUid: string) => Promise<void>;
  onDeleteAccount: () => Promise<void>;
}

export function MyProfileModal({
  isOpen,
  user,
  creationTime,
  friends,
  friendsCount,
  onClose,
  onSaveProfile,
  onRemoveFriend,
  onBlockUser,
  onDeleteAccount,
}: MyProfileModalProps) {
  const [name, setName] = useState(user.name);
  const [avatar, setAvatar] = useState(user.photoURL || user.avatar);
  const [coverPhoto, setCoverPhoto] = useState(user.coverPhoto || "cover:emerald");
  const [bio, setBio] = useState(user.bio || "");
  const [countryCode, setCountryCode] = useState(
    user.countryCode || DEFAULT_COUNTRY_CODE
  );
  const [ageInput, setAgeInput] = useState(
    typeof user.age === "number" ? String(user.age) : ""
  );
  const [city, setCity] = useState(user.city || "");
  const [maritalStatus, setMaritalStatus] = useState<MaritalStatus>(
    user.maritalStatus || "unspecified"
  );
  const [workOrStudy, setWorkOrStudy] = useState(user.workOrStudy || "");
  const [isProfileLocked, setIsProfileLocked] = useState(
    Boolean(user.isProfileLocked)
  );
  const [showAgeCity, setShowAgeCity] = useState(user.showAgeCity !== false);
  const [showPersonalInfo, setShowPersonalInfo] = useState(
    user.showPersonalInfo !== false
  );
  const [showFriends, setShowFriends] = useState(user.showFriends !== false);
  const [showLastSeen, setShowLastSeen] = useState(
    user.showLastSeen !== false
  );

  const [coverUrlInput, setCoverUrlInput] = useState("");
  const [showFriendsPanel, setShowFriendsPanel] = useState(false);
  const [showAllFriendsGrid, setShowAllFriendsGrid] = useState(false);
  const [friendActionUid, setFriendActionUid] = useState<string | null>(null);
  const [confirmBlockFriend, setConfirmBlockFriend] =
    useState<PeerUserProfile | null>(null);
  const [friendsError, setFriendsError] = useState<string | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [deletingAccount, setDeletingAccount] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [uploadingCover, setUploadingCover] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [cardGlassMode, setCardGlassMode] = useState<"transparent" | "solid">(() => {
    try {
      return localStorage.getItem("mirsal_profile_glass_mode") === "solid"
        ? "solid"
        : "transparent";
    } catch {
      return "transparent";
    }
  });
  const [lightboxPhoto, setLightboxPhoto] = useState<{
    src: string;
    alt: string;
  } | null>(null);

  const editFormRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!isOpen) return;
    setName(user.name);
    setAvatar(user.photoURL || user.avatar);
    setCoverPhoto(user.coverPhoto || "cover:emerald");
    setCoverUrlInput(
      user.coverPhoto && /^https?:\/\//i.test(user.coverPhoto)
        ? user.coverPhoto
        : ""
    );
    setBio(user.bio || "");
    setCountryCode(user.countryCode || DEFAULT_COUNTRY_CODE);
    setAgeInput(typeof user.age === "number" ? String(user.age) : "");
    setCity(user.city || "");
    setMaritalStatus(user.maritalStatus || "unspecified");
    setWorkOrStudy(user.workOrStudy || "");
    setIsProfileLocked(Boolean(user.isProfileLocked));
    setShowAgeCity(user.showAgeCity !== false);
    setShowPersonalInfo(user.showPersonalInfo !== false);
    setShowFriends(user.showFriends !== false);
    setShowLastSeen(user.showLastSeen !== false);
    setError(null);
    setFriendsError(null);
    setDeleteError(null);
    setShowFriendsPanel(false);
    setShowAllFriendsGrid(false);
    setShowDeleteConfirm(false);
    setConfirmBlockFriend(null);
    setFriendActionUid(null);
    setDeletingAccount(false);
    setLightboxPhoto(null);
  }, [isOpen, user]);

  if (!isOpen) return null;

  const isCustomCoverImage =
    coverPhoto.startsWith("data:image/") || /^https?:\/\//i.test(coverPhoto);
  const hasAvatarPhoto = isDataUrlAvatar(avatar) || isImageUrlAvatar(avatar);
  const cardGlassClass =
    cardGlassMode === "transparent"
      ? "bg-slate-900/35 backdrop-blur-sm border border-white/20 text-white shadow-lg [text-shadow:0_1px_2px_rgba(0,0,0,0.65)]"
      : "bg-slate-900/85 backdrop-blur-md border border-white/15 text-white shadow-xl [text-shadow:0_1px_2px_rgba(0,0,0,0.45)]";
  const handleToggleGlassMode = () => {
    setCardGlassMode((prev) => {
      const next = prev === "transparent" ? "solid" : "transparent";
      try {
        localStorage.setItem("mirsal_profile_glass_mode", next);
      } catch {
        // ignore storage errors
      }
      return next;
    });
  };
  const country = getCountryByCode(countryCode);
  const displayedFriendsGrid = showAllFriendsGrid
    ? friends
    : friends.slice(0, 6);

  const handleUnfriend = async (friendUid: string) => {
    if (friendActionUid) return;
    setFriendActionUid(friendUid);
    setFriendsError(null);
    try {
      await onRemoveFriend(friendUid);
    } catch (err) {
      setFriendsError(
        err instanceof Error ? err.message : "تعذر إلغاء الصداقة. حاول مجدداً."
      );
    } finally {
      setFriendActionUid(null);
    }
  };

  const handleBlockFriend = async (friendUid: string) => {
    if (friendActionUid) return;
    setFriendActionUid(friendUid);
    setFriendsError(null);
    try {
      await onBlockUser(friendUid);
      setConfirmBlockFriend(null);
    } catch (err) {
      setFriendsError(
        err instanceof Error ? err.message : "تعذر حظر المستخدم. حاول مجدداً."
      );
    } finally {
      setFriendActionUid(null);
    }
  };

  const handleConfirmDeleteAccount = async () => {
    if (deletingAccount) return;
    setDeletingAccount(true);
    setDeleteError(null);
    try {
      await onDeleteAccount();
    } catch (err) {
      setDeleteError(
        err instanceof Error
          ? err.message
          : "تعذر حذف الحساب نهائياً. حاول مجدداً."
      );
    } finally {
      setDeletingAccount(false);
    }
  };

  const handlePhotoUpload = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    setError(null);
    try {
      const compressed = await compressImageToDataUrl(file, 256, 0.78, 72000);
      setAvatar(compressed);
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "تعذر تحديث الصورة الشخصية."
      );
    } finally {
      setUploading(false);
      e.target.value = "";
    }
  };

  const handleCoverUpload = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingCover(true);
    setError(null);
    try {
      const compressed = await compressImageToDataUrl(file, 900, 0.72, 76000);
      setCoverPhoto(compressed);
      setCoverUrlInput("");
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "تعذر تحديث صورة الغلاف."
      );
    } finally {
      setUploadingCover(false);
      e.target.value = "";
    }
  };

  const handleApplyCoverUrl = () => {
    const valid = normalizeCustomImageUrl(coverUrlInput);
    if (!valid) {
      setError("يرجى إدخال رابط صورة صحيح يبدأ بـ https:// أو http://");
      return;
    }
    setError(null);
    setCoverPhoto(valid);
  };

  const handleQuickToggleLock = async () => {
    const nextLocked = !isProfileLocked;
    setIsProfileLocked(nextLocked);
    try {
      await onSaveProfile({
        ...user,
        name: name.trim() || user.name,
        avatar,
        photoURL: avatar,
        coverPhoto,
        bio: bio.trim().slice(0, 160),
        countryCode,
        isProfileLocked: nextLocked,
      });
    } catch {
      // keep local state if offline; user can still click save
    }
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    const cleanName = name.trim();
    if (cleanName.length < 2) {
      setError("يرجى إدخال اسم لا يقل عن حرفين.");
      return;
    }

    let parsedAge: number | null = null;
    if (ageInput.trim()) {
      const num = Number(ageInput.trim());
      if (!Number.isInteger(num) || num < 10 || num > 100) {
        setError("يرجى إدخال عمر صحيح بين 10 و 100 أو تركه فارغاً.");
        return;
      }
      parsedAge = num;
    }

    setSaving(true);
    setError(null);
    try {
      await onSaveProfile({
        ...user,
        name: cleanName,
        avatar,
        photoURL: avatar,
        coverPhoto,
        bio: bio.trim().slice(0, 160),
        countryCode,
        age: parsedAge,
        city: city.trim().slice(0, 60),
        maritalStatus,
        workOrStudy: workOrStudy.trim().slice(0, 80),
        isProfileLocked,
        showAgeCity,
        showPersonalInfo,
        showFriends,
        showLastSeen,
      });
      onClose();
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "تعذر حفظ الملف الشخصي."
      );
    } finally {
      setSaving(false);
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="ملفي الشخصي"
      className="fixed inset-0 z-50 bg-black/55 backdrop-blur-xs flex items-center justify-center p-2.5 sm:p-4"
    >
      <div className="relative w-full max-w-lg rounded-3xl border border-white/20 shadow-2xl overflow-hidden flex flex-col max-h-[92dvh] bg-slate-900">
        {/* Full-Screen Cover Background Layer */}
        <div className="absolute inset-0 z-0 pointer-events-none">
          {isCustomCoverImage ? (
            <img
              src={coverPhoto}
              alt="صورة الغلاف"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
          ) : (
            <div
              className={`w-full h-full bg-gradient-to-br ${resolveCoverPresetClass(
                coverPhoto
              )}`}
            />
          )}
          <div className="absolute inset-0 bg-gradient-to-b from-black/35 via-black/25 to-black/70" />
        </div>

        <header className="relative z-10 px-4 py-3 border-b border-white/15 flex items-center justify-between gap-2 bg-slate-900/55 backdrop-blur-md text-white shrink-0">
          <div className="flex items-center gap-2 min-w-0">
            {showFriendsPanel ? (
              <button
                type="button"
                onClick={() => setShowFriendsPanel(false)}
                aria-label="العودة للملف الشخصي"
                className="min-h-[36px] min-w-[36px] rounded-xl flex items-center justify-center text-white hover:bg-white/15 cursor-pointer"
              >
                <ArrowRight className="w-5 h-5" />
              </button>
            ) : (
              <UserIcon className="w-5 h-5 text-emerald-300 shrink-0" />
            )}
            <h2 className="font-display font-bold text-sm sm:text-base text-white truncate [text-shadow:0_1px_2px_rgba(0,0,0,0.6)]">
              {showFriendsPanel
                ? `إدارة الأصدقاء (${friendsCount})`
                : "ملفي الشخصي"}
            </h2>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <button
              type="button"
              onClick={handleToggleGlassMode}
              className="min-h-[34px] px-2.5 py-1 rounded-xl bg-white/15 hover:bg-white/25 border border-white/25 text-white text-[11px] font-bold flex items-center gap-1.5 cursor-pointer transition-colors"
            >
              <Eye className="w-3.5 h-3.5 text-emerald-300 shrink-0" />
              <span>
                شفافية البطاقات: {cardGlassMode === "transparent" ? "شفاف" : "واضح"}
              </span>
            </button>

            <button
              type="button"
              onClick={onClose}
              aria-label="إغلاق"
              className="min-h-[36px] min-w-[36px] rounded-xl flex items-center justify-center text-white/90 hover:bg-white/15 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </header>

        {showFriendsPanel ? (
          <div className="relative z-10 flex-1 overflow-y-auto custom-scrollbar p-5 space-y-3">
            {friendsError && (
              <p className="text-xs font-medium text-rose-200 bg-rose-950/75 border border-rose-500/40 px-3 py-2 rounded-xl">
                {friendsError}
              </p>
            )}

            {friends.length === 0 ? (
              <div className={`py-12 px-5 rounded-2xl text-center space-y-2 ${cardGlassClass}`}>
                <div className="w-12 h-12 mx-auto rounded-2xl bg-white/15 text-white/80 flex items-center justify-center">
                  <Users className="w-6 h-6" />
                </div>
                <p className="text-sm font-bold text-white">
                  لا يوجد أصدقاء حالياً
                </p>
                <p className="text-xs text-slate-200">
                  يمكنك البحث عن مستخدمين وإضافتهم من زر محادثة جديدة.
                </p>
              </div>
            ) : (
              <div className="space-y-2">
                {friends.map((friend) => {
                  const busy = friendActionUid === friend.uid;
                  const alreadyBlocked = Boolean(
                    user.blockedUsers?.includes(friend.uid)
                  );
                  return (
                    <div
                      key={friend.uid}
                      className={`p-3 rounded-2xl flex items-center justify-between gap-3 ${cardGlassClass}`}
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <Avatar
                          src={friend.avatar}
                          name={friend.displayName}
                          size="md"
                        />
                        <div className="min-w-0">
                          <p className="text-sm font-bold text-white truncate">
                            {friend.displayName}
                          </p>
                          <p className="text-[11px] text-slate-200 truncate">
                            {friend.city || "صديق على مرسال"}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          type="button"
                          disabled={Boolean(friendActionUid)}
                          onClick={() => void handleUnfriend(friend.uid)}
                          className="min-h-[36px] px-2.5 py-1.5 rounded-xl bg-white/15 hover:bg-white/25 border border-white/20 text-white text-xs font-bold flex items-center gap-1 transition-colors cursor-pointer disabled:opacity-50"
                        >
                          {busy ? (
                            <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          ) : (
                            <UserMinus className="w-3.5 h-3.5" />
                          )}
                          <span>إلغاء الصداقة</span>
                        </button>

                        <button
                          type="button"
                          disabled={Boolean(friendActionUid) || alreadyBlocked}
                          onClick={() => setConfirmBlockFriend(friend)}
                          className="min-h-[36px] px-2.5 py-1.5 rounded-xl bg-rose-600/80 hover:bg-rose-600 border border-rose-400/40 text-white text-xs font-bold flex items-center gap-1 transition-colors cursor-pointer disabled:opacity-50"
                        >
                          <Ban className="w-3.5 h-3.5" />
                          <span>{alreadyBlocked ? "محظور" : "حظر"}</span>
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        ) : (
          <form
            onSubmit={(e) => void handleSubmit(e)}
            className="relative z-10 flex-1 overflow-y-auto custom-scrollbar"
          >
            {/* Top Cover Showcase + Overlapping Avatar */}
            <div className="relative">
              <div
                role={isCustomCoverImage ? "button" : undefined}
                tabIndex={isCustomCoverImage ? 0 : undefined}
                aria-label={isCustomCoverImage ? "عرض صورة الغلاف بالكامل" : undefined}
                onClick={() => {
                  if (isCustomCoverImage) {
                    setLightboxPhoto({
                      src: coverPhoto,
                      alt: "صورة الغلاف",
                    });
                  }
                }}
                onKeyDown={(e) => {
                  if (
                    isCustomCoverImage &&
                    (e.key === "Enter" || e.key === " ")
                  ) {
                    e.preventDefault();
                    setLightboxPhoto({
                      src: coverPhoto,
                      alt: "صورة الغلاف",
                    });
                  }
                }}
                className={`relative h-36 sm:h-44 w-full ${
                  isCustomCoverImage ? "cursor-pointer" : ""
                }`}
              >
                <div
                  onClick={(e) => e.stopPropagation()}
                  className="absolute top-2.5 left-2.5 z-20 flex items-center gap-1.5"
                >
                  <label
                    htmlFor="cover-upload-input"
                    aria-label="تغيير صورة الغلاف"
                    className={`relative min-h-[34px] px-3 py-1.5 rounded-xl bg-black/60 hover:bg-black/80 backdrop-blur-xs text-white text-[11px] font-bold inline-flex items-center gap-1.5 cursor-pointer transition-colors shadow-sm border border-white/15 ${
                      uploadingCover ? "opacity-60 pointer-events-none" : ""
                    }`}
                  >
                    {uploadingCover ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <Camera className="w-3.5 h-3.5" />
                    )}
                    <span>تغيير صورة الغلاف</span>
                    <input
                      id="cover-upload-input"
                      type="file"
                      disabled={uploadingCover}
                      onClick={(e) => {
                        e.stopPropagation();
                        e.currentTarget.value = "";
                      }}
                      onChange={(e) => void handleCoverUpload(e)}
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                    />
                  </label>

                  {isCustomCoverImage && (
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setCoverPhoto("cover:emerald");
                        setCoverUrlInput("");
                      }}
                      title="إزالة صورة الغلاف"
                      aria-label="إزالة صورة الغلاف"
                      className="min-h-[34px] w-8 rounded-xl bg-black/60 hover:bg-rose-600/90 backdrop-blur-xs border border-white/15 text-white flex items-center justify-center cursor-pointer transition-colors"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>

              {/* Overlapping Avatar + Identity Card */}
              <div className="px-5 flex flex-col items-center text-center -mt-12 relative z-10">
                <div className="relative p-1 rounded-full bg-slate-900/70 backdrop-blur-md ring-2 ring-white/30 shadow-xl">
                  <button
                    type="button"
                    onClick={() => {
                      if (hasAvatarPhoto) {
                        setLightboxPhoto({
                          src: avatar,
                          alt: name.trim() || user.name,
                        });
                      }
                    }}
                    aria-label={
                      hasAvatarPhoto
                        ? "عرض الصورة الشخصية بالكامل"
                        : name.trim() || user.name
                    }
                    className={`rounded-full block ${
                      hasAvatarPhoto ? "cursor-pointer" : "cursor-default"
                    }`}
                  >
                    <Avatar src={avatar} name={name || user.name} size="xl" />
                  </button>
                  <label
                    htmlFor="avatar-upload-input"
                    aria-label="تغيير الصورة الشخصية"
                    title="تغيير الصورة الشخصية"
                    onClick={(e) => e.stopPropagation()}
                    className={`absolute bottom-1 left-1 z-20 w-8 h-8 rounded-full bg-[#0d7a5f] hover:bg-[#0a634d] dark:bg-[#00a884] text-white border-2 border-white flex items-center justify-center shadow cursor-pointer ${
                      uploading ? "opacity-60 pointer-events-none" : ""
                    }`}
                  >
                    {uploading ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <ImagePlus className="w-3.5 h-3.5" />
                    )}
                    <input
                      id="avatar-upload-input"
                      type="file"
                      disabled={uploading}
                      onClick={(e) => {
                        e.stopPropagation();
                        e.currentTarget.value = "";
                      }}
                      onChange={(e) => void handlePhotoUpload(e)}
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                    />
                  </label>
                </div>

                <div className={`mt-3 w-full rounded-2xl p-4 ${cardGlassClass}`}>
                  <h3 className="font-display font-bold text-lg text-white flex items-center justify-center gap-1.5">
                    {country?.flag && <span>{country.flag}</span>}
                    <span>{name.trim() || user.name}</span>
                    {isProfileLocked && (
                      <Lock className="w-3.5 h-3.5 text-emerald-300" />
                    )}
                  </h3>

                  {bio.trim() ? (
                    <p className="mt-1 text-xs text-slate-100 max-w-sm mx-auto leading-relaxed">
                      {bio.trim()}
                    </p>
                  ) : (
                    <p className="mt-0.5 text-[11px] text-slate-200/80">
                      أضف نبذة شخصية قصيرة تظهر تحت اسمك
                    </p>
                  )}

                  {/* Quick Action Bar */}
                  <div className="mt-3 flex flex-wrap items-center justify-center gap-2 w-full">
                    <button
                      type="button"
                      onClick={() =>
                        editFormRef.current?.scrollIntoView({ behavior: "smooth" })
                      }
                      className="min-h-[36px] px-3 py-1.5 rounded-xl bg-[#00a884] hover:bg-[#069475] text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                      <span>تعديل الملف</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => void handleQuickToggleLock()}
                      className={`min-h-[36px] px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer border ${
                        isProfileLocked
                          ? "bg-amber-500/25 text-amber-200 border-amber-300/40"
                          : "bg-white/15 hover:bg-white/25 text-white border-white/20"
                      }`}
                    >
                      {isProfileLocked ? (
                        <>
                          <Lock className="w-3.5 h-3.5" />
                          <span>الملف مقفل</span>
                        </>
                      ) : (
                        <>
                          <Unlock className="w-3.5 h-3.5" />
                          <span>قفل الملف</span>
                        </>
                      )}
                    </button>

                    {Boolean(avatar) && (
                      <button
                        type="button"
                        onClick={() => setAvatar("")}
                        className="min-h-[36px] px-3 py-1.5 rounded-xl bg-white/15 hover:bg-white/25 border border-white/20 text-xs font-bold text-white cursor-pointer"
                      >
                        إزالة الصورة
                      </button>
                    )}
                  </div>
                </div>
              </div>
            </div>

            <div className="p-5 space-y-4">
              {/* Direct Image URL Fallback for Profile Cover (APK WebView friendly) */}
              <div className={`p-3.5 rounded-2xl space-y-1.5 ${cardGlassClass}`}>
                <label
                  htmlFor="cover-url-input"
                  className="block text-[11px] font-bold text-slate-100"
                >
                  لصق رابط صورة للغلاف (Image URL)
                </label>
                <div className="flex items-center gap-2">
                  <input
                    id="cover-url-input"
                    type="url"
                    dir="ltr"
                    value={coverUrlInput}
                    onChange={(e) => setCoverUrlInput(e.target.value)}
                    placeholder="https://example.com/cover.jpg"
                    className="flex-1 min-w-0 min-h-[38px] px-3 rounded-xl bg-slate-950/60 border border-white/20 text-xs text-white placeholder:text-slate-300/60 focus:border-emerald-400 focus:outline-none text-left"
                  />
                  <button
                    type="button"
                    onClick={handleApplyCoverUrl}
                    className="min-h-[38px] px-3.5 rounded-xl bg-[#00a884] hover:bg-[#069475] text-white text-xs font-bold shrink-0 cursor-pointer"
                  >
                    تطبيق
                  </button>
                </div>
              </div>

              {/* About Summary Card */}
              <div className={`p-3.5 rounded-2xl space-y-2 text-xs ${cardGlassClass}`}>
                <p className="font-bold text-white text-xs">
                  نبذة عني
                </p>
                {city.trim() || ageInput.trim() ? (
                  <div className="flex items-center gap-2 text-slate-100">
                    <MapPin className="w-3.5 h-3.5 text-emerald-300 shrink-0" />
                    <span>
                      {[
                        city.trim() || null,
                        ageInput.trim() ? `${ageInput.trim()} سنة` : null,
                      ]
                        .filter(Boolean)
                        .join(" · ")}
                    </span>
                  </div>
                ) : null}
                {workOrStudy.trim() && (
                  <div className="flex items-center gap-2 text-slate-100">
                    <Briefcase className="w-3.5 h-3.5 text-emerald-300 shrink-0" />
                    <span>{workOrStudy.trim()}</span>
                  </div>
                )}
                {maritalStatus !== "unspecified" && (
                  <div className="flex items-center gap-2 text-slate-100">
                    <Heart className="w-3.5 h-3.5 text-emerald-300 shrink-0" />
                    <span>{formatMaritalStatusAr(maritalStatus)}</span>
                  </div>
                )}
                <div className="flex items-center gap-2 text-slate-200">
                  <Calendar className="w-3.5 h-3.5 text-emerald-300 shrink-0" />
                  <span>{formatJoinMonthYearAr(user.joinedAt, creationTime)}</span>
                </div>
              </div>

              {/* Facebook-Style Friends Grid */}
              <div className={`p-3.5 rounded-2xl space-y-3 ${cardGlassClass}`}>
                <div className="flex items-center justify-between gap-2">
                  <div>
                    <p className="text-xs font-bold text-white flex items-center gap-1.5">
                      <Users className="w-3.5 h-3.5 text-emerald-300" />
                      <span>الأصدقاء ({friendsCount})</span>
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    {friends.length > 6 && (
                      <button
                        type="button"
                        onClick={() => setShowAllFriendsGrid((v) => !v)}
                        className="text-[11px] font-bold text-emerald-300 hover:underline cursor-pointer"
                      >
                        {showAllFriendsGrid ? "عرض أقل" : "عرض الكل"}
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => {
                        setFriendsError(null);
                        setShowFriendsPanel(true);
                      }}
                      className="text-[11px] font-bold text-white bg-white/15 hover:bg-white/25 px-2.5 py-1 rounded-lg border border-white/20 cursor-pointer"
                    >
                      إدارة القائمة
                    </button>
                  </div>
                </div>

                {friends.length === 0 ? (
                  <p className="text-[11px] text-slate-200">
                    لا يوجد أصدقاء مضافون بعد.
                  </p>
                ) : (
                  <div className="grid grid-cols-3 gap-2">
                    {displayedFriendsGrid.map((friend) => (
                      <div
                        key={friend.uid}
                        className="p-2 rounded-xl bg-slate-950/50 border border-white/15 flex flex-col items-center text-center gap-1.5"
                      >
                        <Avatar
                          src={friend.photoURL || friend.avatar}
                          name={friend.displayName}
                          size="md"
                        />
                        <span className="text-[11px] font-bold text-white truncate w-full">
                          {friend.displayName}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Edit Details Form */}
              <div ref={editFormRef} className={`p-4 rounded-2xl space-y-3 ${cardGlassClass}`}>
                <div>
                  <label className="block text-xs font-semibold text-slate-100 mb-1">
                    النبذة الشخصية (Bio)
                  </label>
                  <textarea
                    value={bio}
                    onChange={(e) => setBio(e.target.value)}
                    maxLength={160}
                    rows={2}
                    placeholder="اكتب جملة قصيرة تعبّر عنك (حتى 160 حرفاً)..."
                    className="w-full p-3 rounded-xl bg-slate-950/60 text-xs sm:text-sm text-white placeholder:text-slate-300/60 border border-white/20 focus:border-emerald-400 focus:outline-none resize-none"
                  />
                  <div className="text-left text-[10px] text-slate-200 tabular-nums mt-0.5">
                    {bio.length}/160
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-100 mb-1">
                      الاسم الظاهر
                    </label>
                    <input
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      maxLength={50}
                      className="w-full min-h-[42px] px-3.5 rounded-xl bg-slate-950/60 text-sm text-white border border-white/20 focus:border-emerald-400 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-100 mb-1">
                      الدولة
                    </label>
                    <select
                      value={countryCode}
                      onChange={(e) => setCountryCode(e.target.value)}
                      className="w-full min-h-[42px] px-3 rounded-xl bg-slate-950/75 text-sm text-white border border-white/20 focus:border-emerald-400 focus:outline-none"
                    >
                      {COUNTRIES.map((c) => (
                        <option key={c.code} value={c.code} className="bg-slate-900 text-white">
                          {c.flag} {c.nameAr}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-100 mb-1">
                      العمر
                    </label>
                    <input
                      type="number"
                      min={10}
                      max={100}
                      value={ageInput}
                      onChange={(e) => setAgeInput(e.target.value)}
                      placeholder="مثال: 26"
                      className="w-full min-h-[42px] px-3.5 rounded-xl bg-slate-950/60 text-sm text-white placeholder:text-slate-300/60 border border-white/20 focus:border-emerald-400 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-100 mb-1 flex items-center gap-1">
                      <MapPin className="w-3.5 h-3.5" />
                      <span>المدينة</span>
                    </label>
                    <input
                      type="text"
                      value={city}
                      onChange={(e) => setCity(e.target.value)}
                      maxLength={60}
                      placeholder="مثال: الرياض، القاهرة..."
                      className="w-full min-h-[42px] px-3.5 rounded-xl bg-slate-950/60 text-sm text-white placeholder:text-slate-300/60 border border-white/20 focus:border-emerald-400 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-100 mb-1">
                      الحالة الاجتماعية
                    </label>
                    <select
                      value={maritalStatus}
                      onChange={(e) =>
                        setMaritalStatus(e.target.value as MaritalStatus)
                      }
                      className="w-full min-h-[42px] px-3 rounded-xl bg-slate-950/75 text-sm text-white border border-white/20 focus:border-emerald-400 focus:outline-none"
                    >
                      {MARITAL_STATUS_OPTIONS.map((opt) => (
                        <option key={opt.value} value={opt.value} className="bg-slate-900 text-white">
                          {opt.label}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-100 mb-1 flex items-center gap-1">
                      <Briefcase className="w-3.5 h-3.5" />
                      <span>العمل أو الدراسة</span>
                    </label>
                    <input
                      type="text"
                      value={workOrStudy}
                      onChange={(e) => setWorkOrStudy(e.target.value)}
                      maxLength={80}
                      placeholder="مثال: مهندس برمجيات"
                      className="w-full min-h-[42px] px-3.5 rounded-xl bg-slate-950/60 text-sm text-white placeholder:text-slate-300/60 border border-white/20 focus:border-emerald-400 focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Privacy Controls */}
              <div className={`p-3.5 rounded-2xl space-y-2.5 ${cardGlassClass}`}>
                <div className="flex items-center gap-2 text-xs font-bold text-white">
                  <Shield className="w-4 h-4 text-emerald-300" />
                  <span>خصوصية الملف الشخصي</span>
                </div>

                {[
                  {
                    label: "قفل الملف الشخصي (للأصدقاء فقط)",
                    icon: <Lock className="w-3.5 h-3.5" />,
                    checked: isProfileLocked,
                    onChange: () => setIsProfileLocked((v) => !v),
                  },
                  {
                    label: "إظهار العمر والمدينة",
                    checked: showAgeCity,
                    onChange: () => setShowAgeCity((v) => !v),
                  },
                  {
                    label: "إظهار الحالة الاجتماعية والعمل/الدراسة والدولة",
                    checked: showPersonalInfo,
                    onChange: () => setShowPersonalInfo((v) => !v),
                  },
                  {
                    label: "إظهار قائمة الأصدقاء وعددهم",
                    checked: showFriends,
                    onChange: () => setShowFriends((v) => !v),
                  },
                  {
                    label: "إظهار آخر ظهور وحالة الاتصال",
                    checked: showLastSeen,
                    onChange: () => setShowLastSeen((v) => !v),
                  },
                ].map((item) => (
                  <label
                    key={item.label}
                    className="flex items-center justify-between gap-2 text-xs text-slate-100 cursor-pointer py-1"
                  >
                    <span className="flex items-center gap-1.5">
                      {item.icon}
                      <span>{item.label}</span>
                    </span>
                    <input
                      type="checkbox"
                      checked={item.checked}
                      onChange={item.onChange}
                      className="w-4 h-4 accent-[#00a884] cursor-pointer"
                    />
                  </label>
                ))}
              </div>

              {error && (
                <p className="text-xs font-medium text-rose-200 bg-rose-950/75 border border-rose-500/40 px-3 py-2 rounded-xl">
                  {error}
                </p>
              )}

              <div className={`p-3 rounded-2xl space-y-3 ${cardGlassClass}`}>
                <div className="flex items-center justify-end gap-2">
                  <button
                    type="button"
                    onClick={onClose}
                    className="min-h-[42px] px-4 py-2 rounded-xl bg-white/15 hover:bg-white/25 border border-white/20 text-xs font-bold text-white cursor-pointer"
                  >
                    إلغاء
                  </button>
                  <button
                    type="submit"
                    disabled={saving}
                    className="min-h-[42px] px-5 py-2 rounded-xl bg-[#00a884] hover:bg-[#069475] text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer disabled:opacity-60 shadow"
                  >
                    {saving ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Check className="w-4 h-4" />
                    )}
                    <span>حفظ التعديلات</span>
                  </button>
                </div>

                <div className="pt-2 border-t border-white/15">
                  <button
                    type="button"
                    onClick={() => {
                      setDeleteError(null);
                      setShowDeleteConfirm(true);
                    }}
                    className="w-full min-h-[42px] px-4 py-2 rounded-xl bg-rose-600/80 hover:bg-rose-600 border border-rose-400/40 text-white text-xs font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                    <span>حذف حسابي نهائياً</span>
                  </button>
                </div>
              </div>
            </div>
          </form>
        )}
      </div>

      {showDeleteConfirm && (
        <div
          role="alertdialog"
          aria-modal="true"
          aria-labelledby="confirm-delete-account-title"
          className="fixed inset-0 z-[60] bg-black/65 backdrop-blur-xs flex items-center justify-center p-4"
          onClick={() => {
            if (!deletingAccount) setShowDeleteConfirm(false);
          }}
        >
          <div
            dir="rtl"
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-sm bg-white dark:bg-[#111b21] border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-2xl space-y-4"
          >
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-2xl bg-rose-100 dark:bg-rose-950/70 text-rose-600 dark:text-rose-400 flex items-center justify-center shrink-0">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div className="space-y-1">
                <h3
                  id="confirm-delete-account-title"
                  className="font-display font-bold text-base text-slate-900 dark:text-white"
                >
                  تأكيد حذف الحساب نهائياً
                </h3>
                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                  هل أنت متأكد من حذف حسابك نهائياً؟ لا يمكن التراجع عن هذا الإجراء
                </p>
              </div>
            </div>

            {deleteError && (
              <p className="text-xs font-medium text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/40 px-3 py-2 rounded-xl">
                {deleteError}
              </p>
            )}

            <div className="flex items-center justify-end gap-2">
              <button
                type="button"
                disabled={deletingAccount}
                onClick={() => setShowDeleteConfirm(false)}
                className="min-h-[40px] px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-[#202c33] dark:hover:bg-[#2a3942] text-xs font-bold text-slate-700 dark:text-slate-200 cursor-pointer disabled:opacity-50"
              >
                إلغاء
              </button>
              <button
                type="button"
                disabled={deletingAccount}
                onClick={() => void handleConfirmDeleteAccount()}
                className="min-h-[40px] px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer disabled:opacity-60"
              >
                {deletingAccount ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Trash2 className="w-4 h-4" />
                )}
                <span>تأكيد الحذف</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {confirmBlockFriend && (
        <div
          role="alertdialog"
          aria-modal="true"
          aria-labelledby="confirm-block-friend-title"
          className="fixed inset-0 z-[60] bg-black/65 backdrop-blur-xs flex items-center justify-center p-4"
          onClick={() => {
            if (!friendActionUid) setConfirmBlockFriend(null);
          }}
        >
          <div
            dir="rtl"
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-sm bg-white dark:bg-[#111b21] border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-2xl space-y-4"
          >
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-2xl bg-rose-100 dark:bg-rose-950/70 text-rose-600 dark:text-rose-400 flex items-center justify-center shrink-0">
                <Ban className="w-5 h-5" />
              </div>
              <div className="space-y-1">
                <h3
                  id="confirm-block-friend-title"
                  className="font-display font-bold text-base text-slate-900 dark:text-white"
                >
                  تأكيد حظر المستخدم
                </h3>
                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                  هل أنت متأكد من حظر هذا المستخدم؟ ({confirmBlockFriend.displayName})
                </p>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2">
              <button
                type="button"
                disabled={Boolean(friendActionUid)}
                onClick={() => setConfirmBlockFriend(null)}
                className="min-h-[40px] px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-[#202c33] dark:hover:bg-[#2a3942] text-xs font-bold text-slate-700 dark:text-slate-200 cursor-pointer disabled:opacity-50"
              >
                إلغاء
              </button>
              <button
                type="button"
                disabled={Boolean(friendActionUid)}
                onClick={() => void handleBlockFriend(confirmBlockFriend.uid)}
                className="min-h-[40px] px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer disabled:opacity-60"
              >
                {friendActionUid === confirmBlockFriend.uid ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Ban className="w-4 h-4" />
                )}
                <span>تأكيد</span>
              </button>
            </div>
          </div>
        </div>
      )}
      <ProfilePhotoLightbox
        src={lightboxPhoto?.src || null}
        alt={lightboxPhoto?.alt}
        onClose={() => setLightboxPhoto(null)}
      />
    </div>
  );
}
