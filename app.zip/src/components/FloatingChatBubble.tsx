import {
  Fragment,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ChangeEvent,
  type FormEvent,
  type KeyboardEvent,
  type PointerEvent as ReactPointerEvent,
  type ReactNode,
} from "react";
import {
  Check,
  CheckCheck,
  Clock,
  Eye,
  Film,
  ImagePlus,
  Loader2,
  Lock,
  Maximize2,
  MessageCircle,
  Minus,
  Paperclip,
  PhoneIncoming,
  PhoneMissed,
  PhoneOutgoing,
  Reply,
  SendHorizontal,
  Smile,
  Video,
  X,
} from "lucide-react";
import type {
  ChatMessage,
  Conversation,
  MessageReplyRef,
  PeerUserProfile,
} from "../types/chat";
import {
  compressImageToDataUrl,
  formatCallDurationLabel,
  formatDateSeparator,
  formatLastSeen,
  formatMessageTime,
  loadSecretChatMap,
  prepareVideoDataUrl,
} from "../utils/storage";
import { decryptSecretMessage } from "../services/e2ee";
import { Avatar } from "./Avatar";
import { VoiceNotePlayer } from "./VoiceNotePlayer";

export interface BubbleSendPayload {
  text: string;
  imageDataUrl?: string;
  videoDataUrl?: string;
  replyTo?: MessageReplyRef;
  encrypt?: boolean;
}

interface FloatingChatBubbleProps {
  currentUid: string;
  conversations: Conversation[];
  activeChatId: string | null;
  typingChatIds: Record<string, boolean>;
  peerProfilesByUid: Record<string, PeerUserProfile>;
  onOpenChat: (chatId: string) => void;
  onMarkChatRead?: (chatId: string) => void;
  onTypingChange?: (chatId: string, isTyping: boolean) => void;
  onSendMessageToChat: (chatId: string, payload: BubbleSendPayload) => Promise<void>;
  onPreviewImage?: (src: string) => void;
  onOpenViewOnceImage?: (chatId: string, message: ChatMessage) => void;
}

const BUBBLE_SIZE = 58;
const MARGIN = 12;
const QUICK_EMOJIS = [
  "❤️",
  "😂",
  "👍",
  "😍",
  "🙏",
  "🔥",
  "🎉",
  "👏",
  "😢",
  "😮",
  "✨",
  "🌹",
];

function isSameCalendarDay(a: number, b: number): boolean {
  const da = new Date(a);
  const db = new Date(b);
  return (
    da.getDate() === db.getDate() &&
    da.getMonth() === db.getMonth() &&
    da.getFullYear() === db.getFullYear()
  );
}

function renderInlineMessageText(text: string): ReactNode[] {
  const tokenRegex = /(https?:\/\/[^\s<>"']+|www\.[^\s<>"']+|\*\*[^*]+\*\*)/gi;
  const nodes: ReactNode[] = [];
  let lastIndex = 0;
  let match: RegExpExecArray | null;
  let keyIdx = 0;

  while ((match = tokenRegex.exec(text)) !== null) {
    if (match.index > lastIndex) {
      nodes.push(<span key={`t-${keyIdx++}`}>{text.slice(lastIndex, match.index)}</span>);
    }
    const token = match[0];
    if (token.startsWith("**") && token.endsWith("**") && token.length > 4) {
      nodes.push(
        <strong key={`b-${keyIdx++}`} className="font-bold">
          {token.slice(2, -2)}
        </strong>
      );
    } else {
      const href = /^https?:\/\//i.test(token) ? token : `https://${token}`;
      nodes.push(
        <a
          key={`u-${keyIdx++}`}
          href={href}
          target="_blank"
          rel="noopener noreferrer"
          onClick={(e) => e.stopPropagation()}
          className="underline decoration-current/60 hover:opacity-85 break-all font-medium"
        >
          {token}
        </a>
      );
    }
    lastIndex = tokenRegex.lastIndex;
  }

  if (lastIndex < text.length) {
    nodes.push(<span key={`t-${keyIdx++}`}>{text.slice(lastIndex)}</span>);
  }
  return nodes;
}

function getReplySnippet(msg: ChatMessage, resolvedText: string): string {
  if (resolvedText.trim()) return resolvedText.trim().slice(0, 180);
  if (msg.imageDataUrl) return "📷 صورة";
  if (msg.videoDataUrl) return "🎬 فيديو";
  if (msg.audioDataUrl) return "🎤 رسالة صوتية";
  return "رسالة";
}

export function FloatingChatBubble({
  currentUid,
  conversations,
  activeChatId,
  typingChatIds,
  peerProfilesByUid,
  onOpenChat,
  onMarkChatRead,
  onTypingChange,
  onSendMessageToChat,
  onPreviewImage,
  onOpenViewOnceImage,
}: FloatingChatBubbleProps) {
  const candidateChats = useMemo(() => {
    const nonAi = conversations.filter((c) => c.type !== "ai");
    const sortedNonAi = [...nonAi].sort((a, b) => {
      if ((b.unreadCount || 0) !== (a.unreadCount || 0)) {
        return (b.unreadCount || 0) - (a.unreadCount || 0);
      }
      const aTime =
        a.messages[a.messages.length - 1]?.timestamp ||
        a.lastMessageTimestamp ||
        0;
      const bTime =
        b.messages[b.messages.length - 1]?.timestamp ||
        b.lastMessageTimestamp ||
        0;
      return bTime - aTime;
    });
    const ai = conversations.filter((c) => c.type === "ai");
    return sortedNonAi.length > 0 ? [...sortedNonAi, ...ai] : ai;
  }, [conversations]);

  const totalUnread = useMemo(
    () =>
      conversations.reduce(
        (sum, c) => sum + (c.type !== "ai" ? c.unreadCount || 0 : 0),
        0
      ),
    [conversations]
  );

  const [selectedBubbleChatId, setSelectedBubbleChatId] = useState<string | null>(
    null
  );
  const [isExpanded, setIsExpanded] = useState(false);
  const [draft, setDraft] = useState("");
  const [replyTo, setReplyTo] = useState<MessageReplyRef | null>(null);
  const [pendingImage, setPendingImage] = useState<string | null>(null);
  const [pendingVideo, setPendingVideo] = useState<string | null>(null);
  const [showEmojis, setShowEmojis] = useState(false);
  const [sending, setSending] = useState(false);
  const [uploadingMedia, setUploadingMedia] = useState(false);
  const [sendError, setSendError] = useState<string | null>(null);
  const [decryptedMap, setDecryptedMap] = useState<Record<string, string>>({});
  const [isDragging, setIsDragging] = useState(false);

  const [viewport, setViewport] = useState<{ w: number; h: number }>(() =>
    typeof window === "undefined"
      ? { w: 1024, h: 768 }
      : { w: window.innerWidth, h: window.innerHeight }
  );

  const [pos, setPos] = useState<{ x: number; y: number }>(() => {
    if (typeof window === "undefined") return { x: MARGIN, y: 160 };
    return {
      x: MARGIN,
      y: Math.max(MARGIN + 16, window.innerHeight - BUBBLE_SIZE - 96),
    };
  });

  const dragRef = useRef<{
    pointerId: number;
    startX: number;
    startY: number;
    origX: number;
    origY: number;
    moved: boolean;
  } | null>(null);

  const snappedSideRef = useRef<"left" | "right">("left");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const mediaInputRef = useRef<HTMLInputElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const lastTypingSentAtRef = useRef<number>(0);
  const typingStopTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    const handleResize = () => {
      const w = window.innerWidth;
      const h = window.innerHeight;
      setViewport({ w, h });
      setPos((prev) => {
        const edgeX =
          snappedSideRef.current === "right"
            ? Math.max(MARGIN, w - BUBBLE_SIZE - MARGIN)
            : MARGIN;
        return {
          x: edgeX,
          y: Math.min(Math.max(MARGIN, prev.y), Math.max(MARGIN, h - BUBBLE_SIZE - MARGIN)),
        };
      });
    };
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  // Automatically focus newest unread chat while collapsed
  useEffect(() => {
    if (isExpanded) return;
    const unreadChat = candidateChats.find((c) => (c.unreadCount || 0) > 0);
    if (unreadChat) {
      setSelectedBubbleChatId(unreadChat.id);
    }
  }, [candidateChats, isExpanded]);

  const targetConv = useMemo(() => {
    if (selectedBubbleChatId) {
      const found = candidateChats.find((c) => c.id === selectedBubbleChatId);
      if (found) return found;
    }
    const unread = candidateChats.find((c) => (c.unreadCount || 0) > 0);
    if (unread) return unread;
    const nonActive = candidateChats.find((c) => c.id !== activeChatId);
    return nonActive || candidateChats[0] || null;
  }, [candidateChats, selectedBubbleChatId, activeChatId]);

  const targetPeerPublicKey =
    targetConv?.type === "direct" && targetConv.peerUid
      ? peerProfilesByUid[targetConv.peerUid]?.publicKey
      : undefined;

  // Decrypt E2EE messages for currently displayed floating conversation
  useEffect(() => {
    if (!isExpanded || !targetConv) return;
    const encryptedMsgs = targetConv.messages.filter(
      (m) => m.isEncrypted && m.ciphertext && m.iv
    );
    if (encryptedMsgs.length === 0) return;

    let cancelled = false;
    void Promise.all(
      encryptedMsgs.map(async (m) => {
        const plain = await decryptSecretMessage(
          currentUid,
          targetPeerPublicKey,
          m.ciphertext,
          m.iv
        );
        return [`${m.id}:${m.ciphertext}`, plain] as const;
      })
    ).then((entries) => {
      if (cancelled) return;
      setDecryptedMap((prev) => {
        const next = { ...prev };
        let changed = false;
        entries.forEach(([k, val]) => {
          if (next[k] !== val) {
            next[k] = val;
            changed = true;
          }
        });
        return changed ? next : prev;
      });
    });

    return () => {
      cancelled = true;
    };
  }, [isExpanded, targetConv?.id, targetConv?.messages, currentUid, targetPeerPublicKey]);

  // Mark selected conversation as read when expanded or switched
  useEffect(() => {
    if (!isExpanded || !targetConv || targetConv.type === "ai") return;
    if ((targetConv.unreadCount || 0) > 0) {
      onMarkChatRead?.(targetConv.id);
    }
  }, [isExpanded, targetConv?.id, targetConv?.unreadCount, onMarkChatRead]);

  // Smooth scroll to bottom when opening, switching chats, or receiving new messages
  useEffect(() => {
    if (!isExpanded || !targetConv) return;
    const raf = requestAnimationFrame(() => {
      messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    });
    return () => cancelAnimationFrame(raf);
  }, [isExpanded, targetConv?.id, targetConv?.messages.length]);

  // Clean up typing timer on unmount or chat switch
  useEffect(() => {
    return () => {
      if (typingStopTimerRef.current) {
        clearTimeout(typingStopTimerRef.current);
      }
    };
  }, [targetConv?.id]);

  if (!targetConv) return null;

  const isTargetTyping = Boolean(
    typingChatIds[targetConv.id] || (targetConv.typingUids?.length || 0) > 0
  );

  const isSecretChatActive = Boolean(
    targetConv.type === "direct" &&
      targetPeerPublicKey &&
      loadSecretChatMap()[targetConv.id]
  );

  const handlePointerDown = (e: ReactPointerEvent<HTMLButtonElement>) => {
    if (e.button !== 0 && e.pointerType === "mouse") return;
    e.currentTarget.setPointerCapture(e.pointerId);
    dragRef.current = {
      pointerId: e.pointerId,
      startX: e.clientX,
      startY: e.clientY,
      origX: pos.x,
      origY: pos.y,
      moved: false,
    };
  };

  const handlePointerMove = (e: ReactPointerEvent<HTMLButtonElement>) => {
    const drag = dragRef.current;
    if (!drag || drag.pointerId !== e.pointerId) return;
    const dx = e.clientX - drag.startX;
    const dy = e.clientY - drag.startY;
    if (!drag.moved && Math.hypot(dx, dy) >= 6) {
      drag.moved = true;
      setIsDragging(true);
    }
    if (!drag.moved) return;

    const maxX = Math.max(MARGIN, viewport.w - BUBBLE_SIZE - MARGIN);
    const maxY = Math.max(MARGIN, viewport.h - BUBBLE_SIZE - MARGIN);
    setPos({
      x: Math.min(Math.max(MARGIN, drag.origX + dx), maxX),
      y: Math.min(Math.max(MARGIN, drag.origY + dy), maxY),
    });
  };

  const handlePointerUp = (e: ReactPointerEvent<HTMLButtonElement>) => {
    const drag = dragRef.current;
    if (!drag || drag.pointerId !== e.pointerId) return;
    const wasMoved = drag.moved;
    dragRef.current = null;
    setIsDragging(false);

    if (e.currentTarget.hasPointerCapture(e.pointerId)) {
      e.currentTarget.releasePointerCapture(e.pointerId);
    }

    if (wasMoved) {
      // Snap smoothly to nearest horizontal screen edge like Messenger Chat Heads
      const centerX = pos.x + BUBBLE_SIZE / 2;
      const snapToRight = centerX >= viewport.w / 2;
      snappedSideRef.current = snapToRight ? "right" : "left";
      const snappedX = snapToRight
        ? Math.max(MARGIN, viewport.w - BUBBLE_SIZE - MARGIN)
        : MARGIN;
      const maxY = Math.max(MARGIN, viewport.h - BUBBLE_SIZE - MARGIN);
      const clampedY = Math.min(Math.max(MARGIN + 8, pos.y), maxY);
      setPos({ x: snappedX, y: clampedY });
    } else {
      setIsExpanded((prev) => !prev);
      setSendError(null);
    }
  };

  const handleMinimize = () => {
    setIsExpanded(false);
    setShowEmojis(false);
  };

  const handleCloseWindow = () => {
    setIsExpanded(false);
    setShowEmojis(false);
    setReplyTo(null);
    setPendingImage(null);
    setPendingVideo(null);
    setSendError(null);
  };

  const handleSelectFriend = (chatId: string) => {
    if (chatId === targetConv.id) return;
    setSelectedBubbleChatId(chatId);
    setReplyTo(null);
    setPendingImage(null);
    setPendingVideo(null);
    setShowEmojis(false);
    setSendError(null);
    onMarkChatRead?.(chatId);
  };

  const triggerTypingSignal = (nextText: string) => {
    if (!onTypingChange || targetConv.type === "ai") return;
    const hasContent = nextText.trim().length > 0;
    if (!hasContent) {
      if (typingStopTimerRef.current) clearTimeout(typingStopTimerRef.current);
      lastTypingSentAtRef.current = 0;
      onTypingChange(targetConv.id, false);
      return;
    }

    const now = Date.now();
    if (now - lastTypingSentAtRef.current >= 2500) {
      lastTypingSentAtRef.current = now;
      onTypingChange(targetConv.id, true);
    }
    if (typingStopTimerRef.current) clearTimeout(typingStopTimerRef.current);
    typingStopTimerRef.current = setTimeout(() => {
      lastTypingSentAtRef.current = 0;
      onTypingChange(targetConv.id, false);
    }, 2400);
  };

  const handleMediaPick = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    setSendError(null);
    setUploadingMedia(true);
    try {
      if (file.type.startsWith("video/")) {
        const videoUrl = await prepareVideoDataUrl(file);
        setPendingVideo(videoUrl);
        setPendingImage(null);
      } else if (file.type.startsWith("image/")) {
        const imageUrl = await compressImageToDataUrl(file, 1080, 0.8, 220000);
        setPendingImage(imageUrl);
        setPendingVideo(null);
      } else {
        setSendError("يرجى اختيار صورة أو مقطع فيديو صالح.");
      }
    } catch (err) {
      setSendError(
        err instanceof Error ? err.message : "تعذر تجهيز الملف المرفق."
      );
    } finally {
      setUploadingMedia(false);
    }
  };

  const handleSend = async (e?: FormEvent) => {
    e?.preventDefault();
    const trimmed = draft.trim();
    if ((!trimmed && !pendingImage && !pendingVideo) || sending || uploadingMedia) {
      return;
    }

    setSending(true);
    setSendError(null);
    try {
      if (typingStopTimerRef.current) {
        clearTimeout(typingStopTimerRef.current);
      }
      lastTypingSentAtRef.current = 0;
      onTypingChange?.(targetConv.id, false);

      await onSendMessageToChat(targetConv.id, {
        text: trimmed,
        imageDataUrl: pendingImage || undefined,
        videoDataUrl: pendingVideo || undefined,
        replyTo: replyTo || undefined,
        encrypt: isSecretChatActive && Boolean(trimmed),
      });

      setDraft("");
      setReplyTo(null);
      setPendingImage(null);
      setPendingVideo(null);
      setShowEmojis(false);
    } catch (err) {
      setSendError(
        err instanceof Error ? err.message : "تعذر إرسال الرسالة. حاول مجدداً."
      );
    } finally {
      setSending(false);
    }
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      void handleSend();
    }
  };

  // Compute safe floating chat window geometry inside viewport
  const windowWidth = Math.min(392, Math.max(290, viewport.w - 16));
  const windowHeight = Math.min(560, Math.max(360, viewport.h - 92));
  const placeLeftAligned = pos.x < viewport.w / 2;
  const rawLeft = placeLeftAligned
    ? pos.x
    : pos.x + BUBBLE_SIZE - windowWidth;
  const windowLeft = Math.min(
    Math.max(8, rawLeft),
    Math.max(8, viewport.w - windowWidth - 8)
  );
  const openAbove = pos.y > viewport.h * 0.42;
  const rawTop = openAbove
    ? pos.y - windowHeight - 10
    : pos.y + BUBBLE_SIZE + 10;
  const windowTop = Math.min(
    Math.max(8, rawTop),
    Math.max(8, viewport.h - windowHeight - 8)
  );

  const statusText = isTargetTyping
    ? "يكتب الآن..."
    : targetConv.type === "ai"
    ? "المساعد الذكي"
    : targetConv.type === "group"
    ? `${targetConv.memberIds?.length || 2} أعضاء`
    : targetConv.peerShowLastSeen !== false
    ? formatLastSeen(targetConv.peerLastSeen, targetConv.peerOnline)
    : "محادثة خاصة";

  return (
    <>
      {isExpanded && (
        <div
          dir="rtl"
          role="dialog"
          aria-label={`نافذة محادثة ${targetConv.title}`}
          style={{
            left: `${windowLeft}px`,
            top: `${windowTop}px`,
            width: `${windowWidth}px`,
            height: `${windowHeight}px`,
          }}
          className="fixed z-50 rounded-3xl bg-white dark:bg-[#111b21] border border-slate-200 dark:border-slate-700/90 shadow-2xl overflow-hidden flex flex-col animate-in fade-in zoom-in-95 duration-150"
        >
          {/* Messenger Chat Window Header */}
          <header className="px-3.5 py-2.5 bg-gradient-to-l from-[#075E54] to-[#0d7a5f] dark:from-[#202c33] dark:to-[#18242b] text-white flex items-center justify-between gap-2 shrink-0">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="relative shrink-0">
                <Avatar src={targetConv.avatar} name={targetConv.title} size="sm" />
                {targetConv.type === "direct" &&
                  targetConv.peerShowLastSeen !== false &&
                  targetConv.peerOnline && (
                    <span className="absolute bottom-0 left-0 w-2.5 h-2.5 rounded-full bg-emerald-400 ring-2 ring-[#075E54] dark:ring-[#202c33]" />
                  )}
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-1 min-w-0">
                  <p className="text-xs sm:text-sm font-bold truncate">
                    {targetConv.title}
                  </p>
                  {isSecretChatActive && (
                    <Lock
                      className="w-3 h-3 text-emerald-200 shrink-0"
                      aria-label="محادثة مشفرة"
                    />
                  )}
                </div>
                <p
                  className={`text-[10px] truncate ${
                    isTargetTyping
                      ? "text-emerald-200 font-bold animate-pulse"
                      : "text-emerald-100/85 dark:text-slate-300"
                  }`}
                >
                  {statusText}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1 shrink-0">
              <button
                type="button"
                onClick={() => {
                  setIsExpanded(false);
                  onOpenChat(targetConv.id);
                }}
                aria-label="فتح المحادثة في الشاشة الكاملة"
                title="توسيع في الشاشة الكاملة"
                className="w-7 h-7 rounded-lg bg-white/15 hover:bg-white/25 flex items-center justify-center transition-colors cursor-pointer"
              >
                <Maximize2 className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={handleMinimize}
                aria-label="تصغير إلى الفقاعة العائمة"
                title="تصغير"
                className="w-7 h-7 rounded-lg bg-white/15 hover:bg-white/25 flex items-center justify-center transition-colors cursor-pointer"
              >
                <Minus className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={handleCloseWindow}
                aria-label="إغلاق نافذة المحادثة العائمة"
                title="إغلاق"
                className="w-7 h-7 rounded-lg bg-white/15 hover:bg-rose-500/80 flex items-center justify-center transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </header>

          {/* Top Friend / Chat Switcher Bar */}
          <div className="px-2.5 py-2 border-b border-slate-100 dark:border-slate-800 bg-slate-50/90 dark:bg-[#0e171d] flex items-center gap-2 overflow-x-auto custom-scrollbar shrink-0">
            {candidateChats.map((chat) => {
              const isSelected = chat.id === targetConv.id;
              const chatTyping = Boolean(
                typingChatIds[chat.id] || (chat.typingUids?.length || 0) > 0
              );
              return (
                <button
                  key={chat.id}
                  type="button"
                  onClick={() => handleSelectFriend(chat.id)}
                  title={chat.title}
                  className={`group flex flex-col items-center gap-1 px-1.5 py-1 rounded-2xl shrink-0 transition-colors cursor-pointer ${
                    isSelected
                      ? "bg-emerald-50 dark:bg-[#202c33] ring-1 ring-[#0d7a5f]/50 dark:ring-[#00a884]/60"
                      : "hover:bg-slate-200/60 dark:hover:bg-[#1a252b]"
                  }`}
                >
                  <div className="relative">
                    <div
                      className={`rounded-full p-0.5 ${
                        isSelected
                          ? "ring-2 ring-[#0d7a5f] dark:ring-[#00a884]"
                          : chatTyping
                          ? "ring-2 ring-emerald-400 animate-pulse"
                          : ""
                      }`}
                    >
                      <Avatar src={chat.avatar} name={chat.title} size="sm" />
                    </div>
                    {(chat.unreadCount || 0) > 0 && (
                      <span className="absolute -top-1 -right-1 min-w-[16px] h-4 px-1 rounded-full bg-rose-600 text-white text-[9px] font-bold flex items-center justify-center ring-2 ring-white dark:ring-[#0e171d]">
                        {chat.unreadCount > 99 ? "99+" : chat.unreadCount}
                      </span>
                    )}
                    {chat.type === "direct" &&
                      chat.peerShowLastSeen !== false &&
                      chat.peerOnline && (
                        <span className="absolute bottom-0 left-0 w-2.5 h-2.5 rounded-full bg-emerald-500 ring-2 ring-white dark:ring-[#0e171d]" />
                      )}
                  </div>
                  <span
                    className={`text-[10px] max-w-[56px] truncate ${
                      isSelected
                        ? "font-bold text-[#0d7a5f] dark:text-[#00a884]"
                        : "font-medium text-slate-600 dark:text-slate-300"
                    }`}
                  >
                    {chat.title.split(" ")[0]}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Complete Scrollable Chat History */}
          <div className="flex-1 overflow-y-auto custom-scrollbar p-3 space-y-2 bg-[#efeae2] dark:bg-[#0b141a]">
            {targetConv.messages.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center gap-2 py-8 px-4 text-slate-500 dark:text-slate-400">
                <div className="w-11 h-11 rounded-2xl bg-white/80 dark:bg-[#202c33] flex items-center justify-center shadow-xs">
                  <MessageCircle className="w-5 h-5 text-[#0d7a5f] dark:text-[#00a884]" />
                </div>
                <p className="text-xs font-bold text-slate-700 dark:text-slate-200">
                  لا توجد رسائل بعد مع {targetConv.title}
                </p>
                <p className="text-[11px]">
                  اكتب رسالتك أدناه لبدء المحادثة فوراً
                </p>
              </div>
            ) : (
              targetConv.messages.map((msg, idx) => {
                const prevMsg = idx > 0 ? targetConv.messages[idx - 1] : null;
                const showDateSep =
                  !prevMsg || !isSameCalendarDay(prevMsg.timestamp, msg.timestamp);
                const isMine = msg.senderId === "me";
                const decKey = `${msg.id}:${msg.ciphertext || ""}`;
                const displayText =
                  msg.isEncrypted && msg.ciphertext
                    ? decryptedMap[decKey] ?? "🔒 جاري فك التشفير..."
                    : msg.text;

                return (
                  <Fragment key={msg.id}>
                    {showDateSep && (
                      <div className="flex justify-center py-1">
                        <span className="px-2.5 py-0.5 rounded-full bg-white/85 dark:bg-[#202c33] text-[10px] font-semibold text-slate-600 dark:text-slate-300 shadow-xs">
                          {formatDateSeparator(msg.timestamp)}
                        </span>
                      </div>
                    )}

                    {msg.messageType === "call" && msg.callInfo ? (
                      <div className="flex justify-center py-0.5">
                        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-white/90 dark:bg-[#202c33] text-[11px] font-semibold text-slate-700 dark:text-slate-200 shadow-xs">
                          {msg.callInfo.outcome === "missed" ||
                          msg.callInfo.outcome === "declined" ? (
                            <PhoneMissed className="w-3.5 h-3.5 text-rose-500" />
                          ) : msg.callInfo.callType === "video" ? (
                            <Video className="w-3.5 h-3.5 text-[#0d7a5f] dark:text-[#00a884]" />
                          ) : isMine ? (
                            <PhoneOutgoing className="w-3.5 h-3.5 text-[#0d7a5f] dark:text-[#00a884]" />
                          ) : (
                            <PhoneIncoming className="w-3.5 h-3.5 text-[#0d7a5f] dark:text-[#00a884]" />
                          )}
                          <span>{msg.text}</span>
                          {msg.callInfo.durationSeconds > 0 && (
                            <span className="opacity-70 tabular-nums">
                              ({formatCallDurationLabel(msg.callInfo.durationSeconds)})
                            </span>
                          )}
                        </div>
                      </div>
                    ) : (
                      <div
                        className={`flex items-end gap-1 group ${
                          isMine ? "justify-start" : "justify-end"
                        }`}
                      >
                        <div
                          className={`relative max-w-[84%] rounded-2xl px-3 py-2 text-xs shadow-xs ${
                            isMine
                              ? "bg-[#d9fdd3] dark:bg-[#005c4b] text-slate-900 dark:text-slate-100 rounded-tr-sm"
                              : "bg-white dark:bg-[#202c33] text-slate-800 dark:text-slate-100 rounded-tl-sm"
                          }`}
                        >
                          {/* Group Sender Name */}
                          {!isMine &&
                            targetConv.type === "group" &&
                            msg.senderName && (
                              <p className="text-[10px] font-bold text-[#0d7a5f] dark:text-[#00a884] mb-0.5">
                                {msg.senderName}
                              </p>
                            )}

                          {/* Reply Quote */}
                          {msg.replyTo && (
                            <div className="mb-1.5 p-1.5 rounded-lg bg-black/5 dark:bg-black/25 border-r-2 border-[#0d7a5f] dark:border-[#00a884]">
                              <p className="text-[10px] font-bold text-[#0d7a5f] dark:text-[#00a884] truncate">
                                {msg.replyTo.senderName}
                              </p>
                              <p className="text-[10px] opacity-80 line-clamp-2 break-words">
                                {msg.replyTo.text}
                              </p>
                            </div>
                          )}

                          {/* Media: View Once Image */}
                          {msg.viewOnce ? (
                            msg.viewOnceOpened ? (
                              <div className="flex items-center gap-1.5 py-1 text-[11px] opacity-70 italic">
                                <Eye className="w-3.5 h-3.5" />
                                <span>تمت مشاهدة الصورة</span>
                              </div>
                            ) : (
                              <button
                                type="button"
                                onClick={() => onOpenViewOnceImage?.(targetConv.id, msg)}
                                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-black/5 dark:bg-white/10 font-bold text-[11px] cursor-pointer hover:opacity-90"
                              >
                                <Eye className="w-3.5 h-3.5 text-[#0d7a5f] dark:text-[#00a884]" />
                                <span>صورة للعرض مرة واحدة</span>
                              </button>
                            )
                          ) : (
                            msg.imageDataUrl && (
                              <button
                                type="button"
                                onClick={() => onPreviewImage?.(msg.imageDataUrl!)}
                                className="block mb-1.5 overflow-hidden rounded-xl cursor-pointer"
                              >
                                <img
                                  src={msg.imageDataUrl}
                                  alt="مرفق صورة"
                                  className="max-h-44 w-full object-cover rounded-xl"
                                />
                              </button>
                            )
                          )}

                          {/* Media: Video */}
                          {msg.videoDataUrl && (
                            <video
                              src={msg.videoDataUrl}
                              controls
                              playsInline
                              preload="metadata"
                              className="max-h-44 w-full rounded-xl mb-1.5 bg-black"
                            />
                          )}

                          {/* Media: Voice Note */}
                          {msg.audioDataUrl && (
                            <div className="mb-1">
                              <VoiceNotePlayer
                                src={msg.audioDataUrl}
                                initialDuration={msg.audioDuration}
                                isMine={isMine}
                              />
                            </div>
                          )}

                          {/* Message Text */}
                          {displayText && (
                            <div className="break-words whitespace-pre-wrap leading-relaxed text-[12.5px]">
                              {msg.isEncrypted && (
                                <Lock className="inline-block w-3 h-3 ml-1 opacity-75" />
                              )}
                              {renderInlineMessageText(displayText)}
                            </div>
                          )}

                          {/* Reactions */}
                          {msg.reactions &&
                            Object.keys(msg.reactions).length > 0 && (
                              <div className="flex flex-wrap gap-1 mt-1">
                                {Object.entries(
                                  Object.values(msg.reactions).reduce<
                                    Record<string, number>
                                  >((acc, emoji) => {
                                    acc[emoji] = (acc[emoji] || 0) + 1;
                                    return acc;
                                  }, {})
                                ).map(([emoji, count]) => (
                                  <span
                                    key={emoji}
                                    className="px-1.5 py-0.5 rounded-full bg-white/80 dark:bg-[#111b21]/80 text-[10px] shadow-xs"
                                  >
                                    {emoji} {count > 1 ? count : ""}
                                  </span>
                                ))}
                              </div>
                            )}

                          {/* Footer: Timestamp, Edited, Read Ticks, Quick Reply */}
                          <div className="flex items-center justify-between gap-2 mt-1 pt-0.5">
                            <button
                              type="button"
                              onClick={() => {
                                setReplyTo({
                                  id: msg.id,
                                  senderName: isMine
                                    ? "أنت"
                                    : msg.senderName || targetConv.title,
                                  text: getReplySnippet(msg, displayText),
                                  mediaType: msg.audioDataUrl
                                    ? "audio"
                                    : msg.videoDataUrl
                                    ? "video"
                                    : msg.imageDataUrl
                                    ? "image"
                                    : undefined,
                                });
                                inputRef.current?.focus();
                              }}
                              aria-label="رد على هذه الرسالة"
                              title="رد"
                              className="opacity-70 hover:opacity-100 p-0.5 rounded text-slate-600 dark:text-slate-300 cursor-pointer"
                            >
                              <Reply className="w-3 h-3" />
                            </button>

                            <div className="flex items-center gap-1 text-[9.5px] opacity-75 tabular-nums">
                              {msg.edited && <span>تم التعديل</span>}
                              <span>{formatMessageTime(msg.timestamp)}</span>
                              {isMine && (
                                <span className="inline-flex items-center">
                                  {msg.status === "sending" && (
                                    <Clock className="w-3 h-3 text-slate-400" />
                                  )}
                                  {msg.status === "sent" && (
                                    <Check className="w-3 h-3 text-slate-400" />
                                  )}
                                  {msg.status === "delivered" && (
                                    <CheckCheck className="w-3 h-3 text-slate-400" />
                                  )}
                                  {msg.status === "read" && (
                                    <CheckCheck className="w-3 h-3 text-sky-500" />
                                  )}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    )}
                  </Fragment>
                );
              })
            )}

            {isTargetTyping && (
              <div className="flex justify-end">
                <div className="px-3 py-1.5 rounded-2xl rounded-tl-sm bg-white dark:bg-[#202c33] text-[11px] font-bold text-[#0d7a5f] dark:text-[#00a884] shadow-xs animate-pulse">
                  يكتب الآن...
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Pending Reply / Media / Error Strip */}
          {(replyTo || pendingImage || pendingVideo || sendError) && (
            <div className="px-2.5 py-2 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-[#1a252b] space-y-1.5 shrink-0">
              {sendError && (
                <p className="text-[11px] font-semibold text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/40 px-2.5 py-1 rounded-xl flex items-center justify-between gap-2">
                  <span>{sendError}</span>
                  <button
                    type="button"
                    onClick={() => setSendError(null)}
                    className="cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </p>
              )}

              {replyTo && (
                <div className="flex items-center justify-between gap-2 px-2.5 py-1.5 rounded-xl bg-white dark:bg-[#202c33] border-r-2 border-[#0d7a5f] dark:border-[#00a884]">
                  <div className="min-w-0">
                    <p className="text-[10px] font-bold text-[#0d7a5f] dark:text-[#00a884] truncate">
                      رد على {replyTo.senderName}
                    </p>
                    <p className="text-[11px] text-slate-600 dark:text-slate-300 truncate">
                      {replyTo.text}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setReplyTo(null)}
                    aria-label="إلغاء الرد"
                    className="p-1 rounded-lg text-slate-400 hover:text-slate-600 cursor-pointer shrink-0"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}

              {(pendingImage || pendingVideo) && (
                <div className="flex items-center justify-between gap-2 p-1.5 rounded-xl bg-white dark:bg-[#202c33] border border-slate-200 dark:border-slate-700">
                  <div className="flex items-center gap-2 min-w-0">
                    {pendingImage ? (
                      <img
                        src={pendingImage}
                        alt="معاينة"
                        className="w-10 h-10 rounded-lg object-cover shrink-0"
                      />
                    ) : (
                      <div className="w-10 h-10 rounded-lg bg-slate-900 text-white flex items-center justify-center shrink-0">
                        <Film className="w-4 h-4" />
                      </div>
                    )}
                    <span className="text-[11px] font-semibold text-slate-700 dark:text-slate-200 truncate">
                      {pendingImage ? "صورة جاهزة للإرسال" : "فيديو جاهز للإرسال"}
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setPendingImage(null);
                      setPendingVideo(null);
                    }}
                    aria-label="إزالة المرفق"
                    className="p-1.5 rounded-lg text-slate-400 hover:text-rose-500 cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>
          )}

          {/* Quick Emoji Drawer */}
          {showEmojis && (
            <div className="px-2.5 py-2 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1a252b] flex items-center gap-1.5 overflow-x-auto shrink-0">
              {QUICK_EMOJIS.map((emoji) => (
                <button
                  key={emoji}
                  type="button"
                  onClick={() => {
                    const next = `${draft}${emoji}`;
                    setDraft(next);
                    triggerTypingSignal(next);
                    inputRef.current?.focus();
                  }}
                  className="w-8 h-8 rounded-xl hover:bg-slate-100 dark:hover:bg-[#2a3942] text-base flex items-center justify-center shrink-0 cursor-pointer"
                >
                  {emoji}
                </button>
              ))}
            </div>
          )}

          {/* Full Message Composer Bar */}
          <form
            onSubmit={(e) => void handleSend(e)}
            className="p-2 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-[#202c33] flex items-end gap-1.5 shrink-0"
          >
            <button
              type="button"
              onClick={() => setShowEmojis((v) => !v)}
              aria-label="رموز تعبيرية"
              className="w-9 h-9 rounded-full hover:bg-slate-100 dark:hover:bg-[#2a3942] text-slate-500 dark:text-slate-300 flex items-center justify-center shrink-0 cursor-pointer"
            >
              <Smile className="w-4 h-4" />
            </button>

            <button
              type="button"
              disabled={uploadingMedia}
              onClick={() => mediaInputRef.current?.click()}
              aria-label="إرفاق صورة أو فيديو"
              className="w-9 h-9 rounded-full hover:bg-slate-100 dark:hover:bg-[#2a3942] text-slate-500 dark:text-slate-300 flex items-center justify-center shrink-0 cursor-pointer disabled:opacity-50"
            >
              {uploadingMedia ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : pendingImage || pendingVideo ? (
                <ImagePlus className="w-4 h-4 text-[#0d7a5f] dark:text-[#00a884]" />
              ) : (
                <Paperclip className="w-4 h-4" />
              )}
            </button>
            <input
              ref={mediaInputRef}
              type="file"
              accept="image/*,video/*"
              onChange={(e) => void handleMediaPick(e)}
              className="hidden"
            />

            <textarea
              ref={inputRef}
              rows={1}
              value={draft}
              onChange={(e) => {
                setDraft(e.target.value);
                triggerTypingSignal(e.target.value);
              }}
              onKeyDown={handleKeyDown}
              placeholder={
                isSecretChatActive
                  ? "اكتب رسالة مشفرة..."
                  : `راسل ${targetConv.title.split(" ")[0]}...`
              }
              className="flex-1 min-w-0 max-h-24 min-h-[38px] px-3.5 py-2 rounded-2xl bg-slate-100 dark:bg-[#2a3942] text-xs text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-[#0d7a5f]/50 dark:focus:ring-[#00a884]/50 resize-none leading-snug"
            />

            <button
              type="submit"
              disabled={
                sending ||
                uploadingMedia ||
                (!draft.trim() && !pendingImage && !pendingVideo)
              }
              aria-label="إرسال الرسالة"
              className="w-9 h-9 rounded-full bg-[#0d7a5f] hover:bg-[#0a634d] dark:bg-[#00a884] dark:hover:bg-[#069475] disabled:opacity-45 text-white flex items-center justify-center shrink-0 transition-colors cursor-pointer"
            >
              {sending ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <SendHorizontal className="w-4 h-4 rotate-180" />
              )}
            </button>
          </form>
        </div>
      )}

      {/* Draggable Edge-Snapping Messenger-Style Chat Head Bubble */}
      <button
        type="button"
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerCancel={handlePointerUp}
        aria-label={`الفقاعة العائمة للمحادثة: ${targetConv.title}`}
        title={`${targetConv.title} — اضغط لفتح المحادثة أو اسحب للتثبيت على الحواف`}
        style={{
          left: `${pos.x}px`,
          top: `${pos.y}px`,
          width: `${BUBBLE_SIZE}px`,
          height: `${BUBBLE_SIZE}px`,
          touchAction: "none",
          transition: isDragging
            ? "none"
            : "left 280ms cubic-bezier(0.22, 1, 0.36, 1), top 280ms cubic-bezier(0.22, 1, 0.36, 1), transform 180ms ease",
        }}
        className={`fixed z-50 rounded-full p-0.5 bg-gradient-to-br from-[#0d7a5f] via-[#129977] to-[#25D366] shadow-2xl select-none ${
          isDragging
            ? "scale-110 cursor-grabbing ring-4 ring-emerald-400/40"
            : "hover:scale-105 active:scale-95 cursor-grab"
        } ${isTargetTyping && !isDragging ? "ring-4 ring-emerald-400/50 animate-pulse" : ""}`}
      >
        <div className="w-full h-full rounded-full overflow-hidden bg-white dark:bg-[#111b21] flex items-center justify-center border border-white/70 dark:border-slate-900">
          <Avatar src={targetConv.avatar} name={targetConv.title} size="lg" />
        </div>

        {totalUnread > 0 && (
          <span className="absolute -top-1 -right-1 min-w-[21px] h-[21px] px-1.5 rounded-full bg-rose-600 text-white text-[10px] font-extrabold flex items-center justify-center ring-2 ring-white dark:ring-[#0b141a] shadow-sm">
            {totalUnread > 99 ? "99+" : totalUnread}
          </span>
        )}

        {targetConv.type === "direct" &&
          targetConv.peerShowLastSeen !== false &&
          targetConv.peerOnline && (
            <span className="absolute bottom-0 left-0 w-3.5 h-3.5 rounded-full bg-emerald-500 ring-2 ring-white dark:ring-[#0b141a]" />
          )}
      </button>
    </>
  );
}
