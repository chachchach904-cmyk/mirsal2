import {
  useEffect,
  useMemo,
  useRef,
  useState,
  type PointerEvent as ReactPointerEvent,
} from "react";
import { Pause, Play, Mic } from "lucide-react";

interface VoiceNotePlayerProps {
  src: string;
  initialDuration?: number;
  isMine: boolean;
}

const BAR_COUNT = 28;
const PLAYBACK_RATES = [1, 1.5, 2] as const;

function formatSeconds(sec: number): string {
  if (!Number.isFinite(sec) || sec < 0) return "0:00";
  const total = Math.floor(sec);
  const mins = Math.floor(total / 60);
  const secs = total % 60;
  return `${mins}:${secs.toString().padStart(2, "0")}`;
}

function buildWaveformPeaks(seedSource: string): number[] {
  let hash = 2166136261;
  const sample = seedSource.slice(-120);
  for (let i = 0; i < sample.length; i++) {
    hash ^= sample.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }

  const peaks: number[] = [];
  for (let i = 0; i < BAR_COUNT; i++) {
    hash ^= (i + 1) * 374761393;
    hash = Math.imul(hash, 668265263);
    const normalized = ((hash >>> 0) % 100) / 100;
    const envelope = Math.sin(((i + 1) / (BAR_COUNT + 1)) * Math.PI);
    const height = Math.round(22 + (normalized * 0.65 + envelope * 0.35) * 78);
    peaks.push(Math.min(100, Math.max(20, height)));
  }
  return peaks;
}

export function VoiceNotePlayer({
  src,
  initialDuration = 0,
  isMine,
}: VoiceNotePlayerProps) {
  const audioRef = useRef<HTMLAudioElement>(null);
  const waveformRef = useRef<HTMLDivElement>(null);
  const isScrubbingRef = useRef(false);

  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(initialDuration);
  const [rateIndex, setRateIndex] = useState(0);

  const peaks = useMemo(() => buildWaveformPeaks(src), [src]);
  const playbackRate = PLAYBACK_RATES[rateIndex];

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const handleLoadedMetadata = () => {
      if (Number.isFinite(audio.duration) && audio.duration > 0) {
        setDuration(audio.duration);
      }
    };

    const handleTimeUpdate = () => {
      if (!isScrubbingRef.current) {
        setCurrentTime(audio.currentTime);
      }
    };

    const handleEnded = () => {
      setIsPlaying(false);
      setCurrentTime(0);
    };

    const handlePause = () => {
      setIsPlaying(false);
    };

    const handlePlay = () => {
      setIsPlaying(true);
    };

    audio.addEventListener("loadedmetadata", handleLoadedMetadata);
    audio.addEventListener("timeupdate", handleTimeUpdate);
    audio.addEventListener("ended", handleEnded);
    audio.addEventListener("pause", handlePause);
    audio.addEventListener("play", handlePlay);

    return () => {
      audio.removeEventListener("loadedmetadata", handleLoadedMetadata);
      audio.removeEventListener("timeupdate", handleTimeUpdate);
      audio.removeEventListener("ended", handleEnded);
      audio.removeEventListener("pause", handlePause);
      audio.removeEventListener("play", handlePlay);
    };
  }, [src]);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.playbackRate = playbackRate;
    }
  }, [playbackRate]);

  const togglePlayback = async () => {
    const audio = audioRef.current;
    if (!audio) return;

    if (isPlaying) {
      audio.pause();
    } else {
      try {
        audio.playbackRate = playbackRate;
        await audio.play();
      } catch {
        setIsPlaying(false);
      }
    }
  };

  const maxDur =
    duration > 0 ? duration : initialDuration > 0 ? initialDuration : 1;
  const progressRatio = Math.min(1, Math.max(0, currentTime / maxDur));

  const seekFromClientX = (clientX: number) => {
    const el = waveformRef.current;
    const audio = audioRef.current;
    if (!el || !audio) return;
    const rect = el.getBoundingClientRect();
    if (rect.width <= 0) return;
    const ratio = Math.min(1, Math.max(0, (clientX - rect.left) / rect.width));
    const targetTime = ratio * maxDur;
    audio.currentTime = targetTime;
    setCurrentTime(targetTime);
  };

  const handlePointerDown = (e: ReactPointerEvent<HTMLDivElement>) => {
    isScrubbingRef.current = true;
    e.currentTarget.setPointerCapture(e.pointerId);
    seekFromClientX(e.clientX);
  };

  const handlePointerMove = (e: ReactPointerEvent<HTMLDivElement>) => {
    if (!isScrubbingRef.current) return;
    seekFromClientX(e.clientX);
  };

  const handlePointerUp = () => {
    isScrubbingRef.current = false;
  };

  const cyclePlaybackRate = () => {
    setRateIndex((prev) => (prev + 1) % PLAYBACK_RATES.length);
  };

  return (
    <div className="flex items-center gap-2.5 min-w-[230px] sm:min-w-[265px] py-1">
      <audio ref={audioRef} src={src} preload="metadata" className="hidden" />

      <button
        type="button"
        onClick={() => void togglePlayback()}
        aria-label={isPlaying ? "إيقاف مؤقت" : "تشغيل الرسالة الصوتية"}
        className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 transition-transform active:scale-95 cursor-pointer ${
          isMine
            ? "bg-white/20 hover:bg-white/30 text-white"
            : "bg-emerald-50 dark:bg-emerald-950/60 hover:bg-emerald-100 dark:hover:bg-emerald-950 text-[#0d7a5f] dark:text-[#00a884]"
        }`}
      >
        {isPlaying ? (
          <Pause className="w-4 h-4 fill-current" />
        ) : (
          <Play className="w-4 h-4 fill-current translate-x-[1px]" />
        )}
      </button>

      <div className="flex-1 min-w-0 space-y-1.5">
        {/* Interactive Waveform Scrub Bar */}
        <div
          ref={waveformRef}
          dir="ltr"
          role="slider"
          aria-label="شريط التقدم الصوتي"
          aria-valuemin={0}
          aria-valuemax={Math.round(maxDur)}
          aria-valuenow={Math.round(currentTime)}
          tabIndex={0}
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerCancel={handlePointerUp}
          onKeyDown={(e) => {
            const audio = audioRef.current;
            if (!audio) return;
            if (e.key === "ArrowRight") {
              const next = Math.min(maxDur, audio.currentTime + 2);
              audio.currentTime = next;
              setCurrentTime(next);
            } else if (e.key === "ArrowLeft") {
              const next = Math.max(0, audio.currentTime - 2);
              audio.currentTime = next;
              setCurrentTime(next);
            }
          }}
          className="h-8 flex items-center gap-[3px] cursor-pointer touch-none select-none px-0.5"
        >
          {peaks.map((heightPct, idx) => {
            const barProgress = (idx + 0.5) / BAR_COUNT;
            const isPlayed = barProgress <= progressRatio;
            return (
              <span
                key={idx}
                style={{ height: `${heightPct}%` }}
                className={`flex-1 rounded-full transition-colors duration-150 ${
                  isMine
                    ? isPlayed
                      ? "bg-white"
                      : "bg-white/35"
                    : isPlayed
                    ? "bg-[#0d7a5f] dark:bg-[#00a884]"
                    : "bg-slate-300 dark:bg-slate-600"
                }`}
              />
            );
          })}
        </div>

        <div
          className={`flex items-center justify-between text-[11px] tabular-nums ${
            isMine
              ? "text-emerald-100/90"
              : "text-slate-500 dark:text-slate-400"
          }`}
        >
          <div className="flex items-center gap-1.5">
            <span>{formatSeconds(isPlaying || currentTime > 0 ? currentTime : duration)}</span>
            <Mic className="w-3 h-3 opacity-80" />
          </div>

          <button
            type="button"
            onClick={cyclePlaybackRate}
            aria-label={`سرعة التشغيل ${playbackRate}x`}
            className={`px-1.5 py-0.5 rounded-md text-[10px] font-bold transition-colors cursor-pointer ${
              isMine
                ? "bg-white/15 hover:bg-white/25 text-white"
                : "bg-slate-100 hover:bg-slate-200 dark:bg-slate-700/70 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200"
            }`}
          >
            {playbackRate}x
          </button>
        </div>
      </div>
    </div>
  );
}
