import { useEffect, useState } from "react";
import { ExternalLink, Play, Timer } from "lucide-react";
import type { WatchSessionData } from "../types/chat";

interface FacebookWatchPlayerProps {
  session: WatchSessionData;
  isHost: boolean;
  hostName: string;
  onStartCountdown: () => Promise<void>;
  onMarkStarted: () => Promise<void>;
}

export function FacebookWatchPlayer({
  session,
  isHost,
  hostName,
  onStartCountdown,
  onMarkStarted,
}: FacebookWatchPlayerProps) {
  const [countdownLeft, setCountdownLeft] = useState<number | null>(null);
  const targetUrl = session.mediaUrl || session.videoUrl || session.youtubeUrl;

  useEffect(() => {
    if (session.isStarted) {
      setCountdownLeft(null);
      return;
    }
    const startMs = session.countdownStartAtMs || 0;
    if (!startMs) {
      setCountdownLeft(null);
      return;
    }

    const endMs = startMs + 3000;
    const update = () => {
      const remaining = Math.ceil((endMs - Date.now()) / 1000);
      if (remaining <= 0) {
        setCountdownLeft(null);
        if (isHost && !session.isStarted) {
          void onMarkStarted();
        }
        return false;
      }
      setCountdownLeft(remaining);
      return true;
    };

    if (!update()) return;

    // Local 1-second UI countdown only; triggers a single Firestore update once at 0
    const timer = setInterval(() => {
      if (!update()) {
        clearInterval(timer);
      }
    }, 250);
    return () => clearInterval(timer);
  }, [session.isStarted, session.countdownStartAtMs, isHost, onMarkStarted]);

  const embedUrl = `https://www.facebook.com/plugins/video.php?href=${encodeURIComponent(
    targetUrl
  )}&show_text=false&autoplay=${session.isStarted ? 1 : 0}`;

  return (
    <div className="w-full h-full relative bg-black flex flex-col overflow-hidden">
      <div className="flex-1 min-h-0 relative flex items-center justify-center bg-black">
        {session.isStarted ? (
          <iframe
            src={embedUrl}
            title="مشاهدة فيديو فيسبوك معاً"
            allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share"
            allowFullScreen
            className="w-full h-full border-0 bg-black"
          />
        ) : (
          <div className="p-6 text-center space-y-4 max-w-sm">
            {countdownLeft !== null ? (
              <div className="space-y-2">
                <div className="w-16 h-16 mx-auto rounded-full bg-[#00a884]/20 border-2 border-[#00a884] text-[#00a884] font-display text-3xl font-extrabold flex items-center justify-center">
                  {countdownLeft}
                </div>
                <p className="text-sm font-bold text-white">
                  يبدأ التشغيل المتزامن خلال لحظات...
                </p>
              </div>
            ) : (
              <>
                <div className="w-12 h-12 mx-auto rounded-2xl bg-sky-500/20 text-sky-400 flex items-center justify-center">
                  <Timer className="w-6 h-6" />
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-bold text-white">
                    مقطع فيسبوك جاهز للمشاهدة المتزامنة
                  </p>
                  <p className="text-xs text-slate-400">
                    {isHost
                      ? "اضغط «بدء متزامن» لبدء عد تنازلي قصير وتشغيل الفيديو لكما معاً."
                      : `بانتظار ${hostName} لبدء التشغيل المتزامن.`}
                  </p>
                </div>

                {isHost && (
                  <button
                    type="button"
                    onClick={() => void onStartCountdown()}
                    className="min-h-[42px] px-5 py-2 rounded-xl bg-[#00a884] hover:bg-[#069475] text-white text-xs font-bold inline-flex items-center gap-2 cursor-pointer"
                  >
                    <Play className="w-4 h-4 fill-current" />
                    <span>بدء متزامن (3 ثوانٍ)</span>
                  </button>
                )}
              </>
            )}
          </div>
        )}

        <a
          href={targetUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="absolute bottom-2.5 left-2.5 z-20 px-2.5 py-1.5 rounded-lg bg-black/75 hover:bg-black/90 border border-white/15 text-white text-[11px] font-semibold flex items-center gap-1.5"
        >
          <ExternalLink className="w-3.5 h-3.5" />
          <span>فتح في فيسبوك</span>
        </a>
      </div>
    </div>
  );
}
