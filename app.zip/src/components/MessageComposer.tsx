import {
  memo,
  useCallback,
  useEffect,
  useRef,
  useState,
  type ChangeEvent,
  type KeyboardEvent,
} from "react";
import {
  Ban,
  Eye,
  Loader2,
  Mic,
  Paperclip,
  SendHorizontal,
  ShieldCheck,
  Smile,
  Trash2,
  X,
  Youtube,
} from "lucide-react";
import type { ConversationType, MessageReplyRef } from "../types/chat";
import { EMOJI_CATEGORIES } from "../data/defaults";
import { compressImageToDataUrl, prepareVideoDataUrl } from "../utils/storage";

interface MessageComposerProps {
  conversationId: string;
  conversationType: ConversationType;
  peerUid?: string;
  isBlockedByMe: boolean;
  isBlockedByPeer: boolean;
  blockBusy: boolean;
  replyingTo: MessageReplyRef | null;
  editingMsg: { id: string; originalText: string } | null;
  onCancelReply: () => void;
  onCancelEdit: () => void;
  onToggleBlock: () => void;
  onTypingChange?: (chatId: string, isTyping: boolean) => void;
  onSendMessage: (payload: {
    text: string;
    imageDataUrl?: string;
    videoDataUrl?: string;
    audioDataUrl?: string;
    audioDuration?: number;
    replyTo?: MessageReplyRef;
    viewOnce?: boolean;
  }) => Promise<void> | void;
  onEditMessage: (chatId: string, messageId: string, nextText: string) => Promise<void>;
  onOpenVideoSearch: () => void;
}

const TYPING_THROTTLE_MS = 2500;

function formatTimer(seconds: number): string {
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return `${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
}

export const MessageComposer = memo(function MessageComposer({
  conversationId,
  conversationType,
  peerUid,
  isBlockedByMe,
  isBlockedByPeer,
  blockBusy,
  replyingTo,
  editingMsg,
  onCancelReply,
  onCancelEdit,
  onToggleBlock,
  onTypingChange,
  onSendMessage,
  onEditMessage,
  onOpenVideoSearch,
}: MessageComposerProps) {
  const [draft, setDraft] = useState("");
  const [pendingImage, setPendingImage] = useState<string | null>(null);
  const [pendingImageViewOnce, setPendingImageViewOnce] = useState(false);
  const [pendingVideo, setPendingVideo] = useState<string | null>(null);
  const [isProcessingMedia, setIsProcessingMedia] = useState(false);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [activeEmojiCat, setActiveEmojiCat] = useState(EMOJI_CATEGORIES[0].id);
  const [mediaError, setMediaError] = useState<string | null>(null);

  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const [recordingLevels, setRecordingLevels] = useState<number[]>(() =>
    Array.from({ length: 20 }, () => 22)
  );
  const [swipeCancelOffset, setSwipeCancelOffset] = useState(0);

  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const mediaInputRef = useRef<HTMLInputElement>(null);
  const emojiWrapperRef = useRef<HTMLDivElement>(null);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordingStreamRef = useRef<MediaStream | null>(null);
  const recordingChunksRef = useRef<Blob[]>([]);
  const recordingIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const recordingStartRef = useRef<number>(0);
  const cancelRecordingFlagRef = useRef<boolean>(false);
  const recorderAudioCtxRef = useRef<AudioContext | null>(null);
  const recorderRafRef = useRef<number | null>(null);
  const swipeStartXRef = useRef<number | null>(null);

  const lastTypingWriteAtRef = useRef<number>(0);
  const typingStopTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const isCurrentlyTypingRef = useRef<boolean>(false);
  const onTypingChangeRef = useRef(onTypingChange);
  onTypingChangeRef.current = onTypingChange;

  const isChatBlocked = isBlockedByMe || isBlockedByPeer;

  const clearTypingNow = useCallback((chatId?: string | null) => {
    if (typingStopTimerRef.current) {
      clearTimeout(typingStopTimerRef.current);
      typingStopTimerRef.current = null;
    }
    if (isCurrentlyTypingRef.current && chatId) {
      isCurrentlyTypingRef.current = false;
      lastTypingWriteAtRef.current = 0;
      onTypingChangeRef.current?.(chatId, false);
    } else {
      isCurrentlyTypingRef.current = false;
      lastTypingWriteAtRef.current = 0;
    }
  }, []);

  // Reset composer local attachments on chat switch
  useEffect(() => {
    const activeId = conversationId;
    const isRealChat = conversationType !== "ai";
    setShowEmojiPicker(false);
    setMediaError(null);
    setPendingImage(null);
    setPendingImageViewOnce(false);
    setPendingVideo(null);
    setDraft("");
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
    }

    return () => {
      if (isRealChat && activeId) {
        clearTypingNow(activeId);
      }
    };
  }, [conversationId, conversationType, clearTypingNow]);

  // Populate draft when editing a message
  useEffect(() => {
    if (editingMsg) {
      setDraft(editingMsg.originalText);
      requestAnimationFrame(() => {
        textareaRef.current?.focus();
      });
    }
  }, [editingMsg?.id, editingMsg?.originalText]);

  // Focus textarea when replying
  useEffect(() => {
    if (replyingTo) {
      requestAnimationFrame(() => {
        textareaRef.current?.focus();
      });
    }
  }, [replyingTo?.id]);

  // Stop voice recording if chat gets blocked
  useEffect(() => {
    if (isChatBlocked && isRecording) {
      cancelRecordingFlagRef.current = true;
      if (
        mediaRecorderRef.current &&
        mediaRecorderRef.current.state !== "inactive"
      ) {
        mediaRecorderRef.current.stop();
      }
    }
  }, [isChatBlocked, isRecording]);

  // Cleanup recording resources on unmount
  useEffect(() => {
    return () => {
      if (recordingIntervalRef.current) {
        clearInterval(recordingIntervalRef.current);
      }
      if (recorderRafRef.current !== null) {
        cancelAnimationFrame(recorderRafRef.current);
      }
      if (recorderAudioCtxRef.current) {
        void recorderAudioCtxRef.current.close().catch(() => {});
      }
      if (
        mediaRecorderRef.current &&
        mediaRecorderRef.current.state !== "inactive"
      ) {
        cancelRecordingFlagRef.current = true;
        mediaRecorderRef.current.stop();
      }
      recordingStreamRef.current?.getTracks().forEach((t) => t.stop());
    };
  }, []);

  // Dismiss emoji picker on outside click
  useEffect(() => {
    if (!showEmojiPicker) return;
    const handleClickOutside = (e: MouseEvent) => {
      if (
        emojiWrapperRef.current &&
        !emojiWrapperRef.current.contains(e.target as Node)
      ) {
        setShowEmojiPicker(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [showEmojiPicker]);

  const handleSend = async () => {
    if (isChatBlocked) return;
    const trimmed = draft.trim();
    if (isProcessingMedia) return;

    if (conversationType !== "ai") {
      clearTypingNow(conversationId);
    }

    if (editingMsg) {
      if (!trimmed) return;
      const targetId = editingMsg.id;
      onCancelEdit();
      setDraft("");
      if (textareaRef.current) textareaRef.current.style.height = "auto";
      try {
        await onEditMessage(conversationId, targetId, trimmed);
      } catch (err) {
        setMediaError(
          err instanceof Error ? err.message : "تعذر تعديل الرسالة."
        );
      }
      return;
    }

    if (!trimmed && !pendingImage && !pendingVideo) return;

    const payload = {
      text: trimmed,
      imageDataUrl: pendingImage || undefined,
      videoDataUrl: pendingVideo || undefined,
      replyTo: replyingTo || undefined,
      viewOnce: Boolean(pendingImage && pendingImageViewOnce),
    };

    setDraft("");
    setPendingImage(null);
    setPendingImageViewOnce(false);
    setPendingVideo(null);
    onCancelReply();
    setShowEmojiPicker(false);
    setMediaError(null);
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
    }

    try {
      await onSendMessage(payload);
    } catch (err) {
      setMediaError(
        err instanceof Error && !err.message.startsWith("{")
          ? err.message
          : "تعذر إرسال الرسالة. تحقق من اتصالك وحاول مجدداً."
      );
    }
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      void handleSend();
    }
  };

  const handleTextareaChange = (e: ChangeEvent<HTMLTextAreaElement>) => {
    const nextValue = e.target.value;
    setDraft(nextValue);
    const el = e.target;
    el.style.height = "auto";
    el.style.height = `${Math.min(el.scrollHeight, 128)}px`;

    if (conversationType !== "ai" && !isChatBlocked) {
      if (!nextValue.trim()) {
        clearTypingNow(conversationId);
        return;
      }

      const now = Date.now();
      if (
        !isCurrentlyTypingRef.current ||
        now - lastTypingWriteAtRef.current >= TYPING_THROTTLE_MS
      ) {
        lastTypingWriteAtRef.current = now;
        isCurrentlyTypingRef.current = true;
        onTypingChangeRef.current?.(conversationId, true);
      }

      if (typingStopTimerRef.current) {
        clearTimeout(typingStopTimerRef.current);
      }
      typingStopTimerRef.current = setTimeout(() => {
        clearTypingNow(conversationId);
      }, TYPING_THROTTLE_MS);
    }
  };

  const handleInsertEmoji = (emoji: string) => {
    const textarea = textareaRef.current;
    if (!textarea) {
      setDraft((prev) => prev + emoji);
      return;
    }
    const start = textarea.selectionStart ?? draft.length;
    const end = textarea.selectionEnd ?? draft.length;
    const next = draft.slice(0, start) + emoji + draft.slice(end);
    setDraft(next);
    requestAnimationFrame(() => {
      textarea.focus();
      const pos = start + emoji.length;
      textarea.setSelectionRange(pos, pos);
    });
  };

  const handleMediaSelect = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setMediaError(null);
    if (file.type.startsWith("image/")) {
      setIsProcessingMedia(true);
      try {
        const dataUrl = await compressImageToDataUrl(file, 760, 0.76, 250000);
        setPendingVideo(null);
        setPendingImage(dataUrl);
        setPendingImageViewOnce(false);
      } catch (err) {
        setMediaError(
          err instanceof Error ? err.message : "تعذر تجهيز الصورة للإرسال."
        );
      } finally {
        setIsProcessingMedia(false);
        e.target.value = "";
      }
      return;
    }

    if (file.type.startsWith("video/")) {
      setIsProcessingMedia(true);
      try {
        const dataUrl = await prepareVideoDataUrl(file);
        setPendingImage(null);
        setPendingImageViewOnce(false);
        setPendingVideo(dataUrl);
      } catch (err) {
        setMediaError(
          err instanceof Error ? err.message : "تعذر تجهيز الفيديو للإرسال."
        );
      } finally {
        setIsProcessingMedia(false);
        e.target.value = "";
      }
      return;
    }

    setMediaError("يرجى اختيار ملف صورة أو فيديو صالح.");
    e.target.value = "";
  };

  const stopRecordingTimer = () => {
    if (recordingIntervalRef.current) {
      clearInterval(recordingIntervalRef.current);
      recordingIntervalRef.current = null;
    }
    if (recorderRafRef.current !== null) {
      cancelAnimationFrame(recorderRafRef.current);
      recorderRafRef.current = null;
    }
    if (recorderAudioCtxRef.current) {
      void recorderAudioCtxRef.current.close().catch(() => {});
      recorderAudioCtxRef.current = null;
    }
  };

  const startWaveformMeter = (stream: MediaStream) => {
    try {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext?: typeof AudioContext })
          .webkitAudioContext;
      if (!AudioCtx) return;

      const audioCtx = new AudioCtx();
      recorderAudioCtxRef.current = audioCtx;
      const source = audioCtx.createMediaStreamSource(stream);
      const analyser = audioCtx.createAnalyser();
      analyser.fftSize = 64;
      analyser.smoothingTimeConstant = 0.72;
      source.connect(analyser);

      const dataArray = new Uint8Array(analyser.frequencyBinCount);
      let lastTick = 0;

      const updateLevels = (timestamp: number) => {
        if (!recorderAudioCtxRef.current) return;
        if (timestamp - lastTick >= 65) {
          lastTick = timestamp;
          analyser.getByteFrequencyData(dataArray);
          const nextBars: number[] = [];
          const binSpan = Math.max(1, Math.floor(dataArray.length / 20));
          for (let i = 0; i < 20; i++) {
            const raw =
              dataArray[Math.min(dataArray.length - 1, i * binSpan)] || 0;
            const pct = Math.min(100, Math.max(18, Math.round((raw / 220) * 100)));
            nextBars.push(pct);
          }
          setRecordingLevels(nextBars);
        }
        recorderRafRef.current = requestAnimationFrame(updateLevels);
      };

      recorderRafRef.current = requestAnimationFrame(updateLevels);
    } catch {
      // ignore fallback
    }
  };

  const startVoiceRecording = async () => {
    if (isRecording || isChatBlocked) return;
    setMediaError(null);
    setShowEmojiPicker(false);
    setSwipeCancelOffset(0);
    swipeStartXRef.current = null;

    if (
      !navigator.mediaDevices?.getUserMedia ||
      typeof MediaRecorder === "undefined"
    ) {
      setMediaError("متصفحك لا يدعم تسجيل الرسائل الصوتية.");
      return;
    }

    let stream: MediaStream;
    try {
      stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });
    } catch {
      setMediaError("تعذر الوصول إلى الميكروفون. تأكد من منح الإذن.");
      return;
    }

    recordingStreamRef.current = stream;
    recordingChunksRef.current = [];
    cancelRecordingFlagRef.current = false;

    const preferredTypes = [
      "audio/webm;codecs=opus",
      "audio/webm",
      "audio/mp4",
      "audio/ogg;codecs=opus",
    ];
    const mimeType = preferredTypes.find((t) =>
      MediaRecorder.isTypeSupported(t)
    );

    let recorder: MediaRecorder;
    try {
      recorder = mimeType
        ? new MediaRecorder(stream, { mimeType, audioBitsPerSecond: 24000 })
        : new MediaRecorder(stream);
    } catch {
      recorder = new MediaRecorder(stream);
    }

    mediaRecorderRef.current = recorder;
    recordingStartRef.current = Date.now();
    setRecordingSeconds(0);
    setRecordingLevels(Array.from({ length: 20 }, () => 22));
    setIsRecording(true);
    startWaveformMeter(stream);

    recorder.ondataavailable = (ev) => {
      if (ev.data && ev.data.size > 0) {
        recordingChunksRef.current.push(ev.data);
      }
    };

    recorder.onstop = () => {
      stopRecordingTimer();
      stream.getTracks().forEach((t) => t.stop());
      recordingStreamRef.current = null;
      setIsRecording(false);
      setSwipeCancelOffset(0);
      swipeStartXRef.current = null;

      if (cancelRecordingFlagRef.current) {
        recordingChunksRef.current = [];
        return;
      }

      const durationSec = Math.max(
        1,
        Math.round((Date.now() - recordingStartRef.current) / 1000)
      );
      const blob = new Blob(recordingChunksRef.current, {
        type: recorder.mimeType || "audio/webm",
      });
      recordingChunksRef.current = [];

      if (blob.size < 400) {
        setMediaError("التسجيل الصوتي قصير جداً.");
        return;
      }

      const reader = new FileReader();
      reader.onloadend = async () => {
        const dataUrl = reader.result as string;
        if (!dataUrl || dataUrl.length > 290000) {
          setMediaError("الرسالة الصوتية طويلة جداً. حاول تسجيل مقطع أقصر.");
          return;
        }
        try {
          await onSendMessage({
            text: "",
            audioDataUrl: dataUrl,
            audioDuration: durationSec,
            replyTo: replyingTo || undefined,
          });
          onCancelReply();
        } catch (err) {
          setMediaError(
            err instanceof Error && !err.message.startsWith("{")
              ? err.message
              : "تعذر إرسال الرسالة الصوتية. حاول مجدداً."
          );
        }
      };
      reader.readAsDataURL(blob);
    };

    recorder.start(250);

    recordingIntervalRef.current = setInterval(() => {
      const elapsed = Math.floor(
        (Date.now() - recordingStartRef.current) / 1000
      );
      setRecordingSeconds(elapsed);
      if (elapsed >= 75) {
        if (
          mediaRecorderRef.current &&
          mediaRecorderRef.current.state !== "inactive"
        ) {
          mediaRecorderRef.current.stop();
        }
      }
    }, 300);
  };

  const finishAndSendRecording = () => {
    cancelRecordingFlagRef.current = false;
    if (
      mediaRecorderRef.current &&
      mediaRecorderRef.current.state !== "inactive"
    ) {
      mediaRecorderRef.current.stop();
    }
  };

  const cancelVoiceRecording = () => {
    cancelRecordingFlagRef.current = true;
    setSwipeCancelOffset(0);
    swipeStartXRef.current = null;
    if (
      mediaRecorderRef.current &&
      mediaRecorderRef.current.state !== "inactive"
    ) {
      mediaRecorderRef.current.stop();
    } else {
      stopRecordingTimer();
      recordingStreamRef.current?.getTracks().forEach((t) => t.stop());
      setIsRecording(false);
    }
  };

  const currentEmojiCategory =
    EMOJI_CATEGORIES.find((c) => c.id === activeEmojiCat) || EMOJI_CATEGORIES[0];

  if (isBlockedByMe) {
    return (
      <div className="bg-white dark:bg-[#202c33] border-t border-slate-200 dark:border-slate-800 px-4 py-3.5 shrink-0">
        <div className="max-w-2xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3 bg-rose-50/90 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-800/60 rounded-2xl px-4 py-3">
          <div className="flex items-center gap-2.5 text-rose-800 dark:text-rose-200 text-xs sm:text-sm font-medium text-center sm:text-start">
            <Ban className="w-4 h-4 text-rose-600 dark:text-rose-400 shrink-0" />
            <span>
              لقد قمت بحظر هذا المستخدم. لا يمكن إرسال الرسائل أو إجراء المكالمات في هذه المحادثة.
            </span>
          </div>
          {peerUid && (
            <button
              type="button"
              onClick={onToggleBlock}
              disabled={blockBusy}
              className="min-h-[40px] px-4 py-2 rounded-xl bg-[#0d7a5f] hover:bg-[#0a634d] dark:bg-[#00a884] dark:hover:bg-[#069475] text-white text-xs sm:text-sm font-bold flex items-center gap-1.5 shrink-0 transition-colors cursor-pointer disabled:opacity-60"
            >
              {blockBusy ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <ShieldCheck className="w-4 h-4" />
              )}
              <span>رفع الحظر</span>
            </button>
          )}
        </div>
      </div>
    );
  }

  if (isBlockedByPeer) {
    return (
      <div className="bg-white dark:bg-[#202c33] border-t border-slate-200 dark:border-slate-800 px-4 py-3.5 shrink-0">
        <div className="max-w-2xl mx-auto flex items-center justify-center gap-2 bg-slate-100 dark:bg-[#111b21] border border-slate-200 dark:border-slate-700 rounded-2xl px-4 py-3 text-slate-600 dark:text-slate-300 text-xs sm:text-sm font-medium">
          <Ban className="w-4 h-4 text-slate-500 shrink-0" />
          <span>
            لا يمكنك إرسال رسائل أو إجراء مكالمات في هذه المحادثة حالياً.
          </span>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white dark:bg-[#202c33] border-t border-slate-200 dark:border-slate-800 px-3 sm:px-4 py-2.5 shrink-0 relative">
      {mediaError && (
        <div className="mb-2 px-3 py-2 rounded-xl bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-200 text-xs flex items-center justify-between">
          <span>{mediaError}</span>
          <button
            type="button"
            onClick={() => setMediaError(null)}
            className="p-1 cursor-pointer"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {replyingTo && !isRecording && (
        <div className="mb-2 px-3 py-2 rounded-xl bg-slate-50 dark:bg-[#111b21] border-r-4 border-[#0d7a5f] dark:border-[#00a884] flex items-center justify-between gap-2 text-xs">
          <div className="min-w-0">
            <p className="font-bold text-[#0d7a5f] dark:text-[#00a884]">
              الرد على {replyingTo.senderName}
            </p>
            <p className="text-slate-600 dark:text-slate-300 truncate">
              {replyingTo.text || "وسائط"}
            </p>
          </div>
          <button
            type="button"
            onClick={onCancelReply}
            className="p-1 text-slate-400 hover:text-slate-700 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {editingMsg && !isRecording && (
        <div className="mb-2 px-3 py-2 rounded-xl bg-amber-50 dark:bg-amber-950/30 border-r-4 border-amber-500 flex items-center justify-between gap-2 text-xs">
          <div className="min-w-0">
            <p className="font-bold text-amber-700 dark:text-amber-300">
              تعديل الرسالة
            </p>
            <p className="text-slate-600 dark:text-slate-300 truncate">
              {editingMsg.originalText}
            </p>
          </div>
          <button
            type="button"
            onClick={() => {
              onCancelEdit();
              setDraft("");
            }}
            className="p-1 text-slate-400 hover:text-slate-700 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {isProcessingMedia && !isRecording && (
        <div className="mb-2.5 p-2.5 rounded-xl bg-slate-50 dark:bg-[#111b21] border border-slate-200 dark:border-slate-700 flex items-center gap-2.5 text-xs font-medium text-slate-600 dark:text-slate-300">
          <Loader2 className="w-4 h-4 animate-spin text-[#0d7a5f] dark:text-[#00a884]" />
          <span>جاري ضغط وتجهيز الملف للإرسال...</span>
        </div>
      )}

      {pendingImage && !isRecording && (
        <div className="mb-2.5 p-2 rounded-xl bg-slate-50 dark:bg-[#111b21] border border-slate-200 dark:border-slate-700 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <img
              src={pendingImage}
              alt="معاينة الصورة المرفقة"
              referrerPolicy="no-referrer"
              className="w-14 h-14 rounded-lg object-cover"
            />
            <div className="space-y-1">
              <span className="block text-xs font-medium text-slate-600 dark:text-slate-300">
                صورة جاهزة للإرسال
              </span>
              <button
                type="button"
                onClick={() => setPendingImageViewOnce((v) => !v)}
                className={`px-2 py-0.5 rounded-lg text-[11px] font-bold inline-flex items-center gap-1 cursor-pointer ${
                  pendingImageViewOnce
                    ? "bg-[#0d7a5f] text-white"
                    : "bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-300"
                }`}
              >
                <Eye className="w-3 h-3" />
                <span>عرض مرة واحدة</span>
              </button>
            </div>
          </div>
          <button
            type="button"
            onClick={() => {
              setPendingImage(null);
              setPendingImageViewOnce(false);
            }}
            aria-label="إزالة الصورة"
            className="min-h-[36px] min-w-[36px] rounded-lg flex items-center justify-center text-slate-500 hover:text-rose-600 hover:bg-slate-200/60 dark:hover:bg-slate-800 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {pendingVideo && !isRecording && (
        <div className="mb-2.5 p-2 rounded-xl bg-slate-50 dark:bg-[#111b21] border border-slate-200 dark:border-slate-700 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <video
              src={pendingVideo}
              controls
              playsInline
              className="w-24 h-16 rounded-lg object-cover bg-black shrink-0"
            />
            <span className="text-xs font-medium text-slate-600 dark:text-slate-300 truncate">
              فيديو جاهز للإرسال
            </span>
          </div>
          <button
            type="button"
            onClick={() => setPendingVideo(null)}
            aria-label="إزالة الفيديو"
            className="min-h-[36px] min-w-[36px] rounded-lg flex items-center justify-center text-slate-500 hover:text-rose-600 hover:bg-slate-200/60 dark:hover:bg-slate-800 cursor-pointer shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {showEmojiPicker && !isRecording && (
        <div
          ref={emojiWrapperRef}
          className="absolute bottom-full right-3 left-3 sm:left-auto sm:w-80 mb-2 bg-white dark:bg-[#202c33] border border-slate-200 dark:border-slate-700 rounded-2xl shadow-lg overflow-hidden z-20"
        >
          <div className="flex items-center border-b border-slate-100 dark:border-slate-700/80 px-2 pt-2 gap-1">
            {EMOJI_CATEGORIES.map((cat) => {
              const active = cat.id === activeEmojiCat;
              return (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => setActiveEmojiCat(cat.id)}
                  className={`flex-1 py-2 px-1 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap cursor-pointer ${
                    active
                      ? "border-[#0d7a5f] dark:border-[#00a884] text-[#0d7a5f] dark:text-[#00a884]"
                      : "border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200"
                  }`}
                >
                  {cat.label}
                </button>
              );
            })}
          </div>
          <div className="p-2.5 grid grid-cols-8 gap-1 max-h-52 overflow-y-auto custom-scrollbar">
            {currentEmojiCategory.emojis.map((emoji) => (
              <button
                key={emoji}
                type="button"
                onClick={() => handleInsertEmoji(emoji)}
                className="h-9 rounded-lg text-xl flex items-center justify-center hover:bg-slate-100 dark:hover:bg-slate-700/60 transition-colors cursor-pointer"
              >
                {emoji}
              </button>
            ))}
          </div>
        </div>
      )}

      {isRecording ? (
        <div
          onPointerDown={(e) => {
            if ((e.target as HTMLElement).closest("button")) return;
            swipeStartXRef.current = e.clientX;
            e.currentTarget.setPointerCapture(e.pointerId);
          }}
          onPointerMove={(e) => {
            if (swipeStartXRef.current === null) return;
            const deltaX = e.clientX - swipeStartXRef.current;
            setSwipeCancelOffset(Math.max(-140, Math.min(140, deltaX)));
          }}
          onPointerUp={() => {
            if (swipeStartXRef.current === null) return;
            const cancelledBySwipe = Math.abs(swipeCancelOffset) >= 85;
            swipeStartXRef.current = null;
            if (cancelledBySwipe) {
              if (
                typeof navigator !== "undefined" &&
                typeof navigator.vibrate === "function"
              ) {
                try {
                  navigator.vibrate(30);
                } catch {
                  // ignore
                }
              }
              cancelVoiceRecording();
            } else {
              setSwipeCancelOffset(0);
            }
          }}
          onPointerCancel={() => {
            swipeStartXRef.current = null;
            setSwipeCancelOffset(0);
          }}
          style={{
            transform: swipeCancelOffset
              ? `translateX(${swipeCancelOffset}px)`
              : undefined,
            opacity:
              swipeCancelOffset !== 0
                ? Math.max(0.45, 1 - Math.abs(swipeCancelOffset) / 170)
                : 1,
          }}
          className={`flex items-center justify-between gap-2 sm:gap-3 rounded-2xl px-2.5 sm:px-3 py-1.5 border touch-none select-none transition-colors ${
            Math.abs(swipeCancelOffset) >= 85
              ? "bg-rose-100 dark:bg-rose-950/60 border-rose-400 dark:border-rose-700"
              : "bg-rose-50/90 dark:bg-rose-950/35 border-rose-200 dark:border-rose-800/50"
          }`}
        >
          <button
            type="button"
            onClick={cancelVoiceRecording}
            aria-label="إلغاء التسجيل"
            title="إلغاء التسجيل"
            className="min-h-[44px] min-w-[44px] rounded-xl flex items-center justify-center text-rose-600 dark:text-rose-400 hover:bg-rose-100 dark:hover:bg-rose-900/40 transition-colors cursor-pointer shrink-0"
          >
            <Trash2 className="w-5 h-5" />
          </button>

          <div className="flex-1 flex items-center justify-between gap-2.5 min-w-0 cursor-grab active:cursor-grabbing">
            <div className="flex items-center gap-2 shrink-0">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-600 animate-pulse shrink-0" />
              <span
                dir="ltr"
                className="font-mono text-sm font-bold text-rose-600 dark:text-rose-400 tabular-nums shrink-0"
              >
                {formatTimer(recordingSeconds)}
              </span>
            </div>

            <div
              aria-hidden="true"
              className="flex-1 h-7 flex items-center justify-center gap-[2.5px] max-w-[200px] overflow-hidden"
            >
              {recordingLevels.map((level, idx) => (
                <span
                  key={idx}
                  style={{ height: `${level}%` }}
                  className="w-[3px] rounded-full bg-rose-500/85 dark:bg-rose-400/90 transition-[height] duration-75"
                />
              ))}
            </div>

            <span className="text-[10px] sm:text-[11px] font-semibold text-rose-600/85 dark:text-rose-300/85 whitespace-nowrap shrink-0">
              {Math.abs(swipeCancelOffset) >= 85
                ? "أفلت للإلغاء"
                : "اسحب للإلغاء"}
            </span>
          </div>

          <button
            type="button"
            onClick={finishAndSendRecording}
            aria-label="إرسال الرسالة الصوتية"
            title="إرسال الرسالة الصوتية"
            className="min-h-[44px] min-w-[44px] rounded-xl bg-[#0d7a5f] hover:bg-[#0a634d] dark:bg-[#00a884] dark:hover:bg-[#069475] text-white flex items-center justify-center transition-colors shrink-0 cursor-pointer shadow-xs"
          >
            <SendHorizontal className="w-5 h-5 rotate-180" />
          </button>
        </div>
      ) : (
        <div className="flex items-end gap-1 sm:gap-2">
          <button
            type="button"
            onClick={() => setShowEmojiPicker((v) => !v)}
            aria-label="إدراج رمز تعبيري"
            title="الرموز التعبيرية"
            className={`min-h-[44px] min-w-[44px] rounded-xl flex items-center justify-center transition-colors shrink-0 cursor-pointer ${
              showEmojiPicker
                ? "bg-emerald-50 dark:bg-emerald-950/60 text-[#0d7a5f] dark:text-[#00a884]"
                : "text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700/50"
            }`}
          >
            <Smile className="w-5 h-5" />
          </button>

          <button
            type="button"
            onClick={() => mediaInputRef.current?.click()}
            disabled={isProcessingMedia}
            aria-label="إرفاق صورة أو فيديو"
            title="إرفاق صورة أو فيديو"
            className="min-h-[44px] min-w-[44px] rounded-xl flex items-center justify-center text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700/50 disabled:opacity-50 transition-colors shrink-0 cursor-pointer"
          >
            {isProcessingMedia ? (
              <Loader2 className="w-5 h-5 animate-spin text-[#0d7a5f] dark:text-[#00a884]" />
            ) : (
              <Paperclip className="w-5 h-5" />
            )}
          </button>
          <input
            ref={mediaInputRef}
            type="file"
            accept="image/*,video/*"
            onChange={(e) => void handleMediaSelect(e)}
            className="hidden"
          />

          {conversationType !== "ai" && (
            <button
              type="button"
              onClick={onOpenVideoSearch}
              aria-label="بحث عن فيديو يوتيوب ومشاهدته معاً"
              title="بحث ومشاهدة فيديو يوتيوب معاً"
              className="min-h-[40px] min-w-[40px] rounded-full bg-red-50 hover:bg-red-100 dark:bg-red-950/50 dark:hover:bg-red-950/80 border border-red-200/80 dark:border-red-800/60 shadow-xs flex items-center justify-center transition-colors shrink-0 cursor-pointer"
            >
              <Youtube className="w-5 h-5 text-red-600 dark:text-red-500" />
            </button>
          )}

          <textarea
            ref={textareaRef}
            rows={1}
            value={draft}
            onChange={handleTextareaChange}
            onKeyDown={handleKeyDown}
            placeholder="اكتب رسالتك هنا..."
            aria-label="اكتب رسالتك"
            className="flex-1 min-h-[44px] max-h-32 px-4 py-2.5 rounded-2xl bg-slate-100 dark:bg-[#2a3942] text-sm sm:text-[15px] text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-400 resize-none focus:outline-none focus:ring-2 focus:ring-[#0d7a5f]/50 dark:focus:ring-[#00a884]/50 leading-relaxed"
          />

          <button
            type="button"
            onClick={() => void startVoiceRecording()}
            aria-label="تسجيل رسالة صوتية"
            title="تسجيل رسالة صوتية"
            className="min-h-[44px] min-w-[44px] rounded-xl flex items-center justify-center bg-slate-100 hover:bg-emerald-50 hover:text-[#0d7a5f] dark:bg-[#2a3942] dark:hover:bg-emerald-950/60 dark:hover:text-[#00a884] text-slate-600 dark:text-slate-300 transition-colors shrink-0 cursor-pointer"
          >
            <Mic className="w-5 h-5" />
          </button>

          <button
            type="button"
            onClick={() => void handleSend()}
            disabled={
              isProcessingMedia ||
              (!draft.trim() && !pendingImage && !pendingVideo)
            }
            aria-label="إرسال الرسالة"
            className="min-h-[44px] min-w-[44px] rounded-xl bg-[#0d7a5f] hover:bg-[#0a634d] dark:bg-[#00a884] dark:hover:bg-[#069475] disabled:opacity-40 disabled:pointer-events-none text-white flex items-center justify-center transition-colors shrink-0 cursor-pointer"
          >
            <SendHorizontal className="w-5 h-5 rotate-180" />
          </button>
        </div>
      )}
    </div>
  );
});
