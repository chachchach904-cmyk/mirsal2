import { useCallback, useEffect, useRef, useState } from "react";
import {
  ArrowRight,
  Download,
  EyeOff,
  Loader2,
  RotateCcw,
  ShieldAlert,
  ZoomIn,
  ZoomOut,
} from "lucide-react";

interface ImageLightboxProps {
  src: string | null;
  viewOnceMode?: boolean;
  onClose: () => void;
}

interface ZoomStep {
  scale: number;
  label: string;
  imageClass: string;
}

const ZOOM_STEPS: ZoomStep[] = [
  {
    scale: 1,
    label: "100%",
    imageClass:
      "max-w-full max-h-[82vh] w-auto h-auto object-contain rounded-xl cursor-zoom-in",
  },
  {
    scale: 1.5,
    label: "150%",
    imageClass:
      "w-[140vw] sm:w-[110vw] md:w-[85vw] max-w-none h-auto object-contain rounded-lg cursor-zoom-in",
  },
  {
    scale: 2,
    label: "200%",
    imageClass:
      "w-[190vw] sm:w-[150vw] md:w-[115vw] max-w-none h-auto object-contain rounded-lg cursor-zoom-in",
  },
  {
    scale: 2.5,
    label: "250%",
    imageClass:
      "w-[240vw] sm:w-[190vw] md:w-[145vw] max-w-none h-auto object-contain rounded-lg cursor-zoom-in",
  },
  {
    scale: 3,
    label: "300%",
    imageClass:
      "w-[290vw] sm:w-[230vw] md:w-[175vw] max-w-none h-auto object-contain rounded-lg cursor-zoom-out",
  },
];

export function ImageLightbox({
  src,
  viewOnceMode = false,
  onClose,
}: ImageLightboxProps) {
  const [zoomIndex, setZoomIndex] = useState(0);
  const [isDownloading, setIsDownloading] = useState(false);
  const [privacyShield, setPrivacyShield] = useState(false);
  const viewportRef = useRef<HTMLDivElement>(null);

  const currentZoom = ZOOM_STEPS[zoomIndex] || ZOOM_STEPS[0];

  const handleZoomIn = useCallback(() => {
    setZoomIndex((prev) => Math.min(ZOOM_STEPS.length - 1, prev + 1));
  }, []);

  const handleZoomOut = useCallback(() => {
    setZoomIndex((prev) => Math.max(0, prev - 1));
  }, []);

  const handleResetZoom = useCallback(() => {
    setZoomIndex(0);
    if (viewportRef.current) {
      viewportRef.current.scrollTo({ top: 0, left: 0, behavior: "smooth" });
    }
  }, []);

  const handleToggleDoubleZoom = useCallback(() => {
    setZoomIndex((prev) => (prev === 0 ? 2 : 0));
  }, []);

  useEffect(() => {
    setZoomIndex(0);
    setIsDownloading(false);
    setPrivacyShield(false);
  }, [src, viewOnceMode]);

  // Keyboard navigation + screenshot / focus loss privacy shield for view-once mode
  useEffect(() => {
    if (!src) return;

    const handleKey = (e: KeyboardEvent) => {
      if (viewOnceMode) {
        const lowerKey = e.key.toLowerCase();
        const isScreenshotCombo =
          e.key === "PrintScreen" ||
          ((e.ctrlKey || e.metaKey) && lowerKey === "p") ||
          (e.metaKey && e.shiftKey && ["3", "4", "5", "s"].includes(lowerKey)) ||
          (e.ctrlKey && e.shiftKey && lowerKey === "s");
        if (isScreenshotCombo) {
          e.preventDefault();
          setPrivacyShield(true);
          return;
        }
      }

      if (e.key === "Escape") {
        onClose();
      } else if (e.key === "+" || e.key === "=") {
        e.preventDefault();
        handleZoomIn();
      } else if (e.key === "-" || e.key === "_") {
        e.preventDefault();
        handleZoomOut();
      } else if (e.key === "0") {
        e.preventDefault();
        handleResetZoom();
      }
    };

    const handleVisibility = () => {
      if (viewOnceMode && document.hidden) {
        setPrivacyShield(true);
      }
    };

    const handleWindowBlur = () => {
      if (viewOnceMode) {
        setPrivacyShield(true);
      }
    };

    window.addEventListener("keydown", handleKey);
    if (viewOnceMode) {
      document.addEventListener("visibilitychange", handleVisibility);
      window.addEventListener("blur", handleWindowBlur);
    }

    return () => {
      window.removeEventListener("keydown", handleKey);
      document.removeEventListener("visibilitychange", handleVisibility);
      window.removeEventListener("blur", handleWindowBlur);
    };
  }, [src, viewOnceMode, onClose, handleZoomIn, handleZoomOut, handleResetZoom]);

  const handleDownload = async () => {
    if (viewOnceMode || !src || isDownloading) return;
    setIsDownloading(true);
    const filename = `mirsal-image-${Date.now()}.jpg`;

    const triggerAnchor = (href: string) => {
      const link = document.createElement("a");
      link.href = href;
      link.download = filename;
      link.rel = "noopener noreferrer";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    };

    try {
      if (src.startsWith("data:")) {
        triggerAnchor(src);
        return;
      }

      const response = await fetch(src);
      if (!response.ok) {
        throw new Error("download failed");
      }
      const blob = await response.blob();
      const objectUrl = URL.createObjectURL(blob);
      try {
        triggerAnchor(objectUrl);
      } finally {
        setTimeout(() => URL.revokeObjectURL(objectUrl), 1500);
      }
    } catch {
      triggerAnchor(src);
    } finally {
      setIsDownloading(false);
    }
  };

  if (!src) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={viewOnceMode ? "صورة للعرض لمرة واحدة" : "عارض الصورة"}
      onContextMenu={(e) => {
        if (viewOnceMode) e.preventDefault();
      }}
      className={`fixed inset-0 z-50 bg-black/95 flex flex-col ${
        viewOnceMode ? "select-none" : ""
      }`}
    >
      {/* Top Floating Action Bar */}
      <div className="px-3 sm:px-5 py-3 bg-black/75 backdrop-blur-md border-b border-white/10 flex items-center justify-between gap-2 shrink-0 z-10">
        {/* RTL Back / Close */}
        <button
          type="button"
          onClick={onClose}
          aria-label="إغلاق المعاينة"
          title="رجوع"
          className="min-h-[44px] min-w-[44px] rounded-full bg-white/15 hover:bg-white/25 text-white flex items-center justify-center transition-colors shrink-0 cursor-pointer"
        >
          <ArrowRight className="w-5 h-5" />
        </button>

        {/* Zoom Controls */}
        <div className="flex items-center gap-1 bg-white/10 border border-white/10 rounded-full px-1.5 py-1">
          <button
            type="button"
            onClick={handleZoomOut}
            disabled={zoomIndex === 0}
            aria-label="تصغير الصورة"
            title="تصغير (-)"
            className="min-h-[38px] min-w-[38px] rounded-full text-white hover:bg-white/15 disabled:opacity-35 disabled:pointer-events-none flex items-center justify-center transition-colors cursor-pointer"
          >
            <ZoomOut className="w-4 h-4" />
          </button>

          <span
            dir="ltr"
            className="min-w-[46px] text-center text-xs font-bold text-white tabular-nums select-none"
          >
            {currentZoom.label}
          </span>

          <button
            type="button"
            onClick={handleZoomIn}
            disabled={zoomIndex === ZOOM_STEPS.length - 1}
            aria-label="تكبير الصورة"
            title="تكبير (+)"
            className="min-h-[38px] min-w-[38px] rounded-full text-white hover:bg-white/15 disabled:opacity-35 disabled:pointer-events-none flex items-center justify-center transition-colors cursor-pointer"
          >
            <ZoomIn className="w-4 h-4" />
          </button>

          {zoomIndex > 0 && (
            <button
              type="button"
              onClick={handleResetZoom}
              aria-label="إعادة ضبط التكبير"
              title="الحجم الأصلي (0)"
              className="min-h-[38px] min-w-[38px] rounded-full text-emerald-300 hover:bg-white/15 flex items-center justify-center transition-colors cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Download Button (hidden completely in View-Once mode) or View-Once Lock Badge */}
        {viewOnceMode ? (
          <div className="min-h-[40px] px-3 rounded-full bg-[#25D366]/15 border border-[#25D366]/40 text-[#25D366] text-xs font-bold flex items-center gap-1.5 shrink-0 select-none">
            <span>①</span>
            <span className="hidden sm:inline">لمرة واحدة</span>
          </div>
        ) : (
          <button
            type="button"
            onClick={() => void handleDownload()}
            disabled={isDownloading}
            aria-label="تنزيل الصورة"
            title="تنزيل الصورة"
            className="min-h-[44px] min-w-[44px] sm:px-4 rounded-full bg-[#00a884] hover:bg-[#069475] disabled:opacity-60 text-white font-semibold text-xs sm:text-sm flex items-center justify-center gap-2 transition-colors shrink-0 cursor-pointer"
          >
            {isDownloading ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Download className="w-4 h-4" />
            )}
            <span className="hidden sm:inline">تنزيل</span>
          </button>
        )}
      </div>

      {/* Scrollable & Touch-Pannable Viewport */}
      <div
        ref={viewportRef}
        onClick={(e) => {
          if (e.target === e.currentTarget) {
            onClose();
          }
        }}
        className="flex-1 min-h-0 overflow-auto touch-pan-x touch-pan-y custom-scrollbar relative"
      >
        <div
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              onClose();
            }
          }}
          className="min-w-full min-h-full flex items-center justify-center p-3 sm:p-6"
        >
          <img
            src={src}
            alt="معاينة كاملة للصورة"
            referrerPolicy="no-referrer"
            draggable={!viewOnceMode}
            onContextMenu={(e) => {
              if (viewOnceMode) e.preventDefault();
            }}
            onDoubleClick={(e) => {
              e.stopPropagation();
              handleToggleDoubleZoom();
            }}
            onClick={(e) => {
              e.stopPropagation();
            }}
            className={`m-auto shrink-0 select-none shadow-2xl transition-all duration-150 ${
              currentZoom.imageClass
            } ${viewOnceMode && privacyShield ? "blur-3xl opacity-0" : ""}`}
          />
        </div>

        {/* Automatic Privacy Curtain for View-Once Screenshot / Focus Loss */}
        {viewOnceMode && privacyShield && (
          <div className="fixed inset-0 z-30 bg-black flex flex-col items-center justify-center p-6 text-center space-y-5">
            <div className="w-16 h-16 rounded-full bg-rose-950/70 border border-rose-700/60 text-rose-400 flex items-center justify-center">
              <ShieldAlert className="w-8 h-8" />
            </div>
            <div className="max-w-sm space-y-2">
              <h3 className="font-display text-lg font-bold text-white flex items-center justify-center gap-2">
                <EyeOff className="w-5 h-5 text-rose-400" />
                <span>تم تفعيل حماية الخصوصية</span>
              </h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                للحفاظ على خصوصية الصور المرسلة للعرض مرة واحدة، تم إخفاء الصورة تلقائياً عند فقدان التركيز أو محاولة التصوير.
              </p>
            </div>
            <div className="flex flex-wrap items-center justify-center gap-2.5">
              <button
                type="button"
                onClick={() => setPrivacyShield(false)}
                className="min-h-[42px] px-4 py-2 rounded-xl bg-white/15 hover:bg-white/25 text-white text-xs font-bold cursor-pointer"
              >
                متابعة المشاهدة
              </button>
              <button
                type="button"
                onClick={onClose}
                className="min-h-[42px] px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold cursor-pointer"
              >
                إغلاق وحذف الصورة
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Subtle Bottom Hint */}
      <div className="py-2 px-4 text-center text-[11px] text-white/60 bg-black/75 border-t border-white/5 shrink-0 select-none">
        {viewOnceMode
          ? "صورة للعرض مرة واحدة ① — محمية من الحفظ وستُحذف نهائياً فور إغلاقها"
          : "اضغط مرتين على الصورة للتكبير أو استخدم أزرار التحكم بالأعلى"}
      </div>
    </div>
  );
}
