import {
  memo,
  useEffect,
  useRef,
  useState,
  type ReactNode,
} from "react";
import {
  Check,
  CheckCheck,
  Clock,
  Copy,
  Eye,
  Languages,
  Loader2,
  Lock,
  Pencil,
  PhoneIncoming,
  PhoneMissed,
  PhoneOutgoing,
  Reply,
  Video,
} from "lucide-react";
import type {
  ChatMessage,
  ConversationType,
  MessageReplyRef,
  TranslationLanguageOption,
} from "../types/chat";
import { AI_QUICK_PROMPTS, GEMINI_AVATAR } from "../data/defaults";
import {
  buildTranslationCacheKey,
  formatCallDurationLabel,
  formatDateSeparator,
  formatMessageTime,
  type TranslationPrefs,
} from "../utils/storage";
import {
  decryptSecretMessage,
  E2EE_FALLBACK_UNDECRYPTABLE,
} from "../services/e2ee";
import { Avatar } from "./Avatar";
import { VoiceNotePlayer } from "./VoiceNotePlayer";

const QUICK_REACTIONS = ["❤️", "👍", "😂", "😮", "😢", "😡"] as const;

interface MessageListProps {
  chatId: string;
  chatType: ConversationType;
  chatTitle: string;
  messages: ChatMessage[];
  currentUid: string;
  peerPublicKey?: string;
  isTyping: boolean;
  wallpaperClass: string;
  customWallpaper?: string | null;
  translationPrefs: TranslationPrefs;
  selectedLangOption: TranslationLanguageOption;
  translations: Record<string, string>;
  translatingKeys: Record<string, boolean>;
  hiddenTranslations: Record<string, boolean>;
  onReactMessage: (chatId: string, messageId: string, emoji: string) => Promise<void>;
  onReplyMessage: (reply: MessageReplyRef) => void;
  onStartEditMessage: (id: string, originalText: string) => void;
  onDeleteMessageForMe: (chatId: string, messageId: string) => Promise<void>;
  onDeleteMessageForEveryone: (chatId: string, messageId: string) => Promise<void>;
  onOpenViewOnceImage: (chatId: string, message: ChatMessage) => void;
  onPreviewImage: (src: string) => void;
  onRequestTranslation: (msgId: string, text: string, targetLanguage: string) => Promise<void>;
  onToggleTranslationVisibility: (visibilityKey: string) => void;
  onSendQuickAiPrompt: (promptText: string) => void;
}

function renderInlineSegments(text: string): ReactNode[] {
  const tokenRegex = /(https?:\/\/[^\s<>"']+|www\.[^\s<>"']+|\*\*[^*]+\*\*)/gi;
  const nodes: ReactNode[] = [];
  let lastIndex = 0;
  let match: RegExpExecArray | null;
  let keyIdx = 0;

  while ((match = tokenRegex.exec(text)) !== null) {
    if (match.index > lastIndex) {
      nodes.push(<span key={`t-${keyIdx++}`}>{text.slice(lastIndex, match.index)}</span>);
    }
    const token = match[0];
    if (token.startsWith("**") && token.endsWith("**") && token.length > 4) {
      nodes.push(
        <strong key={`b-${keyIdx++}`} className="font-bold">
          {token.slice(2, -2)}
        </strong>
      );
    } else {
      const href = /^https?:\/\//i.test(token) ? token : `https://${token}`;
      nodes.push(
        <a
          key={`u-${keyIdx++}`}
          href={href}
          target="_blank"
          rel="noopener noreferrer"
          onClick={(e) => e.stopPropagation()}
          className="underline decoration-current/60 hover:opacity-85 break-all font-medium"
        >
          {token}
        </a>
      );
    }
    lastIndex = tokenRegex.lastIndex;
  }

  if (lastIndex < text.length) {
    nodes.push(<span key={`t-${keyIdx++}`}>{text.slice(lastIndex)}</span>);
  }
  return nodes;
}

function renderFormattedText(text: string) {
  const lines = text.split("\n");
  return lines.map((line, idx) => (
    <span key={idx} className="block min-h-[1.25em]">
      {renderInlineSegments(line)}
    </span>
  ));
}

function isSameCalendarDay(a: number, b: number): boolean {
  const da = new Date(a);
  const db = new Date(b);
  return (
    da.getDate() === db.getDate() &&
    da.getMonth() === db.getMonth() &&
    da.getFullYear() === db.getFullYear()
  );
}

export const MessageList = memo(function MessageList({
  chatId,
  chatType,
  chatTitle,
  messages,
  currentUid,
  peerPublicKey,
  isTyping,
  wallpaperClass,
  customWallpaper,
  translationPrefs,
  selectedLangOption,
  translations,
  translatingKeys,
  hiddenTranslations,
  onReactMessage,
  onReplyMessage,
  onStartEditMessage,
  onDeleteMessageForMe,
  onDeleteMessageForEveryone,
  onOpenViewOnceImage,
  onPreviewImage,
  onRequestTranslation,
  onToggleTranslationVisibility,
  onSendQuickAiPrompt,
}: MessageListProps) {
  const [activeActionMsgId, setActiveActionMsgId] = useState<string | null>(null);
  const [copiedMsgId, setCopiedMsgId] = useState<string | null>(null);
  const [decryptedMap, setDecryptedMap] = useState<Record<string, string>>({});

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const longPressTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const touchStartPosRef = useRef<{ x: number; y: number } | null>(null);
  const suppressNextClickRef = useRef<boolean>(false);

  // Reset floating selection on conversation switch
  useEffect(() => {
    setActiveActionMsgId(null);
    setCopiedMsgId(null);
  }, [chatId]);

  // Smooth scroll to latest message
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chatId, messages.length, isTyping]);

  // Close floating message bar on outside pointer tap or Escape
  useEffect(() => {
    if (!activeActionMsgId) return;
    const handlePointerDown = (e: PointerEvent) => {
      const target = e.target as HTMLElement | null;
      if (target?.closest("[data-floating-msg-actions='true']")) {
        return;
      }
      setActiveActionMsgId(null);
    };
    const handleKeyDown = (e: globalThis.KeyboardEvent) => {
      if (e.key === "Escape") {
        setActiveActionMsgId(null);
      }
    };
    document.addEventListener("pointerdown", handlePointerDown);
    window.addEventListener("keydown", handleKeyDown);
    return () => {
      document.removeEventListener("pointerdown", handlePointerDown);
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [activeActionMsgId]);

  // Decrypt any E2EE messages client-side
  useEffect(() => {
    const encryptedMsgs = messages.filter(
      (m) => m.isEncrypted && m.ciphertext && m.iv
    );
    if (encryptedMsgs.length === 0) return;

    let cancelled = false;
    void Promise.all(
      encryptedMsgs.map(async (m) => {
        const plain = await decryptSecretMessage(
          currentUid,
          peerPublicKey,
          m.ciphertext,
          m.iv
        );
        return [`${m.id}:${m.ciphertext}`, plain] as const;
      })
    ).then((entries) => {
      if (cancelled) return;
      setDecryptedMap((prev) => {
        const next = { ...prev };
        let changed = false;
        entries.forEach(([k, val]) => {
          if (next[k] !== val) {
            next[k] = val;
            changed = true;
          }
        });
        return changed ? next : prev;
      });
    });

    return () => {
      cancelled = true;
    };
  }, [messages, currentUid, peerPublicKey]);

  const cancelLongPress = () => {
    if (longPressTimerRef.current) {
      clearTimeout(longPressTimerRef.current);
      longPressTimerRef.current = null;
    }
    touchStartPosRef.current = null;
  };

  const handleCopyText = async (msgId: string, textToCopy: string) => {
    const clean = textToCopy.trim();
    if (!clean) return;
    try {
      await navigator.clipboard.writeText(clean);
      setCopiedMsgId(msgId);
      setTimeout(() => {
        setCopiedMsgId((prev) => (prev === msgId ? null : prev));
      }, 1600);
    } catch {
      // ignore clipboard permissions error
    }
  };

  return (
    <div
      className={`relative flex-1 min-h-0 flex flex-col overflow-hidden ${
        customWallpaper ? "bg-slate-100 dark:bg-[#0b141a]" : wallpaperClass
      }`}
    >
      {customWallpaper && (
        <img
          src={customWallpaper}
          alt=""
          aria-hidden="true"
          referrerPolicy="no-referrer"
          className="absolute inset-0 w-full h-full object-cover pointer-events-none select-none opacity-85"
        />
      )}
      <div className="relative z-10 flex-1 overflow-y-auto custom-scrollbar px-3 sm:px-6 py-4 space-y-2.5">
      {messages.length === 0 ? (
        <div className="h-full flex flex-col items-center justify-center py-10 text-center">
          <div className="bg-white/95 dark:bg-[#202c33]/95 backdrop-blur-sm border border-slate-200/80 dark:border-slate-700/60 rounded-2xl px-6 py-5 max-w-sm space-y-2 shadow-xs">
            <p className="text-sm font-bold text-slate-800 dark:text-slate-100">
              {chatType === "direct"
                ? `ابدأ محادثتك الخاصة مع ${chatTitle}`
                : "لا توجد رسائل بعد في هذه المحادثة"}
            </p>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              {chatType === "direct"
                ? "أرسل رسالة نصية أو صورة أو فيديو أو رسالة صوتية، أو ابدأ مكالمة صوتية أو مرئية من الأعلى."
                : "ابدأ بكتابة رسالة أو سجّل رسالة صوتية أو أرسل صورة."}
            </p>
          </div>
        </div>
      ) : (
        messages.map((msg: ChatMessage, index: number) => {
          const isMine = msg.senderId === "me";
          const prevMsg = index > 0 ? messages[index - 1] : null;
          const showDateSep =
            !prevMsg || !isSameCalendarDay(prevMsg.timestamp, msg.timestamp);

          if (msg.messageType === "call" && msg.callInfo) {
            const isVideoCall = msg.callInfo.callType === "video";
            const isCaller = msg.callInfo.callerId === currentUid;
            const isMissedOrDeclined =
              msg.callInfo.outcome === "missed" ||
              msg.callInfo.outcome === "declined";

            return (
              <div key={msg.id} className="space-y-2">
                {showDateSep && (
                  <div className="flex justify-center py-2">
                    <span className="px-3.5 py-1 rounded-lg bg-white/90 dark:bg-[#182229]/90 text-slate-600 dark:text-slate-300 text-xs font-medium shadow-xs border border-slate-200/60 dark:border-slate-700/40">
                      {formatDateSeparator(msg.timestamp)}
                    </span>
                  </div>
                )}
                <div className="flex justify-center py-1">
                  <div className="inline-flex items-center gap-2.5 px-4 py-2 rounded-2xl bg-white/95 dark:bg-[#202c33]/95 border border-slate-200/80 dark:border-slate-700/70 shadow-xs text-xs">
                    <span
                      className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 ${
                        isMissedOrDeclined
                          ? "bg-rose-50 dark:bg-rose-950/50 text-rose-600 dark:text-rose-400"
                          : "bg-emerald-50 dark:bg-emerald-950/50 text-[#0d7a5f] dark:text-[#00a884]"
                      }`}
                    >
                      {isMissedOrDeclined ? (
                        <PhoneMissed className="w-3.5 h-3.5" />
                      ) : isCaller ? (
                        <PhoneOutgoing className="w-3.5 h-3.5" />
                      ) : (
                        <PhoneIncoming className="w-3.5 h-3.5" />
                      )}
                    </span>
                    <div className="text-start">
                      <p className="font-bold text-slate-800 dark:text-slate-100 flex items-center gap-1">
                        {isVideoCall && (
                          <Video className="w-3.5 h-3.5 inline shrink-0" />
                        )}
                        <span>
                          {msg.callInfo.outcome === "completed"
                            ? `${
                                isVideoCall ? "مكالمة فيديو" : "مكالمة صوتية"
                              } (${formatCallDurationLabel(
                                msg.callInfo.durationSeconds
                              )})`
                            : msg.callInfo.outcome === "declined"
                            ? "مكالمة مرفوضة"
                            : "مكالمة فائتة"}
                        </span>
                      </p>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400">
                        {formatMessageTime(msg.timestamp)}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            );
          }

          const isEncryptedMsg = Boolean(msg.isEncrypted && msg.ciphertext && msg.iv);
          const decryptedPlain = isEncryptedMsg
            ? decryptedMap[`${msg.id}:${msg.ciphertext}`] ||
              "🔒 جاري فك تشفير الرسالة..."
            : msg.text;
          const decryptionFailed =
            isEncryptedMsg && decryptedPlain === E2EE_FALLBACK_UNDECRYPTABLE;
          const displayText = isEncryptedMsg ? decryptedPlain : msg.text;

          const canTranslateMsg =
            !isMine &&
            !msg.isError &&
            !decryptionFailed &&
            displayText.trim().length > 0 &&
            displayText !== "🔒 جاري فك تشفير الرسالة...";
          const cacheKey = buildTranslationCacheKey(
            displayText,
            translationPrefs.targetLanguage
          );
          const visibilityKey = `${msg.id}:${translationPrefs.targetLanguage}`;
          const translatedText = translations[cacheKey];
          const isTranslatingMsg = Boolean(translatingKeys[cacheKey]);
          const isTranslationHidden = Boolean(hiddenTranslations[visibilityKey]);
          const reactionEntries = msg.reactions
            ? Object.entries(msg.reactions)
            : [];
          const showActions = activeActionMsgId === msg.id;

          return (
            <div key={msg.id} className="space-y-2">
              {showDateSep && (
                <div className="flex justify-center py-2">
                  <span className="px-3.5 py-1 rounded-lg bg-white/90 dark:bg-[#182229]/90 text-slate-600 dark:text-slate-300 text-xs font-medium shadow-xs border border-slate-200/60 dark:border-slate-700/40">
                    {formatDateSeparator(msg.timestamp)}
                  </span>
                </div>
              )}

              <div
                className={`group flex flex-col ${
                  isMine ? "items-start" : "items-end"
                }`}
              >
                <div
                  className={`relative max-w-[85%] sm:max-w-[72%] lg:max-w-[65%] ${
                    !isMine && chatType === "ai"
                      ? "flex items-end gap-2 flex-row-reverse"
                      : ""
                  }`}
                >
                  {!isMine && chatType === "ai" && (
                    <Avatar
                      src={GEMINI_AVATAR}
                      name={chatTitle}
                      size="sm"
                      isAi
                      className="!w-7 !h-7 shrink-0 mb-0.5"
                    />
                  )}
                  <div className="relative min-w-0 flex-1">
                  {/* WhatsApp-Style Floating Reactions & Actions ABOVE the message bubble */}
                  {showActions && (
                    <div
                      data-floating-msg-actions="true"
                      onClick={(e) => e.stopPropagation()}
                      onTouchStart={(e) => e.stopPropagation()}
                      className={`absolute bottom-full mb-1.5 z-30 flex flex-col gap-1.5 min-w-[235px] max-w-[90vw] ${
                        isMine ? "right-0 items-start" : "left-0 items-end"
                      }`}
                    >
                      <div className="flex items-center gap-1 bg-white/98 dark:bg-[#202c33]/98 backdrop-blur-md border border-slate-200 dark:border-slate-700 rounded-full px-2 py-1 shadow-xl">
                        {QUICK_REACTIONS.map((emoji) => (
                          <button
                            key={emoji}
                            type="button"
                            onClick={() => {
                              void onReactMessage(chatId, msg.id, emoji);
                              setActiveActionMsgId(null);
                            }}
                            className="w-8 h-8 rounded-full hover:bg-slate-100 dark:hover:bg-slate-700 active:scale-110 flex items-center justify-center text-base transition-transform cursor-pointer"
                          >
                            {emoji}
                          </button>
                        ))}
                      </div>

                      <div className="flex flex-wrap items-center gap-1 bg-white/98 dark:bg-[#202c33]/98 backdrop-blur-md border border-slate-200 dark:border-slate-700 rounded-2xl px-2 py-1.5 shadow-xl">
                        <button
                          type="button"
                          onClick={() => {
                            onReplyMessage({
                              id: msg.id,
                              senderName: isMine ? "أنت" : msg.senderName,
                              text: isEncryptedMsg && !decryptionFailed ? displayText : msg.text,
                              mediaType: msg.audioDataUrl
                                ? "audio"
                                : msg.videoDataUrl
                                ? "video"
                                : msg.imageDataUrl
                                ? "image"
                                : "text",
                            });
                            setActiveActionMsgId(null);
                          }}
                          className="px-2 py-1 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-[11px] font-bold flex items-center gap-1 cursor-pointer"
                        >
                          <Reply className="w-3.5 h-3.5" />
                          <span>رد</span>
                        </button>

                        {displayText.trim().length > 0 && !decryptionFailed && (
                          <button
                            type="button"
                            onClick={() => {
                              void handleCopyText(msg.id, displayText);
                              setActiveActionMsgId(null);
                            }}
                            className="px-2 py-1 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-[11px] font-bold flex items-center gap-1 cursor-pointer"
                          >
                            <Copy className="w-3.5 h-3.5" />
                            <span>نسخ</span>
                          </button>
                        )}

                        {isMine &&
                          chatType !== "ai" &&
                          displayText.trim().length > 0 &&
                          !decryptionFailed && (
                            <button
                              type="button"
                              onClick={() => {
                                onStartEditMessage(msg.id, displayText);
                                setActiveActionMsgId(null);
                              }}
                              className="px-2 py-1 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-[11px] font-bold flex items-center gap-1 cursor-pointer"
                            >
                              <Pencil className="w-3.5 h-3.5" />
                              <span>تعديل</span>
                            </button>
                          )}

                        <button
                          type="button"
                          onClick={() => {
                            void onDeleteMessageForMe(chatId, msg.id);
                            setActiveActionMsgId(null);
                          }}
                          className="px-2 py-1 rounded-xl hover:bg-rose-50 dark:hover:bg-rose-950/50 text-rose-600 dark:text-rose-400 text-[11px] font-bold cursor-pointer"
                        >
                          حذف لدي
                        </button>

                        {isMine && chatType !== "ai" && (
                          <button
                            type="button"
                            onClick={() => {
                              void onDeleteMessageForEveryone(chatId, msg.id);
                              setActiveActionMsgId(null);
                            }}
                            className="px-2 py-1 rounded-xl hover:bg-rose-50 dark:hover:bg-rose-950/50 text-rose-600 dark:text-rose-400 text-[11px] font-bold cursor-pointer"
                          >
                            حذف للجميع
                          </button>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Message Bubble */}
                  <div
                    onContextMenu={(e) => {
                      e.preventDefault();
                      setActiveActionMsgId(msg.id);
                    }}
                    onTouchStart={(e) => {
                      const t = e.touches[0];
                      touchStartPosRef.current = t
                        ? { x: t.clientX, y: t.clientY }
                        : null;
                      suppressNextClickRef.current = false;
                      longPressTimerRef.current = setTimeout(() => {
                        suppressNextClickRef.current = true;
                        setActiveActionMsgId(msg.id);
                        try {
                          navigator.vibrate?.(18);
                        } catch {
                          // ignore
                        }
                      }, 420);
                    }}
                    onTouchMove={(e) => {
                      if (!touchStartPosRef.current || !e.touches[0]) return;
                      const dx = Math.abs(e.touches[0].clientX - touchStartPosRef.current.x);
                      const dy = Math.abs(e.touches[0].clientY - touchStartPosRef.current.y);
                      if (dx > 12 || dy > 12) {
                        cancelLongPress();
                      }
                    }}
                    onTouchEnd={cancelLongPress}
                    onTouchCancel={cancelLongPress}
                    onClick={() => {
                      if (suppressNextClickRef.current) {
                        suppressNextClickRef.current = false;
                        return;
                      }
                      setActiveActionMsgId((prev) =>
                        prev === msg.id ? null : msg.id
                      );
                    }}
                    className={`rounded-2xl px-3.5 py-2.5 shadow-xs transition-all select-text ${
                      showActions ? "ring-2 ring-[#0d7a5f]/50 dark:ring-[#00a884]/60" : ""
                    } ${
                      isMine
                        ? "bg-[#0d7a5f] text-white dark:bg-[#005c4b] dark:text-[#e9edef] rounded-tr-xs"
                        : msg.isError
                        ? "bg-rose-50 dark:bg-rose-950/60 text-rose-800 dark:text-rose-200 border border-rose-200 dark:border-rose-800/60 rounded-tl-xs"
                        : "bg-white text-slate-900 dark:bg-[#202c33] dark:text-[#e9edef] rounded-tl-xs"
                    }`}
                  >
                    {!isMine && chatType === "group" && (
                      <p className="text-[11px] font-bold text-[#0d7a5f] dark:text-[#00a884] mb-1">
                        {msg.senderName}
                      </p>
                    )}

                    {msg.replyTo && (
                      <div
                        className={`mb-2 px-2.5 py-1.5 rounded-xl border-r-4 text-xs ${
                          isMine
                            ? "bg-black/15 border-emerald-200 text-emerald-50"
                            : "bg-slate-100 dark:bg-[#111b21] border-[#0d7a5f] dark:border-[#00a884] text-slate-700 dark:text-slate-300"
                        }`}
                      >
                        <p className="font-bold text-[11px]">
                          {msg.replyTo.senderName}
                        </p>
                        <p className="truncate opacity-90">
                          {msg.replyTo.text ||
                            (msg.replyTo.mediaType === "audio"
                              ? "رسالة صوتية"
                              : msg.replyTo.mediaType === "video"
                              ? "فيديو"
                              : "صورة")}
                        </p>
                      </div>
                    )}

                    {msg.viewOnce ? (
                      msg.viewOnceOpened ? (
                        <div className="mb-1.5 px-3 py-2 rounded-xl bg-black/10 dark:bg-white/5 text-xs flex items-center gap-2 opacity-75">
                          <Eye className="w-4 h-4 shrink-0" />
                          <span>تم فتح صورة العرض لمرة واحدة</span>
                        </div>
                      ) : (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            if (!isMine) {
                              onOpenViewOnceImage(chatId, msg);
                            }
                          }}
                          className={`mb-1.5 px-3.5 py-2 rounded-xl flex items-center gap-2 text-xs font-bold cursor-pointer ${
                            isMine
                              ? "bg-white/15 text-white"
                              : "bg-emerald-50 dark:bg-emerald-950/50 text-[#0d7a5f] dark:text-[#00a884]"
                          }`}
                        >
                          <Eye className="w-4 h-4 shrink-0" />
                          <span>
                            {isMine
                              ? "صورة للعرض مرة واحدة"
                              : "اضغط لفتح الصورة (مرة واحدة)"}
                          </span>
                        </button>
                      )
                    ) : (
                      msg.imageDataUrl && (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onPreviewImage(msg.imageDataUrl!);
                          }}
                          className="block mb-2 rounded-xl overflow-hidden focus:outline-none focus-visible:ring-2 focus-visible:ring-white cursor-zoom-in"
                        >
                          <img
                            src={msg.imageDataUrl}
                            alt="صورة مرسلة في المحادثة"
                            referrerPolicy="no-referrer"
                            className="max-h-72 w-auto object-cover rounded-xl"
                          />
                        </button>
                      )
                    )}

                    {msg.videoDataUrl && (
                      <div className="mb-2 rounded-xl overflow-hidden bg-black max-w-full">
                        <video
                          src={msg.videoDataUrl}
                          controls
                          playsInline
                          preload="metadata"
                          className="max-h-72 w-full rounded-xl bg-black"
                        />
                      </div>
                    )}

                    {msg.audioDataUrl && (
                      <div onClick={(e) => e.stopPropagation()}>
                        <VoiceNotePlayer
                          src={msg.audioDataUrl}
                          initialDuration={msg.audioDuration}
                          isMine={isMine}
                        />
                      </div>
                    )}

                    {displayText && (
                      <div
                        dir="auto"
                        className={`text-[15px] leading-relaxed break-words ${
                          decryptionFailed ? "opacity-85 italic text-xs" : ""
                        }`}
                      >
                        {isEncryptedMsg && !decryptionFailed && (
                          <span
                            title="رسالة مشفرة من طرف إلى طرف"
                            className="inline-flex items-center gap-1 text-[10px] font-bold opacity-80 mb-0.5"
                          >
                            <Lock className="w-3 h-3" />
                            <span>رسالة سرية مشفرة</span>
                          </span>
                        )}
                        {renderFormattedText(displayText)}
                      </div>
                    )}

                    {canTranslateMsg &&
                      translatedText &&
                      !isTranslationHidden && (
                        <div className="mt-2 pt-2 border-t border-slate-200/80 dark:border-slate-700/70 space-y-1">
                          <div className="flex items-center gap-1 text-[11px] font-semibold text-[#0d7a5f] dark:text-[#00a884]">
                            <Languages className="w-3 h-3" />
                            <span>مترجم إلى {selectedLangOption.labelAr}</span>
                          </div>
                          <div
                            dir="auto"
                            className="text-sm leading-relaxed text-slate-700 dark:text-slate-200 break-words"
                          >
                            {renderFormattedText(translatedText)}
                          </div>
                        </div>
                      )}

                    {reactionEntries.length > 0 && (
                      <div className="mt-1.5 flex flex-wrap gap-1">
                        {Object.entries(
                          reactionEntries.reduce<Record<string, number>>(
                            (acc, [, emoji]) => {
                              acc[emoji] = (acc[emoji] || 0) + 1;
                              return acc;
                            },
                            {}
                          )
                        ).map(([emoji, count]) => (
                          <span
                            key={emoji}
                            className="px-1.5 py-0.5 rounded-full bg-black/15 dark:bg-white/10 text-[11px]"
                          >
                            {emoji} {count > 1 ? count : ""}
                          </span>
                        ))}
                      </div>
                    )}

                    <div
                      className={`mt-1.5 flex items-center justify-between gap-3 text-[11px] tabular-nums select-none ${
                        isMine
                          ? "text-emerald-100/90 dark:text-emerald-200/80"
                          : "text-slate-400 dark:text-slate-400"
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        {copiedMsgId === msg.id && (
                          <span className="text-[10px] font-bold text-emerald-200 dark:text-emerald-300">
                            تم النسخ
                          </span>
                        )}
                        {canTranslateMsg ? (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              if (translatedText) {
                                onToggleTranslationVisibility(visibilityKey);
                              } else {
                                void onRequestTranslation(
                                  msg.id,
                                  displayText,
                                  translationPrefs.targetLanguage
                                );
                              }
                            }}
                            disabled={isTranslatingMsg}
                            className="inline-flex items-center gap-1 px-1.5 py-0.5 -mr-1 rounded-md text-[11px] font-semibold text-[#0d7a5f] dark:text-[#00a884] hover:bg-emerald-50 dark:hover:bg-emerald-950/40 transition-colors cursor-pointer disabled:opacity-60"
                          >
                            {isTranslatingMsg ? (
                              <Loader2 className="w-3 h-3 animate-spin" />
                            ) : (
                              <Languages className="w-3 h-3" />
                            )}
                            <span>
                              {isTranslatingMsg
                                ? "جاري الترجمة..."
                                : translatedText
                                ? isTranslationHidden
                                  ? "إظهار الترجمة"
                                  : "إخفاء الترجمة"
                                : "ترجمة"}
                            </span>
                          </button>
                        ) : (
                          <span />
                        )}
                      </div>

                      <div className="flex items-center gap-1.5 flex-wrap justify-end">
                        {msg.edited && (
                          <span className="opacity-75">معدّلة</span>
                        )}
                        {isMine && msg.status === "read" && msg.readAt && (
                          <span className="text-[10px] text-sky-200 dark:text-sky-300/90 font-medium">
                            قُرئت {formatMessageTime(msg.readAt)}
                          </span>
                        )}
                        <span>{formatMessageTime(msg.timestamp)}</span>
                        {isMine && (
                          <span
                            title={
                              msg.status === "read"
                                ? msg.readAt
                                  ? `تمت القراءة ${formatMessageTime(msg.readAt)}`
                                  : "تمت القراءة"
                                : msg.status === "delivered"
                                ? "تم التسليم"
                                : "تم الإرسال"
                            }
                            className="inline-flex items-center"
                          >
                            {msg.status === "sending" && (
                              <Clock className="w-3.5 h-3.5 opacity-80" />
                            )}
                            {msg.status === "sent" && (
                              <Check className="w-3.5 h-3.5 text-[#94a3b8]" />
                            )}
                            {msg.status === "delivered" && (
                              <CheckCheck className="w-3.5 h-3.5 text-[#94a3b8]" />
                            )}
                            {msg.status === "read" && (
                              <CheckCheck className="w-3.5 h-3.5 text-[#38bdf8]" />
                            )}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                  </div>
                </div>
              </div>
            </div>
          );
        })
      )}

      {chatType === "ai" && messages.length <= 1 && !isTyping && (
        <div className="pt-2 flex flex-wrap gap-2 justify-start">
          {AI_QUICK_PROMPTS.map((promptText) => (
            <button
              key={promptText}
              type="button"
              onClick={() => onSendQuickAiPrompt(promptText)}
              className="min-h-[38px] px-3.5 py-2 rounded-xl bg-white/95 dark:bg-[#202c33] border border-slate-200/80 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200 hover:border-[#0d7a5f] dark:hover:border-[#00a884] hover:text-[#0d7a5f] dark:hover:text-[#00a884] transition-colors shadow-xs cursor-pointer"
            >
              {promptText}
            </button>
          ))}
        </div>
      )}

      {isTyping && (
        <div className="flex justify-end items-end gap-2">
          <div className="bg-white dark:bg-[#202c33] text-slate-500 dark:text-slate-300 rounded-2xl rounded-tl-xs px-4 py-3 shadow-xs flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-slate-400 dark:bg-slate-500 animate-bounce [animation-delay:0ms]" />
            <span className="w-2 h-2 rounded-full bg-slate-400 dark:bg-slate-500 animate-bounce [animation-delay:150ms]" />
            <span className="w-2 h-2 rounded-full bg-slate-400 dark:bg-slate-500 animate-bounce [animation-delay:300ms]" />
          </div>
          {chatType === "ai" && (
            <Avatar
              src={GEMINI_AVATAR}
              name={chatTitle}
              size="sm"
              isAi
              className="!w-7 !h-7 shrink-0"
            />
          )}
        </div>
      )}

      <div ref={messagesEndRef} />
      </div>
    </div>
  );
});
