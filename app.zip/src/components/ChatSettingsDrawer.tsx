import { useEffect, useMemo, useState, type ChangeEvent } from "react";
import {
  Ban,
  Check,
  Clapperboard,
  Clock,
  ExternalLink,
  Image as ImageIcon,
  Link2,
  Loader2,
  MonitorOff,
  MonitorUp,
  Palette,
  Pin,
  ShieldCheck,
  Square,
  Trash2,
  Upload,
  User,
  Users,
  X,
} from "lucide-react";
import type {
  ChatWallpaperId,
  Conversation,
  DisappearingTimerSeconds,
  WatchSessionData,
} from "../types/chat";
import { CHAT_WALLPAPERS } from "../data/defaults";
import {
  compressImageToDataUrl,
  formatBlockRemainingAr,
  formatMessageTime,
  normalizeCustomImageUrl,
  supportsDesktopScreenShare,
} from "../utils/storage";
import { Avatar } from "./Avatar";

interface ChatSettingsDrawerProps {
  isOpen: boolean;
  conversation: Conversation;
  isBlockedByMe: boolean;
  blockedUntilMs?: number;
  isBlockedByPeer: boolean;
  isSharingThisChat: boolean;
  watchSession: WatchSessionData | null;
  wallpaperId: ChatWallpaperId;
  customWallpaper?: string | null;
  onClose: () => void;
  onStartScreenShare: () => Promise<void>;
  onStopScreenShare: () => Promise<void>;
  onOpenWatchTogether: () => void;
  onStopWatchTogether: () => Promise<void>;
  onSelectWallpaper: (id: ChatWallpaperId) => void;
  onUploadCustomWallpaper?: (dataUrl: string | null) => void;
  onTogglePin: () => void;
  onOpenPeerProfile: () => void;
  onOpenGroupInfo: () => void;
  onCreateGroupWithPeer: (peerUid: string) => void;
  onSetDisappearingTimer: (seconds: DisappearingTimerSeconds) => Promise<void>;
  onPreviewImage: (src: string) => void;
  onBlockWithDuration: (durationMs: number | null) => Promise<void>;
  onUnblock: () => Promise<void>;
  onDeleteChatForMe: () => Promise<void>;
  onOpenInAppBrowser?: (url: string, title?: string) => void;
}

const WEEK_MS = 7 * 24 * 60 * 60 * 1000;
const MONTH_MS = 30 * 24 * 60 * 60 * 1000;

const DISAPPEARING_OPTIONS: Array<{
  seconds: DisappearingTimerSeconds;
  label: string;
}> = [
  { seconds: 86400, label: "24 ساعة" },
  { seconds: 604800, label: "7 أيام" },
  { seconds: 7776000, label: "90 يوماً" },
  { seconds: 0, label: "إيقاف" },
];

const URL_REGEX = /https?:\/\/[^\s<>"'`]+/gi;

export function formatDisappearingLabel(seconds?: number): string {
  if (seconds === 86400) return "24 ساعة";
  if (seconds === 604800) return "7 أيام";
  if (seconds === 7776000) return "90 يوماً";
  return "متوقف";
}

export function ChatSettingsDrawer({
  isOpen,
  conversation,
  isBlockedByMe,
  blockedUntilMs,
  isBlockedByPeer,
  isSharingThisChat,
  watchSession,
  wallpaperId,
  customWallpaper,
  onClose,
  onStartScreenShare,
  onStopScreenShare,
  onOpenWatchTogether,
  onStopWatchTogether,
  onSelectWallpaper,
  onUploadCustomWallpaper,
  onTogglePin,
  onOpenPeerProfile,
  onOpenGroupInfo,
  onCreateGroupWithPeer,
  onSetDisappearingTimer,
  onPreviewImage,
  onBlockWithDuration,
  onUnblock,
  onDeleteChatForMe,
  onOpenInAppBrowser,
}: ChatSettingsDrawerProps) {
  const [showWallpapers, setShowWallpapers] = useState(false);
  const [uploadingWallpaper, setUploadingWallpaper] = useState(false);
  const [wallpaperUrlInput, setWallpaperUrlInput] = useState("");
  const [wallpaperError, setWallpaperError] = useState<string | null>(null);
  const [showDisappearingPanel, setShowDisappearingPanel] = useState(false);
  const [timerBusy, setTimerBusy] = useState(false);
  const [showSharedPanel, setShowSharedPanel] = useState(false);
  const [sharedTab, setSharedTab] = useState<"images" | "links">("images");
  const [confirmClear, setConfirmClear] = useState(false);
  const [showBlockOptions, setShowBlockOptions] = useState(false);
  const [confirmBlockChoice, setConfirmBlockChoice] = useState<{
    durationMs: number | null;
    label: string;
  } | null>(null);
  const [blockBusy, setBlockBusy] = useState(false);
  const [deleteBusy, setDeleteBusy] = useState(false);
  const [shareBusy, setShareBusy] = useState(false);

  const isChatBlocked = isBlockedByMe || isBlockedByPeer;
  const canDesktopShare = supportsDesktopScreenShare();
  const hasActiveMedia = isSharingThisChat || Boolean(watchSession?.isActive);
  const activeTimer: DisappearingTimerSeconds =
    conversation.disappearingTimer === 86400 ||
    conversation.disappearingTimer === 604800 ||
    conversation.disappearingTimer === 7776000
      ? conversation.disappearingTimer
      : 0;

  const { sharedImages, sharedLinks } = useMemo(() => {
    const imgs: Array<{ id: string; src: string; timestamp: number }> = [];
    const links: Array<{
      id: string;
      url: string;
      senderName: string;
      timestamp: number;
    }> = [];
    const seenUrls = new Set<string>();

    const msgs = [...conversation.messages].reverse();
    for (const m of msgs) {
      if (!m.viewOnce && m.imageDataUrl) {
        imgs.push({ id: m.id, src: m.imageDataUrl, timestamp: m.timestamp });
      }
      if (m.text) {
        const matches = m.text.match(URL_REGEX);
        if (matches) {
          for (const rawUrl of matches) {
            const cleanUrl = rawUrl.replace(/[.,!?)]+$/, "");
            if (cleanUrl && !seenUrls.has(cleanUrl)) {
              seenUrls.add(cleanUrl);
              links.push({
                id: `${m.id}_${links.length}`,
                url: cleanUrl,
                senderName: m.senderId === "me" ? "أنت" : m.senderName,
                timestamp: m.timestamp,
              });
            }
          }
        }
      }
    }

    return { sharedImages: imgs, sharedLinks: links };
  }, [conversation.messages]);

  useEffect(() => {
    if (isOpen) {
      setConfirmClear(false);
      setShowBlockOptions(false);
      setConfirmBlockChoice(null);
      setWallpaperError(null);
      setWallpaperUrlInput(
        customWallpaper && /^https?:\/\//i.test(customWallpaper)
          ? customWallpaper
          : ""
      );
      setShowDisappearingPanel(false);
      setShowSharedPanel(false);
    }
  }, [isOpen, conversation.id, customWallpaper]);

  useEffect(() => {
    if (!isOpen) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleScreenShareAction = async () => {
    if (shareBusy) return;
    setShareBusy(true);
    try {
      if (isSharingThisChat) {
        await onStopScreenShare();
      } else {
        onClose();
        await onStartScreenShare();
      }
    } finally {
      setShareBusy(false);
    }
  };

  const handleTimerSelect = async (seconds: DisappearingTimerSeconds) => {
    if (timerBusy || seconds === activeTimer) return;
    setTimerBusy(true);
    try {
      await onSetDisappearingTimer(seconds);
    } finally {
      setTimerBusy(false);
    }
  };

  const handleWallpaperUpload = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !onUploadCustomWallpaper) return;
    setUploadingWallpaper(true);
    setWallpaperError(null);
    try {
      const compressed = await compressImageToDataUrl(file, 1280, 0.78, 320000);
      onUploadCustomWallpaper(compressed);
      setWallpaperUrlInput("");
    } catch (err) {
      setWallpaperError(
        err instanceof Error ? err.message : "تعذر تحميل صورة الخلفية."
      );
    } finally {
      setUploadingWallpaper(false);
      e.target.value = "";
    }
  };

  const handleApplyWallpaperUrl = () => {
    if (!onUploadCustomWallpaper) return;
    const valid = normalizeCustomImageUrl(wallpaperUrlInput);
    if (!valid) {
      setWallpaperError("يرجى إدخال رابط صورة صحيح يبدأ بـ https:// أو http://");
      return;
    }
    setWallpaperError(null);
    onUploadCustomWallpaper(valid);
  };

  const handleBlockChoice = async (durationMs: number | null) => {
    if (blockBusy) return;
    setBlockBusy(true);
    try {
      await onBlockWithDuration(durationMs);
      setConfirmBlockChoice(null);
      setShowBlockOptions(false);
    } finally {
      setBlockBusy(false);
    }
  };

  const handleUnblockAction = async () => {
    if (blockBusy) return;
    setBlockBusy(true);
    try {
      await onUnblock();
    } finally {
      setBlockBusy(false);
    }
  };

  const handleDeleteForMe = async () => {
    if (deleteBusy) return;
    setDeleteBusy(true);
    try {
      await onDeleteChatForMe();
      setConfirmClear(false);
      onClose();
    } finally {
      setDeleteBusy(false);
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="chat-settings-drawer-title"
      className="fixed inset-0 z-50 flex justify-end bg-black/45 backdrop-blur-xs"
      onClick={onClose}
    >
      <aside
        dir="rtl"
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-sm h-full bg-white dark:bg-[#111b21] border-r border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col overflow-hidden"
      >
        {/* Drawer Header */}
        <div className="px-4 py-3.5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-3 min-w-0">
            <Avatar
              src={conversation.avatar}
              name={conversation.title}
              size="md"
            />
            <div className="min-w-0">
              <h2
                id="chat-settings-drawer-title"
                className="font-display text-base font-bold text-slate-900 dark:text-white truncate"
              >
                إعدادات المحادثة
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                {conversation.title}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="إغلاق إعدادات المحادثة"
            className="min-h-[42px] min-w-[42px] rounded-xl flex items-center justify-center text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Drawer Body */}
        <div className="flex-1 overflow-y-auto custom-scrollbar p-4 space-y-5">
          {/* Quick Profile / Create Group With Peer / Group Info & Pin Actions */}
          <section className="space-y-2">
            {conversation.type === "direct" && (
              <>
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenPeerProfile();
                  }}
                  className="w-full min-h-[44px] px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-[#202c33] border border-slate-200 dark:border-slate-700 text-sm font-bold text-slate-800 dark:text-slate-100 flex items-center justify-between cursor-pointer"
                >
                  <span className="flex items-center gap-2.5">
                    <User className="w-4 h-4 text-[#0d7a5f] dark:text-[#00a884]" />
                    <span>عرض الملف الشخصي</span>
                  </span>
                </button>

                {conversation.peerUid && (
                  <button
                    type="button"
                    onClick={() => {
                      const peerUid = conversation.peerUid!;
                      onClose();
                      onCreateGroupWithPeer(peerUid);
                    }}
                    className="w-full min-h-[44px] px-3.5 py-2 rounded-xl bg-emerald-50/70 hover:bg-emerald-100/70 dark:bg-emerald-950/35 dark:hover:bg-emerald-950/55 border border-emerald-200/80 dark:border-emerald-800/60 text-sm font-bold text-[#0d7a5f] dark:text-[#00a884] flex items-center justify-between gap-2 transition-colors cursor-pointer"
                  >
                    <span className="flex items-center gap-2.5 min-w-0">
                      <Users className="w-4 h-4 shrink-0" />
                      <span className="truncate">
                        👥 إنشاء مجموعة جديدة مع {conversation.title}
                      </span>
                    </span>
                  </button>
                )}
              </>
            )}

            {conversation.type === "group" && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenGroupInfo();
                }}
                className="w-full min-h-[44px] px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-[#202c33] border border-slate-200 dark:border-slate-700 text-sm font-bold text-slate-800 dark:text-slate-100 flex items-center justify-between cursor-pointer"
              >
                <span className="flex items-center gap-2.5">
                  <Users className="w-4 h-4 text-[#0d7a5f] dark:text-[#00a884]" />
                  <span>إدارة المجموعة والأعضاء</span>
                </span>
                <span className="text-xs text-slate-400">
                  {conversation.memberIds?.length || 0} أعضاء
                </span>
              </button>
            )}

            <button
              type="button"
              onClick={onTogglePin}
              className="w-full min-h-[44px] px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-[#202c33] border border-slate-200 dark:border-slate-700 text-sm font-bold text-slate-800 dark:text-slate-100 flex items-center justify-between cursor-pointer"
            >
              <span className="flex items-center gap-2.5">
                <Pin
                  className={`w-4 h-4 ${
                    conversation.pinned
                      ? "text-[#0d7a5f] dark:text-[#00a884]"
                      : "text-slate-400"
                  }`}
                />
                <span>
                  {conversation.pinned
                    ? "إلغاء تثبيت المحادثة"
                    : "تثبيت المحادثة بالأعلى"}
                </span>
              </span>
              {conversation.pinned && (
                <span className="text-[11px] font-bold text-[#0d7a5f] dark:text-[#00a884]">
                  مثبّتة
                </span>
              )}
            </button>
          </section>

          {/* Disappearing Messages Timer Section */}
          <section className="space-y-2.5">
            <h3 className="text-xs font-bold text-slate-500 dark:text-slate-400 px-1">
              ⏱️ الرسائل ذاتية الاختفاء
            </h3>

            <div className="rounded-2xl bg-slate-50 dark:bg-[#202c33]/75 border border-slate-200/70 dark:border-slate-800 p-2.5 space-y-2.5">
              <button
                type="button"
                onClick={() => setShowDisappearingPanel((v) => !v)}
                aria-expanded={showDisappearingPanel}
                className="w-full min-h-[44px] px-3.5 py-2 rounded-xl bg-white dark:bg-[#111b21] border border-slate-200 dark:border-slate-700 text-sm font-bold text-slate-800 dark:text-slate-100 flex items-center justify-between gap-2 cursor-pointer"
              >
                <span className="flex items-center gap-2.5">
                  <Clock className="w-4 h-4 text-[#0d7a5f] dark:text-[#00a884]" />
                  <span>الرسائل ذاتية الاختفاء</span>
                </span>
                <span
                  className={`text-[11px] font-bold ${
                    activeTimer > 0
                      ? "text-[#0d7a5f] dark:text-[#00a884]"
                      : "text-slate-400"
                  }`}
                >
                  {formatDisappearingLabel(activeTimer)}
                </span>
              </button>

              {showDisappearingPanel && (
                <div className="space-y-2 pt-1">
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 px-1 leading-relaxed">
                    عند التفعيل، سيتم حذف الرسائل الجديدة تلقائياً من المحادثة بعد انقضاء المدة المحددة.
                  </p>
                  <div className="grid grid-cols-2 gap-1.5">
                    {DISAPPEARING_OPTIONS.map((opt) => {
                      const selected = activeTimer === opt.seconds;
                      return (
                        <button
                          key={opt.seconds}
                          type="button"
                          disabled={timerBusy}
                          onClick={() => void handleTimerSelect(opt.seconds)}
                          className={`min-h-[40px] px-3 py-2 rounded-xl border text-xs font-bold flex items-center justify-between gap-1.5 transition-colors cursor-pointer disabled:opacity-60 ${
                            selected
                              ? "bg-emerald-50 dark:bg-emerald-950/45 border-[#0d7a5f] dark:border-[#00a884] text-[#0d7a5f] dark:text-[#00a884]"
                              : "bg-white dark:bg-[#111b21] border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:border-slate-300 dark:hover:border-slate-600"
                          }`}
                        >
                          <span>{opt.label}</span>
                          {timerBusy && selected ? (
                            <Loader2 className="w-3.5 h-3.5 animate-spin shrink-0" />
                          ) : selected ? (
                            <Check className="w-3.5 h-3.5 shrink-0" />
                          ) : null}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          </section>

          {/* Shared Media & Links Section */}
          <section className="space-y-2.5">
            <h3 className="text-xs font-bold text-slate-500 dark:text-slate-400 px-1">
              🖼️ الوسائط والروابط المشتركة
            </h3>

            <div className="rounded-2xl bg-slate-50 dark:bg-[#202c33]/75 border border-slate-200/70 dark:border-slate-800 p-2.5 space-y-2.5">
              <button
                type="button"
                onClick={() => setShowSharedPanel((v) => !v)}
                aria-expanded={showSharedPanel}
                className="w-full min-h-[44px] px-3.5 py-2 rounded-xl bg-white dark:bg-[#111b21] border border-slate-200 dark:border-slate-700 text-sm font-bold text-slate-800 dark:text-slate-100 flex items-center justify-between gap-2 cursor-pointer"
              >
                <span className="flex items-center gap-2.5">
                  <ImageIcon className="w-4 h-4 text-[#0d7a5f] dark:text-[#00a884]" />
                  <span>عرض الصور والروابط</span>
                </span>
                <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 tabular-nums">
                  {sharedImages.length} صورة · {sharedLinks.length} رابط
                </span>
              </button>

              {showSharedPanel && (
                <div className="space-y-2.5 pt-1">
                  <div className="grid grid-cols-2 gap-1.5 bg-white dark:bg-[#111b21] p-1 rounded-xl border border-slate-200 dark:border-slate-700">
                    <button
                      type="button"
                      onClick={() => setSharedTab("images")}
                      className={`min-h-[34px] rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
                        sharedTab === "images"
                          ? "bg-[#0d7a5f] dark:bg-[#00a884] text-white"
                          : "text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
                      }`}
                    >
                      <ImageIcon className="w-3.5 h-3.5" />
                      <span>الصور ({sharedImages.length})</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setSharedTab("links")}
                      className={`min-h-[34px] rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
                        sharedTab === "links"
                          ? "bg-[#0d7a5f] dark:bg-[#00a884] text-white"
                          : "text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
                      }`}
                    >
                      <Link2 className="w-3.5 h-3.5" />
                      <span>الروابط ({sharedLinks.length})</span>
                    </button>
                  </div>

                  {sharedTab === "images" ? (
                    sharedImages.length === 0 ? (
                      <p className="text-xs text-slate-500 dark:text-slate-400 text-center py-4 bg-white dark:bg-[#111b21] rounded-xl border border-slate-200/70 dark:border-slate-800">
                        لا توجد صور مشتركة في هذه المحادثة بعد.
                      </p>
                    ) : (
                      <div className="grid grid-cols-3 gap-1.5 max-h-60 overflow-y-auto custom-scrollbar">
                        {sharedImages.map((img) => (
                          <button
                            key={img.id}
                            type="button"
                            onClick={() => {
                              onClose();
                              onPreviewImage(img.src);
                            }}
                            title="فتح الصورة"
                            className="aspect-square rounded-xl overflow-hidden bg-slate-200 dark:bg-slate-800 border border-slate-200/70 dark:border-slate-700 hover:opacity-90 transition-opacity cursor-pointer"
                          >
                            <img
                              src={img.src}
                              alt="صورة مشتركة"
                              referrerPolicy="no-referrer"
                              className="w-full h-full object-cover"
                            />
                          </button>
                        ))}
                      </div>
                    )
                  ) : sharedLinks.length === 0 ? (
                    <p className="text-xs text-slate-500 dark:text-slate-400 text-center py-4 bg-white dark:bg-[#111b21] rounded-xl border border-slate-200/70 dark:border-slate-800">
                      لا توجد روابط مشاركة في هذه المحادثة بعد.
                    </p>
                  ) : (
                    <div className="space-y-1.5 max-h-60 overflow-y-auto custom-scrollbar">
                      {sharedLinks.map((item) =>
                        onOpenInAppBrowser ? (
                          <div
                            key={item.id}
                            className="p-2.5 rounded-xl bg-white dark:bg-[#111b21] border border-slate-200/80 dark:border-slate-700 hover:border-[#0d7a5f] dark:hover:border-[#00a884] transition-colors flex items-start justify-between gap-2"
                          >
                            <button
                              type="button"
                              onClick={() => {
                                onClose();
                                onOpenInAppBrowser(item.url);
                              }}
                              className="flex-1 min-w-0 text-start cursor-pointer"
                            >
                              <span
                                dir="ltr"
                                className="block text-xs font-semibold text-[#0d7a5f] dark:text-[#00a884] break-all line-clamp-2"
                              >
                                {item.url}
                              </span>
                              <p className="text-[10px] text-slate-400 mt-1">
                                {item.senderName} · {formatMessageTime(item.timestamp)}
                              </p>
                            </button>
                            <a
                              href={item.url}
                              target="_blank"
                              rel="noopener noreferrer"
                              title="فتح في متصفح خارجي"
                              className="p-1.5 rounded-lg text-slate-400 hover:text-[#0d7a5f] hover:bg-slate-100 dark:hover:bg-slate-800 shrink-0 transition-colors"
                            >
                              <ExternalLink className="w-3.5 h-3.5" />
                            </a>
                          </div>
                        ) : (
                          <a
                            key={item.id}
                            href={item.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="block p-2.5 rounded-xl bg-white dark:bg-[#111b21] border border-slate-200/80 dark:border-slate-700 hover:border-[#0d7a5f] dark:hover:border-[#00a884] transition-colors"
                          >
                            <div className="flex items-start justify-between gap-2">
                              <span
                                dir="ltr"
                                className="text-xs font-semibold text-[#0d7a5f] dark:text-[#00a884] break-all line-clamp-2"
                              >
                                {item.url}
                              </span>
                              <ExternalLink className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                            </div>
                            <p className="text-[10px] text-slate-400 mt-1">
                              {item.senderName} · {formatMessageTime(item.timestamp)}
                            </p>
                          </a>
                        )
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>
          </section>

          {/* Section: البث والمشاهدة معاً (المكالمات حصراً للمحادثات الثنائية) */}
          <section className="space-y-2.5">
            <h3 className="text-xs font-bold text-slate-500 dark:text-slate-400 px-1">
              البث والمشاهدة معاً
            </h3>

            <div className="rounded-2xl bg-slate-50 dark:bg-[#202c33]/75 border border-slate-200/70 dark:border-slate-800 p-2.5 space-y-2">
              {conversation.type === "direct" && isChatBlocked ? (
                <p className="text-xs text-slate-500 dark:text-slate-400 px-2 py-1.5">
                  لا يمكن استخدام البث أو المكالمات أثناء وجود حظر في هذه المحادثة.
                </p>
              ) : (
                <>
                  {conversation.type === "direct" && canDesktopShare && (
                    <button
                      type="button"
                      onClick={() => void handleScreenShareAction()}
                      disabled={shareBusy}
                      className={`w-full min-h-[46px] px-3.5 py-2.5 rounded-xl text-sm font-bold flex items-center justify-between gap-2 transition-colors cursor-pointer disabled:opacity-60 ${
                        isSharingThisChat
                          ? "bg-rose-600 hover:bg-rose-700 text-white"
                          : "bg-[#0d7a5f] hover:bg-[#0a634d] dark:bg-[#00a884] dark:hover:bg-[#069475] text-white"
                      }`}
                    >
                      <span className="flex items-center gap-2.5">
                        {shareBusy ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : isSharingThisChat ? (
                          <MonitorOff className="w-4 h-4" />
                        ) : (
                          <MonitorUp className="w-4 h-4" />
                        )}
                        <span>
                          {isSharingThisChat
                            ? "إيقاف البث الحالي"
                            : "بث شاشتي لصديقي"}
                        </span>
                      </span>
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={() => {
                      if (hasActiveMedia) {
                        if (isSharingThisChat) {
                          void onStopScreenShare();
                        } else {
                          void onStopWatchTogether();
                        }
                      } else {
                        onClose();
                        onOpenWatchTogether();
                      }
                    }}
                    className={`w-full min-h-[46px] px-3.5 py-2.5 rounded-xl text-sm font-bold flex items-center justify-between gap-2 transition-colors cursor-pointer ${
                      hasActiveMedia
                        ? "bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/60 text-rose-600 dark:text-rose-400"
                        : canDesktopShare && conversation.type === "direct"
                        ? "bg-white dark:bg-[#111b21] border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 hover:border-[#0d7a5f] dark:hover:border-[#00a884]"
                        : "bg-[#0d7a5f] hover:bg-[#0a634d] dark:bg-[#00a884] dark:hover:bg-[#069475] text-white"
                    }`}
                  >
                    <span className="flex items-center gap-2.5">
                      {hasActiveMedia ? (
                        <Square className="w-4 h-4 text-rose-600 dark:text-rose-400" />
                      ) : (
                        <Clapperboard className="w-4 h-4" />
                      )}
                      <span>
                        {hasActiveMedia
                          ? "إيقاف المشاهدة معاً"
                          : "مشاهدة فيلم أو فيديو معاً"}
                      </span>
                    </span>
                  </button>
                </>
              )}
            </div>
          </section>

          {/* Section: تخصيص الدردشة */}
          <section className="space-y-2.5">
            <h3 className="text-xs font-bold text-slate-500 dark:text-slate-400 px-1">
              تخصيص الدردشة
            </h3>

            <div className="rounded-2xl bg-slate-50 dark:bg-[#202c33]/75 border border-slate-200/70 dark:border-slate-800 p-2.5 space-y-3">
              <button
                type="button"
                onClick={() => setShowWallpapers((v) => !v)}
                aria-expanded={showWallpapers}
                className="w-full min-h-[44px] px-3.5 py-2 rounded-xl bg-white dark:bg-[#111b21] border border-slate-200 dark:border-slate-700 text-sm font-bold text-slate-800 dark:text-slate-100 flex items-center justify-between gap-2 cursor-pointer"
              >
                <span className="flex items-center gap-2.5">
                  <Palette className="w-4 h-4 text-[#0d7a5f] dark:text-[#00a884]" />
                  <span>تغيير خلفية الدردشة</span>
                </span>
                <span className="text-[11px] font-semibold text-[#0d7a5f] dark:text-[#00a884]">
                  {customWallpaper
                    ? "صورة مخصصة"
                    : CHAT_WALLPAPERS.find((w) => w.id === wallpaperId)?.label ||
                      ""}
                </span>
              </button>

              {showWallpapers && (
                <div className="space-y-2.5 pt-1">
                  {onUploadCustomWallpaper && (
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <label
                          htmlFor="wallpaper-upload-input"
                          onClick={(e) => e.stopPropagation()}
                          className={`relative flex-1 min-h-[40px] px-3 py-2 rounded-xl bg-[#0d7a5f] hover:bg-[#0a634d] dark:bg-[#00a884] dark:hover:bg-[#069475] text-white text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-colors ${
                            uploadingWallpaper
                              ? "opacity-60 pointer-events-none"
                              : ""
                          }`}
                        >
                          {uploadingWallpaper ? (
                            <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          ) : (
                            <Upload className="w-3.5 h-3.5" />
                          )}
                          <span>رفع صورة خلفية من الجهاز</span>
                          <input
                            id="wallpaper-upload-input"
                            type="file"
                            disabled={uploadingWallpaper}
                            onClick={(e) => {
                              e.stopPropagation();
                              e.currentTarget.value = "";
                            }}
                            onChange={(e) => void handleWallpaperUpload(e)}
                            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                          />
                        </label>
                        {customWallpaper && (
                          <button
                            type="button"
                            onClick={() => {
                              onUploadCustomWallpaper(null);
                              setWallpaperUrlInput("");
                            }}
                            className="min-h-[40px] px-3 py-2 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/60 text-rose-600 dark:text-rose-400 text-xs font-bold cursor-pointer"
                          >
                            إزالة
                          </button>
                        )}
                      </div>

                      <div className="space-y-1">
                        <label
                          htmlFor="wallpaper-url-input"
                          className="block text-[11px] font-semibold text-slate-600 dark:text-slate-300"
                        >
                          لصق رابط صورة (Image URL)
                        </label>
                        <div className="flex items-center gap-1.5">
                          <input
                            id="wallpaper-url-input"
                            type="url"
                            dir="ltr"
                            value={wallpaperUrlInput}
                            onChange={(e) => setWallpaperUrlInput(e.target.value)}
                            placeholder="https://example.com/wallpaper.jpg"
                            className="flex-1 min-w-0 min-h-[36px] px-2.5 rounded-xl bg-white dark:bg-[#111b21] border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white focus:border-[#0d7a5f] focus:outline-none text-left"
                          />
                          <button
                            type="button"
                            onClick={handleApplyWallpaperUrl}
                            className="min-h-[36px] px-3 rounded-xl bg-[#0d7a5f] hover:bg-[#0a634d] dark:bg-[#00a884] dark:hover:bg-[#069475] text-white text-xs font-bold shrink-0 cursor-pointer"
                          >
                            تطبيق
                          </button>
                        </div>
                      </div>

                      {wallpaperError && (
                        <p className="text-[11px] text-rose-600 dark:text-rose-400 px-1">
                          {wallpaperError}
                        </p>
                      )}
                    </div>
                  )}

                  <div className="grid grid-cols-2 gap-2">
                    {CHAT_WALLPAPERS.map((wp) => {
                      const selected = !customWallpaper && wp.id === wallpaperId;
                      return (
                        <button
                          key={wp.id}
                          type="button"
                          onClick={() => {
                            onUploadCustomWallpaper?.(null);
                            onSelectWallpaper(wp.id);
                          }}
                          className={`rounded-xl p-1.5 border text-right transition-all cursor-pointer ${
                            selected
                              ? "border-[#0d7a5f] dark:border-[#00a884] ring-2 ring-[#0d7a5f]/25 dark:ring-[#00a884]/25 bg-emerald-50/50 dark:bg-emerald-950/30"
                              : "border-slate-200 dark:border-slate-700 bg-white dark:bg-[#111b21] hover:border-slate-300 dark:hover:border-slate-600"
                          }`}
                        >
                          <div
                            className={`h-12 w-full rounded-lg ${wp.previewClass} border border-black/10 dark:border-white/10 relative overflow-hidden flex items-center justify-center`}
                          >
                            {selected && (
                              <span className="w-6 h-6 rounded-full bg-[#0d7a5f] dark:bg-[#00a884] text-white flex items-center justify-center shadow-sm">
                                <Check className="w-3.5 h-3.5" />
                              </span>
                            )}
                          </div>
                          <span className="block mt-1.5 px-1 text-[11px] font-semibold text-slate-700 dark:text-slate-200 truncate">
                            {wp.label}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          </section>

          {/* Section: الأمان والحظر المؤقت/الدائم + حذف المحادثة لدي فقط */}
          <section className="space-y-2.5">
            <h3 className="text-xs font-bold text-slate-500 dark:text-slate-400 px-1">
              الأمان والحظر
            </h3>

            <div className="rounded-2xl bg-slate-50 dark:bg-[#202c33]/75 border border-slate-200/70 dark:border-slate-800 p-2.5 space-y-2">
              {conversation.type === "direct" && conversation.peerUid && (
                <>
                  {isBlockedByMe ? (
                    <button
                      type="button"
                      onClick={() => void handleUnblockAction()}
                      disabled={blockBusy}
                      className="w-full min-h-[44px] px-3.5 py-2 rounded-xl border bg-emerald-50 dark:bg-emerald-950/50 border-emerald-200 dark:border-emerald-800/60 text-[#0d7a5f] dark:text-[#00a884] text-sm font-bold flex items-center justify-between gap-2 transition-colors cursor-pointer disabled:opacity-60"
                    >
                      <span className="flex items-center gap-2.5">
                        {blockBusy ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          <ShieldCheck className="w-4 h-4" />
                        )}
                        <span>رفع الحظر</span>
                      </span>
                      <span className="text-[11px] font-semibold">
                        {formatBlockRemainingAr(blockedUntilMs)}
                      </span>
                    </button>
                  ) : showBlockOptions ? (
                    <div className="p-2.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/60 space-y-2">
                      <p className="text-xs font-bold text-rose-800 dark:text-rose-200">
                        اختر مدة الحظر:
                      </p>
                      <div className="grid grid-cols-1 gap-1.5">
                        <button
                          type="button"
                          onClick={() =>
                            setConfirmBlockChoice({
                              durationMs: WEEK_MS,
                              label: "حظر لمدة أسبوع (7 أيام)",
                            })
                          }
                          disabled={blockBusy}
                          className="min-h-[38px] px-3 py-1.5 rounded-lg bg-white dark:bg-[#111b21] border border-rose-200 dark:border-rose-800/60 text-rose-700 dark:text-rose-300 text-xs font-bold text-start hover:bg-rose-100/60 cursor-pointer"
                        >
                          حظر لمدة أسبوع (7 أيام)
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            setConfirmBlockChoice({
                              durationMs: MONTH_MS,
                              label: "حظر لمدة شهر (30 يوماً)",
                            })
                          }
                          disabled={blockBusy}
                          className="min-h-[38px] px-3 py-1.5 rounded-lg bg-white dark:bg-[#111b21] border border-rose-200 dark:border-rose-800/60 text-rose-700 dark:text-rose-300 text-xs font-bold text-start hover:bg-rose-100/60 cursor-pointer"
                        >
                          حظر لمدة شهر (30 يوماً)
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            setConfirmBlockChoice({
                              durationMs: null,
                              label: "حظر للأبد",
                            })
                          }
                          disabled={blockBusy}
                          className="min-h-[38px] px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold text-start cursor-pointer"
                        >
                          حظر للأبد
                        </button>
                      </div>
                      <button
                        type="button"
                        onClick={() => setShowBlockOptions(false)}
                        className="w-full min-h-[34px] rounded-lg bg-white dark:bg-[#111b21] text-slate-600 dark:text-slate-300 text-xs font-semibold cursor-pointer"
                      >
                        إلغاء
                      </button>
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={() => setShowBlockOptions(true)}
                      className="w-full min-h-[44px] px-3.5 py-2 rounded-xl border bg-rose-50 dark:bg-rose-950/40 border-rose-200 dark:border-rose-800/60 text-rose-600 dark:text-rose-400 text-sm font-bold flex items-center justify-between gap-2 transition-colors cursor-pointer"
                    >
                      <span className="flex items-center gap-2.5">
                        <Ban className="w-4 h-4" />
                        <span>حظر هذا المستخدم</span>
                      </span>
                    </button>
                  )}
                </>
              )}

              {confirmClear ? (
                <div className="p-2.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/60 space-y-2">
                  <p className="text-xs font-medium text-rose-800 dark:text-rose-200 leading-relaxed">
                    سيتم إخفاء هذه المحادثة وسجلها من جهازك وحسابك فقط، بينما تبقى محفوظة لدى الطرف الآخر.
                  </p>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => void handleDeleteForMe()}
                      disabled={deleteBusy}
                      className="min-h-[36px] px-3 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold flex items-center gap-1 cursor-pointer disabled:opacity-60"
                    >
                      {deleteBusy && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                      <span>حذف لدي فقط</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setConfirmClear(false)}
                      className="min-h-[36px] px-3 rounded-lg bg-white dark:bg-[#111b21] text-slate-700 dark:text-slate-200 text-xs font-semibold cursor-pointer"
                    >
                      إلغاء
                    </button>
                  </div>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => setConfirmClear(true)}
                  className="w-full min-h-[44px] px-3.5 py-2 rounded-xl bg-white dark:bg-[#111b21] border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:text-rose-600 dark:hover:text-rose-400 text-sm font-semibold flex items-center justify-between gap-2 transition-colors cursor-pointer"
                >
                  <span className="flex items-center gap-2.5">
                    <Trash2 className="w-4 h-4" />
                    <span>حذف المحادثة لدي فقط</span>
                  </span>
                </button>
              )}
            </div>
          </section>
        </div>
      </aside>

      {confirmBlockChoice && (
        <div
          role="alertdialog"
          aria-modal="true"
          aria-labelledby="drawer-confirm-block-title"
          className="fixed inset-0 z-[70] bg-black/65 backdrop-blur-xs flex items-center justify-center p-4"
          onClick={() => {
            if (!blockBusy) setConfirmBlockChoice(null);
          }}
        >
          <div
            dir="rtl"
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-sm bg-white dark:bg-[#111b21] border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-2xl space-y-4"
          >
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-2xl bg-rose-100 dark:bg-rose-950/70 text-rose-600 dark:text-rose-400 flex items-center justify-center shrink-0">
                <Ban className="w-5 h-5" />
              </div>
              <div className="space-y-1">
                <h3
                  id="drawer-confirm-block-title"
                  className="font-display font-bold text-base text-slate-900 dark:text-white"
                >
                  تأكيد الحظر
                </h3>
                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                  هل أنت متأكد من حظر هذا المستخدم؟ ({confirmBlockChoice.label})
                </p>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2">
              <button
                type="button"
                disabled={blockBusy}
                onClick={() => setConfirmBlockChoice(null)}
                className="min-h-[40px] px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-[#202c33] dark:hover:bg-[#2a3942] text-xs font-bold text-slate-700 dark:text-slate-200 cursor-pointer disabled:opacity-50"
              >
                إلغاء
              </button>
              <button
                type="button"
                disabled={blockBusy}
                onClick={() =>
                  void handleBlockChoice(confirmBlockChoice.durationMs)
                }
                className="min-h-[40px] px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer disabled:opacity-60"
              >
                {blockBusy ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Ban className="w-4 h-4" />
                )}
                <span>تأكيد</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
