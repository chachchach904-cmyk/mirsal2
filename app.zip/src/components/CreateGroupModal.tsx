import { useEffect, useState, type ChangeEvent, type FormEvent } from "react";
import { Check, ImagePlus, Loader2, Users, X } from "lucide-react";
import { DEFAULT_USER_AVATAR } from "../data/defaults";
import type { PeerUserProfile } from "../types/chat";
import { compressImageToDataUrl } from "../utils/storage";
import { Avatar } from "./Avatar";

interface CreateGroupModalProps {
  isOpen: boolean;
  friends: PeerUserProfile[];
  preselectedMemberUids: string[];
  onClose: () => void;
  onCreateGroup: (params: {
    groupName: string;
    groupAvatar: string;
    memberUids: string[];
  }) => Promise<void>;
}

export function CreateGroupModal({
  isOpen,
  friends,
  preselectedMemberUids,
  onClose,
  onCreateGroup,
}: CreateGroupModalProps) {
  const [groupName, setGroupName] = useState("");
  const [groupAvatar, setGroupAvatar] = useState(DEFAULT_USER_AVATAR);
  const [selectedUids, setSelectedUids] = useState<string[]>([]);
  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  const [creating, setCreating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!isOpen) return;
    setGroupName("");
    setGroupAvatar(DEFAULT_USER_AVATAR);
    setSelectedUids(preselectedMemberUids);
    setUploadingPhoto(false);
    setError(null);
  }, [isOpen, preselectedMemberUids]);

  if (!isOpen) return null;

  const handleGroupPhotoUpload = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingPhoto(true);
    setError(null);
    try {
      const compressed = await compressImageToDataUrl(file, 256, 0.78, 72000);
      setGroupAvatar(compressed);
    } catch (err) {
      setError(err instanceof Error ? err.message : "تعذر تحميل صورة المجموعة.");
    } finally {
      setUploadingPhoto(false);
      e.target.value = "";
    }
  };

  const toggleMember = (uid: string) => {
    setSelectedUids((prev) =>
      prev.includes(uid) ? prev.filter((id) => id !== uid) : [...prev, uid]
    );
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    const cleanName = groupName.trim();
    if (cleanName.length < 2) {
      setError("يرجى إدخال اسم للمجموعة لا يقل عن حرفين.");
      return;
    }
    if (selectedUids.length === 0) {
      setError("يرجى اختيار صديق واحد على الأقل لإنشاء المجموعة.");
      return;
    }

    setCreating(true);
    setError(null);
    try {
      await onCreateGroup({
        groupName: cleanName,
        groupAvatar,
        memberUids: selectedUids,
      });
      onClose();
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "تعذر إنشاء المجموعة حالياً."
      );
    } finally {
      setCreating(false);
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="إنشاء مجموعة جديدة"
      className="fixed inset-0 z-50 bg-black/55 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4"
    >
      <div className="w-full max-w-md bg-white dark:bg-[#111b21] rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden flex flex-col max-h-[88dvh]">
        <header className="px-5 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between gap-3 bg-slate-50/70 dark:bg-[#202c33]">
          <div className="flex items-center gap-2.5">
            <Users className="w-5 h-5 text-[#0d7a5f] dark:text-[#00a884]" />
            <h2 className="font-display font-bold text-base text-slate-900 dark:text-white">
              إنشاء مجموعة جديدة
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="إغلاق"
            className="min-h-[40px] min-w-[40px] rounded-xl flex items-center justify-center text-slate-500 hover:bg-slate-200/70 dark:text-slate-300 dark:hover:bg-slate-700/50 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </header>

        <form
          onSubmit={(e) => void handleSubmit(e)}
          className="flex-1 overflow-y-auto custom-scrollbar p-5 space-y-4"
        >
          <div className="flex items-center gap-3">
            <label
              htmlFor="group-avatar-upload"
              title="رفع صورة للمجموعة"
              className="relative shrink-0 rounded-full ring-2 ring-emerald-500/30 hover:ring-[#0d7a5f] transition-all cursor-pointer"
            >
              <Avatar
                src={groupAvatar}
                name={groupName || "مجموعة"}
                size="lg"
              />
              <span className="absolute -bottom-0.5 -left-0.5 w-6 h-6 rounded-full bg-[#0d7a5f] dark:bg-[#00a884] text-white border-2 border-white dark:border-[#111b21] flex items-center justify-center shadow">
                {uploadingPhoto ? (
                  <Loader2 className="w-3 h-3 animate-spin" />
                ) : (
                  <ImagePlus className="w-3 h-3" />
                )}
              </span>
              <input
                id="group-avatar-upload"
                type="file"
                disabled={uploadingPhoto}
                onClick={(e) => {
                  e.currentTarget.value = "";
                }}
                onChange={(e) => void handleGroupPhotoUpload(e)}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              />
            </label>
            <div className="flex-1 min-w-0">
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                اسم المجموعة
              </label>
              <input
                type="text"
                value={groupName}
                onChange={(e) => setGroupName(e.target.value)}
                maxLength={60}
                placeholder="مثال: أصدقاء السفر"
                className="w-full min-h-[42px] px-3.5 rounded-xl bg-slate-100 dark:bg-[#202c33] text-sm text-slate-900 dark:text-white border border-transparent focus:border-[#0d7a5f] focus:outline-none"
              />
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs font-semibold text-slate-600 dark:text-slate-300">
              <span>اختر الأعضاء</span>
              <span className="text-[#0d7a5f] dark:text-[#00a884]">
                تم اختيار {selectedUids.length}
              </span>
            </div>

            {friends.length === 0 ? (
              <p className="text-xs text-slate-500 dark:text-slate-400 bg-slate-50 dark:bg-[#202c33] p-4 rounded-2xl text-center">
                أضف أصدقاء أولاً من «محادثة جديدة» لتتمكن من إضافتهم إلى مجموعة.
              </p>
            ) : (
              <div className="space-y-1.5 max-h-56 overflow-y-auto custom-scrollbar">
                {friends.map((friend) => {
                  const isSelected = selectedUids.includes(friend.uid);
                  return (
                    <button
                      key={friend.uid}
                      type="button"
                      onClick={() => toggleMember(friend.uid)}
                      className={`w-full flex items-center justify-between gap-3 p-2.5 rounded-2xl border transition-colors cursor-pointer ${
                        isSelected
                          ? "bg-emerald-50/80 dark:bg-emerald-950/40 border-[#0d7a5f] dark:border-[#00a884]"
                          : "bg-slate-50 dark:bg-[#202c33] border-slate-200/70 dark:border-slate-700/60"
                      }`}
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <Avatar
                          src={friend.photoURL || friend.avatar}
                          name={friend.displayName}
                          size="sm"
                        />
                        <span className="text-xs font-bold text-slate-800 dark:text-slate-100 truncate">
                          {friend.displayName}
                        </span>
                      </div>
                      <span
                        className={`w-5 h-5 rounded-full flex items-center justify-center shrink-0 ${
                          isSelected
                            ? "bg-[#0d7a5f] dark:bg-[#00a884] text-white"
                            : "border border-slate-400"
                        }`}
                      >
                        {isSelected && <Check className="w-3 h-3" />}
                      </span>
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {error && (
            <p className="text-xs font-medium text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/40 px-3 py-2 rounded-xl">
              {error}
            </p>
          )}

          <div className="flex items-center justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="min-h-[42px] px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-[#202c33] dark:hover:bg-[#2a3942] text-xs font-bold text-slate-700 dark:text-slate-200 cursor-pointer"
            >
              إلغاء
            </button>
            <button
              type="submit"
              disabled={creating}
              className="min-h-[42px] px-5 py-2 rounded-xl bg-[#0d7a5f] hover:bg-[#0a634d] dark:bg-[#00a884] dark:hover:bg-[#069475] text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer disabled:opacity-60"
            >
              {creating ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Check className="w-4 h-4" />
              )}
              <span>إنشاء المجموعة</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
