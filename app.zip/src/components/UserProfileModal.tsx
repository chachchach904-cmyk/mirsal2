import { useEffect, useState } from "react";
import {
  Briefcase,
  Calendar,
  Eye,
  Heart,
  Loader2,
  Lock,
  MapPin,
  MessageCircle,
  Phone,
  UserMinus,
  UserPlus,
  Users,
  Video,
  X,
} from "lucide-react";
import { getCountryByCode } from "../data/countries";
import { isDataUrlAvatar, isImageUrlAvatar } from "../data/defaults";
import { fetchUsersByUids } from "../services/firebase";
import type { CallType, PeerUserProfile } from "../types/chat";
import {
  formatJoinMonthYearAr,
  formatLastSeen,
  formatMaritalStatusAr,
  resolveCoverPresetClass,
} from "../utils/storage";
import { Avatar } from "./Avatar";
import { ProfilePhotoLightbox } from "./ProfilePhotoLightbox";

interface UserProfileModalProps {
  isOpen: boolean;
  peer: PeerUserProfile | null;
  currentUid: string;
  myFriendUids: string[];
  knownPeersByUid?: Record<string, PeerUserProfile>;
  onClose: () => void;
  onAddFriend: (uid: string) => Promise<void>;
  onRemoveFriend: (uid: string) => Promise<void>;
  onStartChat: (peer: PeerUserProfile) => Promise<void>;
  onStartCallWithPeer?: (peer: PeerUserProfile, callType: CallType) => Promise<void>;
  onSelectFriendProfile?: (friendPeer: PeerUserProfile) => void;
}

export function UserProfileModal({
  isOpen,
  peer,
  currentUid,
  myFriendUids,
  knownPeersByUid = {},
  onClose,
  onAddFriend,
  onRemoveFriend,
  onStartChat,
  onStartCallWithPeer,
  onSelectFriendProfile,
}: UserProfileModalProps) {
  const [busy, setBusy] = useState(false);
  const [showAllFriends, setShowAllFriends] = useState(false);
  const [peerFriendProfiles, setPeerFriendProfiles] = useState<PeerUserProfile[]>([]);
  const [loadingPeerFriends, setLoadingPeerFriends] = useState(false);
  const [cardGlassMode, setCardGlassMode] = useState<"transparent" | "solid">(() => {
    try {
      return localStorage.getItem("mirsal_profile_glass_mode") === "solid"
        ? "solid"
        : "transparent";
    } catch {
      return "transparent";
    }
  });
  const [lightboxPhoto, setLightboxPhoto] = useState<{
    src: string;
    alt: string;
  } | null>(null);

  const isMe = peer?.uid === currentUid;
  const peerApprovedMe = Boolean(peer?.friends?.includes(currentUid));
  const isLockedForMe = Boolean(peer?.isProfileLocked) && !peerApprovedMe && !isMe;
  const canShowFriends = peer ? peer.showFriends !== false && !isLockedForMe : false;

  const friendUidsKey = (peer?.friends || []).slice(0, 24).join(",");

  useEffect(() => {
    setShowAllFriends(false);
    setLightboxPhoto(null);
  }, [peer?.uid, isOpen]);

  useEffect(() => {
    if (!isOpen || !peer || !canShowFriends) {
      setPeerFriendProfiles([]);
      return;
    }
    const targetUids = (peer.friends || []).filter((id) => Boolean(id)).slice(0, 18);
    if (targetUids.length === 0) {
      setPeerFriendProfiles([]);
      return;
    }

    const immediate: PeerUserProfile[] = [];
    const missing: string[] = [];
    targetUids.forEach((uid) => {
      if (knownPeersByUid[uid]) {
        immediate.push(knownPeersByUid[uid]);
      } else {
        missing.push(uid);
      }
    });
    setPeerFriendProfiles(immediate);

    if (missing.length === 0) return;

    let cancelled = false;
    setLoadingPeerFriends(true);
    void fetchUsersByUids(missing)
      .then((fetched) => {
        if (cancelled) return;
        const resolved = targetUids
          .map((uid) => knownPeersByUid[uid] || fetched[uid])
          .filter((item): item is PeerUserProfile => Boolean(item));
        setPeerFriendProfiles(resolved);
      })
      .finally(() => {
        if (!cancelled) setLoadingPeerFriends(false);
      });

    return () => {
      cancelled = true;
    };
  }, [isOpen, peer?.uid, canShowFriends, friendUidsKey]);

  if (!isOpen || !peer) return null;

  const isFriend = myFriendUids.includes(peer.uid);
  const canShowLastSeen = peer.showLastSeen !== false && !isLockedForMe;
  const canShowAgeCity = peer.showAgeCity !== false && !isLockedForMe;
  const canShowPersonalInfo = peer.showPersonalInfo !== false && !isLockedForMe;

  const country = canShowPersonalInfo ? getCountryByCode(peer.countryCode) : null;
  const isCustomCoverImage = Boolean(
    peer.coverPhoto &&
      (peer.coverPhoto.startsWith("data:image/") ||
        /^https?:\/\//i.test(peer.coverPhoto))
  );
  const peerAvatarSrc = peer.photoURL || peer.avatar || "";
  const hasPeerAvatarPhoto =
    isDataUrlAvatar(peerAvatarSrc) || isImageUrlAvatar(peerAvatarSrc);
  const canExpandCover = isCustomCoverImage && !isLockedForMe && Boolean(peer.coverPhoto);
  const canExpandAvatar = hasPeerAvatarPhoto && !isLockedForMe;
  const cardGlassClass =
    cardGlassMode === "transparent"
      ? "bg-slate-900/35 backdrop-blur-sm border border-white/20 text-white shadow-lg [text-shadow:0_1px_2px_rgba(0,0,0,0.65)]"
      : "bg-slate-900/85 backdrop-blur-md border border-white/15 text-white shadow-xl [text-shadow:0_1px_2px_rgba(0,0,0,0.45)]";
  const handleToggleGlassMode = () => {
    setCardGlassMode((prev) => {
      const next = prev === "transparent" ? "solid" : "transparent";
      try {
        localStorage.setItem("mirsal_profile_glass_mode", next);
      } catch {
        // ignore storage errors
      }
      return next;
    });
  };
  const displayedFriends = showAllFriends
    ? peerFriendProfiles
    : peerFriendProfiles.slice(0, 6);

  const handleToggleFriend = async () => {
    setBusy(true);
    try {
      if (isFriend) {
        await onRemoveFriend(peer.uid);
      } else {
        await onAddFriend(peer.uid);
      }
    } finally {
      setBusy(false);
    }
  };

  const handleChat = async () => {
    setBusy(true);
    try {
      await onStartChat(peer);
      onClose();
    } finally {
      setBusy(false);
    }
  };

  const handleCall = async (callType: CallType) => {
    if (!onStartCallWithPeer) return;
    setBusy(true);
    try {
      onClose();
      await onStartCallWithPeer(peer, callType);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={`ملف ${peer.displayName}`}
      className="fixed inset-0 z-50 bg-black/55 backdrop-blur-xs flex items-center justify-center p-2.5 sm:p-4"
    >
      <div className="relative w-full max-w-md rounded-3xl border border-white/20 shadow-2xl overflow-hidden flex flex-col max-h-[90dvh] bg-slate-900">
        {/* Full-Screen Cover Background Layer */}
        <div className="absolute inset-0 z-0 pointer-events-none">
          {canExpandCover && peer.coverPhoto ? (
            <img
              src={peer.coverPhoto}
              alt={`غلاف ${peer.displayName}`}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
          ) : (
            <div
              className={`w-full h-full bg-gradient-to-br ${resolveCoverPresetClass(
                isLockedForMe ? "cover:emerald" : peer.coverPhoto
              )}`}
            />
          )}
          <div className="absolute inset-0 bg-gradient-to-b from-black/35 via-black/25 to-black/70" />
        </div>

        <header className="relative z-10 px-4 py-3 border-b border-white/15 flex items-center justify-between gap-2 bg-slate-900/55 backdrop-blur-md text-white shrink-0">
          <h2 className="font-display font-bold text-sm sm:text-base text-white truncate [text-shadow:0_1px_2px_rgba(0,0,0,0.6)]">
            الملف الشخصي
          </h2>

          <div className="flex items-center gap-1.5 shrink-0">
            <button
              type="button"
              onClick={handleToggleGlassMode}
              className="min-h-[34px] px-2.5 py-1 rounded-xl bg-white/15 hover:bg-white/25 border border-white/25 text-white text-[11px] font-bold flex items-center gap-1.5 cursor-pointer transition-colors"
            >
              <Eye className="w-3.5 h-3.5 text-emerald-300 shrink-0" />
              <span>
                شفافية البطاقات: {cardGlassMode === "transparent" ? "شفاف" : "واضح"}
              </span>
            </button>

            <button
              type="button"
              onClick={onClose}
              aria-label="إغلاق"
              className="min-h-[36px] min-w-[36px] rounded-xl flex items-center justify-center text-white/90 hover:bg-white/15 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </header>

        <div className="relative z-10 flex-1 overflow-y-auto custom-scrollbar">
          {/* Top Cover Showcase + Overlapping Avatar */}
          <div className="relative">
            <div
              role={canExpandCover ? "button" : undefined}
              tabIndex={canExpandCover ? 0 : undefined}
              aria-label={canExpandCover ? "عرض صورة الغلاف بالكامل" : undefined}
              onClick={() => {
                if (canExpandCover && peer.coverPhoto) {
                  setLightboxPhoto({
                    src: peer.coverPhoto,
                    alt: `غلاف ${peer.displayName}`,
                  });
                }
              }}
              onKeyDown={(e) => {
                if (
                  canExpandCover &&
                  peer.coverPhoto &&
                  (e.key === "Enter" || e.key === " ")
                ) {
                  e.preventDefault();
                  setLightboxPhoto({
                    src: peer.coverPhoto,
                    alt: `غلاف ${peer.displayName}`,
                  });
                }
              }}
              className={`h-32 sm:h-40 w-full ${
                canExpandCover ? "cursor-pointer" : ""
              }`}
            />

            <div className="px-5 flex flex-col items-center text-center -mt-12 relative z-10">
              <div className="relative p-1 rounded-full bg-slate-900/70 backdrop-blur-md ring-2 ring-white/30 shadow-xl">
                <button
                  type="button"
                  onClick={() => {
                    if (canExpandAvatar) {
                      setLightboxPhoto({
                        src: peerAvatarSrc,
                        alt: peer.displayName,
                      });
                    }
                  }}
                  aria-label={
                    canExpandAvatar
                      ? `عرض صورة ${peer.displayName} بالكامل`
                      : peer.displayName
                  }
                  className={`rounded-full block ${
                    canExpandAvatar ? "cursor-pointer" : "cursor-default"
                  }`}
                >
                  <Avatar
                    src={peerAvatarSrc}
                    name={peer.displayName}
                    size="xl"
                  />
                </button>
                {canShowLastSeen && peer.isOnline && (
                  <span className="absolute bottom-1.5 left-1.5 w-3.5 h-3.5 rounded-full bg-emerald-500 ring-2 ring-white" />
                )}
              </div>

              <div className={`mt-3 w-full rounded-2xl p-4 space-y-1 ${cardGlassClass}`}>
                <h3 className="font-display font-bold text-lg text-white flex items-center justify-center gap-1.5">
                  {country?.flag && <span>{country.flag}</span>}
                  <span>{peer.displayName}</span>
                </h3>
                {canShowLastSeen && (
                  <p className="text-xs text-slate-200">
                    {formatLastSeen(peer.lastSeen, peer.isOnline)}
                  </p>
                )}
                {!isLockedForMe && peer.bio && (
                  <p className="text-xs text-slate-100 leading-relaxed max-w-xs mx-auto pt-0.5">
                    {peer.bio}
                  </p>
                )}
              </div>
            </div>
          </div>

          <div className="p-5 space-y-4">
            {/* Quick Action Buttons */}
            {!isMe && (
              <div className={`p-2.5 rounded-2xl ${cardGlassClass}`}>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  <button
                    type="button"
                    disabled={busy}
                    onClick={() => void handleChat()}
                    className="min-h-[42px] px-3 py-2 rounded-xl bg-[#00a884] hover:bg-[#069475] text-white text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-60 shadow"
                  >
                    {busy ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <MessageCircle className="w-3.5 h-3.5" />
                    )}
                    <span>رسالة</span>
                  </button>

                  {onStartCallWithPeer && (
                    <>
                      <button
                        type="button"
                        disabled={busy}
                        onClick={() => void handleCall("audio")}
                        className="min-h-[42px] px-3 py-2 rounded-xl bg-white/15 hover:bg-white/25 border border-white/20 text-white text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-60"
                      >
                        <Phone className="w-3.5 h-3.5 text-emerald-300" />
                        <span>مكالمة صوتية</span>
                      </button>

                      <button
                        type="button"
                        disabled={busy}
                        onClick={() => void handleCall("video")}
                        className="min-h-[42px] px-3 py-2 rounded-xl bg-white/15 hover:bg-white/25 border border-white/20 text-white text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-60"
                      >
                        <Video className="w-3.5 h-3.5 text-emerald-300" />
                        <span>مكالمة فيديو</span>
                      </button>
                    </>
                  )}

                  <button
                    type="button"
                    disabled={busy}
                    onClick={() => void handleToggleFriend()}
                    className={`min-h-[42px] px-3 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-60 border ${
                      isFriend
                        ? "bg-rose-600/80 hover:bg-rose-600 text-white border-rose-400/40"
                        : "bg-white/15 hover:bg-white/25 text-white border-white/20"
                    }`}
                  >
                    {isFriend ? (
                      <>
                        <UserMinus className="w-3.5 h-3.5" />
                        <span>إزالة صديق</span>
                      </>
                    ) : (
                      <>
                        <UserPlus className="w-3.5 h-3.5" />
                        <span>إضافة صديق</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}

            {isLockedForMe ? (
              <div className={`p-4 rounded-2xl text-center space-y-2 ${cardGlassClass}`}>
                <Lock className="w-6 h-6 mx-auto text-emerald-300" />
                <p className="text-xs font-bold text-white">
                  هذا الملف الشخصي مقفل
                </p>
                <p className="text-[11px] text-slate-200">
                  تظهر التفاصيل الكاملة والأصدقاء فقط بعد تبادل الصداقة.
                </p>
              </div>
            ) : (
              <>
                {/* About Section */}
                <div className={`space-y-2.5 rounded-2xl p-4 text-xs ${cardGlassClass}`}>
                  <p className="font-bold text-white">حول</p>

                  {canShowAgeCity && (peer.age || peer.city) && (
                    <div className="flex items-center gap-2 text-slate-100">
                      <MapPin className="w-4 h-4 text-emerald-300 shrink-0" />
                      <span>
                        {[
                          peer.city ? peer.city : null,
                          typeof peer.age === "number" ? `${peer.age} سنة` : null,
                        ]
                          .filter(Boolean)
                          .join(" · ")}
                      </span>
                    </div>
                  )}

                  {canShowPersonalInfo &&
                    peer.maritalStatus &&
                    peer.maritalStatus !== "unspecified" && (
                      <div className="flex items-center gap-2 text-slate-100">
                        <Heart className="w-4 h-4 text-emerald-300 shrink-0" />
                        <span>{formatMaritalStatusAr(peer.maritalStatus)}</span>
                      </div>
                    )}

                  {canShowPersonalInfo && peer.workOrStudy && (
                    <div className="flex items-center gap-2 text-slate-100">
                      <Briefcase className="w-4 h-4 text-emerald-300 shrink-0" />
                      <span>{peer.workOrStudy}</span>
                    </div>
                  )}

                  {canShowFriends && Array.isArray(peer.friends) && (
                    <div className="flex items-center gap-2 text-slate-100">
                      <Users className="w-4 h-4 text-emerald-300 shrink-0" />
                      <span>{peer.friends.length} أصدقاء</span>
                    </div>
                  )}

                  <div className="flex items-center gap-2 text-slate-200">
                    <Calendar className="w-4 h-4 text-emerald-300 shrink-0" />
                    <span>{formatJoinMonthYearAr(peer.joinedAt)}</span>
                  </div>
                </div>

                {/* Facebook-Style Friends Grid */}
                {canShowFriends && Array.isArray(peer.friends) && peer.friends.length > 0 && (
                  <div className={`rounded-2xl p-4 space-y-3 ${cardGlassClass}`}>
                    <div className="flex items-center justify-between gap-2">
                      <p className="text-xs font-bold text-white">
                        الأصدقاء ({peer.friends.length})
                      </p>
                      {peerFriendProfiles.length > 6 && (
                        <button
                          type="button"
                          onClick={() => setShowAllFriends((v) => !v)}
                          className="text-[11px] font-bold text-emerald-300 hover:underline cursor-pointer"
                        >
                          {showAllFriends ? "عرض أقل" : "عرض الكل"}
                        </button>
                      )}
                    </div>

                    {loadingPeerFriends && peerFriendProfiles.length === 0 ? (
                      <div className="flex items-center gap-2 text-xs text-slate-200 py-2">
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        <span>جاري تحميل الأصدقاء...</span>
                      </div>
                    ) : (
                      <div className="grid grid-cols-3 gap-2">
                        {displayedFriends.map((friend) => (
                          <button
                            key={friend.uid}
                            type="button"
                            onClick={() => {
                              if (onSelectFriendProfile) {
                                onSelectFriendProfile(friend);
                              }
                            }}
                            className="p-2 rounded-xl bg-slate-950/50 border border-white/15 flex flex-col items-center text-center gap-1.5 hover:border-emerald-300/60 transition-colors cursor-pointer"
                          >
                            <Avatar
                              src={friend.photoURL || friend.avatar}
                              name={friend.displayName}
                              size="md"
                            />
                            <span className="text-[11px] font-bold text-white truncate w-full">
                              {friend.displayName}
                            </span>
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </div>

      <ProfilePhotoLightbox
        src={lightboxPhoto?.src || null}
        alt={lightboxPhoto?.alt}
        onClose={() => setLightboxPhoto(null)}
      />
    </div>
  );
}
