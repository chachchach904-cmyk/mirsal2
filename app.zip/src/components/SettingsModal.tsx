import { useEffect, useRef, useState } from "react";
import {
  ArrowRight,
  Moon,
  Sun,
  Trash2,
  LogOut,
  Check,
  Loader2,
  ShieldBan,
  ShieldCheck,
  Users,
  Volume2,
  VolumeX,
  Type,
  EyeOff,
  Play,
  Music,
  ChevronDown,
  Smartphone,
  Bell,
  AlertTriangle,
  Lock,
  KeyRound,
  ShieldAlert,
} from "lucide-react";
import { getCountryByCode } from "../data/countries";
import type {
  FontFamilyId,
  FontSizeId,
  NotificationPrefs,
  PeerUserProfile,
  SoundPrefs,
  ThemeMode,
  TypographyPrefs,
  UserProfile,
} from "../types/chat";
import {
  changeAccountPassword,
  fetchUsersByUids,
  revokeAllUserSessions,
} from "../services/firebase";
import {
  MESSAGE_TONE_OPTIONS,
  RINGTONE_OPTIONS,
  playSaveClickSound,
  previewMessageTone,
  previewRingtone,
  stopCallVibration,
  stopRingtone,
} from "../services/sounds";
import {
  getNotificationPermissionState,
  registerMirsalServiceWorker,
  requestImmediateNotificationPermission,
  syncWebPushSubscription,
  updateAppIconBadge,
} from "../services/notifications";
import {
  formatBlockRemainingAr,
  hasAppLockPin,
  saveAppLockPin,
  saveLocalSessionVersion,
  verifyAppLockPin,
} from "../utils/storage";
import { Avatar } from "./Avatar";

interface SettingsModalProps {
  isOpen: boolean;
  user: UserProfile;
  theme: ThemeMode;
  friendsCount: number;
  knownPeersByUid: Record<string, PeerUserProfile>;
  soundPrefs: SoundPrefs;
  typographyPrefs: TypographyPrefs;
  notificationPrefs: NotificationPrefs;
  onClose: () => void;
  onUpdateProfile: (nextUser: UserProfile) => Promise<void>;
  onUnblockUser: (targetUid: string) => Promise<void>;
  onSetTheme: (theme: ThemeMode) => void;
  onChangeSoundPrefs: (next: SoundPrefs) => void;
  onChangeTypographyPrefs: (next: TypographyPrefs) => void;
  onChangeNotificationPrefs: (next: NotificationPrefs) => void;
  onClearAllConversations: () => Promise<void>;
  onDeleteAccount: () => Promise<void>;
  onLogout: () => void;
}

const FONT_FAMILY_OPTIONS: Array<{
  id: FontFamilyId;
  label: string;
  previewClass: string;
}> = [
  {
    id: "whatsapp",
    label: "الافتراضي (IBM Plex)",
    previewClass: "mirsal-preview-whatsapp",
  },
  {
    id: "cairo",
    label: "القاهرة (Cairo)",
    previewClass: "mirsal-preview-cairo",
  },
  {
    id: "tajawal",
    label: "تجوّل (Tajawal)",
    previewClass: "mirsal-preview-tajawal",
  },
  {
    id: "almarai",
    label: "المراعي (Almarai)",
    previewClass: "mirsal-preview-almarai",
  },
  {
    id: "amiri",
    label: "أميري (Amiri)",
    previewClass: "mirsal-preview-amiri",
  },
];

const FONT_SIZE_OPTIONS: Array<{ id: FontSizeId; label: string }> = [
  { id: "sm", label: "صغير" },
  { id: "md", label: "متوسط" },
  { id: "lg", label: "كبير (افتراضي)" },
  { id: "xl", label: "كبير جداً" },
];

export function SettingsModal({
  isOpen,
  user,
  theme,
  friendsCount,
  knownPeersByUid,
  soundPrefs,
  typographyPrefs,
  notificationPrefs,
  onClose,
  onUpdateProfile,
  onUnblockUser,
  onSetTheme,
  onChangeSoundPrefs,
  onChangeTypographyPrefs,
  onChangeNotificationPrefs,
  onClearAllConversations,
  onDeleteAccount,
  onLogout,
}: SettingsModalProps) {
  const [isProfileLocked, setIsProfileLocked] = useState(
    Boolean(user.isProfileLocked)
  );
  const [showLastSeen, setShowLastSeen] = useState(user.showLastSeen !== false);
  const [showAgeCity, setShowAgeCity] = useState(user.showAgeCity !== false);
  const [showPersonalInfo, setShowPersonalInfo] = useState(
    user.showPersonalInfo !== false
  );
  const [showFriends, setShowFriends] = useState(user.showFriends !== false);

  const [privacySavedNotice, setPrivacySavedNotice] = useState(false);
  const [confirmClearAll, setConfirmClearAll] = useState(false);
  const [clearingAll, setClearingAll] = useState(false);
  const [showDeleteAccountConfirm, setShowDeleteAccountConfirm] =
    useState(false);
  const [deletingAccount, setDeletingAccount] = useState(false);
  const [deleteAccountError, setDeleteAccountError] = useState<string | null>(
    null
  );

  const [blockedProfiles, setBlockedProfiles] = useState<
    Record<string, PeerUserProfile>
  >({});
  const [loadingBlocked, setLoadingBlocked] = useState(false);
  const [unblockingUid, setUnblockingUid] = useState<string | null>(null);
  const [showRingtonePicker, setShowRingtonePicker] = useState(false);
  const [notifPermission, setNotifPermission] = useState<
    NotificationPermission | "unsupported"
  >(() => getNotificationPermissionState());
  const [notifToggleNotice, setNotifToggleNotice] = useState<string | null>(
    null
  );
  const [appLockEnabled, setAppLockEnabled] = useState<boolean>(() =>
    hasAppLockPin(user.uid)
  );
  const [showPinSetup, setShowPinSetup] = useState(false);
  const [pinStepInput, setPinStepInput] = useState("");
  const [pinConfirmInput, setPinConfirmInput] = useState("");
  const [pinStatusMsg, setPinStatusMsg] = useState<{
    type: "success" | "error";
    text: string;
  } | null>(null);
  const [savingPin, setSavingPin] = useState(false);

  const [showPasswordForm, setShowPasswordForm] = useState(false);
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmNewPassword, setConfirmNewPassword] = useState("");
  const [passwordStatusMsg, setPasswordStatusMsg] = useState<{
    type: "success" | "error";
    text: string;
  } | null>(null);
  const [changingPassword, setChangingPassword] = useState(false);

  const [revokingSessions, setRevokingSessions] = useState(false);
  const [showRevokeSessionsConfirm, setShowRevokeSessionsConfirm] = useState(false);
  const [sessionsStatusMsg, setSessionsStatusMsg] = useState<{
    type: "success" | "error";
    text: string;
  } | null>(null);

  const privacyNoticeTimerRef = useRef<ReturnType<typeof setTimeout> | null>(
    null
  );

  const blockedUids = user.blockedUsers || [];
  const blockedKey = blockedUids.join(",");

  useEffect(() => {
    if (isOpen) {
      setIsProfileLocked(Boolean(user.isProfileLocked));
      setShowLastSeen(user.showLastSeen !== false);
      setShowAgeCity(user.showAgeCity !== false);
      setShowPersonalInfo(user.showPersonalInfo !== false);
      setShowFriends(user.showFriends !== false);
      setPrivacySavedNotice(false);
      setConfirmClearAll(false);
      setClearingAll(false);
      setShowDeleteAccountConfirm(false);
      setDeletingAccount(false);
      setDeleteAccountError(null);
      setShowRingtonePicker(false);
      setNotifPermission(getNotificationPermissionState());
      setAppLockEnabled(hasAppLockPin(user.uid));
      setShowPinSetup(false);
      setPinStepInput("");
      setPinConfirmInput("");
      setPinStatusMsg(null);
      setShowPasswordForm(false);
      setCurrentPassword("");
      setNewPassword("");
      setConfirmNewPassword("");
      setPasswordStatusMsg(null);
      setShowRevokeSessionsConfirm(false);
      setSessionsStatusMsg(null);
    } else {
      if (privacyNoticeTimerRef.current) {
        clearTimeout(privacyNoticeTimerRef.current);
        privacyNoticeTimerRef.current = null;
      }
      stopRingtone();
    }
  }, [isOpen, user]);

  useEffect(() => {
    return () => {
      if (privacyNoticeTimerRef.current) {
        clearTimeout(privacyNoticeTimerRef.current);
      }
    };
  }, []);

  useEffect(() => {
    if (!isOpen || blockedUids.length === 0) {
      setBlockedProfiles({});
      return;
    }

    const missing = blockedUids.filter(
      (uid) => !knownPeersByUid[uid] && !blockedProfiles[uid]
    );
    if (missing.length === 0) return;

    let cancelled = false;
    setLoadingBlocked(true);
    void fetchUsersByUids(missing)
      .then((fetched) => {
        if (cancelled) return;
        setBlockedProfiles((prev) => ({ ...prev, ...fetched }));
      })
      .finally(() => {
        if (!cancelled) setLoadingBlocked(false);
      });

    return () => {
      cancelled = true;
    };
  }, [isOpen, blockedKey, knownPeersByUid]);

  if (!isOpen) return null;

  const handleTogglePrivacy = async (
    key:
      | "isProfileLocked"
      | "showLastSeen"
      | "showAgeCity"
      | "showPersonalInfo"
      | "showFriends"
  ) => {
    playSaveClickSound();
    const nextState = {
      isProfileLocked:
        key === "isProfileLocked" ? !isProfileLocked : isProfileLocked,
      showLastSeen: key === "showLastSeen" ? !showLastSeen : showLastSeen,
      showAgeCity: key === "showAgeCity" ? !showAgeCity : showAgeCity,
      showPersonalInfo:
        key === "showPersonalInfo" ? !showPersonalInfo : showPersonalInfo,
      showFriends: key === "showFriends" ? !showFriends : showFriends,
    };

    setIsProfileLocked(nextState.isProfileLocked);
    setShowLastSeen(nextState.showLastSeen);
    setShowAgeCity(nextState.showAgeCity);
    setShowPersonalInfo(nextState.showPersonalInfo);
    setShowFriends(nextState.showFriends);

    try {
      await onUpdateProfile({
        ...user,
        ...nextState,
      });
      setPrivacySavedNotice(true);
      if (privacyNoticeTimerRef.current) {
        clearTimeout(privacyNoticeTimerRef.current);
      }
      privacyNoticeTimerRef.current = setTimeout(() => {
        setPrivacySavedNotice(false);
      }, 2000);
    } catch {
      // ignore transient error; Firestore listener will keep state consistent
    }
  };

  const handleConfirmClear = async () => {
    setClearingAll(true);
    try {
      await onClearAllConversations();
      setConfirmClearAll(false);
    } finally {
      setClearingAll(false);
    }
  };

  const handleUnblockClick = async (targetUid: string) => {
    if (unblockingUid) return;
    setUnblockingUid(targetUid);
    try {
      await onUnblockUser(targetUid);
    } finally {
      setUnblockingUid(null);
    }
  };

  const handleSaveAppLockPin = async () => {
    setPinStatusMsg(null);
    const cleanPin = pinStepInput.trim();
    const cleanConfirm = pinConfirmInput.trim();
    if (!/^\d{4}$/.test(cleanPin)) {
      setPinStatusMsg({
        type: "error",
        text: "يرجى إدخال رمز قفل مكون من 4 أرقام بالضبط.",
      });
      return;
    }
    if (cleanPin !== cleanConfirm) {
      setPinStatusMsg({
        type: "error",
        text: "الرمزان غير متطابقين. تأكد من إعادة إدخال نفس الأرقام.",
      });
      return;
    }
    if (!user.uid) return;
    setSavingPin(true);
    try {
      await saveAppLockPin(user.uid, cleanPin);
      setAppLockEnabled(true);
      setShowPinSetup(false);
      setPinStepInput("");
      setPinConfirmInput("");
      setPinStatusMsg({
        type: "success",
        text: "تم تفعيل قفل التطبيق برمز مكون من 4 أرقام بنجاح.",
      });
    } finally {
      setSavingPin(false);
    }
  };

  const handleDisableAppLockPin = async () => {
    setPinStatusMsg(null);
    const cleanPin = pinStepInput.trim();
    if (!/^\d{4}$/.test(cleanPin)) {
      setPinStatusMsg({
        type: "error",
        text: "أدخل الرمز الحالي المكوّن من 4 أرقام لإلغاء القفل.",
      });
      return;
    }
    if (!user.uid) return;
    setSavingPin(true);
    try {
      const ok = await verifyAppLockPin(user.uid, cleanPin);
      if (!ok) {
        setPinStatusMsg({
          type: "error",
          text: "رمز القفل الحالي غير صحيح.",
        });
        return;
      }
      await saveAppLockPin(user.uid, null);
      setAppLockEnabled(false);
      setShowPinSetup(false);
      setPinStepInput("");
      setPinConfirmInput("");
      setPinStatusMsg({
        type: "success",
        text: "تم إيقاف قفل التطبيق.",
      });
    } finally {
      setSavingPin(false);
    }
  };

  const handleSubmitPasswordChange = async () => {
    setPasswordStatusMsg(null);
    if (!currentPassword.trim()) {
      setPasswordStatusMsg({
        type: "error",
        text: "يرجى إدخال كلمة المرور أو رمز PIN الحالي.",
      });
      return;
    }
    if (newPassword.trim().length < 6) {
      setPasswordStatusMsg({
        type: "error",
        text: "يجب أن تتكون كلمة المرور الجديدة من 6 أحرف أو أرقام على الأقل.",
      });
      return;
    }
    if (newPassword !== confirmNewPassword) {
      setPasswordStatusMsg({
        type: "error",
        text: "كلمة المرور الجديدة وتأكيدها غير متطابقتين.",
      });
      return;
    }
    setChangingPassword(true);
    try {
      await changeAccountPassword(currentPassword, newPassword);
      setCurrentPassword("");
      setNewPassword("");
      setConfirmNewPassword("");
      setShowPasswordForm(false);
      setPasswordStatusMsg({
        type: "success",
        text: "تم تحديث كلمة المرور بنجاح.",
      });
    } catch (err) {
      setPasswordStatusMsg({
        type: "error",
        text:
          err instanceof Error
            ? err.message
            : "تعذر تحديث كلمة المرور. حاول مجدداً.",
      });
    } finally {
      setChangingPassword(false);
    }
  };

  const handleRevokeAllSessions = async () => {
    if (revokingSessions || !user.uid) return;
    const uid = user.uid;
    setRevokingSessions(true);
    setSessionsStatusMsg(null);
    try {
      const nextVersion = await revokeAllUserSessions(uid);
      saveLocalSessionVersion(uid, nextVersion);
      setShowRevokeSessionsConfirm(false);
      onLogout();
      onClose();
    } catch (err) {
      setSessionsStatusMsg({
        type: "error",
        text:
          err instanceof Error
            ? err.message
            : "تعذر إنهاء الجلسات حالياً. حاول مجدداً.",
      });
    } finally {
      setRevokingSessions(false);
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="settings-title"
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/50 backdrop-blur-xs p-0 sm:p-4"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full sm:max-w-lg bg-white dark:bg-[#111b21] border-t sm:border border-slate-200 dark:border-slate-800 rounded-t-3xl sm:rounded-3xl p-5 sm:p-6 shadow-xl max-h-[90vh] overflow-y-auto custom-scrollbar"
      >
        <div className="w-10 h-1.5 bg-slate-300 dark:bg-slate-700 rounded-full mx-auto mb-4 sm:hidden" />

        {/* Header with prominent RTL Circular Back Button */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              aria-label="الرجوع إلى الدردشة"
              title="رجوع"
              className="w-10 h-10 rounded-full bg-emerald-50 hover:bg-emerald-100 dark:bg-[#202c33] dark:hover:bg-[#2a3942] border border-emerald-200/80 dark:border-slate-700 text-[#0d7a5f] dark:text-[#00a884] flex items-center justify-center shadow-xs transition-colors cursor-pointer shrink-0"
            >
              <ArrowRight className="w-5 h-5" />
            </button>
            <h2
              id="settings-title"
              className="font-display text-lg font-bold text-slate-900 dark:text-white"
            >
              الإعدادات
            </h2>
          </div>
        </div>

        {/* Privacy Section */}
        <div className="mt-5 pb-5 border-b border-slate-100 dark:border-slate-800 space-y-3">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2 text-sm font-semibold text-slate-800 dark:text-slate-200">
              <EyeOff className="w-4 h-4 text-[#0d7a5f] dark:text-[#00a884]" />
              <span>خصوصية الظهور والملف الشخصي</span>
            </div>

            {privacySavedNotice && (
              <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                <Check className="w-3.5 h-3.5" />
                <span>تم الحفظ</span>
              </span>
            )}
          </div>

          <div className="p-3 rounded-2xl bg-slate-50 dark:bg-[#202c33]/75 border border-slate-200/70 dark:border-slate-800 space-y-2.5">
            <button
              type="button"
              role="switch"
              aria-checked={isProfileLocked}
              onClick={() => void handleTogglePrivacy("isProfileLocked")}
              className="w-full min-h-[46px] px-3 py-2.5 rounded-xl bg-emerald-50/70 dark:bg-emerald-950/35 border border-emerald-200/80 dark:border-emerald-800/60 flex items-center justify-between gap-2.5 text-start text-xs font-bold text-slate-900 dark:text-white cursor-pointer"
            >
              <div className="space-y-0.5">
                <span className="block">🔒 قفل الملف الشخصي</span>
                <span className="block text-[11px] font-medium text-slate-500 dark:text-slate-400">
                  إخفاء العمر، الحالة الاجتماعية، الدراسة/العمل، المدينة والبلد، وقائمة الأصدقاء عن غير الأصدقاء المعتمدين.
                </span>
              </div>
              <span
                className={`px-2.5 py-0.5 rounded-lg text-[11px] font-bold shrink-0 ${
                  isProfileLocked
                    ? "bg-[#0d7a5f] dark:bg-[#00a884] text-white"
                    : "bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300"
                }`}
              >
                {isProfileLocked ? "مقفل" : "مفتوح"}
              </span>
            </button>

            {[
              {
                key: "showLastSeen" as const,
                label: "إخفاء حالة «متصل الآن» وآخر ظهور",
                checked: !showLastSeen,
              },
              {
                key: "showPersonalInfo" as const,
                label:
                  "إخفاء المعلومات الشخصية (الحالة الاجتماعية، الدراسة/العمل، المدينة والبلد) عن الآخرين",
                checked: !showPersonalInfo,
              },
              {
                key: "showAgeCity" as const,
                label: "إخفاء العمر عن الآخرين",
                checked: !showAgeCity,
              },
              {
                key: "showFriends" as const,
                label: "إخفاء قائمة الأصدقاء عن الآخرين",
                checked: !showFriends,
              },
            ].map((item) => (
              <button
                key={item.key}
                type="button"
                role="switch"
                aria-checked={item.checked}
                onClick={() => void handleTogglePrivacy(item.key)}
                className="w-full min-h-[42px] px-3 py-2 rounded-xl bg-white dark:bg-[#111b21] border border-slate-200/80 dark:border-slate-700/70 flex items-center justify-between gap-2.5 text-start text-xs font-semibold text-slate-800 dark:text-slate-200 cursor-pointer"
              >
                <span className="leading-relaxed">{item.label}</span>
                <span
                  className={`px-2.5 py-0.5 rounded-lg text-[11px] font-bold shrink-0 ${
                    item.checked
                      ? "bg-[#0d7a5f] dark:bg-[#00a884] text-white"
                      : "bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300"
                  }`}
                >
                  {item.checked ? "مخفي" : "ظاهر"}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Sounds & Ringtones Section */}
        <div className="py-5 border-b border-slate-100 dark:border-slate-800 space-y-3.5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              {soundPrefs.muted ? (
                <VolumeX className="w-4 h-4 text-rose-500" />
              ) : (
                <Volume2 className="w-4 h-4 text-[#0d7a5f] dark:text-[#00a884]" />
              )}
              <span className="text-sm font-semibold text-slate-800 dark:text-slate-200">
                الأصوات والنغمات
              </span>
            </div>

            <button
              type="button"
              role="switch"
              aria-checked={soundPrefs.muted}
              onClick={() =>
                onChangeSoundPrefs({ ...soundPrefs, muted: !soundPrefs.muted })
              }
              className={`min-h-[34px] px-3 py-1 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
                soundPrefs.muted
                  ? "bg-rose-600 text-white"
                  : "bg-emerald-50 dark:bg-emerald-950/50 text-[#0d7a5f] dark:text-[#00a884] border border-emerald-200 dark:border-emerald-800/60"
              }`}
            >
              {soundPrefs.muted ? "الوضع الصامت مفعّل" : "الأصوات مفعّلة"}
            </button>
          </div>

          {/* Volume Slider (0% - 100%) */}
          <div className="p-3 rounded-2xl bg-slate-50 dark:bg-[#202c33] border border-slate-200/70 dark:border-slate-700/60 space-y-2">
            <div className="flex items-center justify-between">
              <label
                htmlFor="sound-volume-slider"
                className="text-xs font-bold text-slate-700 dark:text-slate-200"
              >
                مستوى الصوت
              </label>
              <span
                dir="ltr"
                className="text-xs font-extrabold text-[#0d7a5f] dark:text-[#00a884] tabular-nums"
              >
                {soundPrefs.muted ? "0%" : `${soundPrefs.volume}%`}
              </span>
            </div>
            <input
              id="sound-volume-slider"
              type="range"
              min={0}
              max={100}
              step={5}
              value={soundPrefs.muted ? 0 : soundPrefs.volume}
              onChange={(e) => {
                const nextVolume = Number(e.target.value);
                onChangeSoundPrefs({
                  ...soundPrefs,
                  volume: nextVolume,
                  muted: nextVolume === 0,
                });
              }}
              className="w-full accent-[#0d7a5f] dark:accent-[#00a884] cursor-pointer"
            />
          </div>

          {/* Message Alert Tones */}
          <div className="space-y-1.5">
            <span className="block text-xs font-semibold text-slate-500 dark:text-slate-400">
              نغمة إشعار الرسائل الواردة
            </span>
            <div className="space-y-1.5">
              {MESSAGE_TONE_OPTIONS.map((tone) => {
                const selected = soundPrefs.messageTone === tone.id;
                return (
                  <div
                    key={tone.id}
                    className={`flex items-center justify-between gap-2 p-2.5 rounded-xl border ${
                      selected
                        ? "bg-emerald-50/70 dark:bg-emerald-950/35 border-[#0d7a5f] dark:border-[#00a884]"
                        : "bg-slate-50 dark:bg-[#202c33] border-slate-200/70 dark:border-slate-700/60"
                    }`}
                  >
                    <button
                      type="button"
                      onClick={() =>
                        onChangeSoundPrefs({
                          ...soundPrefs,
                          messageTone: tone.id,
                        })
                      }
                      className="flex-1 text-start text-xs font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2 cursor-pointer"
                    >
                      <span
                        className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                          selected
                            ? "border-[#0d7a5f] bg-[#0d7a5f] text-white"
                            : "border-slate-400"
                        }`}
                      >
                        {selected && <Check className="w-2.5 h-2.5" />}
                      </span>
                      <span>{tone.label}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => previewMessageTone(tone.id)}
                      className="min-h-[30px] px-2.5 rounded-lg bg-white dark:bg-[#111b21] border border-slate-200 dark:border-slate-700 text-[11px] font-bold text-[#0d7a5f] dark:text-[#00a884] flex items-center gap-1 cursor-pointer"
                    >
                      <Play className="w-3 h-3 fill-current" />
                      <span>معاينة</span>
                    </button>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Call Ringtones & Vibration Settings Section */}
          <div className="pt-3 border-t border-slate-100 dark:border-slate-800 space-y-3">
            <div className="flex items-center gap-2">
              <Music className="w-4 h-4 text-[#0d7a5f] dark:text-[#00a884]" />
              <span className="text-sm font-semibold text-slate-800 dark:text-slate-200">
                إعدادات نغمات الاتصال والاهتزاز
              </span>
            </div>

            {/* 1. Vibration Toggle */}
            <div className="flex items-center justify-between gap-3 p-3 rounded-2xl bg-slate-50 dark:bg-[#202c33] border border-slate-200/70 dark:border-slate-700/60">
              <div className="flex items-center gap-2.5 min-w-0">
                <span className="w-9 h-9 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-[#0d7a5f] dark:text-[#00a884] flex items-center justify-center shrink-0">
                  <Smartphone className="w-4 h-4" />
                </span>
                <div className="min-w-0">
                  <p className="text-xs font-bold text-slate-900 dark:text-white truncate">
                    📳 الاهتزاز عند المكالمات
                  </p>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    {soundPrefs.callVibration !== false
                      ? "مفعّل عند وصول مكالمة واردة"
                      : "متوقف تماماً عند المكالمات"}
                  </p>
                </div>
              </div>

              <button
                type="button"
                role="switch"
                aria-checked={soundPrefs.callVibration !== false}
                aria-label="تفعيل أو إيقاف الاهتزاز عند المكالمات"
                onClick={() => {
                  const nextVibration = !(soundPrefs.callVibration !== false);
                  if (!nextVibration) {
                    stopCallVibration();
                  } else if (
                    typeof navigator !== "undefined" &&
                    typeof navigator.vibrate === "function"
                  ) {
                    try {
                      navigator.vibrate(120);
                    } catch {
                      // ignore
                    }
                  }
                  onChangeSoundPrefs({
                    ...soundPrefs,
                    callVibration: nextVibration,
                  });
                }}
                className={`relative w-12 h-7 rounded-full transition-colors cursor-pointer shrink-0 ${
                  soundPrefs.callVibration !== false
                    ? "bg-[#0d7a5f] dark:bg-[#00a884]"
                    : "bg-slate-300 dark:bg-slate-700"
                }`}
              >
                <span
                  className={`absolute top-1 w-5 h-5 rounded-full bg-white shadow transition-transform ${
                    soundPrefs.callVibration !== false
                      ? "right-1"
                      : "right-6"
                  }`}
                />
              </button>
            </div>

            {/* 2. Call Ringtone Picker Button & 7-Ringtone List */}
            <div className="space-y-2">
              <button
                type="button"
                onClick={() => setShowRingtonePicker((prev) => !prev)}
                aria-expanded={showRingtonePicker}
                className="w-full min-h-[50px] px-3.5 py-2.5 rounded-2xl bg-slate-50 hover:bg-slate-100/80 dark:bg-[#202c33] dark:hover:bg-[#27343c] border border-slate-200/80 dark:border-slate-700/70 flex items-center justify-between gap-3 transition-colors cursor-pointer"
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <span className="w-9 h-9 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-[#0d7a5f] dark:text-[#00a884] flex items-center justify-center shrink-0">
                    <Music className="w-4 h-4" />
                  </span>
                  <div className="text-start min-w-0">
                    <p className="text-xs font-bold text-slate-900 dark:text-white truncate">
                      🎵 نغمة رنين المكالمات
                    </p>
                    <p className="text-[11px] font-semibold text-[#0d7a5f] dark:text-[#00a884] truncate">
                      {RINGTONE_OPTIONS.find((r) => r.id === soundPrefs.ringtone)
                        ?.label || RINGTONE_OPTIONS[0].label}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-1.5 shrink-0 text-xs font-bold text-slate-500 dark:text-slate-300">
                  <span>تغيير</span>
                  <ChevronDown
                    className={`w-4 h-4 transition-transform ${
                      showRingtonePicker ? "rotate-180" : ""
                    }`}
                  />
                </div>
              </button>

              {showRingtonePicker && (
                <div className="rounded-2xl bg-slate-50/90 dark:bg-[#1a252b] border border-slate-200 dark:border-slate-700/80 p-2 space-y-1.5">
                  <p className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 px-1.5 pb-0.5">
                    اضغط على أي نغمة لمعاينتها فورياً واعتمادها لمكالمات الصوت والفيديو:
                  </p>
                  {RINGTONE_OPTIONS.map((ring) => {
                    const selected = soundPrefs.ringtone === ring.id;
                    return (
                      <button
                        key={ring.id}
                        type="button"
                        onClick={() => {
                          onChangeSoundPrefs({
                            ...soundPrefs,
                            ringtone: ring.id,
                          });
                          previewRingtone(ring.id);
                        }}
                        className={`w-full flex items-center justify-between gap-2 p-2.5 rounded-xl border transition-colors cursor-pointer ${
                          selected
                            ? "bg-emerald-50/90 dark:bg-emerald-950/45 border-[#0d7a5f] dark:border-[#00a884]"
                            : "bg-white dark:bg-[#202c33] border-slate-200/70 dark:border-slate-700/60 hover:border-slate-300 dark:hover:border-slate-600"
                        }`}
                      >
                        <span className="flex items-center gap-2.5 min-w-0 text-start text-xs font-bold text-slate-800 dark:text-slate-100">
                          <span
                            className={`w-4 h-4 rounded-full border flex items-center justify-center shrink-0 ${
                              selected
                                ? "border-[#0d7a5f] bg-[#0d7a5f] text-white"
                                : "border-slate-400"
                            }`}
                          >
                            {selected && <Check className="w-2.5 h-2.5" />}
                          </span>
                          <span className="truncate">{ring.label}</span>
                        </span>

                        <span className="px-2 py-1 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 text-[11px] font-bold text-[#0d7a5f] dark:text-[#00a884] flex items-center gap-1 shrink-0">
                          <Play className="w-3 h-3 fill-current" />
                          <span>{selected ? "مختارة" : "معاينة"}</span>
                        </span>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* External Push Notifications Section */}
        <div className="py-5 border-b border-slate-100 dark:border-slate-800 space-y-3">
          <div className="flex items-center gap-2">
            <Bell className="w-4 h-4 text-[#0d7a5f] dark:text-[#00a884]" />
            <span className="text-sm font-semibold text-slate-800 dark:text-slate-200">
              الإشعارات الخارجية
            </span>
          </div>

          {/* Toggle 1: Enable External Push Notifications & App Icon Badge */}
          <div className="p-3 rounded-2xl bg-slate-50 dark:bg-[#202c33] border border-slate-200/70 dark:border-slate-700/60 space-y-2.5">
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-2.5 min-w-0">
                <span className="w-9 h-9 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-[#0d7a5f] dark:text-[#00a884] flex items-center justify-center shrink-0">
                  <Bell className="w-4 h-4" />
                </span>
                <div className="min-w-0">
                  <p className="text-xs font-bold text-slate-900 dark:text-white truncate">
                    تفعيل الإشعارات الخارجية
                  </p>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    {notificationPrefs.notificationsEnabled &&
                    notifPermission === "granted"
                      ? "مفعّلة في الخلفية مع عداد الرسائل على أيقونة التطبيق"
                      : notifPermission === "denied"
                      ? "محظورة من المتصفح — يمكنك السماح بها من إعدادات الموقع"
                      : "تنبيهات فورية للرسائل والمكالمات في الخلفية مع عداد الأيقونة"}
                  </p>
                </div>
              </div>

              <button
                type="button"
                role="switch"
                aria-checked={notificationPrefs.notificationsEnabled}
                aria-label="تفعيل الإشعارات الخارجية"
                onClick={async () => {
                  const nextEnabled = !notificationPrefs.notificationsEnabled;
                  setNotifToggleNotice(null);
                  if (!nextEnabled) {
                    onChangeNotificationPrefs({
                      ...notificationPrefs,
                      notificationsEnabled: false,
                    });
                    void updateAppIconBadge(0);
                    return;
                  }

                  const perm = await requestImmediateNotificationPermission(
                    () => {
                      if (user.uid) void syncWebPushSubscription(user.uid);
                    }
                  );
                  await registerMirsalServiceWorker();
                  setNotifPermission(perm);

                  if (perm === "denied") {
                    setNotifToggleNotice(
                      "إشعارات المتصفح محظورة حالياً من إعدادات المتصفح — اسمح بها من أيقونة القفل بجانب العنوان."
                    );
                  } else if (perm === "unsupported") {
                    setNotifToggleNotice(
                      "تم تفعيل عداد الرسائل غير المقروءة والتنبيهات داخل التطبيق."
                    );
                  }

                  onChangeNotificationPrefs({
                    ...notificationPrefs,
                    notificationsEnabled: true,
                  });
                }}
                className={`relative w-12 h-7 rounded-full transition-colors cursor-pointer shrink-0 ${
                  notificationPrefs.notificationsEnabled
                    ? "bg-[#0d7a5f] dark:bg-[#00a884]"
                    : "bg-slate-300 dark:bg-slate-700"
                }`}
              >
                <span
                  className={`absolute top-1 w-5 h-5 rounded-full bg-white shadow transition-transform ${
                    notificationPrefs.notificationsEnabled ? "right-1" : "right-6"
                  }`}
                />
              </button>
            </div>

            {notifPermission !== "granted" && (
              <button
                type="button"
                onClick={async () => {
                  setNotifToggleNotice(null);
                  const perm = await requestImmediateNotificationPermission(
                    () => {
                      if (user.uid) void syncWebPushSubscription(user.uid);
                    }
                  );
                  await registerMirsalServiceWorker();
                  setNotifPermission(perm);
                  if (perm === "granted") {
                    onChangeNotificationPrefs({
                      ...notificationPrefs,
                      notificationsEnabled: true,
                    });
                  } else if (perm === "denied") {
                    setNotifToggleNotice(
                      "تم رفض إذن الإشعارات من المتصفح — افتح إعدادات الموقع للسماح بالإشعارات."
                    );
                  } else if (perm === "unsupported") {
                    setNotifToggleNotice(
                      "تم تفعيل عداد الرسائل غير المقروءة والتنبيهات داخل التطبيق."
                    );
                  }
                }}
                className="w-full min-h-[38px] px-3 py-2 rounded-xl bg-[#0d7a5f] hover:bg-[#0a634d] dark:bg-[#00a884] dark:hover:bg-[#069475] text-white text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <Bell className="w-3.5 h-3.5" />
                <span>تفعيل الإشعارات الخارجية</span>
              </button>
            )}
          </div>

          {notifToggleNotice && (
            <p className="text-[11px] text-amber-700 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/50 rounded-xl px-3 py-2">
              {notifToggleNotice}
            </p>
          )}
        </div>

        {/* Font Family & Size Section */}
        <div className="py-5 border-b border-slate-100 dark:border-slate-800 space-y-3.5">
          <div className="flex items-center gap-2">
            <Type className="w-4 h-4 text-[#0d7a5f] dark:text-[#00a884]" />
            <span className="text-sm font-semibold text-slate-800 dark:text-slate-200">
              الخط وحجم الكتابة
            </span>
          </div>

          <div className="space-y-1.5">
            <span className="block text-xs font-semibold text-slate-500 dark:text-slate-400">
              نوع خط المحادثة (5 خطوط عربية)
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {FONT_FAMILY_OPTIONS.map((opt) => {
                const active = typographyPrefs.fontFamily === opt.id;
                return (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() =>
                      onChangeTypographyPrefs({
                        ...typographyPrefs,
                        fontFamily: opt.id,
                      })
                    }
                    className={`min-h-[44px] px-2.5 py-2 rounded-xl border text-xs font-bold transition-colors cursor-pointer ${opt.previewClass} ${
                      active
                        ? "border-[#0d7a5f] dark:border-[#00a884] bg-emerald-50/70 dark:bg-emerald-950/40 text-[#0d7a5f] dark:text-[#00a884]"
                        : "border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-[#202c33] text-slate-700 dark:text-slate-300"
                    }`}
                  >
                    {opt.label}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="space-y-1.5">
            <span className="block text-xs font-semibold text-slate-500 dark:text-slate-400">
              حجم الخط الشامل للتطبيق
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {FONT_SIZE_OPTIONS.map((opt) => {
                const active = typographyPrefs.fontSize === opt.id;
                return (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() =>
                      onChangeTypographyPrefs({
                        ...typographyPrefs,
                        fontSize: opt.id,
                      })
                    }
                    className={`min-h-[42px] px-2 py-2 rounded-xl border text-xs font-bold transition-colors cursor-pointer ${
                      active
                        ? "border-[#0d7a5f] dark:border-[#00a884] bg-emerald-50/70 dark:bg-emerald-950/40 text-[#0d7a5f] dark:text-[#00a884]"
                        : "border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-[#202c33] text-slate-700 dark:text-slate-300"
                    }`}
                  >
                    {opt.label}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Friends Count & Blocked Friends Section */}
        <div className="py-5 border-b border-slate-100 dark:border-slate-800 space-y-3.5">
          <div className="flex items-center justify-between p-3.5 rounded-2xl bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200/70 dark:border-emerald-800/50">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-[#0d7a5f]/15 dark:bg-[#00a884]/20 text-[#0d7a5f] dark:text-[#00a884] flex items-center justify-center">
                <Users className="w-4 h-4" />
              </div>
              <span className="text-sm font-bold text-slate-800 dark:text-slate-100">
                عدد أصدقائي
              </span>
            </div>
            <span className="text-lg font-extrabold text-[#0d7a5f] dark:text-[#00a884] tabular-nums">
              {friendsCount}
            </span>
          </div>

          <div className="flex items-center justify-between pt-1">
            <div className="flex items-center gap-2">
              <ShieldBan className="w-4 h-4 text-rose-600 dark:text-rose-400" />
              <span className="text-sm font-semibold text-slate-800 dark:text-slate-200">
                الأصدقاء المحظورون
              </span>
            </div>
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 tabular-nums">
              {blockedUids.length}
            </span>
          </div>

          {blockedUids.length === 0 ? (
            <p className="text-xs text-slate-500 dark:text-slate-400 bg-slate-50 dark:bg-[#202c33]/70 rounded-2xl px-4 py-3 border border-slate-200/70 dark:border-slate-800">
              لا يوجد أصدقاء محظورون حالياً.
            </p>
          ) : loadingBlocked &&
            blockedUids.every(
              (uid) => !knownPeersByUid[uid] && !blockedProfiles[uid]
            ) ? (
            <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 py-2">
              <Loader2 className="w-4 h-4 animate-spin" />
              <span>جاري تحميل قائمة المحظورين...</span>
            </div>
          ) : (
            <div className="space-y-2 max-h-52 overflow-y-auto custom-scrollbar">
              {blockedUids.map((uid) => {
                const prof = knownPeersByUid[uid] || blockedProfiles[uid];
                const displayName = prof?.displayName || "مستخدم مرسال";
                const country = getCountryByCode(prof?.countryCode);
                const isBusy = unblockingUid === uid;
                const durationBadge = formatBlockRemainingAr(
                  user.blockedUntil?.[uid]
                );

                return (
                  <div
                    key={uid}
                    className="flex items-center justify-between gap-3 p-2.5 rounded-2xl bg-slate-50 dark:bg-[#202c33] border border-slate-200/70 dark:border-slate-700/60"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <Avatar
                        src={prof?.photoURL || prof?.avatar || ""}
                        name={displayName}
                        size="md"
                      />
                      <div className="min-w-0">
                        <p className="text-sm font-semibold text-slate-900 dark:text-white truncate flex items-center gap-1.5">
                          <span className="truncate">{displayName}</span>
                          {country?.flag && (
                            <span title={country.nameAr} className="shrink-0">
                              {country.flag}
                            </span>
                          )}
                        </p>
                        <p className="text-[11px] text-rose-600 dark:text-rose-400 font-medium">
                          {durationBadge}
                        </p>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => void handleUnblockClick(uid)}
                      disabled={Boolean(unblockingUid)}
                      className="min-h-[36px] px-3 py-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/50 dark:hover:bg-emerald-950/80 border border-emerald-200 dark:border-emerald-800/60 text-[#0d7a5f] dark:text-[#00a884] text-xs font-bold flex items-center gap-1.5 shrink-0 transition-colors cursor-pointer disabled:opacity-60"
                    >
                      {isBusy ? (
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      ) : (
                        <ShieldCheck className="w-3.5 h-3.5" />
                      )}
                      <span>رفع الحظر</span>
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Theme Switcher */}
        <div className="py-5 border-b border-slate-100 dark:border-slate-800 space-y-3">
          <span className="block text-sm font-semibold text-slate-800 dark:text-slate-200">
            مظهر التطبيق
          </span>
          <div className="grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => onSetTheme("light")}
              aria-pressed={theme === "light"}
              className={`min-h-[50px] px-4 py-2.5 rounded-2xl border flex items-center justify-center gap-2.5 text-sm font-semibold transition-colors cursor-pointer ${
                theme === "light"
                  ? "border-[#0d7a5f] bg-emerald-50/70 text-[#0d7a5f]"
                  : "border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-[#202c33] text-slate-700 dark:text-slate-300"
              }`}
            >
              <Sun className="w-4 h-4" />
              <span>الوضع النهاري</span>
            </button>

            <button
              type="button"
              onClick={() => onSetTheme("dark")}
              aria-pressed={theme === "dark"}
              className={`min-h-[50px] px-4 py-2.5 rounded-2xl border flex items-center justify-center gap-2.5 text-sm font-semibold transition-colors cursor-pointer ${
                theme === "dark"
                  ? "border-[#00a884] bg-emerald-950/40 text-[#00a884]"
                  : "border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-[#202c33] text-slate-700 dark:text-slate-300"
              }`}
            >
              <Moon className="w-4 h-4" />
              <span>الوضع الليلي</span>
            </button>
          </div>
        </div>

        {/* Security & Session Management Section */}
        <div className="py-5 border-b border-slate-100 dark:border-slate-800 space-y-3.5">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-[#0d7a5f] dark:text-[#00a884]" />
            <span className="text-sm font-semibold text-slate-800 dark:text-slate-200">
              الأمان وإدارة الجلسات
            </span>
          </div>

          {/* 1. 4-digit App Lock PIN */}
          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-[#202c33] border border-slate-200/70 dark:border-slate-700/60 space-y-3">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2.5 min-w-0">
                <span className="w-9 h-9 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-[#0d7a5f] dark:text-[#00a884] flex items-center justify-center shrink-0">
                  <Lock className="w-4 h-4" />
                </span>
                <div className="min-w-0">
                  <p className="text-xs font-bold text-slate-900 dark:text-white truncate">
                    قفل التطبيق برمز (4 أرقام)
                  </p>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    {appLockEnabled
                      ? "مفعّل لحماية محادثاتك عند فتح التطبيق"
                      : "غير مفعّل حالياً على هذا الجهاز"}
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  setPinStatusMsg(null);
                  setPinStepInput("");
                  setPinConfirmInput("");
                  setShowPinSetup((v) => !v);
                }}
                className={`min-h-[34px] px-3 py-1.5 rounded-xl text-xs font-bold shrink-0 cursor-pointer transition-colors ${
                  appLockEnabled
                    ? "bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800/60"
                    : "bg-[#0d7a5f] hover:bg-[#0a634d] dark:bg-[#00a884] text-white"
                }`}
              >
                {showPinSetup ? "إغلاق" : appLockEnabled ? "إدارة / إيقاف" : "تفعيل القفل"}
              </button>
            </div>

            {showPinSetup && (
              <div className="pt-2 border-t border-slate-200/70 dark:border-slate-700/60 space-y-2.5">
                <input
                  type="password"
                  inputMode="numeric"
                  maxLength={4}
                  value={pinStepInput}
                  onChange={(e) =>
                    setPinStepInput(e.target.value.replace(/\D/g, "").slice(0, 4))
                  }
                  placeholder={
                    appLockEnabled
                      ? "أدخل رمز القفل الحالي (4 أرقام)"
                      : "أدخل رمز القفل الجديد (4 أرقام)"
                  }
                  className="w-full min-h-[40px] px-3 rounded-xl bg-white dark:bg-[#111b21] border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-[#0d7a5f]"
                />
                {!appLockEnabled && (
                  <input
                    type="password"
                    inputMode="numeric"
                    maxLength={4}
                    value={pinConfirmInput}
                    onChange={(e) =>
                      setPinConfirmInput(e.target.value.replace(/\D/g, "").slice(0, 4))
                    }
                    placeholder="تأكيد رمز القفل (4 أرقام)"
                    className="w-full min-h-[40px] px-3 rounded-xl bg-white dark:bg-[#111b21] border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-[#0d7a5f]"
                  />
                )}
                <div className="flex items-center justify-end gap-2">
                  {appLockEnabled ? (
                    <button
                      type="button"
                      disabled={savingPin}
                      onClick={() => void handleDisableAppLockPin()}
                      className="min-h-[36px] px-3.5 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold cursor-pointer disabled:opacity-60"
                    >
                      إيقاف القفل
                    </button>
                  ) : (
                    <button
                      type="button"
                      disabled={savingPin}
                      onClick={() => void handleSaveAppLockPin()}
                      className="min-h-[36px] px-3.5 py-1.5 rounded-xl bg-[#0d7a5f] hover:bg-[#0a634d] dark:bg-[#00a884] text-white text-xs font-bold cursor-pointer disabled:opacity-60"
                    >
                      حفظ الرمز
                    </button>
                  )}
                </div>
              </div>
            )}

            {pinStatusMsg && (
              <p
                className={`text-[11px] font-semibold px-3 py-2 rounded-xl ${
                  pinStatusMsg.type === "success"
                    ? "bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300"
                    : "bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400"
                }`}
              >
                {pinStatusMsg.text}
              </p>
            )}
          </div>

          {/* 2. Change Password */}
          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-[#202c33] border border-slate-200/70 dark:border-slate-700/60 space-y-3">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2.5 min-w-0">
                <span className="w-9 h-9 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-[#0d7a5f] dark:text-[#00a884] flex items-center justify-center shrink-0">
                  <KeyRound className="w-4 h-4" />
                </span>
                <div className="min-w-0">
                  <p className="text-xs font-bold text-slate-900 dark:text-white truncate">
                    تغيير كلمة المرور / رمز الحساب
                  </p>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    تحديث كلمة مرور الدخول بأمان مع التحقق المسبق
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  setPasswordStatusMsg(null);
                  setShowPasswordForm((v) => !v);
                }}
                className="min-h-[34px] px-3 py-1.5 rounded-xl bg-white dark:bg-[#111b21] border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200 shrink-0 cursor-pointer"
              >
                {showPasswordForm ? "إخفاء" : "تغيير"}
              </button>
            </div>

            {showPasswordForm && (
              <div className="pt-2 border-t border-slate-200/70 dark:border-slate-700/60 space-y-2">
                <input
                  type="password"
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  placeholder="كلمة المرور أو رمز PIN الحالي"
                  className="w-full min-h-[40px] px-3 rounded-xl bg-white dark:bg-[#111b21] border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-[#0d7a5f]"
                />
                <input
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="كلمة المرور الجديدة (6 أحرف/أرقام فأكثر)"
                  className="w-full min-h-[40px] px-3 rounded-xl bg-white dark:bg-[#111b21] border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-[#0d7a5f]"
                />
                <input
                  type="password"
                  value={confirmNewPassword}
                  onChange={(e) => setConfirmNewPassword(e.target.value)}
                  placeholder="تأكيد كلمة المرور الجديدة"
                  className="w-full min-h-[40px] px-3 rounded-xl bg-white dark:bg-[#111b21] border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-[#0d7a5f]"
                />
                <div className="flex justify-end">
                  <button
                    type="button"
                    disabled={changingPassword}
                    onClick={() => void handleSubmitPasswordChange()}
                    className="min-h-[36px] px-4 py-1.5 rounded-xl bg-[#0d7a5f] hover:bg-[#0a634d] dark:bg-[#00a884] text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer disabled:opacity-60"
                  >
                    {changingPassword && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                    <span>تحديث كلمة المرور</span>
                  </button>
                </div>
              </div>
            )}

            {passwordStatusMsg && (
              <p
                className={`text-[11px] font-semibold px-3 py-2 rounded-xl ${
                  passwordStatusMsg.type === "success"
                    ? "bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300"
                    : "bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400"
                }`}
              >
                {passwordStatusMsg.text}
              </p>
            )}
          </div>

          {/* 3. Log Out from All Devices */}
          <div className="space-y-2">
            <button
              type="button"
              disabled={revokingSessions}
              onClick={() => {
                setSessionsStatusMsg(null);
                setShowRevokeSessionsConfirm(true);
              }}
              className="w-full min-h-[44px] px-4 py-2.5 rounded-xl bg-amber-50 hover:bg-amber-100 dark:bg-amber-950/35 dark:hover:bg-amber-950/60 border border-amber-200 dark:border-amber-800/60 text-amber-800 dark:text-amber-300 text-xs font-bold flex items-center justify-between transition-colors cursor-pointer disabled:opacity-60"
            >
              <span>تسجيل الخروج من جميع الأجهزة</span>
              {revokingSessions ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <LogOut className="w-4 h-4" />
              )}
            </button>

            {sessionsStatusMsg && (
              <p
                className={`text-[11px] font-semibold px-3 py-2 rounded-xl ${
                  sessionsStatusMsg.type === "success"
                    ? "bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300"
                    : "bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400"
                }`}
              >
                {sessionsStatusMsg.text}
              </p>
            )}
          </div>
        </div>

        {/* Clear Conversations & Logout */}
        <div className="pt-5 space-y-2.5">
          {confirmClearAll ? (
            <div className="p-3.5 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/60 space-y-3">
              <p className="text-xs font-medium text-rose-800 dark:text-rose-200 leading-relaxed">
                سيتم إخفاء المحادثات لديك فقط (ستبقى محفوظة لدى الطرف الآخر). هل تريد المتابعة؟
              </p>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => void handleConfirmClear()}
                  disabled={clearingAll}
                  className="min-h-[40px] px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 disabled:opacity-60 text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                >
                  {clearingAll && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                  <span>تأكيد المسح لدي</span>
                </button>
                <button
                  type="button"
                  onClick={() => setConfirmClearAll(false)}
                  disabled={clearingAll}
                  className="min-h-[40px] px-4 py-2 rounded-xl bg-white dark:bg-[#202c33] text-slate-700 dark:text-slate-200 text-xs font-semibold cursor-pointer"
                >
                  إلغاء
                </button>
              </div>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => setConfirmClearAll(true)}
              className="w-full min-h-[46px] px-4 py-2.5 rounded-xl border border-rose-200 dark:border-rose-900/60 text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 text-sm font-semibold flex items-center justify-between transition-colors cursor-pointer"
            >
              <span>مسح جميع المحادثات لدي فقط</span>
              <Trash2 className="w-4 h-4" />
            </button>
          )}

          <button
            type="button"
            onClick={() => {
              onLogout();
              onClose();
            }}
            className="w-full min-h-[46px] px-4 py-2.5 rounded-xl bg-slate-100 dark:bg-[#202c33] text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-[#2a3942] text-sm font-semibold flex items-center justify-between transition-colors cursor-pointer"
          >
            <span>تسجيل الخروج</span>
            <LogOut className="w-4 h-4 text-slate-500" />
          </button>

          <button
            type="button"
            onClick={() => {
              setDeleteAccountError(null);
              setShowDeleteAccountConfirm(true);
            }}
            className="w-full min-h-[46px] px-4 py-2.5 rounded-xl bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/40 dark:hover:bg-rose-950/70 border border-rose-200 dark:border-rose-800/60 text-rose-600 dark:text-rose-400 text-sm font-bold flex items-center justify-between transition-colors cursor-pointer"
          >
            <span>حذف حسابي نهائياً</span>
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {showDeleteAccountConfirm && (
        <div
          role="alertdialog"
          aria-modal="true"
          aria-labelledby="settings-delete-account-title"
          className="fixed inset-0 z-[70] bg-black/65 backdrop-blur-xs flex items-center justify-center p-4"
          onClick={() => {
            if (!deletingAccount) setShowDeleteAccountConfirm(false);
          }}
        >
          <div
            dir="rtl"
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-sm bg-white dark:bg-[#111b21] border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-2xl space-y-4"
          >
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-2xl bg-rose-100 dark:bg-rose-950/70 text-rose-600 dark:text-rose-400 flex items-center justify-center shrink-0">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div className="space-y-1">
                <h3
                  id="settings-delete-account-title"
                  className="font-display font-bold text-base text-slate-900 dark:text-white"
                >
                  حذف حسابي نهائياً
                </h3>
                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                  هل أنت متأكد من حذف حسابك نهائياً؟ لا يمكن التراجع عن هذا الإجراء
                </p>
              </div>
            </div>

            {deleteAccountError && (
              <p className="text-xs font-medium text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/40 px-3 py-2 rounded-xl">
                {deleteAccountError}
              </p>
            )}

            <div className="flex items-center justify-end gap-2">
              <button
                type="button"
                disabled={deletingAccount}
                onClick={() => setShowDeleteAccountConfirm(false)}
                className="min-h-[40px] px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-[#202c33] dark:hover:bg-[#2a3942] text-xs font-bold text-slate-700 dark:text-slate-200 cursor-pointer disabled:opacity-50"
              >
                إلغاء
              </button>
              <button
                type="button"
                disabled={deletingAccount}
                onClick={async () => {
                  if (deletingAccount) return;
                  setDeletingAccount(true);
                  setDeleteAccountError(null);
                  try {
                    await onDeleteAccount();
                    setShowDeleteAccountConfirm(false);
                    onClose();
                  } catch (err) {
                    setDeleteAccountError(
                      err instanceof Error
                        ? err.message
                        : "تعذر حذف الحساب نهائياً. حاول مجدداً."
                    );
                  } finally {
                    setDeletingAccount(false);
                  }
                }}
                className="min-h-[40px] px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer disabled:opacity-60"
              >
                {deletingAccount ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Trash2 className="w-4 h-4" />
                )}
                <span>تأكيد الحذف</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {showRevokeSessionsConfirm && (
        <div
          role="alertdialog"
          aria-modal="true"
          aria-labelledby="settings-revoke-sessions-title"
          className="fixed inset-0 z-[70] bg-black/65 backdrop-blur-xs flex items-center justify-center p-4"
          onClick={() => {
            if (!revokingSessions) setShowRevokeSessionsConfirm(false);
          }}
        >
          <div
            dir="rtl"
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-sm bg-white dark:bg-[#111b21] border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-2xl space-y-4"
          >
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-2xl bg-amber-100 dark:bg-amber-950/70 text-amber-700 dark:text-amber-300 flex items-center justify-center shrink-0">
                <LogOut className="w-5 h-5" />
              </div>
              <div className="space-y-1">
                <h3
                  id="settings-revoke-sessions-title"
                  className="font-display font-bold text-base text-slate-900 dark:text-white"
                >
                  تسجيل الخروج من جميع الأجهزة
                </h3>
                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                  هل أنت متأكد من تسجيل الخروج من جميع الأجهزة؟
                </p>
              </div>
            </div>

            {sessionsStatusMsg && sessionsStatusMsg.type === "error" && (
              <p className="text-xs font-medium text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/40 px-3 py-2 rounded-xl">
                {sessionsStatusMsg.text}
              </p>
            )}

            <div className="flex items-center justify-end gap-2">
              <button
                type="button"
                disabled={revokingSessions}
                onClick={() => setShowRevokeSessionsConfirm(false)}
                className="min-h-[40px] px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-[#202c33] dark:hover:bg-[#2a3942] text-xs font-bold text-slate-700 dark:text-slate-200 cursor-pointer disabled:opacity-50"
              >
                إلغاء
              </button>
              <button
                type="button"
                disabled={revokingSessions}
                onClick={() => void handleRevokeAllSessions()}
                className="min-h-[40px] px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer disabled:opacity-60"
              >
                {revokingSessions ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <LogOut className="w-4 h-4" />
                )}
                <span>تأكيد الخروج</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
