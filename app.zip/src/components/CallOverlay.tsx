import { useEffect, useRef, useState } from "react";
import {
  Mic,
  MicOff,
  Video,
  VideoOff,
  PhoneOff,
  Phone,
  SwitchCamera,
  Volume2,
  X,
} from "lucide-react";
import type { ChatCallSignal } from "../types/chat";
import type { ActiveCallSession } from "../services/webrtc";
import {
  stopCallVibration,
  stopOutgoingRingback,
  stopRingtone,
  unlockAudioContext,
} from "../services/sounds";
import { Avatar } from "./Avatar";

interface CallOverlayProps {
  activeCall: ActiveCallSession | null;
  incomingCall: ChatCallSignal | null;
  localStream: MediaStream | null;
  remoteStream: MediaStream | null;
  isMuted: boolean;
  isCameraOff: boolean;
  facingMode: "user" | "environment";
  elapsedSeconds: number;
  callError: string | null;
  onClearError: () => void;
  onAcceptIncoming: (call: ChatCallSignal) => void;
  onDeclineIncoming: (call: ChatCallSignal) => void;
  onEndCall: () => void;
  onToggleMute: () => void;
  onToggleCamera: () => void;
  onSwitchCamera: () => void;
}

function formatCallDuration(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins.toString().padStart(2, "0")}:${secs
    .toString()
    .padStart(2, "0")}`;
}

export function CallOverlay({
  activeCall,
  incomingCall,
  localStream,
  remoteStream,
  isMuted,
  isCameraOff,
  facingMode,
  elapsedSeconds,
  callError,
  onClearError,
  onAcceptIncoming,
  onDeclineIncoming,
  onEndCall,
  onToggleMute,
  onToggleCamera,
  onSwitchCamera,
}: CallOverlayProps) {
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRef = useRef<HTMLVideoElement>(null);
  const remoteAudioRef = useRef<HTMLAudioElement>(null);
  const [needsAudioUnlock, setNeedsAudioUnlock] = useState(false);

  useEffect(() => {
    if (localVideoRef.current && localStream) {
      localVideoRef.current.srcObject = localStream;
    }
  }, [localStream, activeCall?.callType, isCameraOff]);

  useEffect(() => {
    setNeedsAudioUnlock(false);
    if (!remoteStream || !activeCall) return;

    const targetEl =
      activeCall.callType === "video"
        ? remoteVideoRef.current
        : remoteAudioRef.current;

    if (!targetEl) return;

    const attachAndPlay = () => {
      if (targetEl.srcObject !== remoteStream) {
        targetEl.srcObject = remoteStream;
      }
      targetEl.muted = false;
      targetEl.volume = 1;
      void targetEl.play().catch(() => {
        setNeedsAudioUnlock(true);
      });
    };

    attachAndPlay();
    remoteStream.addEventListener("addtrack", attachAndPlay);
    return () => {
      remoteStream.removeEventListener("addtrack", attachAndPlay);
    };
  }, [remoteStream, activeCall?.callId, activeCall?.callType]);

  const handleManualUnlockAudio = async () => {
    unlockAudioContext();
    const targetEl =
      activeCall?.callType === "video"
        ? remoteVideoRef.current
        : remoteAudioRef.current;
    if (!targetEl) return;
    targetEl.muted = false;
    targetEl.volume = 1;
    try {
      await targetEl.play();
      setNeedsAudioUnlock(false);
    } catch {
      // keep button visible if still blocked
    }
  };

  return (
    <>
      {/* Call Error Toast */}
      {callError && (
        <div
          role="alert"
          className="fixed top-4 left-1/2 -translate-x-1/2 z-[60] max-w-md w-[92%] bg-rose-600 text-white px-4 py-3 rounded-2xl shadow-lg flex items-center justify-between gap-3 text-sm font-medium"
        >
          <span>{callError}</span>
          <button
            type="button"
            onClick={onClearError}
            aria-label="إغلاق التنبيه"
            className="p-1 rounded-lg hover:bg-white/20 cursor-pointer shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Incoming Call Banner / Modal (when not already in a call) */}
      {incomingCall && !activeCall && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="مكالمة واردة"
          className="fixed inset-0 z-50 bg-black/55 backdrop-blur-xs flex items-center justify-center p-4"
        >
          <div className="w-full max-w-sm bg-white dark:bg-[#111b21] border border-slate-200 dark:border-slate-800 rounded-3xl p-6 text-center shadow-2xl space-y-6">
            <div className="space-y-3">
              <div className="relative w-16 h-16 mx-auto flex items-center justify-center">
                <span className="absolute inset-0 rounded-full bg-emerald-500/20 animate-ping motion-reduce:hidden" />
                <div className="relative w-16 h-16 rounded-full bg-emerald-50 dark:bg-emerald-950/60 text-[#0d7a5f] dark:text-[#00a884] flex items-center justify-center border border-emerald-200 dark:border-emerald-800/60">
                  {incomingCall.callType === "video" ? (
                    <Video className="w-8 h-8" />
                  ) : (
                    <Phone className="w-8 h-8" />
                  )}
                </div>
              </div>
              <div>
                <p className="text-xs font-semibold text-[#0d7a5f] dark:text-[#00a884]">
                  {incomingCall.callType === "video"
                    ? "مكالمة فيديو واردة"
                    : "مكالمة صوتية واردة"}
                </p>
                <h3 className="font-display text-xl font-bold text-slate-900 dark:text-white mt-1">
                  {incomingCall.callerName}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  مكالمة مباشرة في مرسال
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => {
                  unlockAudioContext();
                  stopRingtone();
                  stopCallVibration();
                  stopOutgoingRingback();
                  onAcceptIncoming(incomingCall);
                }}
                className="min-h-[48px] px-4 py-3 rounded-2xl bg-[#0d7a5f] hover:bg-[#0a634d] dark:bg-[#00a884] dark:hover:bg-[#069475] text-white font-bold text-sm flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                {incomingCall.callType === "video" ? (
                  <Video className="w-4 h-4" />
                ) : (
                  <Phone className="w-4 h-4" />
                )}
                <span>رد</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  unlockAudioContext();
                  stopRingtone();
                  stopCallVibration();
                  stopOutgoingRingback();
                  onDeclineIncoming(incomingCall);
                }}
                className="min-h-[48px] px-4 py-3 rounded-2xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-sm flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <PhoneOff className="w-4 h-4" />
                <span>رفض</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Active Audio / Video Call Screen */}
      {activeCall && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="شاشة المكالمة"
          className="fixed inset-0 z-50 bg-[#0b141a] text-white flex flex-col justify-between overflow-hidden"
        >
          {/* Remote audio element for audio calls (autoPlay + playsInline, never muted) */}
          {activeCall.callType === "audio" && (
            <audio
              ref={remoteAudioRef}
              autoPlay
              playsInline
              onLoadedMetadata={(e) => {
                e.currentTarget.muted = false;
                e.currentTarget.volume = 1;
                void e.currentTarget.play().catch(() => {
                  setNeedsAudioUnlock(true);
                });
              }}
              className="hidden"
            />
          )}

          {/* Top Call Status Header */}
          <header className="relative z-10 px-4 sm:px-6 py-4 bg-gradient-to-b from-black/75 to-transparent flex items-center justify-between gap-4">
            <div className="min-w-0">
              <h2 className="font-display text-lg font-bold truncate">
                {activeCall.peerName}
              </h2>
              <p className="text-xs text-slate-300 flex items-center gap-2 tabular-nums">
                <span>
                  {activeCall.callType === "video"
                    ? "مكالمة فيديو"
                    : "مكالمة صوتية"}
                </span>
                <span aria-hidden="true">·</span>
                <span>
                  {activeCall.status === "ringing"
                    ? "جاري الرنين بانتظار الطرف الآخر..."
                    : formatCallDuration(elapsedSeconds)}
                </span>
              </p>
            </div>

            {activeCall.callType === "video" && (
              <span className="text-xs text-slate-300 bg-white/10 px-3 py-1.5 rounded-xl shrink-0">
                {facingMode === "user" ? "الكاميرا الأمامية" : "الكاميرا الخلفية"}
              </span>
            )}
          </header>

          {needsAudioUnlock && (
            <div className="relative z-20 flex justify-center px-4">
              <button
                type="button"
                onClick={() => void handleManualUnlockAudio()}
                className="min-h-[42px] px-4 py-2 rounded-xl bg-[#00a884] hover:bg-[#069475] text-white text-xs font-bold flex items-center gap-2 shadow-lg cursor-pointer"
              >
                <Volume2 className="w-4 h-4" />
                <span>اضغط لتفعيل صوت الطرف الآخر</span>
              </button>
            </div>
          )}

          {/* Main Video / Audio Stage */}
          <div className="relative flex-1 flex items-center justify-center overflow-hidden">
            {activeCall.callType === "video" ? (
              <>
                <video
                  ref={remoteVideoRef}
                  autoPlay
                  playsInline
                  onLoadedMetadata={(e) => {
                    e.currentTarget.muted = false;
                    e.currentTarget.volume = 1;
                    void e.currentTarget.play().catch(() => {
                      setNeedsAudioUnlock(true);
                    });
                  }}
                  className="w-full h-full object-cover bg-[#111b21]"
                />

                {(!remoteStream || remoteStream.getVideoTracks().length === 0) && (
                  <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-[#111b21] pointer-events-none">
                    <Avatar
                      src={activeCall.peerAvatar || ""}
                      name={activeCall.peerName}
                      size="xl"
                    />
                    <p className="text-sm text-slate-300">
                      {activeCall.status === "ringing"
                        ? "بانتظار انضمام الطرف الآخر للمكالمة..."
                        : "الكاميرا متوقفة لدى الطرف الآخر"}
                    </p>
                  </div>
                )}

                {/* Local PiP Video Preview */}
                <div className="absolute bottom-4 left-4 w-28 sm:w-36 aspect-[3/4] rounded-2xl overflow-hidden bg-slate-900 border-2 border-white/25 shadow-2xl">
                  {isCameraOff ? (
                    <div className="w-full h-full flex items-center justify-center bg-slate-800 text-slate-400">
                      <VideoOff className="w-6 h-6" />
                    </div>
                  ) : (
                    <video
                      ref={localVideoRef}
                      autoPlay
                      playsInline
                      muted
                      className={`w-full h-full object-cover ${
                        facingMode === "user" ? "scale-x-[-1]" : ""
                      }`}
                    />
                  )}
                </div>
              </>
            ) : (
              <div className="flex flex-col items-center justify-center gap-5 p-6 text-center">
                <div className="w-28 h-28 rounded-full bg-[#202c33] border border-slate-700 flex items-center justify-center shadow-xl">
                  <Avatar
                    src={activeCall.peerAvatar || ""}
                    name={activeCall.peerName}
                    size="xl"
                    className="w-24 h-24 text-3xl"
                  />
                </div>
                <div className="space-y-1.5">
                  <h3 className="font-display text-2xl font-bold">
                    {activeCall.peerName}
                  </h3>
                  <p className="text-sm text-slate-300 tabular-nums">
                    {activeCall.status === "ringing"
                      ? "جاري الاتصال بالطرف الآخر..."
                      : `مكالمة صوتية نشطة · ${formatCallDuration(elapsedSeconds)}`}
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* Bottom Call Controls Bar */}
          <footer className="relative z-10 px-4 py-6 bg-gradient-to-t from-black/85 via-black/60 to-transparent flex items-center justify-center gap-4 sm:gap-6">
            <button
              type="button"
              onClick={onToggleMute}
              aria-label={isMuted ? "تشغيل الميكروفون" : "كتم الصوت"}
              title={isMuted ? "تشغيل الميكروفون" : "كتم الصوت"}
              className={`min-h-[54px] min-w-[54px] px-4 rounded-full flex items-center justify-center gap-2 transition-colors cursor-pointer ${
                isMuted
                  ? "bg-white text-slate-900"
                  : "bg-white/15 hover:bg-white/25 text-white"
              }`}
            >
              {isMuted ? (
                <MicOff className="w-6 h-6" />
              ) : (
                <Mic className="w-6 h-6" />
              )}
            </button>

            {activeCall.callType === "video" && (
              <>
                <button
                  type="button"
                  onClick={onToggleCamera}
                  aria-label={isCameraOff ? "تشغيل الكاميرا" : "إيقاف الكاميرا"}
                  title={isCameraOff ? "تشغيل الكاميرا" : "إيقاف الكاميرا"}
                  className={`min-h-[54px] min-w-[54px] px-4 rounded-full flex items-center justify-center gap-2 transition-colors cursor-pointer ${
                    isCameraOff
                      ? "bg-white text-slate-900"
                      : "bg-white/15 hover:bg-white/25 text-white"
                  }`}
                >
                  {isCameraOff ? (
                    <VideoOff className="w-6 h-6" />
                  ) : (
                    <Video className="w-6 h-6" />
                  )}
                </button>

                <button
                  type="button"
                  onClick={onSwitchCamera}
                  aria-label="تبديل الكاميرا الأمامية والخلفية"
                  title="تبديل الكاميرا (أمامية / خلفية)"
                  className="min-h-[54px] min-w-[54px] px-4 rounded-full bg-white/15 hover:bg-white/25 text-white flex items-center justify-center transition-colors cursor-pointer"
                >
                  <SwitchCamera className="w-6 h-6" />
                </button>
              </>
            )}

            <button
              type="button"
              onClick={onEndCall}
              aria-label="إنهاء المكالمة"
              title="إنهاء المكالمة"
              className="min-h-[56px] min-w-[68px] px-5 rounded-full bg-rose-600 hover:bg-rose-700 text-white flex items-center justify-center transition-colors shadow-lg cursor-pointer"
            >
              <PhoneOff className="w-6 h-6" />
            </button>
          </footer>
        </div>
      )}
    </>
  );
}
