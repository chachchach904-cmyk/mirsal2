import {
  useEffect,
  useState,
  type ChangeEvent,
  type FormEvent,
} from "react";
import {
  Moon,
  Sun,
  Loader2,
  ShieldCheck,
  MailCheck,
  Eye,
  EyeOff,
  RefreshCw,
  ArrowRight,
  ImagePlus,
  X,
} from "lucide-react";
import { DEFAULT_USER_AVATAR, isDataUrlAvatar } from "../data/defaults";
import { COUNTRIES, DEFAULT_COUNTRY_CODE } from "../data/countries";
import type { ThemeMode } from "../types/chat";
import { compressImageToDataUrl } from "../utils/storage";
import { Avatar } from "./Avatar";
import { MirsalLogo } from "./MirsalLogo";

export type AuthTab = "register" | "login";

interface PendingVerificationState {
  uid: string;
  name: string;
  email: string;
  avatar: string;
}

interface LoginScreenProps {
  theme: ThemeMode;
  pendingVerification: PendingVerificationState | null;
  onToggleTheme: () => void;
  onRegister: (params: {
    name: string;
    email: string;
    pin: string;
    avatar: string;
    countryCode: string;
  }) => Promise<void>;
  onSignIn: (params: { email: string; pin: string }) => Promise<void>;
  onCheckVerified: () => Promise<boolean>;
  onResendVerification: () => Promise<void>;
  onCancelVerification: () => Promise<void>;
  onResetPin: (email: string) => Promise<void>;
}

export function LoginScreen({
  theme,
  pendingVerification,
  onToggleTheme,
  onRegister,
  onSignIn,
  onCheckVerified,
  onResendVerification,
  onCancelVerification,
  onResetPin,
}: LoginScreenProps) {
  const [tab, setTab] = useState<AuthTab>("register");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [pin, setPin] = useState("");
  const [showPin, setShowPin] = useState(false);
  const [selectedAvatar, setSelectedAvatar] = useState(DEFAULT_USER_AVATAR);
  const [countryCode, setCountryCode] = useState(DEFAULT_COUNTRY_CODE);

  const [error, setError] = useState<string | null>(null);
  const [infoNotice, setInfoNotice] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [checkingVerify, setCheckingVerify] = useState(false);
  const [resendingVerify, setResendingVerify] = useState(false);
  const [resendCooldown, setResendCooldown] = useState(0);
  const [uploadingPhoto, setUploadingPhoto] = useState(false);

  useEffect(() => {
    if (resendCooldown <= 0) return;
    const timer = setInterval(() => {
      setResendCooldown((prev) => Math.max(0, prev - 1));
    }, 1000);
    return () => clearInterval(timer);
  }, [resendCooldown]);

  const handleSignupPhotoUpload = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingPhoto(true);
    setError(null);
    try {
      const compressed = await compressImageToDataUrl(file, 256, 0.78, 72000);
      setSelectedAvatar(compressed);
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "تعذر تجهيز الصورة الشخصية."
      );
    } finally {
      setUploadingPhoto(false);
      e.target.value = "";
    }
  };

  const handlePinChange = (value: string) => {
    const digitsOnly = value.replace(/\D/g, "").slice(0, 6);
    setPin(digitsOnly);
    if (error) setError(null);
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setInfoNotice(null);

    const cleanEmail = email.trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
      setError("يرجى إدخال بريد إلكتروني صحيح.");
      return;
    }

    if (!/^[0-9]{6}$/.test(pin)) {
      setError("يرجى إدخال رمز PIN مكوّن من 6 أرقام.");
      return;
    }

    if (tab === "register") {
      const cleanName = name.trim();
      if (cleanName.length < 2) {
        setError("يرجى إدخال اسم لا يقل عن حرفين.");
        return;
      }

      setSubmitting(true);
      try {
        await onRegister({
          name: cleanName,
          email: cleanEmail,
          pin,
          avatar: selectedAvatar,
          countryCode,
        });
      } catch (err) {
        setError(
          err instanceof Error
            ? err.message
            : "تعذر إنشاء الحساب. حاول مرة أخرى."
        );
      } finally {
        setSubmitting(false);
      }
      return;
    }

    setSubmitting(true);
    try {
      await onSignIn({ email: cleanEmail, pin });
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : "تعذر تسجيل الدخول. تحقق من البيانات وحاول مجدداً."
      );
    } finally {
      setSubmitting(false);
    }
  };

  const handleCheckVerifiedClick = async () => {
    setError(null);
    setInfoNotice(null);
    setCheckingVerify(true);
    try {
      const verified = await onCheckVerified();
      if (!verified) {
        setError(
          "لم يتم تأكيد البريد الإلكتروني بعد. يرجى فتح الرسالة في بريدك والضغط على رابط التأكيد ثم المحاولة مجدداً."
        );
      }
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : "تعذر التحقق من حالة الحساب. حاول مرة أخرى."
      );
    } finally {
      setCheckingVerify(false);
    }
  };

  const handleResendClick = async () => {
    if (resendCooldown > 0) return;
    setError(null);
    setInfoNotice(null);
    setResendingVerify(true);
    try {
      await onResendVerification();
      setInfoNotice("تم إرسال رابط تأكيد جديد إلى بريدك الإلكتروني.");
      setResendCooldown(30);
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : "تعذر إعادة إرسال رابط التأكيد حالياً."
      );
    } finally {
      setResendingVerify(false);
    }
  };

  const handleResetPinClick = async () => {
    setError(null);
    setInfoNotice(null);
    try {
      await onResetPin(email);
      setInfoNotice(
        "تم إرسال رابط إعادة تعيين رمز PIN إلى بريدك الإلكتروني إذا كان مسجلاً."
      );
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "تعذر إرسال رابط إعادة التعيين."
      );
    }
  };

  return (
    <div className="min-h-screen w-full bg-[#f0f2f5] dark:bg-[#0b141a] text-slate-900 dark:text-slate-100 flex flex-col justify-between p-4 sm:p-6 transition-colors duration-200">
      {/* Top Bar */}
      <header className="max-w-5xl w-full mx-auto flex items-center justify-between py-2">
        <div className="flex items-center gap-3">
          <MirsalLogo className="w-12 h-12 shrink-0 drop-shadow-xs" />
          <span className="font-display text-xl font-bold tracking-tight text-[#075E54] dark:text-[#25D366] whitespace-nowrap">
            مرسال
          </span>
        </div>

        <button
          type="button"
          onClick={onToggleTheme}
          aria-label={
            theme === "dark"
              ? "التبديل إلى الوضع النهاري"
              : "التبديل إلى الوضع الليلي"
          }
          className="min-h-[44px] px-4 py-2 rounded-xl bg-white dark:bg-[#202c33] border border-slate-200 dark:border-slate-700/70 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-[#2a3942] transition-colors flex items-center gap-2 text-sm font-medium cursor-pointer"
        >
          {theme === "dark" ? (
            <>
              <Sun className="w-4 h-4 text-amber-400" />
              <span>الوضع النهاري</span>
            </>
          ) : (
            <>
              <Moon className="w-4 h-4 text-slate-600" />
              <span>الوضع الليلي</span>
            </>
          )}
        </button>
      </header>

      {/* Main Content */}
      <main className="max-w-5xl w-full mx-auto my-auto py-6 grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
        <section className="lg:col-span-5 space-y-5 text-center lg:text-start">
          <h1
            className="font-display text-3xl sm:text-4xl font-bold text-slate-900 dark:text-white leading-snug"
            style={{ textWrap: "balance" }}
          >
            تواصل خاص ومباشر بأعلى درجات الخصوصية
          </h1>
          <p className="text-base text-slate-600 dark:text-slate-300 leading-relaxed max-w-md mx-auto lg:mx-0">
            أنشئ حسابك ببريدك الإلكتروني ورمز PIN خاص بالتطبيق، ثم ابحث عن أصدقائك بالاسم للمراسلة الفورية والمكالمات الصوتية والمرئية بأعلى درجات الخصوصية.
          </p>
          <div className="hidden lg:flex items-center gap-3 text-sm text-slate-500 dark:text-slate-400 pt-1">
            <span>حسابات موثّقة بالبريد</span>
            <span aria-hidden="true">·</span>
            <span>محادثات مباشرة ومكالمات فيديو</span>
            <span aria-hidden="true">·</span>
            <span>حالة الاتصال الفورية</span>
          </div>
        </section>

        <section className="lg:col-span-7">
          {pendingVerification ? (
            /* Email Verification Step */
            <div className="bg-white dark:bg-[#111b21] border border-slate-200/80 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-sm max-w-xl mx-auto space-y-6">
              <div className="flex flex-col items-center text-center space-y-3">
                <div className="w-16 h-16 rounded-2xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800/60 text-[#0d7a5f] dark:text-[#00a884] flex items-center justify-center">
                  <MailCheck className="w-8 h-8" />
                </div>
                <h2 className="font-display text-xl font-bold text-slate-900 dark:text-white">
                  تأكيد البريد الإلكتروني
                </h2>
                <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed max-w-md">
                  أرسلنا رابط تفعيل إلى بريدك الإلكتروني{" "}
                  <strong dir="ltr" className="text-slate-900 dark:text-white">
                    {pendingVerification.email}
                  </strong>
                  . افتح الرسالة واضغط على رابط التأكيد (تحقق من مجلد الرسائل غير المرغوب فيها إذا لم تجدها)، ثم اضغط على الزر أدناه.
                </p>
              </div>

              {error && (
                <p
                  role="alert"
                  className="text-sm text-rose-700 dark:text-rose-300 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/60 px-4 py-3 rounded-xl"
                >
                  {error}
                </p>
              )}

              {infoNotice && (
                <p className="text-sm text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/60 px-4 py-3 rounded-xl">
                  {infoNotice}
                </p>
              )}

              <div className="space-y-3">
                <button
                  type="button"
                  onClick={handleCheckVerifiedClick}
                  disabled={checkingVerify}
                  className="w-full min-h-[50px] px-6 py-3 rounded-xl bg-[#0d7a5f] hover:bg-[#0a634d] dark:bg-[#00a884] dark:hover:bg-[#069475] disabled:opacity-60 text-white font-display font-bold text-base flex items-center justify-center gap-2 transition-colors cursor-pointer"
                >
                  {checkingVerify && <Loader2 className="w-4 h-4 animate-spin" />}
                  <span>تم التأكيد، متابعة</span>
                </button>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <button
                    type="button"
                    onClick={handleResendClick}
                    disabled={resendingVerify || resendCooldown > 0}
                    className="min-h-[44px] px-4 py-2.5 rounded-xl bg-slate-100 dark:bg-[#202c33] hover:bg-slate-200 dark:hover:bg-[#2a3942] disabled:opacity-55 text-slate-700 dark:text-slate-200 text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer"
                  >
                    {resendingVerify ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <RefreshCw className="w-3.5 h-3.5" />
                    )}
                    <span>
                      {resendCooldown > 0
                        ? `إعادة الإرسال (${resendCooldown}ث)`
                        : "إعادة إرسال رابط التأكيد"}
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => void onCancelVerification()}
                    className="min-h-[44px] px-4 py-2.5 rounded-xl bg-slate-100 dark:bg-[#202c33] hover:bg-slate-200 dark:hover:bg-[#2a3942] text-slate-700 dark:text-slate-200 text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer"
                  >
                    <ArrowRight className="w-3.5 h-3.5" />
                    <span>تغيير الحساب</span>
                  </button>
                </div>
              </div>
            </div>
          ) : (
            /* Auth Tabs Card */
            <form
              onSubmit={handleSubmit}
              className="bg-white dark:bg-[#111b21] border border-slate-200/80 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-sm max-w-xl mx-auto"
            >
              {/* Two Tabs: إنشاء حساب جديد / تسجيل الدخول */}
              <div className="grid grid-cols-2 gap-1.5 p-1 bg-slate-100 dark:bg-[#202c33] rounded-2xl mb-6">
                <button
                  type="button"
                  onClick={() => {
                    setTab("register");
                    setError(null);
                    setInfoNotice(null);
                  }}
                  className={`min-h-[44px] px-3 py-2 rounded-xl text-sm font-bold transition-colors cursor-pointer ${
                    tab === "register"
                      ? "bg-white dark:bg-[#2a3942] text-[#0d7a5f] dark:text-[#00a884] shadow-xs"
                      : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200"
                  }`}
                >
                  إنشاء حساب جديد
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setTab("login");
                    setError(null);
                    setInfoNotice(null);
                  }}
                  className={`min-h-[44px] px-3 py-2 rounded-xl text-sm font-bold transition-colors cursor-pointer ${
                    tab === "login"
                      ? "bg-white dark:bg-[#2a3942] text-[#0d7a5f] dark:text-[#00a884] shadow-xs"
                      : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200"
                  }`}
                >
                  تسجيل الدخول
                </button>
              </div>

              <div className="space-y-4">
                {tab === "register" && (
                  <>
                    <div className="space-y-1.5">
                      <label
                        htmlFor="auth-name"
                        className="block text-sm font-semibold text-slate-800 dark:text-slate-200"
                      >
                        الاسم الشخصي
                      </label>
                      <input
                        id="auth-name"
                        type="text"
                        value={name}
                        onChange={(e) => {
                          setName(e.target.value);
                          if (error) setError(null);
                        }}
                        placeholder="اكتب اسمك كما سيظهر لأصدقائك"
                        maxLength={40}
                        autoFocus
                        className="w-full min-h-[48px] px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-[#202c33] border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-[#0d7a5f] dark:focus:ring-[#00a884] text-sm"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label
                        htmlFor="auth-country"
                        className="block text-sm font-semibold text-slate-800 dark:text-slate-200"
                      >
                        البلد
                      </label>
                      <select
                        id="auth-country"
                        value={countryCode}
                        onChange={(e) => setCountryCode(e.target.value)}
                        className="w-full min-h-[48px] px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-[#202c33] border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#0d7a5f] dark:focus:ring-[#00a884] text-sm cursor-pointer"
                      >
                        {COUNTRIES.map((country) => (
                          <option key={country.code} value={country.code}>
                            {country.flag} {country.nameAr}
                          </option>
                        ))}
                      </select>
                    </div>
                  </>
                )}

                <div className="space-y-1.5">
                  <label
                    htmlFor="auth-email"
                    className="block text-sm font-semibold text-slate-800 dark:text-slate-200"
                  >
                    البريد الإلكتروني
                  </label>
                  <input
                    id="auth-email"
                    dir="ltr"
                    type="email"
                    autoComplete="email"
                    value={email}
                    onChange={(e) => {
                      setEmail(e.target.value);
                      if (error) setError(null);
                    }}
                    placeholder="name@example.com"
                    className="w-full min-h-[48px] px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-[#202c33] border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-[#0d7a5f] dark:focus:ring-[#00a884] text-sm text-left"
                  />
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label
                      htmlFor="auth-pin"
                      className="block text-sm font-semibold text-slate-800 dark:text-slate-200"
                    >
                      {tab === "register"
                        ? "رمز مرور PIN جديد من 6 أرقام خاص بالتطبيق"
                        : "رمز مرور PIN المكوّن من 6 أرقام"}
                    </label>
                    {tab === "login" && (
                      <button
                        type="button"
                        onClick={() => void handleResetPinClick()}
                        className="text-xs font-semibold text-[#0d7a5f] dark:text-[#00a884] hover:underline cursor-pointer"
                      >
                        نسيت رمز PIN؟
                      </button>
                    )}
                  </div>

                  <div className="relative flex items-center">
                    <input
                      id="auth-pin"
                      dir="ltr"
                      type={showPin ? "text" : "password"}
                      inputMode="numeric"
                      pattern="[0-9]{6}"
                      maxLength={6}
                      autoComplete={
                        tab === "register" ? "new-password" : "current-password"
                      }
                      value={pin}
                      onChange={(e) => handlePinChange(e.target.value)}
                      placeholder="••••••"
                      className="w-full min-h-[50px] px-4 pl-12 py-2.5 rounded-xl bg-slate-50 dark:bg-[#202c33] border border-slate-200 dark:border-slate-700 text-center font-mono text-xl font-bold tracking-[0.4em] text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-[#0d7a5f] dark:focus:ring-[#00a884] tabular-nums"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPin((v) => !v)}
                      aria-label={showPin ? "إخفاء الرمز" : "إظهار الرمز"}
                      className="absolute left-2 min-h-[38px] min-w-[38px] rounded-lg flex items-center justify-center text-slate-500 hover:text-slate-700 dark:hover:text-slate-200 cursor-pointer"
                    >
                      {showPin ? (
                        <EyeOff className="w-4 h-4" />
                      ) : (
                        <Eye className="w-4 h-4" />
                      )}
                    </button>
                  </div>

                  {tab === "register" && (
                    <div className="flex items-start gap-2.5 p-3 rounded-xl bg-amber-50/90 dark:bg-emerald-950/35 border border-amber-300/90 dark:border-emerald-700/60 text-amber-950 dark:text-emerald-100">
                      <ShieldCheck className="w-4 h-4 text-amber-700 dark:text-emerald-400 shrink-0 mt-0.5" />
                      <p className="text-xs font-medium leading-relaxed">
                        لأمانك: اختر رمز PIN جديداً من 6 أرقام خاصاً بتطبيق مرسال فقط، ولا تستخدم كلمة مرور بريدك الإلكتروني الحقيقية
                      </p>
                    </div>
                  )}
                </div>

                {tab === "register" && (
                  <div className="pt-1">
                    <div className="flex items-center justify-between gap-3 p-3 rounded-2xl bg-slate-50 dark:bg-[#202c33] border border-slate-200 dark:border-slate-700/70">
                      <div className="flex items-center gap-3 min-w-0">
                        <Avatar
                          src={selectedAvatar}
                          name={name.trim() || "م"}
                          size="md"
                        />
                        <div className="min-w-0">
                          <span className="block text-xs font-bold text-slate-800 dark:text-slate-100">
                            الصورة الشخصية
                          </span>
                          <span className="block text-[11px] text-slate-500 dark:text-slate-400 truncate">
                            {isDataUrlAvatar(selectedAvatar)
                              ? "صورة حقيقية من جهازك"
                              : "الحروف الأولى من اسمك (أو ارفع صورة)"}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        {isDataUrlAvatar(selectedAvatar) && (
                          <button
                            type="button"
                            onClick={() => setSelectedAvatar(DEFAULT_USER_AVATAR)}
                            aria-label="إزالة الصورة"
                            className="min-h-[38px] w-9 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/50 text-rose-600 dark:text-rose-400 flex items-center justify-center cursor-pointer"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        )}
                        <label
                          htmlFor="signup-avatar-upload"
                          className={`relative min-h-[38px] px-3.5 py-2 rounded-xl bg-white dark:bg-[#111b21] border border-slate-200 dark:border-slate-700 hover:border-[#0d7a5f] dark:hover:border-[#00a884] text-xs font-bold text-[#0d7a5f] dark:text-[#00a884] flex items-center gap-1.5 shrink-0 transition-colors cursor-pointer ${
                            uploadingPhoto ? "opacity-60 pointer-events-none" : ""
                          }`}
                        >
                          {uploadingPhoto ? (
                            <Loader2 className="w-4 h-4 animate-spin shrink-0" />
                          ) : (
                            <ImagePlus className="w-4 h-4 shrink-0" />
                          )}
                          <span>رفع صورة</span>
                          <input
                            id="signup-avatar-upload"
                            type="file"
                            disabled={uploadingPhoto}
                            onClick={(e) => {
                              e.currentTarget.value = "";
                            }}
                            onChange={(e) => void handleSignupPhotoUpload(e)}
                            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                          />
                        </label>
                      </div>
                    </div>
                  </div>
                )}

                {error && (
                  <p
                    role="alert"
                    className="text-xs font-medium text-rose-700 dark:text-rose-300 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/60 px-3.5 py-2.5 rounded-xl"
                  >
                    {error}
                  </p>
                )}

                {infoNotice && (
                  <p className="text-xs font-medium text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/60 px-3.5 py-2.5 rounded-xl">
                    {infoNotice}
                  </p>
                )}

                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full min-h-[50px] px-6 py-3.5 rounded-xl bg-[#0d7a5f] hover:bg-[#0a634d] dark:bg-[#00a884] dark:hover:bg-[#069475] disabled:opacity-60 text-white font-display font-bold text-base transition-colors shadow-sm cursor-pointer flex items-center justify-center gap-2 active:scale-[0.99]"
                >
                  {submitting && <Loader2 className="w-4 h-4 animate-spin" />}
                  <span>
                    {tab === "register"
                      ? "إنشاء الحساب وإرسال رابط التأكيد"
                      : "تسجيل الدخول"}
                  </span>
                </button>
              </div>
            </form>
          )}
        </section>
      </main>

      <footer className="max-w-5xl w-full mx-auto text-center text-xs text-slate-500 dark:text-slate-400 py-2">
        مرسال · محادثات مباشرة ومكالمات صوتية ومرئية خاصة
      </footer>
    </div>
  );
}
