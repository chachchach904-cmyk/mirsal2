import { useCallback, useEffect, useState, type FormEvent } from "react";
import {
  Clapperboard,
  ExternalLink,
  Globe,
  Loader2,
  RefreshCw,
  Send,
  ShieldAlert,
  X,
} from "lucide-react";
import type { MediaResolveResult } from "../types/chat";
import { extractSiteNameFromUrl } from "../utils/storage";

interface InAppBrowserModalProps {
  isOpen: boolean;
  url: string;
  initialTitle?: string;
  canWatchTogether?: boolean;
  onClose: () => void;
  onShareToChat?: (url: string, title?: string) => Promise<void> | void;
  onWatchTogether?: (resolved: MediaResolveResult) => Promise<void> | void;
}

export function InAppBrowserModal({
  isOpen,
  url,
  initialTitle,
  canWatchTogether = false,
  onClose,
  onShareToChat,
  onWatchTogether,
}: InAppBrowserModalProps) {
  const [addressInput, setAddressInput] = useState(url);
  const [activeUrl, setActiveUrl] = useState(url);
  const [resolved, setResolved] = useState<MediaResolveResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [forceCardView, setForceCardView] = useState(false);
  const [sharing, setSharing] = useState(false);
  const [watching, setWatching] = useState(false);
  const [thumbFailed, setThumbFailed] = useState(false);

  const loadResolvedMedia = useCallback(async (targetUrl: string) => {
    const clean = targetUrl.trim();
    if (!clean) return;
    const normalized = /^https?:\/\//i.test(clean) ? clean : `https://${clean}`;
    setActiveUrl(normalized);
    setAddressInput(normalized);
    setLoading(true);
    setError(null);
    setForceCardView(false);
    setThumbFailed(false);

    try {
      const res = await fetch(
        `/api/resolve-media?url=${encodeURIComponent(normalized)}`,
        { signal: AbortSignal.timeout(8000) }
      );
      const data = (await res.json().catch(() => ({}))) as MediaResolveResult & {
        error?: string;
      };
      if (!res.ok || data.error) {
        setResolved({
          url: normalized,
          resolvedUrl: normalized,
          platform: "web",
          siteName: extractSiteNameFromUrl(normalized),
          title: initialTitle || extractSiteNameFromUrl(normalized) || normalized,
          description: "",
          thumbnail: "",
          directVideoUrl: null,
          embedUrl: null,
          videoId: null,
          canEmbed: false,
          isVideo: false,
          blockReason:
            data.error || "تعذر فحص الرابط للعرض المدمج. يمكنك فتحه في متصفح خارجي.",
        });
      } else {
        setResolved(data);
      }
    } catch {
      setError("تعذر فحص هذا الموقع عبر الخادم. يمكنك فتحه مباشرة في متصفح خارجي.");
      setResolved({
        url: normalized,
        resolvedUrl: normalized,
        platform: "web",
        siteName: extractSiteNameFromUrl(normalized),
        title: initialTitle || extractSiteNameFromUrl(normalized) || normalized,
        description: "",
        thumbnail: "",
        directVideoUrl: null,
        embedUrl: null,
        videoId: null,
        canEmbed: false,
        isVideo: false,
        blockReason: "انتهت مهلة الاتصال أو تعذر تحليل الصفحة للعرض المدمج.",
      });
    } finally {
      setLoading(false);
    }
  }, [initialTitle]);

  useEffect(() => {
    if (!isOpen || !url) return;
    void loadResolvedMedia(url);
  }, [isOpen, url, loadResolvedMedia]);

  useEffect(() => {
    if (!isOpen) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const finalHref = resolved?.resolvedUrl || activeUrl;
  const pageTitle =
    resolved?.title || initialTitle || extractSiteNameFromUrl(finalHref) || "المتصفح المدمج";
  const siteName = resolved?.siteName || extractSiteNameFromUrl(finalHref);
  const iframeSrc = resolved?.embedUrl || finalHref;

  const handleNavigate = (e: FormEvent) => {
    e.preventDefault();
    if (!addressInput.trim()) return;
    void loadResolvedMedia(addressInput);
  };

  const handleShare = async () => {
    if (!onShareToChat || sharing) return;
    setSharing(true);
    try {
      await onShareToChat(finalHref, pageTitle);
      onClose();
    } finally {
      setSharing(false);
    }
  };

  const handleWatch = async () => {
    if (!onWatchTogether || !resolved || watching) return;
    setWatching(true);
    try {
      await onWatchTogether(resolved);
      onClose();
    } finally {
      setWatching(false);
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="المتصفح المدمج في مرسال"
      className="fixed inset-0 z-[70] flex items-center justify-center bg-black/65 backdrop-blur-xs p-0 sm:p-4"
      onClick={onClose}
    >
      <div
        dir="rtl"
        onClick={(e) => e.stopPropagation()}
        className="w-full h-full sm:h-[90dvh] sm:max-w-4xl bg-white dark:bg-[#111b21] sm:rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col overflow-hidden"
      >
        {/* Top Browser Bar */}
        <header className="px-3 sm:px-4 py-2.5 bg-slate-50 dark:bg-[#202c33] border-b border-slate-200 dark:border-slate-800 space-y-2 shrink-0">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2 min-w-0">
              <div className="w-8 h-8 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-[#0d7a5f] dark:text-[#00a884] flex items-center justify-center shrink-0">
                <Globe className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <h2 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white truncate">
                  {pageTitle}
                </h2>
                {siteName && (
                  <p className="text-[10.5px] text-slate-500 dark:text-slate-400 truncate">
                    {siteName}
                  </p>
                )}
              </div>
            </div>

            <div className="flex items-center gap-1.5 shrink-0">
              {onShareToChat && (
                <button
                  type="button"
                  disabled={sharing}
                  onClick={() => void handleShare()}
                  className="min-h-[36px] px-2.5 sm:px-3 rounded-xl bg-[#0d7a5f] hover:bg-[#0a634d] dark:bg-[#00a884] dark:hover:bg-[#069475] text-white text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-50"
                >
                  {sharing ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <Send className="w-3.5 h-3.5" />
                  )}
                  <span className="hidden sm:inline">مشاركة</span>
                </button>
              )}

              {canWatchTogether && onWatchTogether && resolved && (
                <button
                  type="button"
                  disabled={watching}
                  onClick={() => void handleWatch()}
                  className="min-h-[36px] px-2.5 sm:px-3 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-50"
                >
                  {watching ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <Clapperboard className="w-3.5 h-3.5" />
                  )}
                  <span className="hidden sm:inline">مشاهدة معاً</span>
                </button>
              )}

              <a
                href={finalHref}
                target="_blank"
                rel="noopener noreferrer"
                className="min-h-[36px] px-2.5 sm:px-3 rounded-xl bg-slate-200/80 hover:bg-slate-300/80 dark:bg-[#2a3942] dark:hover:bg-[#374852] text-slate-800 dark:text-slate-100 text-xs font-bold flex items-center gap-1.5 transition-colors"
                title="فتح الموقع الأصلي"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span className="hidden md:inline">فتح الموقع الأصلي</span>
              </a>

              <button
                type="button"
                onClick={onClose}
                aria-label="إغلاق المتصفح"
                className="min-h-[36px] min-w-[36px] rounded-xl flex items-center justify-center text-slate-500 hover:bg-slate-200/70 dark:hover:bg-slate-700 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          <form onSubmit={handleNavigate} className="flex items-center gap-2">
            <input
              type="text"
              dir="ltr"
              value={addressInput}
              onChange={(e) => setAddressInput(e.target.value)}
              placeholder="https://..."
              aria-label="عنوان الرابط"
              className="flex-1 min-h-[38px] px-3 rounded-xl bg-white dark:bg-[#111b21] border border-slate-200 dark:border-slate-700 text-xs text-slate-800 dark:text-slate-100 font-mono focus:outline-none focus:ring-2 focus:ring-[#0d7a5f] dark:focus:ring-[#00a884]"
            />
            <button
              type="button"
              onClick={() => void loadResolvedMedia(activeUrl)}
              disabled={loading}
              aria-label="تحديث الصفحة"
              className="min-h-[38px] min-w-[38px] rounded-xl bg-white dark:bg-[#111b21] border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-200 flex items-center justify-center hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
            </button>
          </form>
        </header>

        {/* Browser Body */}
        <div className="flex-1 min-h-0 flex flex-col bg-slate-100 dark:bg-[#0b141a] overflow-hidden">
          {loading ? (
            <div className="flex-1 flex flex-col items-center justify-center gap-3 p-6 text-slate-500 dark:text-slate-400">
              <Loader2 className="w-8 h-8 animate-spin text-[#0d7a5f] dark:text-[#00a884]" />
              <p className="text-xs sm:text-sm font-semibold">
                جاري فحص وتجهيز الصفحة للعرض داخل مرسال...
              </p>
            </div>
          ) : resolved?.directVideoUrl ? (
            <div className="flex-1 overflow-y-auto p-4 flex flex-col items-center justify-center gap-4">
              <video
                src={resolved.directVideoUrl}
                controls
                playsInline
                autoPlay
                className="w-full max-w-3xl max-h-[62dvh] rounded-2xl bg-black shadow-xl"
              />
              <div className="w-full max-w-3xl bg-white dark:bg-[#111b21] rounded-2xl p-4 border border-slate-200 dark:border-slate-800 space-y-1.5">
                <span className="text-[11px] font-bold text-[#0d7a5f] dark:text-[#00a884]">
                  {siteName}
                </span>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  {pageTitle}
                </h3>
                {resolved.description && (
                  <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                    {resolved.description}
                  </p>
                )}
              </div>
            </div>
          ) : resolved?.canEmbed && !forceCardView ? (
            <div className="flex-1 flex flex-col min-h-0">
              <div className="px-3 py-1.5 bg-slate-200/75 dark:bg-[#182229] border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2 text-[11px] text-slate-600 dark:text-slate-300 shrink-0">
                <span>تم التحميل داخل المتصفح المدمج لمرسال</span>
                <button
                  type="button"
                  onClick={() => setForceCardView(true)}
                  className="font-bold text-[#0d7a5f] dark:text-[#00a884] hover:underline cursor-pointer"
                >
                  عرض بطاقة الملخص والروابط
                </button>
              </div>
              <iframe
                src={iframeSrc}
                title={pageTitle}
                sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-presentation"
                allow="autoplay; fullscreen; encrypted-media; picture-in-picture"
                className="w-full flex-1 border-0 bg-white dark:bg-[#0b141a]"
              />
            </div>
          ) : (
            <div className="flex-1 overflow-y-auto p-4 sm:p-6 flex items-center justify-center">
              <div className="w-full max-w-lg bg-white dark:bg-[#111b21] border border-slate-200 dark:border-slate-800 rounded-3xl p-5 sm:p-6 shadow-xl space-y-4">
                {resolved?.thumbnail && !thumbFailed ? (
                  <div className="w-full aspect-video rounded-2xl overflow-hidden bg-slate-900">
                    <img
                      src={resolved.thumbnail}
                      alt={pageTitle}
                      referrerPolicy="no-referrer"
                      onError={() => setThumbFailed(true)}
                      className="w-full h-full object-cover"
                    />
                  </div>
                ) : (
                  <div className="w-14 h-14 mx-auto rounded-2xl bg-emerald-50 dark:bg-emerald-950/60 text-[#0d7a5f] dark:text-[#00a884] flex items-center justify-center">
                    <Globe className="w-7 h-7" />
                  </div>
                )}

                <div className="space-y-1.5 text-center sm:text-right">
                  {siteName && (
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-lg bg-slate-100 dark:bg-[#202c33] text-[11px] font-bold text-slate-600 dark:text-slate-300">
                      {siteName}
                    </span>
                  )}
                  <h3 className="text-base font-bold text-slate-900 dark:text-white leading-snug">
                    {pageTitle}
                  </h3>
                  {resolved?.description && (
                    <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                      {resolved.description}
                    </p>
                  )}
                  <p
                    dir="ltr"
                    className="text-[11px] font-mono text-slate-400 break-all pt-1"
                  >
                    {finalHref}
                  </p>
                </div>

                {(resolved?.blockReason || error) && (
                  <div className="p-3 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200/80 dark:border-amber-800/50 flex items-start gap-2.5 text-xs text-amber-800 dark:text-amber-200">
                    <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5" />
                    <span className="leading-relaxed">
                      {error || resolved?.blockReason}
                    </span>
                  </div>
                )}

                <div className="flex flex-wrap items-center gap-2 pt-1">
                  <a
                    href={finalHref}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 min-w-[140px] min-h-[44px] px-4 py-2.5 rounded-xl bg-[#0d7a5f] hover:bg-[#0a634d] dark:bg-[#00a884] dark:hover:bg-[#069475] text-white text-xs font-bold flex items-center justify-center gap-2 transition-colors"
                  >
                    <ExternalLink className="w-4 h-4" />
                    <span>فتح الموقع الأصلي</span>
                  </a>

                  {resolved?.canEmbed && (
                    <button
                      type="button"
                      onClick={() => setForceCardView(false)}
                      className="min-h-[44px] px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-[#202c33] dark:hover:bg-[#2a3942] text-slate-800 dark:text-slate-100 text-xs font-bold cursor-pointer"
                    >
                      العودة للإطار المدمج
                    </button>
                  )}

                  {onShareToChat && (
                    <button
                      type="button"
                      disabled={sharing}
                      onClick={() => void handleShare()}
                      className="min-h-[44px] px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-[#202c33] dark:hover:bg-[#2a3942] text-slate-800 dark:text-slate-100 text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>مشاركة في المحادثة</span>
                    </button>
                  )}

                  {canWatchTogether && onWatchTogether && resolved && (
                    <button
                      type="button"
                      disabled={watching}
                      onClick={() => void handleWatch()}
                      className="min-h-[44px] px-4 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                    >
                      <Clapperboard className="w-3.5 h-3.5" />
                      <span>تشغيل في المشاهدة المشتركة</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
