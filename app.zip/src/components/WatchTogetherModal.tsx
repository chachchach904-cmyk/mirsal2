import { useEffect, useRef, useState, type ChangeEvent, type FormEvent } from "react";
import {
  Clapperboard,
  Clock,
  FileVideo,
  Film,
  History,
  Link2,
  Loader2,
  Music2,
  Play,
  Trash2,
  Upload,
  X,
  Youtube,
} from "lucide-react";
import type { MediaResolveResult, WatchHistoryItem } from "../types/chat";
import {
  buildSafeWatchVideoId,
  extractSiteNameFromUrl,
  extractYouTubeVideoId,
  formatMessageTime,
  isShortFacebookShareUrl,
  parseFacebookVideoUrl,
  parseInstagramUrl,
  parseTikTokVideoUrl,
  parseUniversalWebUrl,
  parseWatchStreamUrl,
} from "../utils/storage";

export function GoogleGIcon({ className = "w-5 h-5" }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      aria-hidden="true"
      className={className}
    >
      <path
        fill="#4285F4"
        d="M23.49 12.27c0-.79-.07-1.54-.19-2.27H12v4.51h6.47a5.53 5.53 0 0 1-2.4 3.63v3.01h3.88c2.27-2.09 3.54-5.17 3.54-8.88Z"
      />
      <path
        fill="#34A853"
        d="M12 24c3.24 0 5.95-1.07 7.94-2.9l-3.88-3.01c-1.07.72-2.45 1.15-4.06 1.15-3.12 0-5.77-2.11-6.72-4.96H1.28v3.1A12 12 0 0 0 12 24Z"
      />
      <path
        fill="#FBBC05"
        d="M5.28 14.28A7.2 7.2 0 0 1 4.9 12c0-.79.14-1.56.38-2.28v-3.1H1.28A12 12 0 0 0 0 12c0 1.94.46 3.77 1.28 5.38l4-3.1Z"
      />
      <path
        fill="#EA4335"
        d="M12 4.76c1.76 0 3.34.61 4.58 1.8l3.43-3.43C17.95 1.19 15.24 0 12 0 7.31 0 3.26 2.69 1.28 6.62l4 3.1C6.23 6.87 8.88 4.76 12 4.76Z"
      />
    </svg>
  );
}

type WatchMethodTab = "youtube" | "facebook" | "tiktok" | "stream" | "file";

interface WatchTogetherModalProps {
  isOpen: boolean;
  isDirectChat: boolean;
  watchHistory?: WatchHistoryItem[];
  onClose: () => void;
  onStartYouTube: (
    videoId: string,
    youtubeUrl: string,
    title?: string
  ) => Promise<void>;
  onStartFacebook: (facebookUrl: string, title?: string) => Promise<void>;
  onStartTikTok: (
    videoId: string,
    tiktokUrl: string,
    title?: string
  ) => Promise<void>;
  onStartStream: (
    mediaType: "mp4" | "m3u8",
    mediaUrl: string,
    title?: string
  ) => Promise<void>;
  onStartInstagram?: (
    videoId: string,
    instagramUrl: string,
    title?: string
  ) => Promise<void>;
  onStartWebLink?: (
    videoId: string,
    webUrl: string,
    title?: string,
    siteName?: string
  ) => Promise<void>;
  onStartVideoFile: (file: File) => Promise<void>;
  onDeleteWatchHistory?: (historyId: string) => Promise<void>;
}

export function WatchTogetherModal({
  isOpen,
  isDirectChat,
  watchHistory = [],
  onClose,
  onStartYouTube,
  onStartFacebook,
  onStartTikTok,
  onStartStream,
  onStartInstagram,
  onStartWebLink,
  onStartVideoFile,
  onDeleteWatchHistory,
}: WatchTogetherModalProps) {
  const [activeTab, setActiveTab] = useState<WatchMethodTab>("youtube");
  const [youtubeInput, setYoutubeInput] = useState("");
  const [facebookInput, setFacebookInput] = useState("");
  const [tiktokInput, setTiktokInput] = useState("");
  const [streamInput, setStreamInput] = useState("");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [deletingHistoryId, setDeletingHistoryId] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setError(null);
      setBusy(false);
    }
  }, [isOpen]);

  useEffect(() => {
    if (!isOpen) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const resolveAndStartTikTok = async (rawInput: string): Promise<boolean> => {
    const parsed = parseTikTokVideoUrl(rawInput);
    if (!parsed) return false;

    setBusy(true);
    setError(null);
    try {
      let resolvedUrl = parsed.url;
      let videoId = parsed.videoId;
      let resolvedTitle: string | undefined;

      try {
        const res = await fetch(
          `/api/resolve-tiktok?url=${encodeURIComponent(parsed.url)}`,
          { signal: AbortSignal.timeout(6500) }
        );
        if (res.ok) {
          const data = (await res.json()) as {
            resolvedUrl?: string;
            videoId?: string | null;
            title?: string;
            available?: boolean;
            unavailableReason?: string | null;
          };
          if (data.available === false) {
            setError(
              data.unavailableReason ||
                "هذا الفيديو غير متاح أو محذوف أو خاص على تيك توك."
            );
            return false;
          }
          if (data.resolvedUrl) resolvedUrl = data.resolvedUrl;
          if (data.videoId) videoId = data.videoId;
          if (data.title) resolvedTitle = data.title;
        }
      } catch {
        // fallback to direct videoId if offline/timeout
      }

      if (!videoId) {
        setError(
          "تعذر استخراج معرف الفيديو من رابط تيك توك. تأكد أن الرابط عام وسليم ثم حاول مجدداً."
        );
        return false;
      }

      await onStartTikTok(videoId, resolvedUrl, resolvedTitle);
      return true;
    } catch {
      setError("تعذر تشغيل فيديو تيك توك في المحادثة. حاول مجدداً.");
      return false;
    } finally {
      setBusy(false);
    }
  };

  const resolveAndStartAnyWebUrl = async (rawInput: string): Promise<boolean> => {
    const igParsed = parseInstagramUrl(rawInput);
    if (igParsed) {
      setBusy(true);
      setError(null);
      try {
        if (onStartInstagram) {
          await onStartInstagram(
            buildSafeWatchVideoId("ig", igParsed.shortCode),
            igParsed.url
          );
        } else if (onStartWebLink) {
          await onStartWebLink(
            buildSafeWatchVideoId("ig", igParsed.shortCode),
            igParsed.url,
            "منشور/ريل إنستغرام",
            "Instagram"
          );
        }
        return true;
      } catch {
        setError("تعذر فتح رابط إنستغرام في المشاهدة المشتركة.");
        return false;
      } finally {
        setBusy(false);
      }
    }

    const webUrl = parseUniversalWebUrl(rawInput);
    if (!webUrl) return false;

    setBusy(true);
    setError(null);
    try {
      let resolved: MediaResolveResult | null = null;
      try {
        const res = await fetch(
          `/api/resolve-media?url=${encodeURIComponent(webUrl)}`,
          { signal: AbortSignal.timeout(6500) }
        );
        if (res.ok) {
          resolved = (await res.json()) as MediaResolveResult;
        }
      } catch {
        // fallback to raw web link
      }

      if (resolved?.platform === "youtube" && resolved.videoId) {
        await onStartYouTube(resolved.videoId, resolved.resolvedUrl, resolved.title);
        return true;
      }
      if (resolved?.platform === "facebook") {
        await onStartFacebook(resolved.resolvedUrl, resolved.title);
        return true;
      }
      if (resolved?.platform === "tiktok" && resolved.videoId) {
        await onStartTikTok(resolved.videoId, resolved.resolvedUrl, resolved.title);
        return true;
      }
      if (resolved?.platform === "instagram" && onStartInstagram) {
        await onStartInstagram(
          resolved.videoId || buildSafeWatchVideoId("ig", resolved.resolvedUrl),
          resolved.resolvedUrl,
          resolved.title
        );
        return true;
      }

      const finalUrl = resolved?.resolvedUrl || webUrl;
      const siteName = resolved?.siteName || extractSiteNameFromUrl(finalUrl);
      const title = resolved?.title || siteName || "رابط ويب مشترك";

      if (onStartWebLink) {
        await onStartWebLink(
          buildSafeWatchVideoId("web", finalUrl),
          finalUrl,
          title,
          siteName
        );
        return true;
      }

      return false;
    } catch {
      setError("تعذر تشغيل هذا الرابط في المشاهدة المشتركة.");
      return false;
    } finally {
      setBusy(false);
    }
  };

  const handleSubmitYoutube = async (e: FormEvent) => {
    e.preventDefault();
    const fbUrl = parseFacebookVideoUrl(youtubeInput);
    if (fbUrl) {
      setBusy(true);
      setError(null);
      try {
        await onStartFacebook(fbUrl);
        setYoutubeInput("");
        onClose();
      } catch {
        setError("تعذر تشغيل فيديو فيسبوك في المحادثة. حاول مجدداً.");
      } finally {
        setBusy(false);
      }
      return;
    }

    if (parseTikTokVideoUrl(youtubeInput)) {
      const ok = await resolveAndStartTikTok(youtubeInput);
      if (ok) {
        setYoutubeInput("");
        onClose();
      }
      return;
    }

    if (parseInstagramUrl(youtubeInput)) {
      const ok = await resolveAndStartAnyWebUrl(youtubeInput);
      if (ok) {
        setYoutubeInput("");
        onClose();
      }
      return;
    }

    const videoId = extractYouTubeVideoId(youtubeInput);
    if (!videoId) {
      setError(
        "الرابط غير صالح. يرجى لصق رابط فيديو يوتيوب صحيح مثل youtube.com أو youtu.be."
      );
      return;
    }

    setBusy(true);
    setError(null);
    try {
      await onStartYouTube(videoId, youtubeInput.trim());
      setYoutubeInput("");
      onClose();
    } catch {
      setError("تعذر تشغيل فيديو يوتيوب في المحادثة. حاول مجدداً.");
    } finally {
      setBusy(false);
    }
  };

  const handleSubmitFacebook = async (e: FormEvent) => {
    e.preventDefault();
    const fbUrl = parseFacebookVideoUrl(facebookInput);
    if (!fbUrl) {
      setError(
        "الرابط غير صالح. يرجى لصق رابط فيديو أو ريلز فيسبوك عام مثل facebook.com أو fb.watch."
      );
      return;
    }

    setBusy(true);
    setError(null);
    try {
      await onStartFacebook(fbUrl);
      setFacebookInput("");
      onClose();
    } catch {
      setError("تعذر تشغيل فيديو فيسبوك في المحادثة. حاول مجدداً.");
    } finally {
      setBusy(false);
    }
  };

  const handleSubmitTikTok = async (e: FormEvent) => {
    e.preventDefault();
    if (!parseTikTokVideoUrl(tiktokInput)) {
      setError(
        "الرابط غير صالح. يرجى لصق رابط فيديو تيك توك صحيح مثل tiktok.com أو vm.tiktok.com."
      );
      return;
    }
    const ok = await resolveAndStartTikTok(tiktokInput);
    if (ok) {
      setTiktokInput("");
      onClose();
    }
  };

  const handleSubmitStream = async (e: FormEvent) => {
    e.preventDefault();
    const fbUrl = parseFacebookVideoUrl(streamInput);
    if (fbUrl) {
      setBusy(true);
      setError(null);
      try {
        await onStartFacebook(fbUrl);
        setStreamInput("");
        onClose();
      } catch {
        setError("تعذر تشغيل فيديو فيسبوك في المحادثة. حاول مجدداً.");
      } finally {
        setBusy(false);
      }
      return;
    }

    if (parseTikTokVideoUrl(streamInput)) {
      const ok = await resolveAndStartTikTok(streamInput);
      if (ok) {
        setStreamInput("");
        onClose();
      }
      return;
    }

    const ytId = extractYouTubeVideoId(streamInput);
    if (ytId) {
      setBusy(true);
      setError(null);
      try {
        await onStartYouTube(ytId, streamInput.trim());
        setStreamInput("");
        onClose();
      } catch {
        setError("تعذر تشغيل فيديو يوتيوب.");
      } finally {
        setBusy(false);
      }
      return;
    }

    const parsed = parseWatchStreamUrl(streamInput);
    if (parsed) {
      setBusy(true);
      setError(null);
      try {
        await onStartStream(parsed.mediaType, parsed.url);
        setStreamInput("");
        onClose();
      } catch {
        setError("تعذر تشغيل رابط البث في المحادثة. حاول مجدداً.");
      } finally {
        setBusy(false);
      }
      return;
    }

    const okWeb = await resolveAndStartAnyWebUrl(streamInput);
    if (okWeb) {
      setStreamInput("");
      onClose();
      return;
    }

    setError(
      "الرابط غير صالح. أدخل رابطاً يبدأ بـ https:// (مباشر .mp4/.m3u8 أو إنستغرام أو صفحة فيديو)."
    );
  };

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith("video/")) {
      setError("يرجى اختيار ملف فيديو صالح من جهازك.");
      e.target.value = "";
      return;
    }
    setError(null);
    setSelectedFile(file);
  };

  const handleStartFileShare = async () => {
    if (!selectedFile || busy) return;
    if (!isDirectChat) {
      setError("البث المباشر للفيديو متاح في المحادثات الخاصة مع الأصدقاء.");
      return;
    }

    setBusy(true);
    setError(null);
    try {
      await onStartVideoFile(selectedFile);
      setSelectedFile(null);
      onClose();
    } catch {
      setError("تعذر بدء بث ملف الفيديو. حاول مجدداً.");
    } finally {
      setBusy(false);
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024 * 1024) {
      return `${Math.max(1, Math.round(bytes / 1024))} ك.ب`;
    }
    return `${(bytes / (1024 * 1024)).toFixed(1)} م.ب`;
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="watch-together-title"
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/50 backdrop-blur-xs p-0 sm:p-4"
      onClick={onClose}
    >
      <div
        dir="rtl"
        onClick={(e) => e.stopPropagation()}
        className="w-full sm:max-w-md bg-white dark:bg-[#111b21] border-t sm:border border-slate-200 dark:border-slate-800 rounded-t-3xl sm:rounded-3xl p-5 sm:p-6 shadow-2xl max-h-[90vh] overflow-y-auto custom-scrollbar"
      >
        <div className="w-10 h-1.5 bg-slate-300 dark:bg-slate-700 rounded-full mx-auto mb-4 sm:hidden" />

        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-[#0d7a5f] dark:text-[#00a884] flex items-center justify-center">
              <Clapperboard className="w-5 h-5" />
            </div>
            <div>
              <h2
                id="watch-together-title"
                className="font-display text-base sm:text-lg font-bold text-slate-900 dark:text-white"
              >
                مشاهدة فيلم أو فيديو معاً
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                اختر الطريقة المناسبة للمشاهدة المتزامنة مع صديقك
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="إغلاق"
            className="min-h-[42px] min-w-[42px] rounded-xl flex items-center justify-center text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 5 Method Tabs */}
        <div className="mt-4 grid grid-cols-5 gap-1 p-1 rounded-2xl bg-slate-100 dark:bg-[#202c33]">
          <button
            type="button"
            onClick={() => {
              setActiveTab("youtube");
              setError(null);
            }}
            className={`min-h-[42px] px-1 py-2 rounded-xl text-[10.5px] sm:text-xs font-bold flex flex-col sm:flex-row items-center justify-center gap-1 transition-colors cursor-pointer ${
              activeTab === "youtube"
                ? "bg-white dark:bg-[#111b21] text-rose-600 dark:text-rose-400 shadow-xs"
                : "text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white"
            }`}
          >
            <Youtube className="w-3.5 h-3.5 shrink-0" />
            <span>يوتيوب</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveTab("facebook");
              setError(null);
            }}
            className={`min-h-[42px] px-1 py-2 rounded-xl text-[10.5px] sm:text-xs font-bold flex flex-col sm:flex-row items-center justify-center gap-1 transition-colors cursor-pointer ${
              activeTab === "facebook"
                ? "bg-white dark:bg-[#111b21] text-blue-600 dark:text-blue-400 shadow-xs"
                : "text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white"
            }`}
          >
            <Film className="w-3.5 h-3.5 shrink-0" />
            <span>فيسبوك</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveTab("tiktok");
              setError(null);
            }}
            className={`min-h-[42px] px-1 py-2 rounded-xl text-[10.5px] sm:text-xs font-bold flex flex-col sm:flex-row items-center justify-center gap-1 transition-colors cursor-pointer ${
              activeTab === "tiktok"
                ? "bg-white dark:bg-[#111b21] text-slate-900 dark:text-white shadow-xs"
                : "text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white"
            }`}
          >
            <Music2 className="w-3.5 h-3.5 shrink-0" />
            <span>تيك توك</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveTab("stream");
              setError(null);
            }}
            className={`min-h-[42px] px-1 py-2 rounded-xl text-[10.5px] sm:text-xs font-bold flex flex-col sm:flex-row items-center justify-center gap-1 transition-colors cursor-pointer ${
              activeTab === "stream"
                ? "bg-white dark:bg-[#111b21] text-[#0d7a5f] dark:text-[#00a884] shadow-xs"
                : "text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white"
            }`}
          >
            <Link2 className="w-3.5 h-3.5 shrink-0" />
            <span>مباشر</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveTab("file");
              setError(null);
            }}
            className={`min-h-[42px] px-1 py-2 rounded-xl text-[10.5px] sm:text-xs font-bold flex flex-col sm:flex-row items-center justify-center gap-1 transition-colors cursor-pointer ${
              activeTab === "file"
                ? "bg-white dark:bg-[#111b21] text-[#0d7a5f] dark:text-[#00a884] shadow-xs"
                : "text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white"
            }`}
          >
            <FileVideo className="w-3.5 h-3.5 shrink-0" />
            <span>الهاتف</span>
          </button>
        </div>

        {/* Method Content */}
        <div className="mt-4">
          {activeTab === "youtube" && (
            <form onSubmit={(e) => void handleSubmitYoutube(e)} className="space-y-3">
              <div className="space-y-1.5">
                <label
                  htmlFor="watch-youtube-url"
                  className="block text-xs font-semibold text-slate-700 dark:text-slate-200"
                >
                  أ) لصق رابط فيديو يوتيوب (YouTube)
                </label>
                <input
                  id="watch-youtube-url"
                  type="text"
                  dir="ltr"
                  value={youtubeInput}
                  onChange={(e) => {
                    setYoutubeInput(e.target.value);
                    if (error) setError(null);
                  }}
                  placeholder="https://www.youtube.com/watch?v=..."
                  className="w-full min-h-[44px] px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-[#202c33] border border-slate-200 dark:border-slate-700 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-rose-500"
                />
              </div>

              {error && (
                <p role="alert" className="text-xs text-rose-600 dark:text-rose-400">
                  {error}
                </p>
              )}

              <button
                type="submit"
                disabled={busy || !youtubeInput.trim()}
                className="w-full min-h-[46px] px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 disabled:opacity-50 text-white text-sm font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                {busy ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Play className="w-4 h-4" />
                )}
                <span>تشغيل يوتيوب معاً</span>
              </button>
            </form>
          )}

          {activeTab === "facebook" && (
            <form onSubmit={(e) => void handleSubmitFacebook(e)} className="space-y-3">
              <div className="space-y-1.5">
                <label
                  htmlFor="watch-facebook-url"
                  className="block text-xs font-semibold text-slate-700 dark:text-slate-200"
                >
                  ب) لصق رابط فيديو أو ريلز فيسبوك (Facebook Watch / Reels)
                </label>
                <input
                  id="watch-facebook-url"
                  type="url"
                  dir="ltr"
                  value={facebookInput}
                  onChange={(e) => {
                    setFacebookInput(e.target.value);
                    if (error) setError(null);
                  }}
                  placeholder="https://www.facebook.com/.../videos/... أو /reel/ أو /share/v/..."
                  className="w-full min-h-[44px] px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-[#202c33] border border-slate-200 dark:border-slate-700 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                  يدعم فيديوهات فيسبوك العامة (Public) فقط (/videos/، /reel/، /watch/، /share/v/، fb.watch).
                </p>
                {isShortFacebookShareUrl(facebookInput) && (
                  <p className="text-[11px] text-amber-700 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/50 rounded-xl px-2.5 py-1.5 leading-relaxed">
                    يدعم فيديوهات فيسبوك العامة (Public) فقط؛ وإذا لم يعمل رابط المشاركة القصير (/share/v/)، افتح الفيديو في المتصفح وانسخ الرابط الكامل من شريط العنوان.
                  </p>
                )}
              </div>

              {error && (
                <p role="alert" className="text-xs text-rose-600 dark:text-rose-400">
                  {error}
                </p>
              )}

              <button
                type="submit"
                disabled={busy || !facebookInput.trim()}
                className="w-full min-h-[46px] px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-sm font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                {busy ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Play className="w-4 h-4" />
                )}
                <span>تشغيل فيديو فيسبوك معاً</span>
              </button>
            </form>
          )}

          {activeTab === "tiktok" && (
            <form onSubmit={(e) => void handleSubmitTikTok(e)} className="space-y-3">
              <div className="space-y-1.5">
                <label
                  htmlFor="watch-tiktok-url"
                  className="block text-xs font-semibold text-slate-700 dark:text-slate-200"
                >
                  ج) لصق رابط فيديو تيك توك (TikTok)
                </label>
                <input
                  id="watch-tiktok-url"
                  type="url"
                  dir="ltr"
                  value={tiktokInput}
                  onChange={(e) => {
                    setTiktokInput(e.target.value);
                    if (error) setError(null);
                  }}
                  placeholder="https://www.tiktok.com/@user/video/... أو https://vm.tiktok.com/..."
                  className="w-full min-h-[44px] px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-[#202c33] border border-slate-200 dark:border-slate-700 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-pink-500"
                />
                <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                  يدعم روابط فيديوهات تيك توك الكاملة والروابط المختصرة (tiktok.com و vm.tiktok.com) مع مزامنة التشغيل والإيقاف مع صديقك.
                </p>
              </div>

              {error && (
                <p role="alert" className="text-xs text-rose-600 dark:text-rose-400">
                  {error}
                </p>
              )}

              <button
                type="submit"
                disabled={busy || !tiktokInput.trim()}
                className="w-full min-h-[46px] px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 dark:bg-pink-600 dark:hover:bg-pink-700 disabled:opacity-50 text-white text-sm font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                {busy ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Play className="w-4 h-4" />
                )}
                <span>تشغيل فيديو تيك توك معاً</span>
              </button>
            </form>
          )}

          {activeTab === "stream" && (
            <form onSubmit={(e) => void handleSubmitStream(e)} className="space-y-3">
              <div className="space-y-1.5">
                <label
                  htmlFor="watch-stream-url"
                  className="block text-xs font-semibold text-slate-700 dark:text-slate-200"
                >
                  د) لصق رابط بث مباشر (.mp4 / .m3u8) أو إنستغرام أو صفحة ويب
                </label>
                <input
                  id="watch-stream-url"
                  type="url"
                  dir="ltr"
                  value={streamInput}
                  onChange={(e) => {
                    setStreamInput(e.target.value);
                    if (error) setError(null);
                  }}
                  placeholder="https://... (.mp4, .m3u8, instagram.com/reel, أو رابط موقع)"
                  className="w-full min-h-[44px] px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-[#202c33] border border-slate-200 dark:border-slate-700 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-[#0d7a5f] dark:focus:ring-[#00a884]"
                />
                <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                  يدعم روابط البث المباشر (.mp4/.m3u8)، إنستغرام ريلز، وأي صفحة ويب أو خبر مع مزامنة التحكم للمنشئ.
                </p>
              </div>

              {error && (
                <p role="alert" className="text-xs text-rose-600 dark:text-rose-400">
                  {error}
                </p>
              )}

              <button
                type="submit"
                disabled={busy || !streamInput.trim()}
                className="w-full min-h-[46px] px-4 py-2.5 rounded-xl bg-[#0d7a5f] hover:bg-[#0a634d] dark:bg-[#00a884] dark:hover:bg-[#069475] disabled:opacity-50 text-white text-sm font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                {busy ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Play className="w-4 h-4" />
                )}
                <span>تشغيل البث المباشر معاً</span>
              </button>
            </form>
          )}

          {activeTab === "file" && (
            <div className="space-y-3">
              <div className="space-y-1.5">
                <span className="block text-xs font-semibold text-slate-700 dark:text-slate-200">
                  ج) اختيار ملف فيديو من ذاكرة الهاتف للبث المباشر (WebRTC)
                </span>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                  يُبث الفيديو مباشرة من جهازك لصديقك دون رفعه للخوادم، مع إبقاء الميكروفون والدردشة الكتابية مفتوحين.
                </p>
              </div>

              <input
                ref={fileInputRef}
                type="file"
                accept="video/*"
                onChange={handleFileChange}
                className="hidden"
              />

              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="w-full min-h-[96px] p-4 rounded-2xl border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-[#0d7a5f] dark:hover:border-[#00a884] bg-slate-50 dark:bg-[#202c33]/70 flex flex-col items-center justify-center gap-2 text-center transition-colors cursor-pointer"
              >
                <Upload className="w-6 h-6 text-[#0d7a5f] dark:text-[#00a884]" />
                {selectedFile ? (
                  <div className="space-y-0.5 max-w-full px-2">
                    <p className="text-xs font-bold text-slate-800 dark:text-slate-100 truncate">
                      {selectedFile.name}
                    </p>
                    <p className="text-[11px] text-[#0d7a5f] dark:text-[#00a884] font-semibold">
                      {formatFileSize(selectedFile.size)} · اضغط لتغيير الملف
                    </p>
                  </div>
                ) : (
                  <span className="text-xs font-bold text-slate-700 dark:text-slate-200">
                    اضغط لاختيار فيديو أو فيلم من الهاتف
                  </span>
                )}
              </button>

              {error && (
                <p role="alert" className="text-xs text-rose-600 dark:text-rose-400">
                  {error}
                </p>
              )}

              <button
                type="button"
                onClick={() => void handleStartFileShare()}
                disabled={busy || !selectedFile}
                className="w-full min-h-[46px] px-4 py-2.5 rounded-xl bg-[#0d7a5f] hover:bg-[#0a634d] dark:bg-[#00a884] dark:hover:bg-[#069475] disabled:opacity-50 text-white text-sm font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                {busy ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Play className="w-4 h-4" />
                )}
                <span>بدء البث والمشاهدة معاً</span>
              </button>
            </div>
          )}

          {/* Saved Links History for this chat */}
          <div className="pt-3 border-t border-slate-100 dark:border-slate-800 space-y-2">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-1.5">
                <History className="w-4 h-4 text-[#0d7a5f] dark:text-[#00a884]" />
                <span className="text-xs font-bold text-slate-800 dark:text-slate-100">
                  سجل الروابط المحفوظة
                </span>
              </div>
              {watchHistory.length > 0 && (
                <span className="px-2 py-0.5 rounded-full bg-slate-100 dark:bg-[#202c33] text-[10px] font-bold text-slate-600 dark:text-slate-300">
                  {watchHistory.length}
                </span>
              )}
            </div>

            {watchHistory.length === 0 ? (
              <p className="text-[11px] text-slate-500 dark:text-slate-400 bg-slate-50 dark:bg-[#202c33]/60 rounded-xl px-3 py-2.5 text-center">
                لم يتم حفظ روابط مشاهدة مشتركة في هذه المحادثة بعد. كل رابط تشغله سيُحفظ هنا للرجوع إليه لاحقاً.
              </p>
            ) : (
              <div className="max-h-48 overflow-y-auto space-y-1.5 pe-0.5">
                {watchHistory.map((item) => {
                  const badgeLabel =
                    item.mediaType === "youtube"
                      ? "يوتيوب"
                      : item.mediaType === "facebook"
                      ? "فيسبوك"
                      : item.mediaType === "tiktok"
                      ? "تيك توك"
                      : item.mediaType === "instagram"
                      ? "إنستغرام"
                      : item.mediaType === "web"
                      ? item.siteName || extractSiteNameFromUrl(item.url) || "موقع ويب"
                      : item.mediaType === "m3u8"
                      ? "HLS"
                      : "MP4";
                  const badgeTone =
                    item.mediaType === "youtube"
                      ? "bg-rose-50 dark:bg-rose-950/50 text-rose-600 dark:text-rose-400"
                      : item.mediaType === "facebook"
                      ? "bg-blue-50 dark:bg-blue-950/50 text-blue-600 dark:text-blue-400"
                      : item.mediaType === "tiktok"
                      ? "bg-pink-50 dark:bg-pink-950/50 text-pink-600 dark:text-pink-400"
                      : item.mediaType === "instagram"
                      ? "bg-fuchsia-50 dark:bg-fuchsia-950/50 text-fuchsia-600 dark:text-fuchsia-400"
                      : item.mediaType === "web"
                      ? "bg-amber-50 dark:bg-amber-950/50 text-amber-700 dark:text-amber-300"
                      : "bg-emerald-50 dark:bg-emerald-950/50 text-[#0d7a5f] dark:text-[#00a884]";

                  return (
                    <div
                      key={item.id}
                      className="flex items-center gap-2 p-2 rounded-xl bg-slate-50 dark:bg-[#202c33] border border-slate-200/70 dark:border-slate-700/60"
                    >
                      <button
                        type="button"
                        disabled={busy}
                        onClick={async () => {
                          setBusy(true);
                          setError(null);
                          try {
                            if (item.mediaType === "youtube") {
                              await onStartYouTube(
                                item.videoId,
                                item.url,
                                item.title
                              );
                            } else if (item.mediaType === "facebook") {
                              await onStartFacebook(item.url, item.title);
                            } else if (item.mediaType === "tiktok") {
                              await onStartTikTok(
                                item.videoId,
                                item.url,
                                item.title
                              );
                            } else if (item.mediaType === "instagram" && onStartInstagram) {
                              await onStartInstagram(
                                item.videoId,
                                item.url,
                                item.title
                              );
                            } else if (item.mediaType === "web" && onStartWebLink) {
                              await onStartWebLink(
                                item.videoId,
                                item.url,
                                item.title,
                                item.siteName
                              );
                            } else {
                              await onStartStream(
                                item.mediaType === "m3u8" ? "m3u8" : "mp4",
                                item.url,
                                item.title
                              );
                            }
                            onClose();
                          } catch {
                            setError("تعذر إعادة تشغيل الرابط المحفوظ.");
                          } finally {
                            setBusy(false);
                          }
                        }}
                        className="flex-1 min-w-0 flex items-center gap-2.5 text-start cursor-pointer group"
                      >
                        <span className="w-8 h-8 rounded-lg bg-emerald-100/80 dark:bg-emerald-950/60 text-[#0d7a5f] dark:text-[#00a884] flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                          <Play className="w-3.5 h-3.5 fill-current" />
                        </span>
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-1.5">
                            <span
                              className={`px-1.5 py-0.5 rounded-md text-[10px] font-bold shrink-0 ${badgeTone}`}
                            >
                              {badgeLabel}
                            </span>
                            <p className="text-xs font-bold text-slate-900 dark:text-slate-100 truncate">
                              {item.title}
                            </p>
                          </div>
                          <p className="text-[10px] text-slate-500 dark:text-slate-400 truncate mt-0.5 flex items-center gap-1">
                            <span>بواسطة {item.addedByName}</span>
                            <span>·</span>
                            <Clock className="w-2.5 h-2.5 inline shrink-0" />
                            <span>{formatMessageTime(item.savedAt)}</span>
                          </p>
                        </div>
                      </button>

                      {onDeleteWatchHistory && (
                        <button
                          type="button"
                          disabled={deletingHistoryId === item.id}
                          onClick={async () => {
                            setDeletingHistoryId(item.id);
                            try {
                              await onDeleteWatchHistory(item.id);
                            } finally {
                              setDeletingHistoryId(null);
                            }
                          }}
                          aria-label="حذف الرابط من السجل"
                          title="حذف الرابط"
                          className="w-8 h-8 rounded-lg text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 flex items-center justify-center shrink-0 transition-colors cursor-pointer"
                        >
                          {deletingHistoryId === item.id ? (
                            <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          ) : (
                            <Trash2 className="w-3.5 h-3.5" />
                          )}
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

interface VideoSearchItem {
  videoId: string;
  title: string;
  thumbnail: string;
  channel: string;
  duration: string;
  url: string;
}

interface VideoSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectVideo: (
    videoId: string,
    youtubeUrl: string,
    title?: string
  ) => Promise<void>;
}

export function VideoSearchModal({
  isOpen,
  onClose,
  onSelectVideo,
}: VideoSearchModalProps) {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<VideoSearchItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectingId, setSelectingId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [hasSearched, setHasSearched] = useState(false);

  const inputRef = useRef<HTMLInputElement>(null);
  const abortRef = useRef<AbortController | null>(null);

  useEffect(() => {
    if (!isOpen) return;
    setError(null);
    setSelectingId(null);
    const t = setTimeout(() => inputRef.current?.focus(), 60);
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKeyDown);
    return () => {
      clearTimeout(t);
      window.removeEventListener("keydown", onKeyDown);
    };
  }, [isOpen, onClose]);

  useEffect(() => {
    return () => {
      abortRef.current?.abort();
    };
  }, []);

  if (!isOpen) return null;

  const handleSearch = async (e: FormEvent) => {
    e.preventDefault();
    const q = query.trim();
    if (!q) {
      setError("يرجى كتابة كلمة للبحث عن الفيديو.");
      return;
    }

    abortRef.current?.abort();
    const controller = new AbortController();
    abortRef.current = controller;

    setLoading(true);
    setError(null);
    setHasSearched(true);

    try {
      const res = await fetch(
        `/api/search-videos?q=${encodeURIComponent(q)}`,
        { signal: controller.signal }
      );
      const data = (await res.json().catch(() => ({}))) as {
        results?: VideoSearchItem[];
        error?: string;
      };
      if (!res.ok) {
        setError(data.error || "تعذر الاتصال بمحرك البحث حالياً.");
        setResults([]);
        return;
      }
      setResults(Array.isArray(data.results) ? data.results : []);
    } catch (err) {
      if ((err as { name?: string })?.name === "AbortError") return;
      setError("تعذر البحث عن الفيديوهات. تحقق من اتصال الإنترنت وحاول مجدداً.");
      setResults([]);
    } finally {
      if (abortRef.current === controller) {
        setLoading(false);
      }
    }
  };

  const handlePick = async (item: VideoSearchItem) => {
    if (selectingId) return;
    setSelectingId(item.videoId);
    setError(null);
    try {
      await onSelectVideo(item.videoId, item.url, item.title);
      onClose();
    } catch {
      setError("تعذر تشغيل الفيديو المختار في المشاهدة المشتركة.");
    } finally {
      setSelectingId(null);
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="video-search-modal-title"
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/55 backdrop-blur-xs p-0 sm:p-4"
      onClick={onClose}
    >
      <div
        dir="rtl"
        onClick={(e) => e.stopPropagation()}
        className="w-full sm:max-w-lg bg-white dark:bg-[#111b21] border-t sm:border border-slate-200 dark:border-slate-800 rounded-t-3xl sm:rounded-3xl shadow-2xl max-h-[88dvh] flex flex-col overflow-hidden"
      >
        <div className="w-10 h-1.5 bg-slate-300 dark:bg-slate-700 rounded-full mx-auto mt-3 sm:hidden shrink-0" />

        <div className="p-4 sm:p-5 border-b border-slate-100 dark:border-slate-800 space-y-3 shrink-0">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-9 h-9 rounded-full bg-white dark:bg-[#202c33] border border-slate-200 dark:border-slate-700 shadow-xs flex items-center justify-center shrink-0">
                <GoogleGIcon className="w-5 h-5" />
              </div>
              <div className="min-w-0">
                <h2
                  id="video-search-modal-title"
                  className="font-display text-sm sm:text-base font-bold text-slate-900 dark:text-white truncate"
                >
                  البحث السريع عن فيديو للمشاهدة معاً
                </h2>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                  ابحث واختر أي فيديو ليبدأ التشغيل المتزامن فوراً لدى الطرفين
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={onClose}
              aria-label="إغلاق البحث"
              className="min-h-[40px] min-w-[40px] rounded-xl flex items-center justify-center text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer shrink-0"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <form onSubmit={handleSearch} className="flex items-center gap-2">
            <input
              ref={inputRef}
              type="search"
              value={query}
              onChange={(e) => {
                setQuery(e.target.value);
                if (error) setError(null);
              }}
              placeholder="ابحث عن فيديو، فيلم، بودكاست، أو موسيقى..."
              className="flex-1 min-h-[44px] px-4 rounded-full bg-slate-100 dark:bg-[#202c33] border border-slate-200/80 dark:border-slate-700 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-[#4285F4]/60"
            />
            <button
              type="submit"
              disabled={loading || !query.trim()}
              className="min-h-[44px] px-4 rounded-full bg-[#4285F4] hover:bg-[#3367d6] disabled:opacity-50 text-white text-xs sm:text-sm font-bold flex items-center justify-center gap-1.5 shrink-0 transition-colors cursor-pointer"
            >
              {loading ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <span>بحث</span>
              )}
            </button>
          </form>
        </div>

        <div className="flex-1 overflow-y-auto custom-scrollbar p-4 space-y-2.5">
          {error && (
            <p
              role="alert"
              className="text-xs font-medium text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/40 px-3.5 py-2.5 rounded-xl"
            >
              {error}
            </p>
          )}

          {loading ? (
            <div className="py-12 flex flex-col items-center justify-center gap-2.5 text-slate-500 dark:text-slate-400">
              <Loader2 className="w-7 h-7 animate-spin text-[#4285F4]" />
              <p className="text-xs font-semibold">
                جاري البحث عن الفيديوهات القابلة للتشغيل...
              </p>
            </div>
          ) : results.length > 0 ? (
            <div className="space-y-2">
              {results.map((item) => {
                const isPicking = selectingId === item.videoId;
                return (
                  <button
                    key={item.videoId}
                    type="button"
                    disabled={Boolean(selectingId)}
                    onClick={() => void handlePick(item)}
                    className="w-full flex items-center gap-3 p-2.5 rounded-2xl bg-slate-50 dark:bg-[#1a252b] hover:bg-emerald-50/70 dark:hover:bg-[#202c33] border border-slate-200/80 dark:border-slate-800 text-start transition-colors cursor-pointer disabled:opacity-60 group"
                  >
                    <div className="relative w-28 sm:w-32 aspect-video rounded-xl overflow-hidden bg-slate-900 shrink-0">
                      <img
                        src={item.thumbnail}
                        alt={item.title}
                        loading="lazy"
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                      {item.duration && (
                        <span
                          dir="ltr"
                          className="absolute bottom-1 left-1 px-1.5 py-0.5 rounded bg-black/80 text-white text-[10px] font-mono font-bold"
                        >
                          {item.duration}
                        </span>
                      )}
                      {isPicking && (
                        <div className="absolute inset-0 bg-black/55 flex items-center justify-center">
                          <Loader2 className="w-5 h-5 animate-spin text-white" />
                        </div>
                      )}
                    </div>

                    <div className="flex-1 min-w-0 space-y-1">
                      <p className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white line-clamp-2 leading-snug group-hover:text-[#0d7a5f] dark:group-hover:text-[#00a884] transition-colors">
                        {item.title}
                      </p>
                      {item.channel && (
                        <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                          {item.channel}
                        </p>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          ) : hasSearched && !error ? (
            <div className="py-10 text-center space-y-1">
              <p className="text-sm font-bold text-slate-700 dark:text-slate-200">
                لم يتم العثور على نتائج مطابقة
              </p>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                جرّب كلمات بحث أخرى واضغط بحث.
              </p>
            </div>
          ) : (
            <div className="py-10 text-center space-y-2">
              <div className="w-12 h-12 mx-auto rounded-full bg-slate-100 dark:bg-[#202c33] flex items-center justify-center">
                <Youtube className="w-6 h-6 text-rose-600" />
              </div>
              <p className="text-xs font-semibold text-slate-600 dark:text-slate-300">
                اكتب اسم الفيديو أو الموضوع واضغط بحث ثم اختر الفيديو للمشاهدة معاً فوراً
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
