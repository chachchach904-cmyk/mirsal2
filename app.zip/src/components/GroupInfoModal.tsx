import { useEffect, useState } from "react";
import {
  Crown,
  Loader2,
  LogOut,
  UserMinus,
  UserPlus,
  Users,
  X,
} from "lucide-react";
import { fetchUsersByUids } from "../services/firebase";
import type { Conversation, PeerUserProfile } from "../types/chat";
import { Avatar } from "./Avatar";

interface GroupInfoModalProps {
  isOpen: boolean;
  conversation: Conversation;
  currentUid: string;
  myFriends: PeerUserProfile[];
  onClose: () => void;
  onAddMember: (chatId: string, uid: string) => Promise<void>;
  onRemoveMember: (chatId: string, uid: string) => Promise<void>;
  onLeaveGroup: (chatId: string) => Promise<void>;
  onViewProfile: (peer: PeerUserProfile) => void;
}

export function GroupInfoModal({
  isOpen,
  conversation,
  currentUid,
  myFriends,
  onClose,
  onAddMember,
  onRemoveMember,
  onLeaveGroup,
  onViewProfile,
}: GroupInfoModalProps) {
  const [membersMap, setMembersMap] = useState<Record<string, PeerUserProfile>>(
    {}
  );
  const [loadingMembers, setLoadingMembers] = useState(false);
  const [busyUid, setBusyUid] = useState<string | null>(null);
  const [leaving, setLeaving] = useState(false);

  const memberIds = conversation.memberIds || [];
  const adminIds = conversation.adminIds || [];
  const isAdmin = adminIds.includes(currentUid);

  useEffect(() => {
    if (!isOpen || memberIds.length === 0) return;
    let active = true;
    setLoadingMembers(true);
    void fetchUsersByUids(memberIds)
      .then((res) => {
        if (active) setMembersMap(res);
      })
      .catch(() => {})
      .finally(() => {
        if (active) setLoadingMembers(false);
      });
    return () => {
      active = false;
    };
  }, [isOpen, memberIds.join(",")]);

  if (!isOpen) return null;

  const friendsNotInGroup = myFriends.filter(
    (f) => !memberIds.includes(f.uid)
  );

  const handleAdd = async (uid: string) => {
    setBusyUid(uid);
    try {
      await onAddMember(conversation.id, uid);
    } finally {
      setBusyUid(null);
    }
  };

  const handleRemove = async (uid: string) => {
    setBusyUid(uid);
    try {
      await onRemoveMember(conversation.id, uid);
    } finally {
      setBusyUid(null);
    }
  };

  const handleLeave = async () => {
    setLeaving(true);
    try {
      await onLeaveGroup(conversation.id);
    } finally {
      setLeaving(false);
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="معلومات المجموعة"
      className="fixed inset-0 z-50 bg-black/55 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4"
    >
      <div className="w-full max-w-md bg-white dark:bg-[#111b21] rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden flex flex-col max-h-[88dvh]">
        <header className="px-5 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between gap-3 bg-slate-50/70 dark:bg-[#202c33]">
          <div className="flex items-center gap-3 min-w-0">
            <Avatar
              src={conversation.avatar}
              name={conversation.title}
              size="md"
            />
            <div className="min-w-0">
              <h2 className="font-display font-bold text-base text-slate-900 dark:text-white truncate">
                {conversation.groupName || conversation.title}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {memberIds.length} أعضاء
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="إغلاق"
            className="min-h-[40px] min-w-[40px] rounded-xl flex items-center justify-center text-slate-500 hover:bg-slate-200/70 dark:text-slate-300 dark:hover:bg-slate-700/50 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </header>

        <div className="flex-1 overflow-y-auto custom-scrollbar p-5 space-y-5">
          {/* Current Members */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs font-bold text-slate-700 dark:text-slate-200">
              <span className="flex items-center gap-1.5">
                <Users className="w-4 h-4 text-[#0d7a5f] dark:text-[#00a884]" />
                <span>أعضاء المجموعة</span>
              </span>
              {loadingMembers && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
            </div>

            <div className="space-y-1.5">
              {memberIds.map((uid) => {
                const profile =
                  membersMap[uid] ||
                  myFriends.find((f) => f.uid === uid) ||
                  null;
                const displayName =
                  uid === currentUid
                    ? "أنت"
                    : profile?.displayName || "عضو مرسال";
                const isMemberAdmin = adminIds.includes(uid);

                return (
                  <div
                    key={uid}
                    className="flex items-center justify-between gap-2 p-2.5 rounded-2xl bg-slate-50 dark:bg-[#202c33] border border-slate-200/70 dark:border-slate-700/60"
                  >
                    <button
                      type="button"
                      onClick={() => {
                        if (profile && uid !== currentUid) {
                          onViewProfile(profile);
                        }
                      }}
                      className="flex items-center gap-2.5 min-w-0 text-start cursor-pointer"
                    >
                      <Avatar
                        src={profile?.photoURL || profile?.avatar || ""}
                        name={displayName}
                        size="sm"
                      />
                      <div className="min-w-0">
                        <p className="text-xs font-bold text-slate-900 dark:text-white truncate flex items-center gap-1.5">
                          <span>{displayName}</span>
                          {isMemberAdmin && (
                            <span className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded-md bg-amber-100 dark:bg-amber-950/50 text-amber-700 dark:text-amber-300 text-[10px] font-bold">
                              <Crown className="w-2.5 h-2.5" />
                              مشرف
                            </span>
                          )}
                        </p>
                      </div>
                    </button>

                    {isAdmin && uid !== currentUid && (
                      <button
                        type="button"
                        disabled={busyUid === uid}
                        onClick={() => void handleRemove(uid)}
                        title="إزالة من المجموعة"
                        className="min-h-[34px] px-2.5 rounded-xl bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/40 text-rose-600 dark:text-rose-300 text-[11px] font-bold flex items-center gap-1 cursor-pointer disabled:opacity-50"
                      >
                        {busyUid === uid ? (
                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        ) : (
                          <UserMinus className="w-3.5 h-3.5" />
                        )}
                        <span>إزالة</span>
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Add Friends to Group (Admins) */}
          {isAdmin && friendsNotInGroup.length > 0 && (
            <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
              <p className="text-xs font-bold text-slate-700 dark:text-slate-200">
                إضافة أصدقاء إلى المجموعة
              </p>
              <div className="space-y-1.5">
                {friendsNotInGroup.map((friend) => (
                  <div
                    key={friend.uid}
                    className="flex items-center justify-between gap-2 p-2.5 rounded-2xl bg-slate-50 dark:bg-[#202c33] border border-slate-200/70 dark:border-slate-700/60"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <Avatar
                        src={friend.photoURL || friend.avatar}
                        name={friend.displayName}
                        size="sm"
                      />
                      <span className="text-xs font-bold text-slate-800 dark:text-slate-100 truncate">
                        {friend.displayName}
                      </span>
                    </div>
                    <button
                      type="button"
                      disabled={busyUid === friend.uid}
                      onClick={() => void handleAdd(friend.uid)}
                      className="min-h-[34px] px-3 rounded-xl bg-[#0d7a5f] hover:bg-[#0a634d] dark:bg-[#00a884] dark:hover:bg-[#069475] text-white text-[11px] font-bold flex items-center gap-1 cursor-pointer disabled:opacity-50"
                    >
                      {busyUid === friend.uid ? (
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      ) : (
                        <UserPlus className="w-3.5 h-3.5" />
                      )}
                      <span>إضافة</span>
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Leave Group */}
          <div className="pt-3 border-t border-slate-100 dark:border-slate-800">
            <button
              type="button"
              disabled={leaving}
              onClick={() => void handleLeave()}
              className="w-full min-h-[44px] px-4 py-2.5 rounded-2xl bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/40 dark:hover:bg-rose-950/70 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-800/60 text-xs font-bold flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60"
            >
              {leaving ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <LogOut className="w-4 h-4" />
              )}
              <span>مغادرة المجموعة</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
