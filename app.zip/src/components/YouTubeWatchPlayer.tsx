import { useCallback, useEffect, useId, useRef, useState } from "react";
import { Volume2, VolumeX } from "lucide-react";
import type { WatchSessionData } from "../types/chat";

interface YTPlayerInstance {
  playVideo: () => void;
  pauseVideo: () => void;
  seekTo: (seconds: number, allowSeekAhead: boolean) => void;
  getCurrentTime: () => number;
  getPlaybackRate: () => number;
  getPlayerState?: () => number;
  mute: () => void;
  unMute: () => void;
  isMuted: () => boolean;
  destroy: () => void;
}

interface YTGlobal {
  Player: new (
    element: HTMLElement | string,
    options: {
      videoId: string;
      playerVars?: Record<string, string | number>;
      events?: {
        onReady?: (event: { target: YTPlayerInstance }) => void;
        onStateChange?: (event: {
          data: number;
          target: YTPlayerInstance;
        }) => void;
        onError?: () => void;
      };
    }
  ) => YTPlayerInstance;
  PlayerState?: {
    ENDED: number;
    PLAYING: number;
    PAUSED: number;
    BUFFERING: number;
  };
}

declare global {
  interface Window {
    YT?: YTGlobal;
    onYouTubeIframeAPIReady?: () => void;
  }
}

let ytApiPromise: Promise<YTGlobal | null> | null = null;

function loadYouTubeIframeApi(): Promise<YTGlobal | null> {
  if (typeof window === "undefined") return Promise.resolve(null);
  if (window.YT?.Player) return Promise.resolve(window.YT);
  if (ytApiPromise) return ytApiPromise;

  ytApiPromise = new Promise((resolve) => {
    const existingScript = document.querySelector<HTMLScriptElement>(
      'script[src*="youtube.com/iframe_api"]'
    );
    const prevCallback = window.onYouTubeIframeAPIReady;
    const timeout = setTimeout(() => {
      resolve(window.YT?.Player ? window.YT : null);
    }, 5000);

    window.onYouTubeIframeAPIReady = () => {
      clearTimeout(timeout);
      prevCallback?.();
      resolve(window.YT || null);
    };

    if (!existingScript) {
      const tag = document.createElement("script");
      tag.src = "https://www.youtube.com/iframe_api";
      tag.async = true;
      tag.onerror = () => {
        clearTimeout(timeout);
        resolve(null);
      };
      document.head.appendChild(tag);
    }
  });

  return ytApiPromise;
}

interface YouTubeWatchPlayerProps {
  session: WatchSessionData;
  isHost: boolean;
  hostName: string;
  externalMuted?: boolean;
  isMiniMode?: boolean;
  seekSignal?: { nonce: number; deltaSeconds: number } | null;
  onPlaybackSync: (
    playbackState: "playing" | "paused",
    playbackTime: number,
    playbackRate: number
  ) => void;
}

export function YouTubeWatchPlayer({
  session,
  isHost,
  hostName: _hostName,
  externalMuted,
  isMiniMode = false,
  seekSignal,
  onPlaybackSync,
}: YouTubeWatchPlayerProps) {
  const hostElId = useId().replace(/:/g, "");
  const containerRef = useRef<HTMLDivElement>(null);
  const playerRef = useRef<YTPlayerInstance | null>(null);
  const sessionRef = useRef<WatchSessionData>(session);
  const onPlaybackSyncRef = useRef(onPlaybackSync);
  const isHostRef = useRef(isHost);
  const lastSeekNonceRef = useRef<number>(0);
  const suppressNextSyncRef = useRef<number>(0);
  const lastCommittedStateRef = useRef<{
    state: "playing" | "paused";
    time: number;
  } | null>(null);

  sessionRef.current = session;
  onPlaybackSyncRef.current = onPlaybackSync;
  isHostRef.current = isHost;

  const [useFallbackIframe, setUseFallbackIframe] = useState(false);
  const [isMuted, setIsMuted] = useState(false);

  const syncPeerPlayer = useCallback(
    (player: YTPlayerInstance, snap: WatchSessionData) => {
      if (isHost) return;
      const targetPlaying =
        typeof snap.isPlaying === "boolean"
          ? snap.isPlaying
          : snap.playbackState !== "paused";
      const targetRate =
        typeof snap.playbackRate === "number" && snap.playbackRate > 0
          ? snap.playbackRate
          : 1;
      const baseTime = snap.currentTime ?? snap.playbackTime ?? 0;
      const drift =
        targetPlaying && snap.updatedAtMs
          ? Math.max(0, (Date.now() - snap.updatedAtMs) / 1000) * targetRate
          : 0;
      const expectedTime = Math.max(0, baseTime + drift);

      try {
        const current = player.getCurrentTime?.() ?? 0;
        if (Math.abs(current - expectedTime) > 2.2) {
          player.seekTo(expectedTime, true);
        }
        if (targetPlaying) {
          player.playVideo();
        } else {
          player.pauseVideo();
        }
      } catch {
        // ignore if player isn't attached yet
      }
    },
    [isHost]
  );

  useEffect(() => {
    let cancelled = false;
    setUseFallbackIframe(false);

    void loadYouTubeIframeApi().then((YT) => {
      if (cancelled) return;
      if (!YT?.Player || !containerRef.current) {
        setUseFallbackIframe(true);
        return;
      }

      const mountTarget = document.createElement("div");
      mountTarget.id = `yt-${hostElId}`;
      mountTarget.className = "w-full h-full";
      containerRef.current.innerHTML = "";
      containerRef.current.appendChild(mountTarget);

      try {
        const player = new YT.Player(mountTarget, {
          videoId: session.videoId,
          playerVars: {
            autoplay: 1,
            rel: 0,
            playsinline: 1,
            controls: isHost ? 1 : 0,
            disablekb: isHost ? 0 : 1,
            modestbranding: 1,
          },
          events: {
            onReady: (ev) => {
              if (cancelled) return;
              playerRef.current = ev.target;
              if (externalMuted) {
                try {
                  ev.target.mute();
                } catch {
                  // ignore
                }
              }
              if (!isHost) {
                suppressNextSyncRef.current = Date.now() + 1000;
                syncPeerPlayer(ev.target, sessionRef.current);
              } else {
                const startTime =
                  sessionRef.current.currentTime ??
                  sessionRef.current.playbackTime ??
                  0;
                if (startTime > 1) {
                  ev.target.seekTo(startTime, true);
                }
                if (
                  sessionRef.current.isPlaying === false ||
                  sessionRef.current.playbackState === "paused"
                ) {
                  ev.target.pauseVideo();
                } else {
                  ev.target.playVideo();
                }
              }
            },
            onStateChange: (ev) => {
              if (!isHost || cancelled) return;
              if (Date.now() < suppressNextSyncRef.current) return;
              const stateCode = ev.data;
              // 1 = PLAYING, 2 = PAUSED (no interval polling — commits ONLY on Play, Pause, or post-Seek state transition)
              if (stateCode !== 1 && stateCode !== 2) return;

              const playbackState: "playing" | "paused" =
                stateCode === 1 ? "playing" : "paused";
              const currentTime = ev.target.getCurrentTime?.() ?? 0;
              const playbackRate = ev.target.getPlaybackRate?.() ?? 1;

              const prev = lastCommittedStateRef.current;
              if (
                prev &&
                prev.state === playbackState &&
                Math.abs(prev.time - currentTime) < 1.2
              ) {
                return;
              }
              lastCommittedStateRef.current = {
                state: playbackState,
                time: currentTime,
              };
              onPlaybackSyncRef.current(
                playbackState,
                currentTime,
                playbackRate
              );
            },
            onError: () => {
              if (!cancelled) {
                setUseFallbackIframe(true);
              }
            },
          },
        });
        playerRef.current = player;
      } catch {
        setUseFallbackIframe(true);
      }
    });

    return () => {
      cancelled = true;
      try {
        playerRef.current?.destroy?.();
      } catch {
        // ignore
      }
      playerRef.current = null;
    };
  }, [session.videoId, isHost, hostElId, syncPeerPlayer]);

  // Event-driven peer sync on Firestore snapshot changes (NO interval)
  useEffect(() => {
    if (isHost || !playerRef.current) return;
    syncPeerPlayer(playerRef.current, session);
  }, [
    isHost,
    syncPeerPlayer,
    session.isPlaying,
    session.playbackState,
    session.currentTime,
    session.playbackTime,
    session.playbackRate,
    session.updatedAtMs,
  ]);

  useEffect(() => {
    if (typeof externalMuted !== "boolean") return;
    setIsMuted(externalMuted);
    const p = playerRef.current;
    if (!p) return;
    try {
      if (externalMuted) {
        p.mute();
      } else {
        p.unMute();
      }
    } catch {
      // ignore
    }
  }, [externalMuted]);

  useEffect(() => {
    if (!seekSignal || seekSignal.nonce === lastSeekNonceRef.current) return;
    lastSeekNonceRef.current = seekSignal.nonce;
    const p = playerRef.current;
    if (!p) return;
    try {
      const current = p.getCurrentTime?.() ?? 0;
      const nextTime = Math.max(0, current + seekSignal.deltaSeconds);
      p.seekTo(nextTime, true);
      if (isHostRef.current) {
        const stateCode = p.getPlayerState?.();
        const playbackState: "playing" | "paused" =
          stateCode === 2 ? "paused" : "playing";
        const rate = p.getPlaybackRate?.() ?? 1;
        lastCommittedStateRef.current = {
          state: playbackState,
          time: nextTime,
        };
        onPlaybackSyncRef.current(playbackState, nextTime, rate);
      }
    } catch {
      // ignore
    }
  }, [seekSignal]);

  const handleTogglePeerMute = () => {
    const p = playerRef.current;
    if (!p) return;
    try {
      if (p.isMuted()) {
        p.unMute();
        setIsMuted(false);
      } else {
        p.mute();
        setIsMuted(true);
      }
    } catch {
      // ignore
    }
  };

  if (useFallbackIframe) {
    return (
      <div className="w-full h-full relative bg-black">
        <iframe
          key={session.videoId}
          src={`https://www.youtube-nocookie.com/embed/${session.videoId}?autoplay=1&rel=0&controls=${
            isHost ? 1 : 0
          }`}
          title="مشاهدة فيديو يوتيوب معاً"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
          allowFullScreen
          className="w-full h-full border-0"
        />
        {!isHost && (
          <div
            aria-hidden="true"
            className="absolute inset-0 z-10 bg-transparent cursor-default select-none"
          />
        )}
      </div>
    );
  }

  return (
    <div className="w-full h-full relative bg-black overflow-hidden">
      <div ref={containerRef} className="w-full h-full" />

      {!isHost && (
        <div
          aria-hidden="true"
          className="absolute inset-0 z-10 bg-transparent cursor-default select-none"
        />
      )}

      {!isHost && !isMiniMode && (
        <button
          type="button"
          onClick={handleTogglePeerMute}
          className="absolute bottom-2.5 left-2.5 z-20 min-h-[34px] px-2.5 rounded-lg bg-black/75 hover:bg-black/90 border border-white/15 text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
        >
          {isMuted ? (
            <>
              <VolumeX className="w-4 h-4 text-rose-400" />
              <span>تشغيل الصوت</span>
            </>
          ) : (
            <>
              <Volume2 className="w-4 h-4" />
              <span>كتم</span>
            </>
          )}
        </button>
      )}
    </div>
  );
}
