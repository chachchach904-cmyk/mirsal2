import { useCallback, useEffect, useMemo, useState, type FormEvent } from "react";
import {
  ArrowRight,
  X,
  Search,
  Loader2,
  UserCheck,
  MessageSquarePlus,
  Users,
  UserPlus,
  ShieldCheck,
} from "lucide-react";
import type { PeerUserProfile } from "../types/chat";
import { getCountryByCode } from "../data/countries";
import { formatLastSeen, normalizeArabicSearch } from "../utils/storage";
import { Avatar } from "./Avatar";

interface NewChatModalProps {
  isOpen: boolean;
  myFriends: PeerUserProfile[];
  myFriendUids: string[];
  loadingFriends: boolean;
  onClose: () => void;
  onRefreshFriends: () => Promise<void>;
  onSearchExactUser: (query: string) => Promise<PeerUserProfile[]>;
  onAddFriend: (uid: string) => Promise<void>;
  onStartDirectChat: (peer: PeerUserProfile) => Promise<void>;
  onOpenCreateGroup: () => void;
  onViewProfile: (peer: PeerUserProfile) => void;
}

export function NewChatModal({
  isOpen,
  myFriends,
  myFriendUids,
  loadingFriends,
  onClose,
  onRefreshFriends,
  onSearchExactUser,
  onAddFriend,
  onStartDirectChat,
  onOpenCreateGroup,
  onViewProfile,
}: NewChatModalProps) {
  const [queryText, setQueryText] = useState("");
  const [exactResults, setExactResults] = useState<PeerUserProfile[]>([]);
  const [hasSearchedExact, setHasSearchedExact] = useState(false);
  const [searchingExact, setSearchingExact] = useState(false);
  const [startingUid, setStartingUid] = useState<string | null>(null);
  const [addingUid, setAddingUid] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!isOpen) return;
    setQueryText("");
    setExactResults([]);
    setHasSearchedExact(false);
    setSearchingExact(false);
    setStartingUid(null);
    setError(null);
    void onRefreshFriends();
  }, [isOpen, onRefreshFriends]);

  const filteredLocalFriends = useMemo(() => {
    const q = normalizeArabicSearch(queryText);
    if (!q) return myFriends;
    return myFriends.filter((f) =>
      normalizeArabicSearch(f.displayName).includes(q)
    );
  }, [myFriends, queryText]);

  const runExactSearch = useCallback(
    async (e?: FormEvent) => {
      e?.preventDefault();
      const trimmed = queryText.trim();
      if (!trimmed) {
        setExactResults([]);
        setHasSearchedExact(false);
        return;
      }
      setSearchingExact(true);
      setError(null);
      try {
        const matches = await onSearchExactUser(trimmed);
        setExactResults(matches);
        setHasSearchedExact(true);
      } catch (err) {
        setError(
          err instanceof Error && !err.message.startsWith("{")
            ? err.message
            : "تعذر البحث حالياً. تأكد من الاتصال وحاول مجدداً."
        );
      } finally {
        setSearchingExact(false);
      }
    },
    [queryText, onSearchExactUser]
  );

  if (!isOpen) return null;

  const handleSelectPeer = async (peer: PeerUserProfile) => {
    if (startingUid) return;
    setError(null);
    setStartingUid(peer.uid);
    try {
      await onStartDirectChat(peer);
      onClose();
    } catch (err) {
      setError(
        err instanceof Error && !err.message.startsWith("{")
          ? err.message
          : "تعذر فتح المحادثة. تأكد من اتصالك بالإنترنت وحاول مرة أخرى."
      );
    } finally {
      setStartingUid(null);
    }
  };

  const handleAddFriendClick = async (uid: string) => {
    if (addingUid) return;
    setAddingUid(uid);
    try {
      await onAddFriend(uid);
    } finally {
      setAddingUid(null);
    }
  };

  const renderPeerRow = (peer: PeerUserProfile) => {
    const isStarting = startingUid === peer.uid;
    const isAlreadyFriend = myFriendUids.includes(peer.uid);
    const isAdding = addingUid === peer.uid;
    const canShowOnline = peer.showLastSeen !== false;
    const country = getCountryByCode(peer.countryCode);

    return (
      <div
        key={peer.uid}
        className="w-full p-3 rounded-2xl bg-slate-50/90 dark:bg-[#202c33] border border-slate-200/70 dark:border-slate-700/60 flex items-center justify-between gap-2.5"
      >
        <button
          type="button"
          onClick={() => onViewProfile(peer)}
          className="flex items-center gap-3 min-w-0 text-start flex-1 cursor-pointer group"
        >
          <div className="relative shrink-0">
            <Avatar src={peer.photoURL || peer.avatar} name={peer.displayName} size="lg" />
            {canShowOnline && peer.isOnline && (
              <span
                title="متصل الآن"
                className="absolute bottom-0 left-0 w-3.5 h-3.5 rounded-full bg-emerald-500 ring-2 ring-white dark:ring-[#202c33]"
              />
            )}
          </div>

          <div className="min-w-0 space-y-0.5">
            <h3 className="font-bold text-sm text-slate-900 dark:text-white truncate flex items-center gap-1.5 group-hover:text-[#0d7a5f] dark:group-hover:text-[#00a884] transition-colors">
              <span className="truncate">{peer.displayName}</span>
              {!peer.isProfileLocked &&
                peer.showPersonalInfo !== false &&
                country?.flag && (
                  <span title={country.nameAr} className="shrink-0 text-sm leading-none">
                    {country.flag}
                  </span>
                )}
            </h3>
            <p
              className={`text-xs font-medium truncate ${
                canShowOnline && peer.isOnline
                  ? "text-[#0d7a5f] dark:text-[#00a884]"
                  : "text-slate-500 dark:text-slate-400"
              }`}
            >
              {canShowOnline
                ? formatLastSeen(peer.lastSeen, peer.isOnline)
                : "عرض الملف الشخصي"}
            </p>
          </div>
        </button>

        <div className="flex items-center gap-1.5 shrink-0">
          {!isAlreadyFriend && (
            <button
              type="button"
              onClick={() => void handleAddFriendClick(peer.uid)}
              disabled={isAdding}
              aria-label="إضافة صديق"
              title="إضافة إلى أصدقائي"
              className="min-h-[38px] px-2.5 py-2 rounded-xl bg-white dark:bg-[#111b21] border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:border-[#0d7a5f] text-xs font-bold flex items-center gap-1 cursor-pointer disabled:opacity-60"
            >
              {isAdding ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <UserPlus className="w-3.5 h-3.5 text-[#0d7a5f] dark:text-[#00a884]" />
              )}
              <span className="hidden sm:inline">إضافة</span>
            </button>
          )}

          <button
            type="button"
            onClick={() => void handleSelectPeer(peer)}
            disabled={Boolean(startingUid)}
            className="min-h-[38px] px-3.5 py-2 rounded-xl bg-[#0d7a5f] hover:bg-[#0a634d] dark:bg-[#00a884] dark:hover:bg-[#069475] text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer disabled:opacity-70"
          >
            {isStarting ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <UserCheck className="w-4 h-4" />
            )}
            <span>مراسلة</span>
          </button>
        </div>
      </div>
    );
  };

  // Merge local friends matches + exact remote search matches without duplicates
  const displayedExactExtras = exactResults.filter(
    (r) => !filteredLocalFriends.some((f) => f.uid === r.uid)
  );

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="new-chat-modal-title"
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/50 backdrop-blur-xs p-0 sm:p-4"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full sm:max-w-lg bg-white dark:bg-[#111b21] border-t sm:border border-slate-200 dark:border-slate-800 rounded-t-3xl sm:rounded-3xl p-5 sm:p-6 shadow-xl max-h-[88vh] flex flex-col"
      >
        <div className="w-10 h-1.5 bg-slate-300 dark:bg-slate-700 rounded-full mx-auto mb-4 sm:hidden shrink-0" />

        <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800 shrink-0">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              aria-label="رجوع"
              title="رجوع"
              className="w-10 h-10 rounded-full bg-emerald-50 hover:bg-emerald-100 dark:bg-[#202c33] dark:hover:bg-[#2a3942] border border-emerald-200/80 dark:border-slate-700 text-[#0d7a5f] dark:text-[#00a884] flex items-center justify-center shadow-xs transition-colors cursor-pointer shrink-0"
            >
              <ArrowRight className="w-5 h-5" />
            </button>
            <div className="w-9 h-9 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 text-[#0d7a5f] dark:text-[#00a884] flex items-center justify-center shrink-0">
              <MessageSquarePlus className="w-5 h-5" />
            </div>
            <div>
              <h2
                id="new-chat-modal-title"
                className="font-display text-lg font-bold text-slate-900 dark:text-white"
              >
                محادثة أو مجموعة جديدة
              </h2>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                أصدقاؤك فقط — والبحث بالاسم الكامل أو البريد المطابق
              </p>
            </div>
          </div>
        </div>

        {/* Create Group Button */}
        <div className="mt-3.5 shrink-0">
          <button
            type="button"
            onClick={() => {
              onClose();
              onOpenCreateGroup();
            }}
            className="w-full min-h-[44px] px-4 py-2.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/35 border border-emerald-200/80 dark:border-emerald-800/50 hover:bg-emerald-100/80 dark:hover:bg-emerald-950/55 text-[#0d7a5f] dark:text-[#00a884] text-sm font-bold flex items-center justify-between transition-colors cursor-pointer"
          >
            <span className="flex items-center gap-2.5">
              <Users className="w-4 h-4" />
              <span>إنشاء مجموعة جديدة</span>
            </span>
            <span className="text-xs font-semibold">أضف أصدقاءك للمجموعة</span>
          </button>
        </div>

        {/* Exact Name / Email Search Form */}
        <form onSubmit={(e) => void runExactSearch(e)} className="mt-4 space-y-2 shrink-0">
          <label
            htmlFor="exact-user-search"
            className="block text-xs font-semibold text-slate-700 dark:text-slate-300"
          >
            ابحث عن صديق جديد بالاسم الكامل أو البريد الإلكتروني الدقيق
          </label>

          <div className="flex items-center gap-2">
            <div className="relative flex-1 flex items-center">
              <Search className="w-4 h-4 text-slate-400 absolute right-3.5 pointer-events-none" />
              <input
                id="exact-user-search"
                type="search"
                value={queryText}
                onChange={(e) => {
                  setQueryText(e.target.value);
                  setHasSearchedExact(false);
                  if (error) setError(null);
                }}
                placeholder="الاسم الكامل أو email@example.com"
                className="w-full min-h-[44px] pr-10 pl-8 py-2 rounded-xl bg-slate-50 dark:bg-[#202c33] border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-[#0d7a5f] dark:focus:ring-[#00a884] text-sm"
              />
              {queryText && (
                <button
                  type="button"
                  onClick={() => {
                    setQueryText("");
                    setExactResults([]);
                    setHasSearchedExact(false);
                  }}
                  aria-label="مسح البحث"
                  className="absolute left-2 p-1 rounded-lg text-slate-400 hover:text-slate-600 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            <button
              type="submit"
              disabled={!queryText.trim() || searchingExact}
              className="min-h-[44px] px-4 py-2 rounded-xl bg-[#0d7a5f] hover:bg-[#0a634d] dark:bg-[#00a884] dark:hover:bg-[#069475] disabled:opacity-50 text-white text-xs sm:text-sm font-bold flex items-center gap-1.5 shrink-0 cursor-pointer"
            >
              {searchingExact ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Search className="w-4 h-4" />
              )}
              <span>بحث</span>
            </button>
          </div>
        </form>

        {error && (
          <p
            role="alert"
            className="mt-3 text-xs font-medium text-rose-700 dark:text-rose-300 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/60 px-3.5 py-2.5 rounded-xl shrink-0"
          >
            {error}
          </p>
        )}

        {/* Privacy-Strict Friends & Exact Search Results */}
        <div className="mt-4 flex-1 overflow-y-auto custom-scrollbar space-y-2.5 min-h-[180px]">
          {hasSearchedExact && (
            <div className="space-y-2">
              <span className="block text-xs font-bold text-[#0d7a5f] dark:text-[#00a884] px-1">
                نتائج البحث المطابق ({exactResults.length})
              </span>
              {exactResults.length === 0 ? (
                <div className="p-4 rounded-2xl bg-slate-50 dark:bg-[#202c33] border border-slate-200/70 dark:border-slate-700/60 text-center space-y-1">
                  <p className="text-xs font-semibold text-slate-800 dark:text-slate-100">
                    لم يتم العثور على مستخدم مطابق تماماً
                  </p>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    لحماية الخصوصية، تظهر النتائج فقط عند إدخال الاسم الكامل أو البريد الإلكتروني الصحيح تماماً.
                  </p>
                </div>
              ) : (
                displayedExactExtras.map((peer) => renderPeerRow(peer))
              )}
            </div>
          )}

          <div className="space-y-2">
            <div className="flex items-center justify-between px-1">
              <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                أصدقائي ({filteredLocalFriends.length})
              </span>
              <span className="text-[11px] text-slate-400 flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-[#0d7a5f]" />
                <span>الخصوصية محمية</span>
              </span>
            </div>

            {loadingFriends && myFriends.length === 0 ? (
              <div className="py-10 flex flex-col items-center justify-center gap-2 text-slate-500 dark:text-slate-400">
                <Loader2 className="w-6 h-6 animate-spin text-[#0d7a5f] dark:text-[#00a884]" />
                <span className="text-xs font-medium">جاري تحميل أصدقائك...</span>
              </div>
            ) : filteredLocalFriends.length === 0 ? (
              <div className="p-5 rounded-2xl bg-slate-50 dark:bg-[#202c33] border border-slate-200/80 dark:border-slate-700/60 text-center space-y-1.5">
                <p className="text-sm font-semibold text-slate-800 dark:text-slate-100">
                  {queryText.trim()
                    ? "لا يوجد صديق في قائمتك بهذا الاسم"
                    : "قائمة أصدقائك فارغة حالياً"}
                </p>
                <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                  أدخل الاسم الكامل لصديقك أو بريده الإلكتروني في خانة البحث بالأعلى ثم اضغط «بحث» لإضافته ومراسلته.
                </p>
              </div>
            ) : (
              filteredLocalFriends.map((peer) => renderPeerRow(peer))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
