import { useEffect, useId, useState } from "react";
import {
  isAiAvatarSrc,
  isDataUrlAvatar,
  isImageUrlAvatar,
} from "../data/defaults";

interface AvatarProps {
  src: string;
  name: string;
  size?: "sm" | "md" | "lg" | "xl";
  isAi?: boolean;
  className?: string;
}

const SIZE_CLASSES = {
  sm: "w-9 h-9 text-xs",
  md: "w-11 h-11 text-sm",
  lg: "w-12 h-12 text-base",
  xl: "w-16 h-16 text-xl",
};

const INITIALS_PALETTES = [
  "from-emerald-600 to-teal-700",
  "from-sky-600 to-blue-700",
  "from-indigo-600 to-violet-700",
  "from-teal-600 to-cyan-700",
  "from-amber-600 to-orange-700",
  "from-rose-600 to-pink-700",
];

function getInitialsFromName(rawName: string): string {
  const clean = (rawName || "").trim();
  if (!clean) return "م";
  const parts = clean.split(/\s+/).filter(Boolean);
  if (parts.length >= 2) {
    const first = Array.from(parts[0])[0] || "";
    const second = Array.from(parts[1])[0] || "";
    const hasArabic = /[\u0600-\u06FF]/.test(first + second);
    return hasArabic ? `${first} ${second}` : `${first}${second}`.toUpperCase();
  }
  const chars = Array.from(parts[0]);
  return (chars[0] || "م").toUpperCase();
}

function getPaletteForName(rawName: string): string {
  const str = (rawName || "mirsal").trim();
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = (hash * 31 + str.charCodeAt(i)) | 0;
  }
  return INITIALS_PALETTES[Math.abs(hash) % INITIALS_PALETTES.length];
}

function AiSparkleAvatar({
  size,
  name,
  className,
}: {
  size: "sm" | "md" | "lg" | "xl";
  name: string;
  className: string;
}) {
  const uid = useId().replace(/:/g, "");
  const gradId = `ai-sparkle-grad-${uid}`;
  const glowId = `ai-sparkle-glow-${uid}`;

  return (
    <div
      role="img"
      aria-label={name}
      className={`${SIZE_CLASSES[size]} relative rounded-full shrink-0 flex items-center justify-center overflow-hidden bg-gradient-to-br from-[#071822] via-[#0c2738] to-[#1b1440] ring-1 ring-cyan-400/55 shadow-[0_0_16px_rgba(16,185,129,0.42),0_0_24px_rgba(139,92,246,0.28)] select-none ${className}`}
    >
      <span
        aria-hidden="true"
        className="absolute inset-0 bg-[radial-gradient(circle_at_30%_25%,rgba(16,185,129,0.42),transparent_55%),radial-gradient(circle_at_75%_80%,rgba(139,92,246,0.45),transparent_58%)]"
      />
      <svg
        viewBox="0 0 48 48"
        fill="none"
        aria-hidden="true"
        className="relative w-[68%] h-[68%] drop-shadow-[0_0_8px_rgba(34,211,238,0.65)]"
      >
        <defs>
          <linearGradient id={gradId} x1="6" y1="6" x2="42" y2="42" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#34d399" />
            <stop offset="50%" stopColor="#22d3ee" />
            <stop offset="100%" stopColor="#a78bfa" />
          </linearGradient>
          <radialGradient id={glowId} cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#ffffff" stopOpacity="0.95" />
            <stop offset="100%" stopColor="#ffffff" stopOpacity="0" />
          </radialGradient>
        </defs>
        {/* Main Gemini-inspired 4-point AI sparkle */}
        <path
          d="M24 5C25.35 16.25 31.75 22.65 43 24C31.75 25.35 25.35 31.75 24 43C22.65 31.75 16.25 25.35 5 24C16.25 22.65 22.65 16.25 24 5Z"
          fill={`url(#${gradId})`}
        />
        <circle cx="24" cy="24" r="5.5" fill={`url(#${glowId})`} />
        {/* Secondary accent sparkle */}
        <path
          d="M36.5 7.5C36.9 10.6 38.4 12.1 41.5 12.5C38.4 12.9 36.9 14.4 36.5 17.5C36.1 14.4 34.6 12.9 31.5 12.5C34.6 12.1 36.1 10.6 36.5 7.5Z"
          fill="#67e8f9"
        />
      </svg>
    </div>
  );
}

export function Avatar({
  src,
  name,
  size = "md",
  isAi = false,
  className = "",
}: AvatarProps) {
  const [imgError, setImgError] = useState(false);

  useEffect(() => {
    setImgError(false);
  }, [src]);

  if (isAi || isAiAvatarSrc(src)) {
    return <AiSparkleAvatar size={size} name={name} className={className} />;
  }

  const hasPhoto = isDataUrlAvatar(src) || isImageUrlAvatar(src);
  if (hasPhoto && !imgError) {
    return (
      <img
        src={src.trim()}
        alt={name}
        referrerPolicy="no-referrer"
        onError={() => setImgError(true)}
        className={`${SIZE_CLASSES[size]} rounded-full object-cover shrink-0 ring-1 ring-black/10 dark:ring-white/15 bg-slate-200 dark:bg-slate-800 ${className}`}
      />
    );
  }

  const initials = getInitialsFromName(name);
  const palette = getPaletteForName(name);

  return (
    <div
      role="img"
      aria-label={name}
      className={`${SIZE_CLASSES[size]} rounded-full shrink-0 ring-1 ring-black/10 dark:ring-white/15 bg-gradient-to-br ${palette} text-white font-display font-bold flex items-center justify-center select-none shadow-xs ${className}`}
    >
      <span dir="auto" className="leading-none tracking-tight">
        {initials}
      </span>
    </div>
  );
}
