import { useEffect } from "react";
import { X } from "lucide-react";

interface ProfilePhotoLightboxProps {
  src: string | null;
  alt?: string;
  onClose: () => void;
}

export function ProfilePhotoLightbox({
  src,
  alt = "معاينة الصورة",
  onClose,
}: ProfilePhotoLightboxProps) {
  useEffect(() => {
    if (!src) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        onClose();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [src, onClose]);

  if (!src) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={alt}
      onClick={onClose}
      className="fixed inset-0 z-[80] bg-black/92 backdrop-blur-sm flex flex-col p-3 sm:p-6"
    >
      <div className="flex items-center justify-end shrink-0 z-10">
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onClose();
          }}
          aria-label="إغلاق الصورة"
          title="إغلاق"
          className="min-h-[44px] min-w-[44px] rounded-full bg-white/15 hover:bg-white/25 border border-white/20 text-white flex items-center justify-center transition-colors cursor-pointer shadow-lg"
        >
          <X className="w-6 h-6" />
        </button>
      </div>

      <div className="flex-1 min-h-0 flex items-center justify-center p-2 sm:p-4">
        <img
          src={src}
          alt={alt}
          referrerPolicy="no-referrer"
          onClick={(e) => e.stopPropagation()}
          className="max-w-full max-h-[84dvh] w-auto h-auto object-contain rounded-2xl shadow-2xl border border-white/10 select-none"
        />
      </div>
    </div>
  );
}
