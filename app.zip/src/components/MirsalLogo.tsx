interface MirsalLogoProps {
  className?: string;
}

export function MirsalLogo({ className = "w-12 h-12" }: MirsalLogoProps) {
  return (
    <svg
      viewBox="0 0 64 64"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-hidden="true"
    >
      <defs>
        <linearGradient id="mirsal-bg-grad" x1="8" y1="6" x2="56" y2="58" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#129977" />
          <stop offset="55%" stopColor="#0d7a5f" />
          <stop offset="100%" stopColor="#065340" />
        </linearGradient>
        <linearGradient id="mirsal-accent-grad" x1="18" y1="20" x2="46" y2="44" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#ffffff" />
          <stop offset="100%" stopColor="#d1fae5" />
        </linearGradient>
      </defs>

      <rect x="4" y="4" width="56" height="56" rx="18" fill="url(#mirsal-bg-grad)" />
      <rect
        x="5"
        y="5"
        width="54"
        height="54"
        rx="17"
        stroke="white"
        strokeOpacity="0.18"
        strokeWidth="1.5"
      />

      {/* Stylized Speech Bubble + Paper-Plane Pulse */}
      <path
        d="M19 20.5C19 18.0147 21.0147 16 23.5 16H42.5C44.9853 16 47 18.0147 47 20.5V34.5C47 36.9853 44.9853 39 42.5 39H29.4L21.8 45.4C20.55 46.45 19 45.56 19 43.92V20.5Z"
        fill="url(#mirsal-accent-grad)"
      />

      {/* Voice/Message Wave Inside Bubble */}
      <rect x="26" y="25" width="3.5" height="6" rx="1.75" fill="#0d7a5f" />
      <rect x="31.5" y="22" width="3.5" height="12" rx="1.75" fill="#0d7a5f" />
      <rect x="37" y="24" width="3.5" height="8" rx="1.75" fill="#0d7a5f" />

      {/* Subtle Signal Spark */}
      <circle cx="48.5" cy="15.5" r="4.5" fill="#25D366" stroke="#065340" strokeWidth="1.8" />
    </svg>
  );
}
