import { useEffect, useRef, useState, type FormEvent } from "react";
import {
  Clapperboard,
  Film,
  Globe,
  Image as ImageIcon,
  Loader2,
  Newspaper,
  Search,
  Send,
  Sparkles,
  X,
} from "lucide-react";
import type {
  UniversalSearchCategory,
  UniversalSearchResult,
} from "../types/chat";
import { GoogleGIcon } from "./WatchTogetherModal";

const SEARCH_TABS: Array<{
  id: UniversalSearchCategory;
  label: string;
}> = [
  { id: "all", label: "الكل" },
  { id: "web", label: "المواقع" },
  { id: "videos", label: "الفيديوهات" },
  { id: "images", label: "الصور" },
  { id: "news", label: "الأخبار" },
];

interface UniversalSearchModalProps {
  isOpen: boolean;
  isDirectChat: boolean;
  onClose: () => void;
  onOpenInAppBrowser: (
    url: string,
    title?: string,
    canWatchTogether?: boolean
  ) => void;
  onShareToChat: (item: UniversalSearchResult) => Promise<void> | void;
  onWatchTogether: (item: UniversalSearchResult) => Promise<void>;
}

function ResultThumbnail({ item }: { item: UniversalSearchResult }) {
  const [imgFailed, setImgFailed] = useState(false);

  const fallbackIcon =
    item.category === "videos" ? (
      <Film className="w-6 h-6 text-rose-500" />
    ) : item.category === "images" ? (
      <ImageIcon className="w-6 h-6 text-sky-500" />
    ) : item.category === "news" ? (
      <Newspaper className="w-6 h-6 text-amber-500" />
    ) : (
      <Globe className="w-6 h-6 text-[#0d7a5f] dark:text-[#00a884]" />
    );

  if (!item.thumbnail || imgFailed) {
    return (
      <div className="w-24 sm:w-28 aspect-video rounded-xl bg-slate-200/70 dark:bg-[#202c33] flex items-center justify-center shrink-0 border border-slate-200 dark:border-slate-700/70">
        {fallbackIcon}
      </div>
    );
  }

  return (
    <div className="relative w-24 sm:w-28 aspect-video rounded-xl overflow-hidden bg-slate-900 shrink-0 border border-slate-200/70 dark:border-slate-800">
      <img
        src={item.thumbnail}
        alt={item.title}
        loading="lazy"
        referrerPolicy="no-referrer"
        onError={() => setImgFailed(true)}
        className="w-full h-full object-cover"
      />
      {item.duration && (
        <span
          dir="ltr"
          className="absolute bottom-1 left-1 px-1.5 py-0.5 rounded bg-black/80 text-white text-[10px] font-mono font-bold"
        >
          {item.duration}
        </span>
      )}
    </div>
  );
}

export function UniversalSearchModal({
  isOpen,
  isDirectChat,
  onClose,
  onOpenInAppBrowser,
  onShareToChat,
  onWatchTogether,
}: UniversalSearchModalProps) {
  const [query, setQuery] = useState("");
  const [activeType, setActiveType] = useState<UniversalSearchCategory>("all");
  const [results, setResults] = useState<UniversalSearchResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [hasSearched, setHasSearched] = useState(false);

  const inputRef = useRef<HTMLInputElement>(null);
  const abortRef = useRef<AbortController | null>(null);

  useEffect(() => {
    if (!isOpen) return;
    setError(null);
    setBusyId(null);
    const timer = setTimeout(() => inputRef.current?.focus(), 60);
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKeyDown);
    return () => {
      clearTimeout(timer);
      window.removeEventListener("keydown", onKeyDown);
    };
  }, [isOpen, onClose]);

  useEffect(() => {
    return () => {
      abortRef.current?.abort();
    };
  }, []);

  if (!isOpen) return null;

  const executeSearch = async (
    rawQuery: string,
    targetType: UniversalSearchCategory
  ) => {
    const q = rawQuery.trim();
    if (!q) {
      setError("يرجى كتابة كلمة أو عبارة للبحث.");
      return;
    }

    abortRef.current?.abort();
    const controller = new AbortController();
    abortRef.current = controller;

    setLoading(true);
    setError(null);
    setHasSearched(true);

    try {
      const res = await fetch(
        `/api/universal-search?q=${encodeURIComponent(q)}&type=${encodeURIComponent(
          targetType
        )}`,
        { signal: controller.signal }
      );
      const data = (await res.json().catch(() => ({}))) as {
        results?: UniversalSearchResult[];
        error?: string;
      };
      if (!res.ok) {
        setError(data.error || "تعذر تنفيذ البحث الشامل حالياً.");
        setResults([]);
        return;
      }
      setResults(Array.isArray(data.results) ? data.results : []);
    } catch (err) {
      if ((err as { name?: string })?.name === "AbortError") return;
      setError("تعذر الاتصال بمحرك البحث. تحقق من الشبكة وحاول مجدداً.");
      setResults([]);
    } finally {
      if (abortRef.current === controller) {
        setLoading(false);
      }
    }
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    void executeSearch(query, activeType);
  };

  const handleSwitchTab = (tab: UniversalSearchCategory) => {
    setActiveType(tab);
    if (query.trim()) {
      void executeSearch(query, tab);
    }
  };

  const handleShare = async (item: UniversalSearchResult) => {
    if (busyId) return;
    setBusyId(`share_${item.id}`);
    setError(null);
    try {
      await onShareToChat(item);
      onClose();
    } catch {
      setError("تعذر مشاركة النتيجة في المحادثة.");
    } finally {
      setBusyId(null);
    }
  };

  const handleWatch = async (item: UniversalSearchResult) => {
    if (busyId) return;
    setBusyId(`watch_${item.id}`);
    setError(null);
    try {
      await onWatchTogether(item);
      onClose();
    } catch {
      setError("تعذر تشغيل هذا الرابط في المشاهدة المشتركة.");
    } finally {
      setBusyId(null);
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="universal-search-modal-title"
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/55 backdrop-blur-xs p-0 sm:p-4"
      onClick={onClose}
    >
      <div
        dir="rtl"
        onClick={(e) => e.stopPropagation()}
        className="w-full sm:max-w-2xl bg-white dark:bg-[#111b21] border-t sm:border border-slate-200 dark:border-slate-800 rounded-t-3xl sm:rounded-3xl shadow-2xl max-h-[90dvh] flex flex-col overflow-hidden"
      >
        <div className="w-10 h-1.5 bg-slate-300 dark:bg-slate-700 rounded-full mx-auto mt-3 sm:hidden shrink-0" />

        {/* Header & Search Form */}
        <div className="p-4 sm:p-5 border-b border-slate-100 dark:border-slate-800 space-y-3 shrink-0">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-9 h-9 rounded-full bg-white dark:bg-[#202c33] border border-slate-200 dark:border-slate-700 shadow-xs flex items-center justify-center shrink-0">
                <GoogleGIcon className="w-5 h-5" />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <h2
                    id="universal-search-modal-title"
                    className="font-display text-sm sm:text-base font-bold text-slate-900 dark:text-white truncate"
                  >
                    محرك البحث الشامل في مرسال
                  </h2>
                  <span
                    dir="ltr"
                    className="hidden sm:inline-flex items-center px-2 py-0.5 rounded-md bg-emerald-50 dark:bg-emerald-950/60 text-[#0d7a5f] dark:text-[#00a884] text-[10px] font-bold"
                  >
                    MIRSAL UNIVERSAL SEARCH
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                  مواقع، فيديوهات، صور، وأخبار — افتحها، شاركها، أو شاهدها معاً
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={onClose}
              aria-label="إغلاق البحث"
              className="min-h-[40px] min-w-[40px] rounded-xl flex items-center justify-center text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer shrink-0"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="flex items-center gap-2">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                ref={inputRef}
                type="search"
                value={query}
                onChange={(e) => {
                  setQuery(e.target.value);
                  if (error) setError(null);
                }}
                placeholder="ابحث في الويب، يوتيوب، فيديوهات، صور، أخبار..."
                className="w-full min-h-[44px] pr-10 pl-3.5 rounded-full bg-slate-100 dark:bg-[#202c33] border border-slate-200/80 dark:border-slate-700 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-[#4285F4]/60"
              />
            </div>

            <button
              type="submit"
              disabled={loading || !query.trim()}
              className="min-h-[44px] px-4 sm:px-5 rounded-full bg-[#4285F4] hover:bg-[#3367d6] disabled:opacity-50 text-white text-xs sm:text-sm font-bold flex items-center justify-center gap-1.5 shrink-0 transition-colors cursor-pointer"
            >
              {loading ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Search className="w-4 h-4" />
              )}
              <span>بحث</span>
            </button>
          </form>

          {/* 5 Filter Tabs */}
          <div className="grid grid-cols-5 gap-1 p-1 rounded-2xl bg-slate-100 dark:bg-[#202c33]">
            {SEARCH_TABS.map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => handleSwitchTab(tab.id)}
                className={`min-h-[36px] px-1.5 py-1.5 rounded-xl text-[11px] sm:text-xs font-bold transition-colors cursor-pointer ${
                  activeType === tab.id
                    ? "bg-white dark:bg-[#111b21] text-[#0d7a5f] dark:text-[#00a884] shadow-xs"
                    : "text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white"
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Results Area */}
        <div className="flex-1 overflow-y-auto custom-scrollbar p-4 space-y-2.5">
          {error && (
            <p
              role="alert"
              className="text-xs font-medium text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/40 px-3.5 py-2.5 rounded-xl"
            >
              {error}
            </p>
          )}

          {loading ? (
            <div className="py-12 flex flex-col items-center justify-center gap-2.5 text-slate-500 dark:text-slate-400">
              <Loader2 className="w-7 h-7 animate-spin text-[#4285F4]" />
              <p className="text-xs font-semibold">
                جاري البحث في المصادر المفتوحة وتجهيز النتائج...
              </p>
            </div>
          ) : results.length > 0 ? (
            <div className="space-y-2.5">
              {results.map((item) => {
                const isSharing = busyId === `share_${item.id}`;
                const isWatching = busyId === `watch_${item.id}`;
                const canWatch =
                  isDirectChat &&
                  (item.watchable ||
                    item.category === "videos" ||
                    (item.platform && item.platform !== "web"));

                const categoryLabel =
                  item.category === "videos"
                    ? "فيديو"
                    : item.category === "images"
                    ? "صورة"
                    : item.category === "news"
                    ? "خبر"
                    : "موقع";

                return (
                  <article
                    key={item.id}
                    className="p-3 rounded-2xl bg-slate-50 dark:bg-[#1a252b] border border-slate-200/80 dark:border-slate-800 space-y-2.5"
                  >
                    <div className="flex items-start gap-3">
                      <ResultThumbnail item={item} />

                      <div className="flex-1 min-w-0 space-y-1">
                        <div className="flex flex-wrap items-center gap-1.5 text-[10.5px]">
                          <span className="px-2 py-0.5 rounded-md bg-emerald-50 dark:bg-emerald-950/60 text-[#0d7a5f] dark:text-[#00a884] font-bold">
                            {item.siteName || categoryLabel}
                          </span>
                          <span className="px-1.5 py-0.5 rounded-md bg-slate-200/80 dark:bg-[#202c33] text-slate-600 dark:text-slate-300 font-semibold">
                            {categoryLabel}
                          </span>
                          {item.publishedAt && (
                            <span className="text-slate-400 truncate max-w-[140px]">
                              {item.publishedAt}
                            </span>
                          )}
                        </div>

                        <h3 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white line-clamp-2 leading-snug">
                          {item.title}
                        </h3>

                        {item.description && (
                          <p className="text-[11px] text-slate-600 dark:text-slate-300 line-clamp-2 leading-relaxed">
                            {item.description}
                          </p>
                        )}

                        <p
                          dir="ltr"
                          className="text-[10.5px] font-mono text-slate-400 truncate"
                        >
                          {item.url}
                        </p>
                      </div>
                    </div>

                    {/* 3 Clean Action Buttons */}
                    <div className="flex flex-wrap items-center gap-1.5 pt-1 border-t border-slate-200/70 dark:border-slate-800/80">
                      <button
                        type="button"
                        onClick={() =>
                          onOpenInAppBrowser(
                            item.url,
                            item.title,
                            Boolean(canWatch)
                          )
                        }
                        className="min-h-[34px] px-3 py-1.5 rounded-xl bg-white dark:bg-[#202c33] hover:bg-slate-100 dark:hover:bg-[#2a3942] border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 text-[11px] font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <Globe className="w-3.5 h-3.5 text-[#4285F4]" />
                        <span>فتح في المتصفح المدمج</span>
                      </button>

                      <button
                        type="button"
                        disabled={Boolean(busyId)}
                        onClick={() => void handleShare(item)}
                        className="min-h-[34px] px-3 py-1.5 rounded-xl bg-[#0d7a5f] hover:bg-[#0a634d] dark:bg-[#00a884] dark:hover:bg-[#069475] disabled:opacity-50 text-white text-[11px] font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                      >
                        {isSharing ? (
                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        ) : (
                          <Send className="w-3.5 h-3.5" />
                        )}
                        <span>مشاركة في المحادثة</span>
                      </button>

                      {canWatch && (
                        <button
                          type="button"
                          disabled={Boolean(busyId)}
                          onClick={() => void handleWatch(item)}
                          className="min-h-[34px] px-3 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-700 disabled:opacity-50 text-white text-[11px] font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                        >
                          {isWatching ? (
                            <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          ) : (
                            <Clapperboard className="w-3.5 h-3.5" />
                          )}
                          <span>تشغيل في المشاهدة المشتركة</span>
                        </button>
                      )}
                    </div>
                  </article>
                );
              })}
            </div>
          ) : hasSearched && !error ? (
            <div className="py-12 text-center space-y-1.5">
              <p className="text-sm font-bold text-slate-700 dark:text-slate-200">
                لم يتم العثور على نتائج مطابقة في هذا التصنيف
              </p>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                جرّب كلمات بحث أخرى أو انتقل لتبويب «الكل».
              </p>
            </div>
          ) : (
            <div className="py-10 text-center space-y-2.5">
              <div className="w-12 h-12 mx-auto rounded-full bg-slate-100 dark:bg-[#202c33] flex items-center justify-center">
                <Sparkles className="w-6 h-6 text-[#4285F4]" />
              </div>
              <p className="text-xs font-semibold text-slate-600 dark:text-slate-300">
                ابحث عن أي موضوع أو موقع أو فيديو أو صورة أو خبر ثم افتحه داخل مرسال أو شاركه فوراً
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
