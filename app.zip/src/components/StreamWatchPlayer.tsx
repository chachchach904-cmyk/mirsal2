import { useCallback, useEffect, useRef, useState } from "react";
import Hls from "hls.js";
import {
  Columns2,
  ExternalLink,
  Globe,
  Instagram,
  Loader2,
  Maximize,
  Maximize2,
  Minimize,
  Music2,
  Pause,
  PictureInPicture2,
  Play,
  ShieldAlert,
  Volume2,
  VolumeX,
} from "lucide-react";
import type { MediaResolveResult, WatchSessionData } from "../types/chat";
import {
  extractSiteNameFromUrl,
  extractTikTokVideoId,
  isInstagramUrl,
  isTikTokVideoUrl,
  parseInstagramUrl,
} from "../utils/storage";

export type WatchPlayerSizeMode = "split" | "mini" | "fullscreen";

const SPEED_OPTIONS = [1, 1.25, 1.5, 2] as const;

function formatWatchTime(seconds: number): string {
  const safe = Math.max(0, Math.floor(seconds));
  const h = Math.floor(safe / 3600);
  const m = Math.floor((safe % 3600) / 60);
  const s = safe % 60;
  if (h > 0) {
    return `${h}:${m.toString().padStart(2, "0")}:${s
      .toString()
      .padStart(2, "0")}`;
  }
  return `${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
}

interface StreamWatchPlayerProps {
  session: WatchSessionData;
  isHost: boolean;
  hostName: string;
  sizeMode?: WatchPlayerSizeMode;
  externalMuted?: boolean;
  seekSignal?: { nonce: number; deltaSeconds: number } | null;
  onChangeSizeMode?: (mode: WatchPlayerSizeMode) => void;
  onPlaybackSync: (
    playbackState: "playing" | "paused",
    playbackTime: number,
    playbackRate: number
  ) => void;
}

export function StreamWatchPlayer({
  session,
  isHost,
  hostName: _hostName,
  sizeMode,
  externalMuted,
  seekSignal,
  onChangeSizeMode,
  onPlaybackSync,
}: StreamWatchPlayerProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const tiktokIframeRef = useRef<HTMLIFrameElement>(null);
  const hlsRef = useRef<Hls | null>(null);
  const sessionRef = useRef<WatchSessionData>(session);
  const isScrubbingRef = useRef<boolean>(false);
  const tiktokReadyRef = useRef<boolean>(false);
  const tiktokTimeRef = useRef<number>(
    session.currentTime ?? session.playbackTime ?? 0
  );
  const tiktokPlayingRef = useRef<boolean>(
    session.isPlaying ?? session.playbackState !== "paused"
  );
  const suppressTikTokEventRef = useRef<boolean>(false);
  const lastSeekNonceRef = useRef<number>(0);
  const isHostRef = useRef<boolean>(isHost);
  const onPlaybackSyncRef = useRef(onPlaybackSync);

  sessionRef.current = session;
  isHostRef.current = isHost;
  onPlaybackSyncRef.current = onPlaybackSync;

  const [streamError, setStreamError] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(
    session.isPlaying ?? session.playbackState !== "paused"
  );
  const [currentTime, setCurrentTime] = useState(
    session.currentTime ?? session.playbackTime ?? 0
  );
  const [duration, setDuration] = useState(0);
  const [playbackRate, setPlaybackRate] = useState(session.playbackRate ?? 1);
  const [isMuted, setIsMuted] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);

  const [resolvedTikTokId, setResolvedTikTokId] = useState<string | null>(null);
  const [resolvedTikTokUrl, setResolvedTikTokUrl] = useState<string | null>(null);
  const [tikTokUnavailableReason, setTikTokUnavailableReason] = useState<string | null>(null);
  const [isResolvingTikTok, setIsResolvingTikTok] = useState(false);

  const [resolvedMedia, setResolvedMedia] = useState<MediaResolveResult | null>(null);
  const [isResolvingWeb, setIsResolvingWeb] = useState(false);

  const rawMediaUrl = session.videoUrl || session.mediaUrl || session.youtubeUrl;
  const isTikTok =
    session.mediaType === "tiktok" || isTikTokVideoUrl(rawMediaUrl || "");
  const isInstagram =
    !isTikTok &&
    (session.mediaType === "instagram" || isInstagramUrl(rawMediaUrl || ""));
  const isWebPage =
    !isTikTok && !isInstagram && session.mediaType === "web";

  const directTikTokId = isTikTok
    ? /^\d{10,25}$/.test(session.videoId || "")
      ? session.videoId
      : extractTikTokVideoId(rawMediaUrl || "")
    : null;
  const tiktokVideoId = directTikTokId || resolvedTikTokId;
  const effectiveTikTokLink = resolvedTikTokUrl || rawMediaUrl;

  // Determine the actual native video URL if direct stream or extracted from web/instagram
  const effectiveNativeVideoUrl = isWebPage || isInstagram
    ? resolvedMedia?.directVideoUrl || null
    : !isTikTok
    ? rawMediaUrl
    : null;

  const isHls =
    Boolean(effectiveNativeVideoUrl) &&
    (session.mediaType === "m3u8" ||
      (effectiveNativeVideoUrl || "").toLowerCase().includes(".m3u8"));

  // Resolve TikTok links & availability
  useEffect(() => {
    if (!isTikTok || !rawMediaUrl) {
      setResolvedTikTokId(null);
      setResolvedTikTokUrl(null);
      setTikTokUnavailableReason(null);
      setIsResolvingTikTok(false);
      return;
    }

    let cancelled = false;
    const controller = new AbortController();
    setIsResolvingTikTok(!directTikTokId);
    setTikTokUnavailableReason(null);
    if (!directTikTokId) {
      setResolvedTikTokId(null);
    }

    fetch(`/api/resolve-tiktok?url=${encodeURIComponent(rawMediaUrl)}`, {
      signal: controller.signal,
    })
      .then((res) => (res.ok ? res.json() : null))
      .then(
        (
          data: {
            videoId?: string | null;
            resolvedUrl?: string;
            available?: boolean;
            unavailableReason?: string | null;
          } | null
        ) => {
          if (cancelled || !data) return;
          if (data.videoId && /^\d{10,25}$/.test(data.videoId)) {
            setResolvedTikTokId(data.videoId);
          }
          if (data.resolvedUrl) {
            setResolvedTikTokUrl(data.resolvedUrl);
          }
          if (data.available === false) {
            setTikTokUnavailableReason(
              data.unavailableReason || "هذا الفيديو غير متاح أو محذوف أو خاص على تيك توك."
            );
          }
        }
      )
      .catch(() => {
        // fallback handled gracefully below with open-in-TikTok button
      })
      .finally(() => {
        if (!cancelled) {
          setIsResolvingTikTok(false);
        }
      });

    return () => {
      cancelled = true;
      controller.abort();
    };
  }, [isTikTok, rawMediaUrl, directTikTokId]);

  // Resolve Instagram / Web links via /api/resolve-media
  useEffect(() => {
    if ((!isWebPage && !isInstagram) || !rawMediaUrl) {
      setResolvedMedia(null);
      setIsResolvingWeb(false);
      return;
    }

    let cancelled = false;
    const controller = new AbortController();
    setIsResolvingWeb(true);
    setResolvedMedia(null);

    fetch(`/api/resolve-media?url=${encodeURIComponent(rawMediaUrl)}`, {
      signal: controller.signal,
    })
      .then((res) => (res.ok ? res.json() : null))
      .then((data: MediaResolveResult | null) => {
        if (cancelled) return;
        if (data) {
          setResolvedMedia(data);
        }
      })
      .catch(() => {
        // handled cleanly with fallback UI below
      })
      .finally(() => {
        if (!cancelled) {
          setIsResolvingWeb(false);
        }
      });

    return () => {
      cancelled = true;
      controller.abort();
    };
  }, [isWebPage, isInstagram, rawMediaUrl]);

  const postTikTokCommand = useCallback(
    (type: string, value?: number) => {
      const win = tiktokIframeRef.current?.contentWindow;
      if (!win) return;
      win.postMessage(
        {
          type,
          ...(typeof value === "number" ? { value } : {}),
          "x-tiktok-player": true,
        },
        "https://www.tiktok.com"
      );
    },
    []
  );

  const applyTikTokPeerSync = useCallback(
    (snap: WatchSessionData) => {
      if (isHost || !isTikTok || !tiktokVideoId || !tiktokReadyRef.current) {
        return;
      }

      const targetPlaying =
        typeof snap.isPlaying === "boolean"
          ? snap.isPlaying
          : snap.playbackState !== "paused";
      const baseTime = snap.currentTime ?? snap.playbackTime ?? 0;
      const drift =
        targetPlaying && snap.updatedAtMs
          ? Math.max(0, (Date.now() - snap.updatedAtMs) / 1000)
          : 0;
      const expectedTime = baseTime + drift;

      if (
        Number.isFinite(expectedTime) &&
        Math.abs(tiktokTimeRef.current - expectedTime) > 1.8
      ) {
        postTikTokCommand("seekTo", Math.max(0, Math.floor(expectedTime)));
        tiktokTimeRef.current = expectedTime;
        setCurrentTime(expectedTime);
      }

      if (targetPlaying !== tiktokPlayingRef.current) {
        postTikTokCommand(targetPlaying ? "play" : "pause");
        tiktokPlayingRef.current = targetPlaying;
        setIsPlaying(targetPlaying);
      }
    },
    [isHost, isTikTok, tiktokVideoId, postTikTokCommand]
  );

  const applyPeerSyncFromSession = useCallback(
    (snap: WatchSessionData) => {
      if (isHost || isTikTok) return;
      const video = videoRef.current;
      if (!video) return;

      const targetPlaying =
        typeof snap.isPlaying === "boolean"
          ? snap.isPlaying
          : snap.playbackState !== "paused";
      const targetRate =
        typeof snap.playbackRate === "number" && snap.playbackRate > 0
          ? snap.playbackRate
          : 1;
      const baseTime = snap.currentTime ?? snap.playbackTime ?? 0;
      const drift =
        targetPlaying && snap.updatedAtMs
          ? Math.max(0, (Date.now() - snap.updatedAtMs) / 1000) * targetRate
          : 0;
      const expectedTime = baseTime + drift;

      if (video.playbackRate !== targetRate) {
        video.playbackRate = targetRate;
      }
      setPlaybackRate(targetRate);

      if (
        video.readyState >= 1 &&
        Number.isFinite(expectedTime) &&
        Math.abs((video.currentTime || 0) - expectedTime) > 1.8
      ) {
        try {
          video.currentTime = expectedTime;
          setCurrentTime(expectedTime);
        } catch {
          // ignore seek errors on live streams without seekable range
        }
      }

      if (!targetPlaying && !video.paused) {
        video.pause();
        setIsPlaying(false);
      } else if (targetPlaying && video.paused) {
        video.play().catch(() => {
          video.muted = true;
          setIsMuted(true);
          video.play().catch(() => {});
        });
        setIsPlaying(true);
      }
    },
    [isHost, isTikTok]
  );

  // TikTok Player postMessage sync listener
  useEffect(() => {
    if (!isTikTok || !tiktokVideoId || tikTokUnavailableReason) return;
    tiktokReadyRef.current = false;

    const handleMessage = (event: MessageEvent) => {
      if (event.origin !== "https://www.tiktok.com") return;
      const data = event.data as
        | {
            type?: string;
            value?: unknown;
            "x-tiktok-player"?: boolean;
          }
        | undefined;
      if (!data || !data["x-tiktok-player"]) return;

      if (data.type === "onPlayerReady") {
        tiktokReadyRef.current = true;
        if (!isHost) {
          applyTikTokPeerSync(sessionRef.current);
        }
        return;
      }

      if (data.type === "onCurrentTime" && data.value && typeof data.value === "object") {
        const val = data.value as { currentTime?: number; duration?: number };
        if (typeof val.currentTime === "number" && !isScrubbingRef.current) {
          tiktokTimeRef.current = val.currentTime;
          setCurrentTime(val.currentTime);
        }
        if (typeof val.duration === "number" && val.duration > 0) {
          setDuration(val.duration);
        }
        return;
      }

      if (data.type === "onStateChange") {
        const stateCode = Number(data.value);
        if (stateCode === 1) {
          const changed = !tiktokPlayingRef.current;
          tiktokPlayingRef.current = true;
          setIsPlaying(true);
          if (isHost && changed && !suppressTikTokEventRef.current) {
            onPlaybackSync("playing", tiktokTimeRef.current || 0, 1);
          }
        } else if (stateCode === 2) {
          const changed = tiktokPlayingRef.current;
          tiktokPlayingRef.current = false;
          setIsPlaying(false);
          if (isHost && changed && !suppressTikTokEventRef.current) {
            onPlaybackSync("paused", tiktokTimeRef.current || 0, 1);
          }
        }
      }
    };

    window.addEventListener("message", handleMessage);
    return () => {
      window.removeEventListener("message", handleMessage);
      tiktokReadyRef.current = false;
    };
  }, [
    isTikTok,
    tiktokVideoId,
    tikTokUnavailableReason,
    isHost,
    applyTikTokPeerSync,
    onPlaybackSync,
  ]);

  // Native MP4 / HLS / Extracted Video setup
  useEffect(() => {
    const video = videoRef.current;
    if (!video || !effectiveNativeVideoUrl) return;

    setStreamError(null);

    if (hlsRef.current) {
      hlsRef.current.destroy();
      hlsRef.current = null;
    }

    if (isHls) {
      if (video.canPlayType("application/vnd.apple.mpegurl")) {
        video.src = effectiveNativeVideoUrl;
      } else if (Hls.isSupported()) {
        const hls = new Hls({
          enableWorker: true,
          lowLatencyMode: true,
        });
        hlsRef.current = hls;
        hls.loadSource(effectiveNativeVideoUrl);
        hls.attachMedia(video);
        hls.on(Hls.Events.ERROR, (_ev, data) => {
          if (data.fatal) {
            setStreamError(
              "تعذر تحميل البث المباشر (.m3u8). تأكد من صلاحية الرابط والسماح بالتشغيل."
            );
          }
        });
      } else {
        setStreamError("المتصفح الحالي لا يدعم تشغيل بث m3u8.");
      }
    } else {
      video.src = effectiveNativeVideoUrl;
    }

    const initialPlaying =
      typeof sessionRef.current.isPlaying === "boolean"
        ? sessionRef.current.isPlaying
        : sessionRef.current.playbackState !== "paused";
    video.playbackRate = sessionRef.current.playbackRate ?? 1;

    if (initialPlaying) {
      video.play().catch(() => {
        if (!isHost) {
          video.muted = true;
          setIsMuted(true);
          video.play().catch(() => {});
        }
      });
    }

    return () => {
      if (hlsRef.current) {
        hlsRef.current.destroy();
        hlsRef.current = null;
      }
      video.pause();
      video.removeAttribute("src");
      video.load();
    };
  }, [effectiveNativeVideoUrl, isHls, isHost]);

  // Apply remote host play/pause/seek/speed sync updates for viewers (event-driven only, zero polling)
  useEffect(() => {
    if (isHost) return;
    if (isTikTok) {
      applyTikTokPeerSync(session);
      return;
    }
    if (effectiveNativeVideoUrl) {
      applyPeerSyncFromSession(session);
    }
  }, [
    isHost,
    isTikTok,
    effectiveNativeVideoUrl,
    applyTikTokPeerSync,
    applyPeerSyncFromSession,
    session.isPlaying,
    session.playbackState,
    session.currentTime,
    session.playbackTime,
    session.playbackRate,
    session.updatedAtMs,
  ]);

  useEffect(() => {
    const onFsChange = () => {
      const active = document.fullscreenElement === containerRef.current;
      setIsFullscreen(active);
      if (!active) {
        try {
          (
            screen.orientation as ScreenOrientation & {
              unlock?: () => void;
            }
          )?.unlock?.();
        } catch {
          // ignore
        }
      }
    };
    document.addEventListener("fullscreenchange", onFsChange);
    return () => document.removeEventListener("fullscreenchange", onFsChange);
  }, []);

  useEffect(() => {
    if (typeof externalMuted !== "boolean") return;
    setIsMuted(externalMuted);
    if (isTikTok) {
      postTikTokCommand(externalMuted ? "mute" : "unMute");
      return;
    }
    const video = videoRef.current;
    if (video) {
      video.muted = externalMuted;
    }
  }, [externalMuted, isTikTok, postTikTokCommand]);

  useEffect(() => {
    if (!seekSignal || seekSignal.nonce === lastSeekNonceRef.current) return;
    lastSeekNonceRef.current = seekSignal.nonce;
    if (isTikTok) {
      const nextTime = Math.max(
        0,
        (tiktokTimeRef.current || 0) + seekSignal.deltaSeconds
      );
      suppressTikTokEventRef.current = true;
      postTikTokCommand("seekTo", Math.floor(nextTime));
      tiktokTimeRef.current = nextTime;
      setCurrentTime(nextTime);
      if (isHostRef.current) {
        onPlaybackSyncRef.current(
          tiktokPlayingRef.current ? "playing" : "paused",
          nextTime,
          1
        );
      }
      setTimeout(() => {
        suppressTikTokEventRef.current = false;
      }, 250);
      return;
    }
    const video = videoRef.current;
    if (!video) return;
    const nextTime = Math.max(
      0,
      (video.currentTime || 0) + seekSignal.deltaSeconds
    );
    video.currentTime = nextTime;
    setCurrentTime(nextTime);
    if (isHostRef.current) {
      onPlaybackSyncRef.current(
        video.paused ? "paused" : "playing",
        nextTime,
        video.playbackRate || 1
      );
    }
  }, [seekSignal, isTikTok, postTikTokCommand]);

  const handleHostTogglePlay = () => {
    if (!isHost) return;
    if (isTikTok) {
      const nextPlaying = !tiktokPlayingRef.current;
      suppressTikTokEventRef.current = true;
      postTikTokCommand(nextPlaying ? "play" : "pause");
      tiktokPlayingRef.current = nextPlaying;
      setIsPlaying(nextPlaying);
      onPlaybackSync(
        nextPlaying ? "playing" : "paused",
        tiktokTimeRef.current || 0,
        1
      );
      setTimeout(() => {
        suppressTikTokEventRef.current = false;
      }, 250);
      return;
    }

    const video = videoRef.current;
    if (!video) return;
    if (video.paused) {
      video.play().catch(() => {});
      setIsPlaying(true);
      onPlaybackSync("playing", video.currentTime || 0, video.playbackRate || 1);
    } else {
      video.pause();
      setIsPlaying(false);
      onPlaybackSync("paused", video.currentTime || 0, video.playbackRate || 1);
    }
  };

  const handleHostScrubPreview = (nextTime: number) => {
    if (!isHost) return;
    isScrubbingRef.current = true;
    if (isTikTok) {
      tiktokTimeRef.current = nextTime;
      setCurrentTime(nextTime);
      return;
    }
    const video = videoRef.current;
    if (!video) return;
    video.currentTime = nextTime;
    setCurrentTime(nextTime);
  };

  const handleHostSeekCommit = (nextTime: number) => {
    if (!isHost) return;
    isScrubbingRef.current = false;
    if (isTikTok) {
      postTikTokCommand("seekTo", Math.max(0, Math.floor(nextTime)));
      tiktokTimeRef.current = nextTime;
      setCurrentTime(nextTime);
      onPlaybackSync(
        tiktokPlayingRef.current ? "playing" : "paused",
        nextTime,
        1
      );
      return;
    }
    const video = videoRef.current;
    if (!video) return;
    video.currentTime = nextTime;
    setCurrentTime(nextTime);
    onPlaybackSync(
      video.paused ? "paused" : "playing",
      nextTime,
      video.playbackRate || 1
    );
  };

  const handleHostSpeed = (nextRate: number) => {
    const video = videoRef.current;
    if (!isHost || !video || isTikTok) return;
    video.playbackRate = nextRate;
    setPlaybackRate(nextRate);
    onPlaybackSync(
      video.paused ? "paused" : "playing",
      video.currentTime || 0,
      nextRate
    );
  };

  const handleToggleMute = () => {
    if (isTikTok) {
      const nextMuted = !isMuted;
      postTikTokCommand(nextMuted ? "mute" : "unMute");
      setIsMuted(nextMuted);
      return;
    }
    const video = videoRef.current;
    if (!video) return;
    video.muted = !video.muted;
    setIsMuted(video.muted);
  };

  const handleToggleFullscreen = async () => {
    const el = containerRef.current;
    if (!el) return;
    const orientationApi = (
      typeof screen !== "undefined" ? screen.orientation : undefined
    ) as
      | (ScreenOrientation & {
          lock?: (orientation: string) => Promise<void>;
          unlock?: () => void;
        })
      | undefined;

    try {
      if (document.fullscreenElement === el) {
        try {
          orientationApi?.unlock?.();
        } catch {
          // ignore
        }
        await document.exitFullscreen();
      } else if (el.requestFullscreen) {
        await el.requestFullscreen();
        try {
          await orientationApi?.lock?.("landscape");
        } catch {
          // unsupported on desktop or restricted browsers
        }
      }
    } catch {
      // ignore
    }
  };

  const tiktokEmbedUrl =
    tiktokVideoId && !tikTokUnavailableReason
      ? `https://www.tiktok.com/embed/v2/${tiktokVideoId}`
      : "";

  const parsedIg = isInstagram ? parseInstagramUrl(rawMediaUrl || "") : null;
  const igEmbedUrl =
    resolvedMedia?.embedUrl || parsedIg?.embedUrl || null;
  const canEmbedWeb =
    (isWebPage || isInstagram) &&
    !effectiveNativeVideoUrl &&
    Boolean(resolvedMedia?.canEmbed ?? (isInstagram && Boolean(igEmbedUrl)));

  const showNativeVideoStage = Boolean(effectiveNativeVideoUrl);
  const showSynchronizedStrip =
    sizeMode !== "mini" &&
    ((isTikTok && Boolean(tiktokEmbedUrl)) || showNativeVideoStage);

  return (
    <div
      ref={containerRef}
      className="w-full h-full bg-black relative flex flex-col overflow-hidden select-none"
    >
      <div className="flex-1 min-h-0 relative bg-black flex items-center justify-center">
        {isTikTok ? (
          tiktokEmbedUrl ? (
            <iframe
              ref={tiktokIframeRef}
              src={tiktokEmbedUrl}
              title="مشاهدة فيديو تيك توك معاً"
              allow="autoplay; fullscreen; encrypted-media"
              allowFullScreen
              className="w-full h-full border-0 bg-black"
            />
          ) : isResolvingTikTok ? (
            <div className="p-6 text-center space-y-2.5">
              <Loader2 className="w-7 h-7 mx-auto animate-spin text-pink-400" />
              <p className="text-xs font-semibold text-slate-300">
                جاري فحص رابط تيك توك وتجهيز المشغل...
              </p>
            </div>
          ) : (
            <div className="p-6 text-center space-y-3 max-w-sm">
              <div className="w-12 h-12 mx-auto rounded-2xl bg-pink-500/20 text-pink-400 flex items-center justify-center">
                <Music2 className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <p className="text-sm font-bold text-white">
                  {tikTokUnavailableReason
                    ? "تعذر تشغيل فيديو تيك توك"
                    : "فيديو تيك توك للمشاهدة معاً"}
                </p>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {tikTokUnavailableReason ||
                    "تعذر استخراج معرف الفيديو تلقائياً أو أن الحساب خاص/محذوف. يمكنك فتح الرابط مباشرة في تيك توك."}
                </p>
              </div>
              <a
                href={effectiveTikTokLink}
                target="_blank"
                rel="noopener noreferrer"
                className="min-h-[40px] px-4 py-2 rounded-xl bg-pink-600 hover:bg-pink-700 text-white text-xs font-bold inline-flex items-center gap-2"
              >
                <ExternalLink className="w-4 h-4" />
                <span>فتح في تيك توك</span>
              </a>
            </div>
          )
        ) : showNativeVideoStage ? (
          <video
            ref={videoRef}
            controls={false}
            playsInline
            preload="auto"
            onClick={isHost ? handleHostTogglePlay : undefined}
            onLoadedMetadata={(e) => {
              const dur = e.currentTarget.duration;
              if (Number.isFinite(dur) && dur > 0) setDuration(dur);
              if (!isHost) {
                applyPeerSyncFromSession(sessionRef.current);
              }
            }}
            onTimeUpdate={(e) => {
              if (!isScrubbingRef.current) {
                setCurrentTime(e.currentTarget.currentTime || 0);
              }
              if (
                Number.isFinite(e.currentTarget.duration) &&
                e.currentTarget.duration > 0
              ) {
                setDuration(e.currentTarget.duration);
              }
            }}
            onPlay={() => {
              setIsPlaying(true);
            }}
            onPause={() => {
              setIsPlaying(false);
            }}
            onError={() => {
              if (!isHls) {
                setStreamError(
                  "تعذر تشغيل رابط الفيديو. تأكد من صلاحية الرابط وعدم حظره من المصدر."
                );
              }
            }}
            className="w-full h-full object-contain bg-black"
          />
        ) : isWebPage || isInstagram ? (
          isResolvingWeb ? (
            <div className="p-6 text-center space-y-2.5">
              <Loader2 className="w-7 h-7 mx-auto animate-spin text-[#00a884]" />
              <p className="text-xs font-semibold text-slate-300">
                جاري فحص الرابط واستخراج المشغل المدمج...
              </p>
            </div>
          ) : canEmbedWeb ? (
            <>
              <iframe
                src={
                  (isInstagram ? igEmbedUrl : resolvedMedia?.embedUrl) ||
                  resolvedMedia?.resolvedUrl ||
                  rawMediaUrl
                }
                title={resolvedMedia?.title || "المشاهدة المشتركة"}
                sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-presentation"
                allow="autoplay; fullscreen; encrypted-media; picture-in-picture"
                allowFullScreen
                className="w-full h-full border-0 bg-white dark:bg-[#0b141a]"
              />
              <a
                href={resolvedMedia?.resolvedUrl || rawMediaUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="absolute bottom-2.5 left-2.5 z-20 px-2.5 py-1.5 rounded-lg bg-black/75 hover:bg-black/90 border border-white/15 text-white text-[11px] font-semibold flex items-center gap-1.5"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span>فتح الموقع الأصلي</span>
              </a>
            </>
          ) : (
            <div className="p-5 sm:p-6 text-center space-y-3 max-w-md">
              <div className="w-12 h-12 mx-auto rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
                {isInstagram ? (
                  <Instagram className="w-6 h-6" />
                ) : (
                  <ShieldAlert className="w-6 h-6" />
                )}
              </div>
              <div className="space-y-1">
                <p className="text-xs font-bold text-[#00a884]">
                  {resolvedMedia?.siteName || extractSiteNameFromUrl(rawMediaUrl)}
                </p>
                <p className="text-sm font-bold text-white line-clamp-2">
                  {resolvedMedia?.title || "عرض الرابط الخارجي"}
                </p>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {resolvedMedia?.blockReason ||
                    "الموقع الأصلي يمنع التضمين داخل إطار خارجي لأسباب أمنية أو يتطلب المشاهدة من المصدر مباشرة."}
                </p>
              </div>
              <a
                href={resolvedMedia?.resolvedUrl || rawMediaUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="min-h-[42px] px-4 py-2 rounded-xl bg-[#00a884] hover:bg-[#069475] text-white text-xs font-bold inline-flex items-center gap-2"
              >
                <ExternalLink className="w-4 h-4" />
                <span>فتح الموقع الأصلي</span>
              </a>
            </div>
          )
        ) : (
          <div className="p-6 text-center space-y-2 text-slate-300">
            <Globe className="w-8 h-8 mx-auto text-slate-400" />
            <p className="text-xs">الرابط غير مدعوم للتشغيل المباشر.</p>
          </div>
        )}

        {/* Viewer Interaction Lock: transparent overlay prevents touching player */}
        {!isHost && (showNativeVideoStage || Boolean(tiktokEmbedUrl)) && (
          <div
            aria-hidden="true"
            className="absolute inset-0 z-10 bg-transparent cursor-default select-none"
          />
        )}

        {/* Quick 3-mode floating size toggle on player corner if handler is provided */}
        {onChangeSizeMode && sizeMode && sizeMode !== "mini" && (
          <div className="absolute top-2 left-2 z-20 flex items-center gap-1 bg-black/70 border border-white/15 rounded-lg p-0.5 backdrop-blur-xs">
            <button
              type="button"
              onClick={() => onChangeSizeMode("split")}
              title="نصف الشاشة (50%)"
              aria-label="نصف الشاشة"
              className={`p-1.5 rounded-md transition-colors cursor-pointer ${
                sizeMode === "split"
                  ? "bg-[#00a884] text-white"
                  : "text-slate-200 hover:bg-white/15"
              }`}
            >
              <Columns2 className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={() => onChangeSizeMode("mini")}
              title="نافذة عائمة مصغرة"
              aria-label="نافذة عائمة مصغرة"
              className="p-1.5 rounded-md transition-colors cursor-pointer text-slate-200 hover:bg-white/15"
            >
              <PictureInPicture2 className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={() => onChangeSizeMode("fullscreen")}
              title="ملء الشاشة (100%)"
              aria-label="ملء الشاشة"
              className={`p-1.5 rounded-md transition-colors cursor-pointer ${
                sizeMode === "fullscreen"
                  ? "bg-[#00a884] text-white"
                  : "text-slate-200 hover:bg-white/15"
              }`}
            >
              <Maximize2 className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {streamError && showNativeVideoStage && (
          <div className="absolute inset-0 z-30 bg-black/85 flex flex-col items-center justify-center p-4 text-center gap-3">
            <p className="text-xs sm:text-sm text-rose-300 font-medium max-w-sm leading-relaxed">
              {streamError}
            </p>
            <a
              href={rawMediaUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="px-3.5 py-2 rounded-xl bg-white/15 hover:bg-white/25 text-white text-xs font-bold inline-flex items-center gap-1.5"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>فتح الموقع الأصلي</span>
            </a>
          </div>
        )}
      </div>

      {/* Synchronized Control Strip */}
      {showSynchronizedStrip &&
        (isHost ? (
          <div className="z-20 px-2.5 py-1.5 bg-[#0c1419]/95 border-t border-slate-800 flex flex-wrap items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={handleHostTogglePlay}
              aria-label={isPlaying ? "إيقاف مؤقت" : "تشغيل"}
              className="min-h-[34px] min-w-[34px] rounded-lg bg-[#00a884] hover:bg-[#069475] text-white flex items-center justify-center transition-colors cursor-pointer shrink-0"
            >
              {isPlaying ? (
                <Pause className="w-4 h-4 fill-current" />
              ) : (
                <Play className="w-4 h-4 fill-current" />
              )}
            </button>

            <span
              dir="ltr"
              className="text-[11px] font-mono text-slate-300 tabular-nums shrink-0"
            >
              {formatWatchTime(currentTime)}
            </span>

            <input
              type="range"
              min={0}
              max={Math.max(1, Math.floor(duration || currentTime + 10))}
              value={Math.min(
                Math.floor(currentTime),
                Math.max(1, Math.floor(duration || currentTime + 10))
              )}
              onChange={(e) => handleHostScrubPreview(Number(e.target.value))}
              onPointerUp={(e) =>
                handleHostSeekCommit(Number(e.currentTarget.value))
              }
              onTouchEnd={(e) =>
                handleHostSeekCommit(Number(e.currentTarget.value))
              }
              onKeyUp={(e) =>
                handleHostSeekCommit(Number(e.currentTarget.value))
              }
              aria-label="تقديم أو ترجيع الفيديو"
              className="flex-1 min-w-[70px] accent-[#00a884] cursor-pointer"
            />

            <span
              dir="ltr"
              className="text-[11px] font-mono text-slate-400 tabular-nums shrink-0 hidden sm:inline"
            >
              {duration > 0 ? formatWatchTime(duration) : "--:--"}
            </span>

            {!isTikTok && (
              <div
                dir="ltr"
                className="flex items-center gap-1 bg-[#1b272e] rounded-lg p-0.5 shrink-0"
              >
                {SPEED_OPTIONS.map((rate) => (
                  <button
                    key={rate}
                    type="button"
                    onClick={() => handleHostSpeed(rate)}
                    className={`px-1.5 py-1 rounded-md text-[11px] font-bold transition-colors cursor-pointer ${
                      playbackRate === rate
                        ? "bg-[#00a884] text-white"
                        : "text-slate-300 hover:bg-slate-700/60"
                    }`}
                  >
                    {rate}x
                  </button>
                ))}
              </div>
            )}

            <button
              type="button"
              onClick={handleToggleMute}
              aria-label={isMuted ? "تشغيل الصوت" : "كتم الصوت"}
              className="min-h-[34px] min-w-[34px] rounded-lg bg-[#202c33] hover:bg-[#2a3942] text-slate-200 flex items-center justify-center transition-colors cursor-pointer shrink-0"
            >
              {isMuted ? (
                <VolumeX className="w-4 h-4 text-rose-400" />
              ) : (
                <Volume2 className="w-4 h-4" />
              )}
            </button>

            <button
              type="button"
              onClick={() => void handleToggleFullscreen()}
              aria-label={isFullscreen ? "إنهاء ملء الشاشة" : "ملء الشاشة وتدوير"}
              title={isFullscreen ? "إنهاء ملء الشاشة" : "ملء الشاشة وتدوير"}
              className="min-h-[34px] px-2 rounded-lg bg-[#202c33] hover:bg-[#2a3942] text-slate-200 text-[11px] font-semibold flex items-center gap-1 transition-colors cursor-pointer shrink-0"
            >
              {isFullscreen ? (
                <Minimize className="w-4 h-4" />
              ) : (
                <Maximize className="w-4 h-4" />
              )}
              <span className="hidden md:inline">
                {isFullscreen ? "تصغير" : "ملء الشاشة وتدوير"}
              </span>
            </button>
          </div>
        ) : (
          <div className="z-20 px-3 py-1.5 bg-[#0c1419]/95 border-t border-slate-800 flex items-center justify-between gap-2 shrink-0">
            <div className="flex items-center gap-2 text-[11px] text-slate-300 font-medium truncate">
              <span dir="ltr" className="font-mono tabular-nums text-slate-200">
                {formatWatchTime(currentTime)}
              </span>
              {!isTikTok && playbackRate !== 1 && (
                <span dir="ltr" className="text-[#00a884] font-bold">
                  {playbackRate}x
                </span>
              )}
            </div>

            <div className="flex items-center gap-1.5 shrink-0">
              <button
                type="button"
                onClick={handleToggleMute}
                aria-label={isMuted ? "تشغيل الصوت" : "كتم الصوت"}
                className={`min-h-[34px] px-2.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
                  isMuted
                    ? "bg-amber-600 hover:bg-amber-700 text-white"
                    : "bg-[#202c33] hover:bg-[#2a3942] text-slate-200"
                }`}
              >
                {isMuted ? (
                  <>
                    <VolumeX className="w-4 h-4" />
                    <span>تشغيل الصوت</span>
                  </>
                ) : (
                  <>
                    <Volume2 className="w-4 h-4" />
                    <span>الصوت</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={() => void handleToggleFullscreen()}
                aria-label={
                  isFullscreen ? "إنهاء ملء الشاشة" : "ملء الشاشة وتدوير"
                }
                title={isFullscreen ? "إنهاء ملء الشاشة" : "ملء الشاشة وتدوير"}
                className="min-h-[34px] px-2.5 rounded-lg bg-[#202c33] hover:bg-[#2a3942] text-slate-200 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                {isFullscreen ? (
                  <Minimize className="w-4 h-4" />
                ) : (
                  <Maximize className="w-4 h-4" />
                )}
                <span className="hidden sm:inline">
                  {isFullscreen ? "تصغير" : "ملء الشاشة وتدوير"}
                </span>
              </button>
            </div>
          </div>
        ))}
    </div>
  );
}
