import { useCallback, useEffect, useRef, useState } from "react";
import {
  ArrowDownRight,
  ArrowRight,
  Bot,
  Check,
  Clapperboard,
  Columns2,
  GripVertical,
  Languages,
  Loader2,
  Lock,
  Maximize2,
  Mic,
  MicOff,
  MonitorOff,
  MonitorUp,
  Music2,
  PanelBottomClose,
  PanelBottomOpen,
  Pause,
  Phone,
  PictureInPicture2,
  Play,
  Plus,
  Rewind,
  RotateCcw,
  Share2,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  Unlock,
  Video,
  Volume2,
  VolumeX,
  X,
  Youtube,
} from "lucide-react";
import type {
  CallType,
  ChatMessage,
  ChatWallpaperId,
  Conversation,
  DisappearingTimerSeconds,
  MessageReplyRef,
  ScreenShareSignal,
  WatchHistoryItem,
  WatchSessionData,
} from "../types/chat";
import type { ActiveScreenShareSession } from "../services/webrtc";
import { translateTextFast } from "../services/translate";
import { CHAT_WALLPAPERS, TRANSLATION_LANGUAGES } from "../data/defaults";
import { getCountryByCode } from "../data/countries";
import {
  buildTranslationCacheKey,
  formatLastSeen,
  loadSecretChatMap,
  loadTranslationCache,
  loadTranslationPrefs,
  saveTranslationCache,
  saveTranslationPrefs,
  setSecretChatEnabledForChat,
} from "../utils/storage";
import { Avatar } from "./Avatar";
import { ChatSettingsDrawer } from "./ChatSettingsDrawer";
import { VideoSearchModal, WatchTogetherModal } from "./WatchTogetherModal";
import {
  StreamWatchPlayer,
  type WatchPlayerSizeMode,
} from "./StreamWatchPlayer";
import { YouTubeWatchPlayer } from "./YouTubeWatchPlayer";
import { FacebookWatchPlayer } from "./FacebookWatchPlayer";
import { MessageList } from "./MessageList";
import { MessageComposer } from "./MessageComposer";

interface ChatViewProps {
  currentUid: string;
  conversation: Conversation | null;
  peerPublicKey?: string;
  isTyping: boolean;
  isBlockedByMe: boolean;
  blockedUntilMs?: number;
  isBlockedByPeer: boolean;
  wallpaperId: ChatWallpaperId;
  customWallpaper?: string | null;
  activeScreenShare: ActiveScreenShareSession | null;
  screenStream: MediaStream | null;
  remoteShareAudioStream: MediaStream | null;
  isScreenShareMicActive: boolean;
  screenShareError: string | null;
  incomingScreenShareOffer: ScreenShareSignal | null;
  isVideoPaused: boolean;
  videoCurrentTime: number;
  videoDuration: number;
  watchSession: WatchSessionData | null;
  watchMicActive: boolean;
  watchMicConnecting: boolean;
  watchMicLocked: boolean;
  watchRemoteAudioStream: MediaStream | null;
  watchMicError: string | null;
  watchHistory?: WatchHistoryItem[];
  onBackMobile: () => void;
  onTypingChange?: (chatId: string, isTyping: boolean) => void;
  onSendMessage: (payload: {
    text: string;
    imageDataUrl?: string;
    videoDataUrl?: string;
    audioDataUrl?: string;
    audioDuration?: number;
    replyTo?: MessageReplyRef;
    viewOnce?: boolean;
    encrypt?: boolean;
  }) => Promise<void> | void;
  onReactMessage: (
    chatId: string,
    messageId: string,
    emoji: string
  ) => Promise<void>;
  onEditMessage: (
    chatId: string,
    messageId: string,
    nextText: string,
    encrypt?: boolean
  ) => Promise<void>;
  onDeleteMessageForMe: (chatId: string, messageId: string) => Promise<void>;
  onDeleteMessageForEveryone: (
    chatId: string,
    messageId: string
  ) => Promise<void>;
  onTogglePin: (chatId: string) => void;
  onOpenPeerProfile: (peerUid: string) => void;
  onOpenGroupInfo: (chatId: string) => void;
  onCreateGroupWithPeer: (peerUid: string) => void;
  onSetDisappearingTimer: (
    chatId: string,
    seconds: DisappearingTimerSeconds
  ) => Promise<void>;
  onOpenViewOnceImage: (chatId: string, message: ChatMessage) => void;
  onDeleteChatForMe: (chatId: string) => Promise<void>;
  onBlockPeer: (
    peerUid: string,
    durationMs?: number | null
  ) => Promise<void>;
  onUnblockPeer: (peerUid: string) => Promise<void>;
  onStartCall: (chatId: string, chatTitle: string, callType: CallType) => void;
  onStartScreenShare: (chatId: string, peerName: string) => Promise<void>;
  onStartVideoFileWatch: (
    chatId: string,
    peerName: string,
    file: File
  ) => Promise<void>;
  onJoinScreenShare: (offer: ScreenShareSignal) => Promise<void>;
  onStopScreenShare: () => Promise<void>;
  onToggleScreenShareMic: () => Promise<void>;
  onToggleVideoPlayback: () => void;
  onSeekVideo: (seconds: number) => void;
  onClearScreenShareError: () => void;
  onStartYouTubeWatch: (
    chatId: string,
    videoId: string,
    youtubeUrl: string,
    title?: string
  ) => Promise<void>;
  onStartFacebookWatch: (
    chatId: string,
    facebookUrl: string,
    title?: string
  ) => Promise<void>;
  onStartTikTokWatch: (
    chatId: string,
    videoId: string,
    tiktokUrl: string,
    title?: string
  ) => Promise<void>;
  onStartFacebookWatchCountdown: (chatId: string) => Promise<void>;
  onMarkWatchStarted: (chatId: string) => Promise<void>;
  onStartStreamWatch: (
    chatId: string,
    mediaType: "mp4" | "m3u8",
    mediaUrl: string,
    title?: string
  ) => Promise<void>;
  onDeleteWatchHistory?: (chatId: string, historyId: string) => Promise<void>;
  onSyncWatchPlayback: (
    chatId: string,
    playbackState: "playing" | "paused",
    playbackTime: number,
    playbackRate?: number
  ) => Promise<void>;
  onStopWatchTogether: (chatId: string) => Promise<void>;
  onToggleWatchMic: () => Promise<void>;
  onToggleWatchGuestMicAllowed: (
    chatId: string,
    allowed: boolean
  ) => Promise<void>;
  onStopWatchMic: () => void;
  onClearWatchMicError: () => void;
  onSelectWallpaper: (id: ChatWallpaperId) => void;
  onUploadCustomWallpaper?: (dataUrl: string | null) => void;
  onOpenNewChat: () => void;
  onSelectAiChat: () => void;
  onPreviewImage: (src: string) => void;
}

interface WatchFloatingBox {
  x: number;
  y: number;
  width: number;
  height: number;
}

const MIN_WATCH_FLOATING_WIDTH = 190;
const MIN_WATCH_FLOATING_HEIGHT = 160;

function getDefaultWatchFloatingBox(): WatchFloatingBox {
  const vw = typeof window !== "undefined" ? window.innerWidth : 400;
  const width = Math.min(320, Math.max(220, Math.round(vw * 0.82)));
  const height = 228;
  return clampWatchFloatingBox({ x: 12, y: 68, width, height });
}

function clampWatchFloatingBox(box: WatchFloatingBox): WatchFloatingBox {
  if (typeof window === "undefined") return box;
  const vw = window.innerWidth;
  const vh = window.innerHeight;
  const maxWidth = Math.max(MIN_WATCH_FLOATING_WIDTH, vw - 16);
  const maxHeight = Math.max(MIN_WATCH_FLOATING_HEIGHT, vh - 24);
  const width = Math.min(Math.max(MIN_WATCH_FLOATING_WIDTH, box.width), maxWidth);
  const height = Math.min(
    Math.max(MIN_WATCH_FLOATING_HEIGHT, box.height),
    maxHeight
  );
  const maxX = Math.max(8, vw - width - 8);
  const maxY = Math.max(8, vh - height - 8);
  return {
    x: Math.min(Math.max(8, box.x), maxX),
    y: Math.min(Math.max(8, box.y), maxY),
    width,
    height,
  };
}

function formatTimer(seconds: number): string {
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return `${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
}

export function ChatView({
  currentUid,
  conversation,
  peerPublicKey,
  isTyping,
  isBlockedByMe,
  blockedUntilMs,
  isBlockedByPeer,
  wallpaperId,
  customWallpaper,
  activeScreenShare,
  screenStream,
  remoteShareAudioStream,
  isScreenShareMicActive,
  screenShareError,
  incomingScreenShareOffer,
  isVideoPaused,
  videoCurrentTime,
  videoDuration,
  watchSession,
  watchMicActive,
  watchMicConnecting,
  watchMicLocked,
  watchRemoteAudioStream,
  watchMicError,
  watchHistory = [],
  onBackMobile,
  onTypingChange,
  onSendMessage,
  onReactMessage,
  onEditMessage,
  onDeleteMessageForMe,
  onDeleteMessageForEveryone,
  onTogglePin,
  onOpenPeerProfile,
  onOpenGroupInfo,
  onCreateGroupWithPeer,
  onSetDisappearingTimer,
  onOpenViewOnceImage,
  onDeleteChatForMe,
  onBlockPeer,
  onUnblockPeer,
  onStartCall,
  onStartScreenShare,
  onStartVideoFileWatch,
  onJoinScreenShare,
  onStopScreenShare,
  onToggleScreenShareMic,
  onToggleVideoPlayback,
  onSeekVideo,
  onClearScreenShareError,
  onStartYouTubeWatch,
  onStartFacebookWatch,
  onStartTikTokWatch,
  onStartFacebookWatchCountdown,
  onMarkWatchStarted,
  onStartStreamWatch,
  onDeleteWatchHistory,
  onSyncWatchPlayback,
  onStopWatchTogether,
  onToggleWatchMic,
  onToggleWatchGuestMicAllowed,
  onClearWatchMicError,
  onSelectWallpaper,
  onUploadCustomWallpaper,
  onOpenNewChat,
  onSelectAiChat,
  onPreviewImage,
}: ChatViewProps) {
  const [replyingTo, setReplyingTo] = useState<MessageReplyRef | null>(null);
  const [editingMsg, setEditingMsg] = useState<{
    id: string;
    originalText: string;
  } | null>(null);

  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [showQuickTranslate, setShowQuickTranslate] = useState(false);
  const [isWatchModalOpen, setIsWatchModalOpen] = useState(false);
  const [isVideoSearchOpen, setIsVideoSearchOpen] = useState(false);
  const [watchPlayerSizeMode, setWatchPlayerSizeMode] =
    useState<WatchPlayerSizeMode>("split");
  const [floatingBox, setFloatingBox] = useState<WatchFloatingBox>(() =>
    getDefaultWatchFloatingBox()
  );
  const [isManipulatingWatch, setIsManipulatingWatch] = useState(false);
  const [miniPlayerMuted, setMiniPlayerMuted] = useState(false);
  const [watchSeekSignal, setWatchSeekSignal] = useState<{
    nonce: number;
    deltaSeconds: number;
  } | null>(null);
  const [hideChatText, setHideChatText] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);
  const [blockBusy, setBlockBusy] = useState(false);

  const [secretChatMap, setSecretChatMap] = useState<Record<string, boolean>>(() =>
    loadSecretChatMap()
  );

  // Translation state with persistent browser cache
  const [translationPrefs, setTranslationPrefs] = useState(() =>
    loadTranslationPrefs()
  );
  const [translations, setTranslations] = useState<Record<string, string>>(() =>
    loadTranslationCache()
  );
  const [hiddenTranslations, setHiddenTranslations] = useState<
    Record<string, boolean>
  >({});
  const [translatingKeys, setTranslatingKeys] = useState<
    Record<string, boolean>
  >({});

  const inFlightTranslationsRef = useRef<Set<string>>(new Set());
  const translationsRef = useRef<Record<string, string>>(translations);
  translationsRef.current = translations;

  const quickTranslateRef = useRef<HTMLDivElement>(null);
  const screenVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVoiceAudioRef = useRef<HTMLAudioElement>(null);
  const watchRemoteAudioRef = useRef<HTMLAudioElement>(null);
  const watchFloatingSectionRef = useRef<HTMLElement>(null);
  const floatingLiveRef = useRef<WatchFloatingBox>(floatingBox);
  floatingLiveRef.current = floatingBox;
  const watchPointerActionRef = useRef<
    | {
        kind: "drag";
        pointerId: number;
        startX: number;
        startY: number;
        originBox: WatchFloatingBox;
      }
    | {
        kind: "resize";
        pointerId: number;
        startX: number;
        startY: number;
        originBox: WatchFloatingBox;
      }
    | null
  >(null);

  const isChatBlocked = isBlockedByMe || isBlockedByPeer;

  const isSecretChatActive = Boolean(
    conversation &&
      conversation.type === "direct" &&
      secretChatMap[conversation.id] &&
      peerPublicKey
  );
  const secretChatRequested = Boolean(
    conversation && conversation.type === "direct" && secretChatMap[conversation.id]
  );

  const isScreenShareInThisChat = Boolean(
    activeScreenShare &&
      conversation &&
      activeScreenShare.chatId === conversation.id
  );

  const isWatchInThisChat = Boolean(
    watchSession &&
      watchSession.isActive &&
      conversation &&
      watchSession.chatId === conversation.id
  );

  const isWatchHost = Boolean(
    watchSession &&
      (watchSession.hostId || watchSession.startedByUid) === currentUid
  );

  const isSplitStageVisible = isScreenShareInThisChat || isWatchInThisChat;

  useEffect(() => {
    saveTranslationPrefs(translationPrefs);
  }, [translationPrefs]);

  useEffect(() => {
    setIsDrawerOpen(false);
    setShowQuickTranslate(false);
    setIsWatchModalOpen(false);
    setIsVideoSearchOpen(false);
    setWatchPlayerSizeMode("split");
    setMiniPlayerMuted(false);
    setWatchSeekSignal(null);
    setHideChatText(false);
    setActionError(null);
    setReplyingTo(null);
    setEditingMsg(null);
  }, [conversation?.id]);

  useEffect(() => {
    if (!isSplitStageVisible) {
      setHideChatText(false);
    }
    if (!isWatchInThisChat) {
      setWatchPlayerSizeMode("split");
      setMiniPlayerMuted(false);
      setWatchSeekSignal(null);
      setIsManipulatingWatch(false);
      watchPointerActionRef.current = null;
    }
  }, [isSplitStageVisible, isWatchInThisChat]);

  useEffect(() => {
    if (watchPlayerSizeMode !== "mini") return;
    const handleResize = () => {
      setFloatingBox((prev) => clampWatchFloatingBox(prev));
    };
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, [watchPlayerSizeMode]);

  const applyFloatingDomTransform = useCallback((box: WatchFloatingBox) => {
    floatingLiveRef.current = box;
    const el = watchFloatingSectionRef.current;
    if (!el) return;
    el.style.transform = `translate3d(${box.x}px, ${box.y}px, 0)`;
    el.style.width = `${box.width}px`;
    el.style.height = `${box.height}px`;
  }, []);

  const handleWatchDragPointerDown = (
    e: React.PointerEvent<HTMLDivElement>
  ) => {
    if (watchPlayerSizeMode !== "mini") return;
    if ((e.target as HTMLElement).closest("button")) return;
    e.preventDefault();
    e.stopPropagation();
    try {
      e.currentTarget.setPointerCapture(e.pointerId);
    } catch {
      // ignore if unsupported
    }
    watchPointerActionRef.current = {
      kind: "drag",
      pointerId: e.pointerId,
      startX: e.clientX,
      startY: e.clientY,
      originBox: floatingLiveRef.current,
    };
    setIsManipulatingWatch(true);
  };

  const handleWatchResizePointerDown = (
    e: React.PointerEvent<HTMLDivElement>
  ) => {
    if (watchPlayerSizeMode !== "mini") return;
    e.preventDefault();
    e.stopPropagation();
    try {
      e.currentTarget.setPointerCapture(e.pointerId);
    } catch {
      // ignore if unsupported
    }
    watchPointerActionRef.current = {
      kind: "resize",
      pointerId: e.pointerId,
      startX: e.clientX,
      startY: e.clientY,
      originBox: floatingLiveRef.current,
    };
    setIsManipulatingWatch(true);
  };

  const handleWatchPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    const action = watchPointerActionRef.current;
    if (!action || action.pointerId !== e.pointerId) return;
    e.preventDefault();
    const dx = e.clientX - action.startX;
    const dy = e.clientY - action.startY;

    if (action.kind === "drag") {
      const next = clampWatchFloatingBox({
        ...action.originBox,
        x: action.originBox.x + dx,
        y: action.originBox.y + dy,
      });
      applyFloatingDomTransform(next);
    } else {
      const vw = typeof window !== "undefined" ? window.innerWidth : 400;
      const vh = typeof window !== "undefined" ? window.innerHeight : 700;
      const maxAvailableW = Math.max(
        MIN_WATCH_FLOATING_WIDTH,
        vw - action.originBox.x - 8
      );
      const maxAvailableH = Math.max(
        MIN_WATCH_FLOATING_HEIGHT,
        vh - action.originBox.y - 8
      );
      const nextWidth = Math.min(
        Math.max(MIN_WATCH_FLOATING_WIDTH, action.originBox.width + dx),
        maxAvailableW
      );
      const nextHeight = Math.min(
        Math.max(MIN_WATCH_FLOATING_HEIGHT, action.originBox.height + dy),
        maxAvailableH
      );
      applyFloatingDomTransform({
        ...action.originBox,
        width: nextWidth,
        height: nextHeight,
      });
    }
  };

  const handleWatchPointerEnd = (e: React.PointerEvent<HTMLDivElement>) => {
    const action = watchPointerActionRef.current;
    if (!action || action.pointerId !== e.pointerId) return;
    try {
      if (e.currentTarget.hasPointerCapture(e.pointerId)) {
        e.currentTarget.releasePointerCapture(e.pointerId);
      }
    } catch {
      // ignore
    }
    watchPointerActionRef.current = null;
    setIsManipulatingWatch(false);
    setFloatingBox(floatingLiveRef.current);
  };

  const handleResetWatchFloatingBox = () => {
    const defaultBox = getDefaultWatchFloatingBox();
    applyFloatingDomTransform(defaultBox);
    setFloatingBox(defaultBox);
  };

  useEffect(() => {
    if (screenVideoRef.current && screenStream && isScreenShareInThisChat) {
      screenVideoRef.current.srcObject = screenStream;
      void screenVideoRef.current.play().catch(() => {});
    }
  }, [screenStream, isScreenShareInThisChat]);

  useEffect(() => {
    if (
      remoteVoiceAudioRef.current &&
      remoteShareAudioStream &&
      isScreenShareInThisChat
    ) {
      remoteVoiceAudioRef.current.srcObject = remoteShareAudioStream;
      remoteVoiceAudioRef.current.muted = false;
      void remoteVoiceAudioRef.current.play().catch(() => {});
    }
  }, [remoteShareAudioStream, isScreenShareInThisChat]);

  useEffect(() => {
    if (watchRemoteAudioRef.current) {
      watchRemoteAudioRef.current.srcObject = watchRemoteAudioStream || null;
      watchRemoteAudioRef.current.muted = false;
      if (watchRemoteAudioStream) {
        void watchRemoteAudioRef.current.play().catch(() => {});
      }
    }
  }, [watchRemoteAudioStream]);

  useEffect(() => {
    if (!showQuickTranslate) return;
    const handleClickOutside = (e: MouseEvent) => {
      if (
        quickTranslateRef.current &&
        !quickTranslateRef.current.contains(e.target as Node)
      ) {
        setShowQuickTranslate(false);
      }
    };
    const handleKey = (e: globalThis.KeyboardEvent) => {
      if (e.key === "Escape") setShowQuickTranslate(false);
    };
    document.addEventListener("mousedown", handleClickOutside);
    window.addEventListener("keydown", handleKey);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
      window.removeEventListener("keydown", handleKey);
    };
  }, [showQuickTranslate]);

  const requestTranslation = useCallback(
    async (msgId: string, text: string, targetLanguage: string) => {
      const cleanText = text.trim();
      if (!cleanText) return;
      const cacheKey = buildTranslationCacheKey(cleanText, targetLanguage);
      const visibilityKey = `${msgId}:${targetLanguage}`;

      if (translationsRef.current[cacheKey]) {
        setHiddenTranslations((prev) => ({ ...prev, [visibilityKey]: false }));
        return;
      }

      if (inFlightTranslationsRef.current.has(cacheKey)) return;
      inFlightTranslationsRef.current.add(cacheKey);
      setTranslatingKeys((prev) => ({ ...prev, [cacheKey]: true }));

      try {
        const translatedText = await translateTextFast(
          cleanText,
          targetLanguage
        );

        if (translatedText) {
          setTranslations((prev) => {
            const next = {
              ...prev,
              [cacheKey]: translatedText,
            };
            saveTranslationCache(next);
            return next;
          });
          setHiddenTranslations((prev) => ({
            ...prev,
            [visibilityKey]: false,
          }));
        }
      } catch {
        // Silent resilience
      } finally {
        inFlightTranslationsRef.current.delete(cacheKey);
        setTranslatingKeys((prev) => {
          const next = { ...prev };
          delete next[cacheKey];
          return next;
        });
      }
    },
    []
  );

  // Auto-translate incoming unencrypted text messages when enabled
  useEffect(() => {
    if (!translationPrefs.autoTranslate || !conversation) return;
    const incomingTextMsgs = conversation.messages
      .filter(
        (m) =>
          m.senderId !== "me" &&
          !m.isError &&
          !m.isEncrypted &&
          m.messageType !== "call" &&
          m.text.trim().length > 0
      )
      .slice(-25);

    incomingTextMsgs.forEach((m) => {
      const cacheKey = buildTranslationCacheKey(
        m.text,
        translationPrefs.targetLanguage
      );
      if (
        !translationsRef.current[cacheKey] &&
        !inFlightTranslationsRef.current.has(cacheKey)
      ) {
        void requestTranslation(m.id, m.text, translationPrefs.targetLanguage);
      }
    });
  }, [
    translationPrefs.autoTranslate,
    translationPrefs.targetLanguage,
    conversation?.id,
    conversation?.messages,
    requestTranslation,
  ]);

  const handleToggleBlock = useCallback(
    async (durationMs: number | null = null) => {
      if (!conversation?.peerUid || blockBusy) return;
      setBlockBusy(true);
      try {
        if (isBlockedByMe) {
          await onUnblockPeer(conversation.peerUid);
        } else {
          await onBlockPeer(conversation.peerUid, durationMs);
        }
      } catch (err) {
        setActionError(
          err instanceof Error && !err.message.startsWith("{")
            ? err.message
            : "تعذر تحديث حالة الحظر. حاول مجدداً."
        );
      } finally {
        setBlockBusy(false);
      }
    },
    [conversation?.peerUid, blockBusy, isBlockedByMe, onUnblockPeer, onBlockPeer]
  );

  const handleToggleTranslationVisibility = useCallback((visibilityKey: string) => {
    setHiddenTranslations((prev) => ({
      ...prev,
      [visibilityKey]: !prev[visibilityKey],
    }));
  }, []);

  const handleStartEditMessage = useCallback(
    (id: string, originalText: string) => {
      setEditingMsg({ id, originalText });
    },
    []
  );

  const handleCancelReply = useCallback(() => setReplyingTo(null), []);
  const handleCancelEdit = useCallback(() => setEditingMsg(null), []);
  const handleOpenVideoSearch = useCallback(() => setIsVideoSearchOpen(true), []);

  const handleSendFromComposer = useCallback(
    async (payload: {
      text: string;
      imageDataUrl?: string;
      videoDataUrl?: string;
      audioDataUrl?: string;
      audioDuration?: number;
      replyTo?: MessageReplyRef;
      viewOnce?: boolean;
    }) => {
      await onSendMessage({
        ...payload,
        encrypt: isSecretChatActive && Boolean(payload.text.trim()),
      });
    },
    [onSendMessage, isSecretChatActive]
  );

  const handleEditFromComposer = useCallback(
    async (chatId: string, messageId: string, nextText: string) => {
      await onEditMessage(chatId, messageId, nextText, isSecretChatActive);
    },
    [onEditMessage, isSecretChatActive]
  );

  const handleSendQuickAiPrompt = useCallback(
    (promptText: string) => {
      void onSendMessage({ text: promptText });
    },
    [onSendMessage]
  );

  const handleToggleSecretChat = useCallback(() => {
    if (!conversation || conversation.type !== "direct") return;
    if (!peerPublicKey) {
      setActionError(
        "الطرف الآخر لم يفعّل مفتاح التشفير الطرفي بعد. ستعمل المحادثة السرية بمجرد تسجيل دخوله من جهازه."
      );
      return;
    }
    const nextVal = !secretChatMap[conversation.id];
    setSecretChatEnabledForChat(conversation.id, nextVal);
    setSecretChatMap((prev) => ({ ...prev, [conversation.id]: nextVal }));
  }, [conversation, peerPublicKey, secretChatMap]);

  if (!conversation) {
    return (
      <div className="flex-1 h-full flex flex-col bg-[#f8fafc] dark:bg-[#0b141a]">
        <div className="md:hidden px-3 py-2.5 flex items-center">
          <button
            type="button"
            onClick={onBackMobile}
            aria-label="العودة إلى قائمة المحادثات"
            className="min-h-[44px] px-3 rounded-xl flex items-center gap-2 text-slate-700 dark:text-slate-200 hover:bg-slate-200/60 dark:hover:bg-slate-800 transition-colors cursor-pointer text-sm font-semibold"
          >
            <ArrowRight className="w-5 h-5" />
            <span>المحادثات</span>
          </button>
        </div>
        <div className="flex-1 flex flex-col items-center justify-center p-8 text-center">
          <div className="max-w-md space-y-5">
            <div className="w-16 h-16 rounded-2xl bg-emerald-50 dark:bg-emerald-950/60 text-[#0d7a5f] dark:text-[#00a884] flex items-center justify-center mx-auto border border-emerald-200/70 dark:border-emerald-800/50">
              <Bot className="w-8 h-8" />
            </div>
            <div className="space-y-2">
              <h2 className="font-display text-2xl font-bold text-slate-900 dark:text-white">
                مرحباً بك في مرسال
              </h2>
              <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
                ابدأ محادثة مباشرة مع أصدقائك عبر البحث بالاسم، أو تحدّث مع المساعد الذكي.
              </p>
            </div>
            <div className="flex flex-wrap items-center justify-center gap-2.5 pt-2">
              <button
                type="button"
                onClick={onOpenNewChat}
                className="min-h-[44px] px-5 py-2.5 rounded-xl bg-[#0d7a5f] hover:bg-[#0a634d] dark:bg-[#00a884] dark:hover:bg-[#069475] text-white text-sm font-semibold flex items-center gap-2 transition-colors cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>محادثة جديدة</span>
              </button>
              <button
                type="button"
                onClick={onSelectAiChat}
                className="min-h-[44px] px-4 py-2.5 rounded-xl bg-white dark:bg-[#202c33] border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 hover:bg-slate-50 dark:hover:bg-[#2a3942] text-sm font-semibold flex items-center gap-2 transition-colors cursor-pointer"
              >
                <Sparkles className="w-4 h-4 text-[#0d7a5f] dark:text-[#00a884]" />
                <span>المساعد الذكي</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  const peerCountry = getCountryByCode(conversation.peerCountryCode);
  const selectedLangOption =
    TRANSLATION_LANGUAGES.find(
      (l) => l.code === translationPrefs.targetLanguage
    ) || TRANSLATION_LANGUAGES[0];

  const wallpaperClass =
    CHAT_WALLPAPERS.find((w) => w.id === wallpaperId)?.canvasClass ||
    "chat-wallpaper-default";

  const headerStatusText =
    conversation.type === "direct"
      ? isBlockedByMe
        ? "تم حظر هذا المستخدم"
        : conversation.peerShowLastSeen === false
        ? "محادثة خاصة"
        : formatLastSeen(conversation.peerLastSeen, conversation.peerOnline)
      : conversation.subtitle;

  return (
    <div className="flex-1 flex flex-col h-full min-w-0 bg-[#efeae2] dark:bg-[#0b141a]">
      {/* Hidden Remote Watch Party Audio Player (Unmuted, autoPlay + playsInline) */}
      <audio
        ref={watchRemoteAudioRef}
        autoPlay
        playsInline
        className="hidden"
      />

      {/* Sticky Chat Header */}
      <header className="min-h-[64px] px-3 sm:px-5 py-2.5 bg-white dark:bg-[#202c33] border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2 sm:gap-3 shrink-0 z-10">
        <div className="flex items-center gap-2 sm:gap-3 min-w-0">
          <button
            type="button"
            onClick={onBackMobile}
            aria-label="العودة إلى قائمة المحادثات"
            className="md:hidden min-h-[44px] min-w-[44px] -mr-1 rounded-xl flex items-center justify-center text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700/50 transition-colors cursor-pointer"
          >
            <ArrowRight className="w-5 h-5" />
          </button>

          <button
            type="button"
            onClick={() => {
              if (conversation.type === "direct" && conversation.peerUid) {
                onOpenPeerProfile(conversation.peerUid);
              } else if (conversation.type === "group") {
                onOpenGroupInfo(conversation.id);
              }
            }}
            className={`flex items-center gap-2.5 min-w-0 text-start rounded-xl p-1 -m-1 ${
              conversation.type !== "ai"
                ? "hover:bg-slate-100 dark:hover:bg-slate-700/40 cursor-pointer"
                : "cursor-default"
            }`}
          >
            <div className="relative shrink-0">
              <Avatar
                src={conversation.avatar}
                name={conversation.title}
                size="md"
                isAi={conversation.type === "ai"}
              />
              {conversation.type === "direct" &&
                conversation.peerOnline &&
                !isChatBlocked && (
                  <span
                    title="متصل الآن"
                    className="absolute bottom-0 left-0 w-3 h-3 rounded-full bg-emerald-500 ring-2 ring-white dark:ring-[#202c33]"
                  />
                )}
            </div>

            <div className="min-w-0">
              <h2 className="font-display font-bold text-sm sm:text-base text-slate-900 dark:text-white truncate flex items-center gap-1.5">
                {conversation.type === "direct" && peerCountry?.flag && (
                  <span
                    title={peerCountry.nameAr}
                    className="shrink-0 text-base leading-none"
                  >
                    {peerCountry.flag}
                  </span>
                )}
                <span className="truncate">{conversation.title}</span>
                {isSecretChatActive && (
                  <span
                    title="محادثة سرية مشفرة E2EE"
                    className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded-md bg-emerald-50 dark:bg-emerald-950/60 text-[#0d7a5f] dark:text-[#00a884] text-[10px] font-bold shrink-0"
                  >
                    <Lock className="w-3 h-3" />
                    <span className="hidden sm:inline">سرية</span>
                  </span>
                )}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                {isTyping ? (
                  <span className="inline-flex items-center gap-1 text-[#0d7a5f] dark:text-[#00a884] font-bold animate-pulse">
                    يكتب الآن...
                  </span>
                ) : isBlockedByMe ? (
                  <span className="text-rose-600 dark:text-rose-400 font-semibold">
                    تم حظر هذا المستخدم
                  </span>
                ) : conversation.type === "direct" &&
                  conversation.peerOnline &&
                  !isBlockedByPeer ? (
                  <span className="text-[#0d7a5f] dark:text-[#00a884] font-semibold">
                    متصل الآن
                  </span>
                ) : (
                  headerStatusText
                )}
              </p>
            </div>
          </button>
        </div>

        {/* Header Actions: Secret Chat Lock + Audio/Video Call + Quick Translation + Settings */}
        <div className="flex items-center gap-1 sm:gap-2 shrink-0">
          {conversation.type === "direct" && (
            <>
              <button
                type="button"
                onClick={handleToggleSecretChat}
                aria-label="محادثة سرية مشفرة (E2EE)"
                title={
                  isSecretChatActive
                    ? "المحادثة السرية المشفرة مفعّلة (اضغط للإيقاف)"
                    : peerPublicKey
                    ? "تفعيل المحادثة السرية المشفرة (E2EE)"
                    : "بانتظار مفتاح تشفير الطرف الآخر"
                }
                className={`min-h-[42px] min-w-[42px] rounded-xl flex items-center justify-center transition-colors cursor-pointer ${
                  isSecretChatActive
                    ? "bg-emerald-100 text-[#0d7a5f] dark:bg-emerald-950/80 dark:text-[#00a884] border border-emerald-300/70 dark:border-emerald-800/70"
                    : "bg-slate-100 hover:bg-emerald-50 hover:text-[#0d7a5f] dark:bg-[#2a3942] dark:hover:bg-emerald-950/60 dark:hover:text-[#00a884] text-slate-600 dark:text-slate-300"
                }`}
              >
                {isSecretChatActive ? (
                  <Lock className="w-[18px] h-[18px]" />
                ) : (
                  <Unlock className="w-[18px] h-[18px]" />
                )}
              </button>

              <button
                type="button"
                disabled={isChatBlocked}
                onClick={() =>
                  onStartCall(conversation.id, conversation.title, "audio")
                }
                aria-label="مكالمة صوتية"
                title={
                  isChatBlocked
                    ? "المكالمات متوقفة بسبب الحظر"
                    : "بدء مكالمة صوتية"
                }
                className="min-h-[42px] min-w-[42px] rounded-xl bg-slate-100 hover:bg-emerald-50 hover:text-[#0d7a5f] dark:bg-[#2a3942] dark:hover:bg-emerald-950/60 dark:hover:text-[#00a884] text-slate-700 dark:text-slate-200 disabled:opacity-40 disabled:pointer-events-none flex items-center justify-center transition-colors cursor-pointer"
              >
                <Phone className="w-[18px] h-[18px]" />
              </button>

              <button
                type="button"
                disabled={isChatBlocked}
                onClick={() =>
                  onStartCall(conversation.id, conversation.title, "video")
                }
                aria-label="مكالمة فيديو"
                title={
                  isChatBlocked
                    ? "المكالمات متوقفة بسبب الحظر"
                    : "بدء مكالمة فيديو"
                }
                className="min-h-[42px] min-w-[42px] rounded-xl bg-slate-100 hover:bg-emerald-50 hover:text-[#0d7a5f] dark:bg-[#2a3942] dark:hover:bg-emerald-950/60 dark:hover:text-[#00a884] text-slate-700 dark:text-slate-200 disabled:opacity-40 disabled:pointer-events-none flex items-center justify-center transition-colors cursor-pointer"
              >
                <Video className="w-[18px] h-[18px]" />
              </button>
            </>
          )}

          <div ref={quickTranslateRef} className="relative">
            <button
              type="button"
              onClick={() => setShowQuickTranslate((v) => !v)}
              aria-label="الترجمة الفورية السريعة"
              title="الترجمة الفورية"
              className={`relative min-h-[42px] min-w-[42px] px-2.5 rounded-xl flex items-center justify-center transition-colors cursor-pointer ${
                translationPrefs.autoTranslate || showQuickTranslate
                  ? "bg-emerald-50 text-[#0d7a5f] border border-emerald-200/80 dark:bg-emerald-950/60 dark:text-[#00a884] dark:border-emerald-800/60"
                  : "bg-slate-100 hover:bg-slate-200/80 dark:bg-[#2a3942] dark:hover:bg-[#354650] text-slate-700 dark:text-slate-200"
              }`}
            >
              <Languages className="w-[18px] h-[18px]" />
              {translationPrefs.autoTranslate && (
                <span className="absolute top-1.5 left-1.5 w-2 h-2 rounded-full bg-emerald-500 ring-2 ring-white dark:ring-[#202c33]" />
              )}
            </button>

            {showQuickTranslate && (
              <div className="absolute left-0 top-full mt-2 w-64 bg-white dark:bg-[#202c33] border border-slate-200 dark:border-slate-700 rounded-2xl shadow-xl p-3 space-y-3 z-30">
                <div className="flex items-center justify-between gap-2 pb-2 border-b border-slate-100 dark:border-slate-700/70">
                  <div className="min-w-0">
                    <p className="text-xs font-bold text-slate-900 dark:text-white">
                      الترجمة الفورية
                    </p>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                      اللغة: {selectedLangOption.labelAr}
                    </p>
                  </div>
                  <button
                    type="button"
                    role="switch"
                    aria-checked={translationPrefs.autoTranslate}
                    onClick={() =>
                      setTranslationPrefs({
                        ...translationPrefs,
                        autoTranslate: !translationPrefs.autoTranslate,
                      })
                    }
                    className={`w-10 h-6 rounded-full p-0.5 transition-colors flex items-center cursor-pointer shrink-0 ${
                      translationPrefs.autoTranslate
                        ? "bg-[#0d7a5f] dark:bg-[#00a884] justify-start"
                        : "bg-slate-300 dark:bg-slate-600 justify-end"
                    }`}
                  >
                    <span className="w-5 h-5 rounded-full bg-white shadow-xs" />
                  </button>
                </div>

                <div className="space-y-1 max-h-56 overflow-y-auto custom-scrollbar">
                  <p className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 px-1 pb-0.5">
                    اختر لغة الترجمة
                  </p>
                  {TRANSLATION_LANGUAGES.map((lang) => {
                    const active = lang.code === translationPrefs.targetLanguage;
                    return (
                      <button
                        key={lang.code}
                        type="button"
                        onClick={() => {
                          setTranslationPrefs({
                            ...translationPrefs,
                            targetLanguage: lang.code,
                          });
                          setShowQuickTranslate(false);
                        }}
                        className={`w-full min-h-[38px] px-2.5 py-1.5 rounded-xl text-xs font-semibold flex items-center justify-between transition-colors cursor-pointer ${
                          active
                            ? "bg-emerald-50 dark:bg-emerald-950/60 text-[#0d7a5f] dark:text-[#00a884]"
                            : "text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-[#2a3942]"
                        }`}
                      >
                        <span>{lang.labelAr}</span>
                        {active && <Check className="w-4 h-4 shrink-0" />}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </div>

          <button
            type="button"
            onClick={() => setIsDrawerOpen(true)}
            aria-label="إعدادات المحادثة"
            title="إعدادات المحادثة"
            className="min-h-[42px] min-w-[42px] px-2.5 sm:px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200/80 dark:bg-[#2a3942] dark:hover:bg-[#354650] text-slate-800 dark:text-slate-100 text-xs sm:text-sm font-bold flex items-center justify-center gap-2 shrink-0 transition-colors cursor-pointer"
          >
            <SlidersHorizontal className="w-4 h-4 text-[#0d7a5f] dark:text-[#00a884]" />
            <span className="hidden sm:inline">إعدادات</span>
          </button>
        </div>
      </header>

      {/* Active Secret Chat Info Banner */}
      {conversation.type === "direct" && secretChatRequested && (
        <div
          className={`px-4 py-1.5 border-b text-[11px] font-semibold flex items-center justify-between gap-2 shrink-0 ${
            isSecretChatActive
              ? "bg-emerald-50/95 dark:bg-emerald-950/40 border-emerald-200/80 dark:border-emerald-800/60 text-[#0d7a5f] dark:text-[#00a884]"
              : "bg-amber-50/95 dark:bg-amber-950/40 border-amber-200/80 dark:border-amber-800/60 text-amber-700 dark:text-amber-300"
          }`}
        >
          <span className="flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 shrink-0" />
            {isSecretChatActive
              ? "وضع المحادثة السرية (E2EE) مفعّل — رسائلك النصية الجديدة تُشفّر محلياً بمفاتيح الجهاز."
              : "بانتظار توفر مفتاح التشفير لدى الطرف الآخر لتفعيل التشفير الطرفي الكامل."}
          </span>
        </div>
      )}

      {/* Action / Screen Share / Watch Mic Error Banner */}
      {(actionError || screenShareError || watchMicError) && (
        <div className="px-4 py-2 bg-rose-50 dark:bg-rose-950/60 border-b border-rose-200 dark:border-rose-800/60 flex items-center justify-between gap-2 text-xs text-rose-700 dark:text-rose-200 shrink-0">
          <span>{actionError || screenShareError || watchMicError}</span>
          <button
            type="button"
            onClick={() => {
              setActionError(null);
              if (screenShareError) onClearScreenShareError();
              if (watchMicError) onClearWatchMicError();
            }}
            aria-label="إغلاق التنبيه"
            className="p-1 rounded-lg hover:bg-rose-100 dark:hover:bg-rose-900/50 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Optional Incoming Screen Share Prompt */}
      {incomingScreenShareOffer &&
        !isScreenShareInThisChat &&
        !isChatBlocked && (
          <div className="px-4 py-2.5 bg-emerald-50 dark:bg-emerald-950/40 border-b border-emerald-200 dark:border-emerald-800/60 flex items-center justify-between gap-3 shrink-0">
            <div className="flex items-center gap-2 text-xs sm:text-sm font-semibold text-emerald-900 dark:text-emerald-100 min-w-0">
              {incomingScreenShareOffer.shareMode === "video" ? (
                <Clapperboard className="w-4 h-4 text-[#0d7a5f] dark:text-[#00a884] shrink-0" />
              ) : (
                <MonitorUp className="w-4 h-4 text-[#0d7a5f] dark:text-[#00a884] shrink-0" />
              )}
              <span className="truncate">
                {incomingScreenShareOffer.shareMode === "video"
                  ? `${incomingScreenShareOffer.sharerName} بدأ بث فيديو للمشاهدة معاً الآن`
                  : `${incomingScreenShareOffer.sharerName} بدأ بث شاشته معك الآن`}
              </span>
            </div>
            <button
              type="button"
              onClick={() => void onJoinScreenShare(incomingScreenShareOffer)}
              className="min-h-[36px] px-3.5 py-1.5 rounded-xl bg-[#0d7a5f] hover:bg-[#0a634d] dark:bg-[#00a884] dark:hover:bg-[#069475] text-white text-xs font-bold shrink-0 cursor-pointer"
            >
              {incomingScreenShareOffer.shareMode === "video"
                ? "مشاهدة الفيديو"
                : "مشاهدة البث"}
            </button>
          </div>
        )}

      {/* Split-Screen Screen/Video File Share Stage */}
      {isScreenShareInThisChat && activeScreenShare && (
        <section
          aria-label={
            activeScreenShare.shareMode === "video"
              ? "بث الفيديو المباشر"
              : "بث الشاشة المباشر"
          }
          className={`bg-[#091015] border-b border-slate-800 flex flex-col shrink-0 ${
            hideChatText
              ? "flex-1 min-h-0"
              : "h-[44vh] sm:h-[46vh] min-h-[240px] max-h-[460px]"
          }`}
        >
          <div className="flex-1 min-h-0 relative bg-black flex items-center justify-center overflow-hidden">
            {screenStream ? (
              <video
                ref={screenVideoRef}
                autoPlay
                playsInline
                muted={activeScreenShare.role === "sharer"}
                className="w-full h-full object-contain bg-black"
              />
            ) : (
              <div className="flex flex-col items-center gap-2 text-slate-300 text-xs sm:text-sm">
                <Loader2 className="w-6 h-6 animate-spin text-[#00a884]" />
                <span>
                  {activeScreenShare.shareMode === "video"
                    ? "جاري تهيئة بث الفيديو..."
                    : "جاري تهيئة بث الشاشة..."}
                </span>
              </div>
            )}

            <audio
              ref={remoteVoiceAudioRef}
              autoPlay
              playsInline
              className="hidden"
            />

            <div className="absolute top-3 right-3 px-2.5 py-1 rounded-lg bg-black/70 text-white text-[11px] font-semibold flex items-center gap-1.5 backdrop-blur-xs">
              <span className="w-2 h-2 rounded-full bg-emerald-400" />
              <span>
                {activeScreenShare.role === "sharer"
                  ? activeScreenShare.status === "connected"
                    ? activeScreenShare.shareMode === "video"
                      ? `تبث الفيديو مع ${activeScreenShare.peerName}`
                      : `تشاهد شاشتك مع ${activeScreenShare.peerName}`
                    : "بانتظار اتصال صديقك..."
                  : activeScreenShare.shareMode === "video"
                  ? `بث فيديو من ${activeScreenShare.peerName}`
                  : `بث شاشة ${activeScreenShare.peerName}`}
              </span>
            </div>
          </div>

          {activeScreenShare.shareMode === "video" &&
            activeScreenShare.role === "sharer" && (
              <div className="px-3 py-1.5 bg-[#0c1419] border-t border-slate-800/90 flex items-center gap-2.5 shrink-0">
                <button
                  type="button"
                  onClick={onToggleVideoPlayback}
                  aria-label={isVideoPaused ? "تشغيل الفيديو" : "إيقاف مؤقت"}
                  className="min-h-[34px] min-w-[34px] rounded-lg bg-[#202c33] hover:bg-[#2a3942] text-white flex items-center justify-center transition-colors cursor-pointer shrink-0"
                >
                  {isVideoPaused ? (
                    <Play className="w-4 h-4 fill-current" />
                  ) : (
                    <Pause className="w-4 h-4 fill-current" />
                  )}
                </button>
                <span
                  dir="ltr"
                  className="text-[11px] font-mono text-slate-300 tabular-nums shrink-0"
                >
                  {formatTimer(Math.floor(videoCurrentTime))}
                </span>
                <input
                  type="range"
                  min={0}
                  max={Math.max(1, Math.floor(videoDuration))}
                  value={Math.min(
                    Math.floor(videoCurrentTime),
                    Math.max(1, Math.floor(videoDuration))
                  )}
                  onChange={(e) => onSeekVideo(Number(e.target.value))}
                  aria-label="تقديم أو ترجيع الفيديو"
                  className="flex-1 accent-[#00a884] cursor-pointer"
                />
                <span
                  dir="ltr"
                  className="text-[11px] font-mono text-slate-400 tabular-nums shrink-0"
                >
                  {formatTimer(Math.floor(videoDuration))}
                </span>
              </div>
            )}

          <div className="px-3 py-2 bg-[#111b21] border-t border-slate-800 flex flex-wrap items-center justify-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => void onToggleScreenShareMic()}
              className={`min-h-[40px] px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer ${
                isScreenShareMicActive
                  ? "bg-[#00a884] text-white"
                  : "bg-[#202c33] hover:bg-[#2a3942] text-slate-200 border border-slate-700"
              }`}
            >
              {isScreenShareMicActive ? (
                <Mic className="w-4 h-4" />
              ) : (
                <MicOff className="w-4 h-4 text-slate-400" />
              )}
              <span>
                {isScreenShareMicActive ? "كتم المايك" : "فتح المايك"}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setHideChatText((v) => !v)}
              className="min-h-[40px] px-3.5 py-1.5 rounded-xl bg-[#202c33] hover:bg-[#2a3942] text-slate-200 border border-slate-700 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              {hideChatText ? (
                <PanelBottomOpen className="w-4 h-4 text-[#00a884]" />
              ) : (
                <PanelBottomClose className="w-4 h-4 text-slate-300" />
              )}
              <span>{hideChatText ? "إظهار الكتابة" : "إخفاء الكتابة"}</span>
            </button>

            <button
              type="button"
              onClick={() => void onStopScreenShare()}
              className="min-h-[40px] px-3.5 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <MonitorOff className="w-4 h-4" />
              <span>إيقاف البث</span>
            </button>
          </div>
        </section>
      )}

      {/* 3-Mode Watch Together Stage (Split 50% / Smooth Pointer-Draggable & Corner-Resizable Floating Player / Full-Screen 100%) */}
      {!isScreenShareInThisChat && isWatchInThisChat && watchSession && (
        <section
          ref={watchFloatingSectionRef}
          aria-label="المشاهدة معاً"
          style={
            watchPlayerSizeMode === "mini"
              ? {
                  width: `${floatingBox.width}px`,
                  height: `${floatingBox.height}px`,
                  transform: `translate3d(${floatingBox.x}px, ${floatingBox.y}px, 0)`,
                }
              : undefined
          }
          className={
            watchPlayerSizeMode === "fullscreen"
              ? "fixed inset-0 z-50 bg-black flex flex-col"
              : watchPlayerSizeMode === "mini"
              ? "fixed top-0 left-0 z-40 rounded-2xl overflow-hidden shadow-2xl border border-slate-700/90 bg-[#091015] flex flex-col will-change-transform touch-none"
              : `bg-[#091015] border-b border-slate-800 flex flex-col shrink-0 ${
                  hideChatText
                    ? "flex-1 min-h-0"
                    : "h-[45dvh] sm:h-[46vh] min-h-[210px] max-h-[50dvh]"
                }`
          }
        >
          {/* Smooth Pointer-Draggable Header Bar */}
          <div
            onPointerDown={handleWatchDragPointerDown}
            onPointerMove={handleWatchPointerMove}
            onPointerUp={handleWatchPointerEnd}
            onPointerCancel={handleWatchPointerEnd}
            className={`bg-[#111b21] border-b border-slate-800/90 px-2.5 py-1.5 flex items-center justify-between gap-2 shrink-0 select-none ${
              watchPlayerSizeMode === "mini"
                ? isManipulatingWatch
                  ? "cursor-grabbing touch-none"
                  : "cursor-grab touch-none"
                : ""
            }`}
          >
            <div className="flex items-center gap-1.5 min-w-0">
              {watchPlayerSizeMode === "mini" ? (
                <GripVertical className="w-4 h-4 text-[#00a884] shrink-0" />
              ) : (
                <>
                  {watchSession.mediaType === "mp4" ||
                  watchSession.mediaType === "m3u8" ? (
                    <Clapperboard className="w-4 h-4 text-[#00a884] shrink-0" />
                  ) : watchSession.mediaType === "facebook" ? (
                    <Share2 className="w-4 h-4 text-sky-400 shrink-0" />
                  ) : watchSession.mediaType === "tiktok" ? (
                    <Music2 className="w-4 h-4 text-pink-400 shrink-0" />
                  ) : (
                    <Youtube className="w-4 h-4 text-rose-500 shrink-0" />
                  )}
                  <span className="text-[11px] font-bold text-slate-200 truncate">
                    {`مشاهدة معاً — ${watchSession.startedByName}`}
                  </span>
                </>
              )}
            </div>

            <div className="flex items-center gap-1 shrink-0">
              {watchPlayerSizeMode !== "mini" && (
                <button
                  type="button"
                  onClick={() => {
                    setWatchPlayerSizeMode("mini");
                    setHideChatText(false);
                    setFloatingBox((prev) => clampWatchFloatingBox(prev));
                  }}
                  title="تحويل إلى نافذة عائمة قابلة للسحب"
                  className="px-2 py-1 rounded-lg bg-[#1b272e] hover:bg-slate-700/70 border border-slate-700/80 text-[10px] font-bold text-slate-200 flex items-center gap-1 cursor-pointer"
                >
                  <PictureInPicture2 className="w-3 h-3 text-[#00a884]" />
                  <span>عائم متحرك</span>
                </button>
              )}

              <button
                type="button"
                onClick={() => void onStopWatchTogether(conversation.id)}
                aria-label="إغلاق المشاهدة"
                className="w-6 h-6 rounded-lg bg-rose-600/90 hover:bg-rose-600 text-white flex items-center justify-center cursor-pointer shrink-0"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          <div
            className={`flex-1 min-h-0 bg-black relative ${
              isManipulatingWatch ? "pointer-events-none select-none" : ""
            }`}
          >
            {watchSession.mediaType === "mp4" ||
            watchSession.mediaType === "m3u8" ||
            watchSession.mediaType === "tiktok" ? (
              <StreamWatchPlayer
                session={watchSession}
                isHost={isWatchHost}
                hostName={watchSession.startedByName}
                sizeMode={watchPlayerSizeMode}
                externalMuted={
                  watchPlayerSizeMode === "mini" ? miniPlayerMuted : undefined
                }
                seekSignal={watchSeekSignal}
                onChangeSizeMode={(nextMode) => {
                  setWatchPlayerSizeMode(nextMode);
                  if (nextMode !== "split") setHideChatText(false);
                }}
                onPlaybackSync={(playbackState, playbackTime, playbackRate) =>
                  void onSyncWatchPlayback(
                    conversation.id,
                    playbackState,
                    playbackTime,
                    playbackRate
                  )
                }
              />
            ) : watchSession.mediaType === "facebook" ? (
              <FacebookWatchPlayer
                session={watchSession}
                isHost={isWatchHost}
                hostName={watchSession.startedByName}
                onStartCountdown={() =>
                  onStartFacebookWatchCountdown(conversation.id)
                }
                onMarkStarted={() => onMarkWatchStarted(conversation.id)}
              />
            ) : (
              <YouTubeWatchPlayer
                session={watchSession}
                isHost={isWatchHost}
                hostName={watchSession.startedByName}
                externalMuted={
                  watchPlayerSizeMode === "mini" ? miniPlayerMuted : undefined
                }
                isMiniMode={watchPlayerSizeMode === "mini"}
                seekSignal={watchSeekSignal}
                onPlaybackSync={(playbackState, playbackTime, playbackRate) =>
                  void onSyncWatchPlayback(
                    conversation.id,
                    playbackState,
                    playbackTime,
                    playbackRate
                  )
                }
              />
            )}
          </div>

          {watchPlayerSizeMode === "mini" ? (
            <div className="bg-[#111b21] border-t border-slate-800 px-2 py-1.5 pr-8 flex items-center justify-between gap-1 shrink-0">
              <div className="flex items-center gap-1 min-w-0">
                <button
                  type="button"
                  onClick={() => setMiniPlayerMuted((v) => !v)}
                  aria-label={miniPlayerMuted ? "تشغيل الصوت" : "كتم الصوت"}
                  title={miniPlayerMuted ? "تشغيل الصوت" : "كتم الصوت"}
                  className={`min-h-[28px] px-2 rounded-lg text-[11px] font-bold flex items-center gap-1 transition-colors cursor-pointer shrink-0 ${
                    miniPlayerMuted
                      ? "bg-amber-600 hover:bg-amber-700 text-white"
                      : "bg-[#202c33] hover:bg-[#2a3942] text-slate-200 border border-slate-700"
                  }`}
                >
                  {miniPlayerMuted ? (
                    <VolumeX className="w-3.5 h-3.5" />
                  ) : (
                    <Volume2 className="w-3.5 h-3.5" />
                  )}
                </button>

                {watchSession.mediaType !== "facebook" && (
                  <button
                    type="button"
                    onClick={() =>
                      setWatchSeekSignal({
                        nonce: Date.now(),
                        deltaSeconds: -10,
                      })
                    }
                    aria-label="ترجيع 10 ثوانٍ"
                    title="ترجيع 10 ثوانٍ"
                    className="min-h-[28px] px-2 rounded-lg bg-[#202c33] hover:bg-[#2a3942] text-slate-200 border border-slate-700 text-[10px] font-bold flex items-center gap-1 transition-colors cursor-pointer shrink-0"
                  >
                    <Rewind className="w-3 h-3" />
                    <span dir="ltr">10s</span>
                  </button>
                )}
              </div>

              <div className="flex items-center gap-1 shrink-0">
                <button
                  type="button"
                  onClick={handleResetWatchFloatingBox}
                  aria-label="إعادة ضبط الحجم والموقع"
                  title="إعادة ضبط الحجم والموقع"
                  className="min-h-[28px] px-2 rounded-lg bg-[#202c33] hover:bg-[#2a3942] text-slate-200 border border-slate-700 text-[11px] font-bold flex items-center justify-center transition-colors cursor-pointer shrink-0"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setWatchPlayerSizeMode("fullscreen");
                    setHideChatText(false);
                  }}
                  aria-label="ملء الشاشة"
                  title="ملء الشاشة"
                  className="min-h-[28px] px-2 rounded-lg bg-[#202c33] hover:bg-[#2a3942] text-slate-200 border border-slate-700 text-[11px] font-bold flex items-center gap-1 transition-colors cursor-pointer shrink-0"
                >
                  <Maximize2 className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">ملء الشاشة</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="bg-[#111b21] border-t border-slate-800 px-3 py-2 flex flex-wrap items-center justify-between gap-1.5 shrink-0">
              <div className="flex items-center gap-2 text-xs text-slate-200 font-semibold truncate">
                {watchSession.mediaType === "mp4" ||
                watchSession.mediaType === "m3u8" ? (
                  <Clapperboard className="w-4 h-4 text-[#00a884] shrink-0" />
                ) : watchSession.mediaType === "facebook" ? (
                  <Share2 className="w-4 h-4 text-sky-400 shrink-0" />
                ) : watchSession.mediaType === "tiktok" ? (
                  <Music2 className="w-4 h-4 text-pink-400 shrink-0" />
                ) : (
                  <Youtube className="w-4 h-4 text-rose-500 shrink-0" />
                )}
                <span className="truncate">
                  مشاهدة معاً — {watchSession.startedByName}
                </span>
              </div>

              <div className="flex flex-wrap items-center gap-1.5 shrink-0">
                <div className="flex items-center gap-1 bg-[#1b272e] border border-slate-700/80 rounded-xl p-0.5 shrink-0">
                  <button
                    type="button"
                    onClick={() => {
                      setWatchPlayerSizeMode("split");
                      setHideChatText(false);
                    }}
                    title="نصف الشاشة (50%)"
                    aria-label="نصف الشاشة 50%"
                    className={`min-h-[30px] px-2 rounded-lg text-[11px] font-bold flex items-center gap-1 transition-colors cursor-pointer ${
                      watchPlayerSizeMode === "split"
                        ? "bg-[#00a884] text-white"
                        : "text-slate-300 hover:bg-slate-700/60"
                    }`}
                  >
                    <Columns2 className="w-3.5 h-3.5 shrink-0" />
                    <span className="hidden sm:inline">50%</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setWatchPlayerSizeMode("mini");
                      setHideChatText(false);
                    }}
                    title="نافذة عائمة مصغرة"
                    aria-label="نافذة عائمة مصغرة"
                    className="min-h-[30px] px-2 rounded-lg text-[11px] font-bold flex items-center gap-1 transition-colors cursor-pointer text-slate-300 hover:bg-slate-700/60"
                  >
                    <PictureInPicture2 className="w-3.5 h-3.5 shrink-0" />
                    <span className="hidden sm:inline">عائم</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setWatchPlayerSizeMode("fullscreen");
                      setHideChatText(false);
                    }}
                    title="ملء الشاشة (100%)"
                    aria-label="ملء الشاشة 100%"
                    className={`min-h-[30px] px-2 rounded-lg text-[11px] font-bold flex items-center gap-1 transition-colors cursor-pointer ${
                      watchPlayerSizeMode === "fullscreen"
                        ? "bg-[#00a884] text-white"
                        : "text-slate-300 hover:bg-slate-700/60"
                    }`}
                  >
                    <Maximize2 className="w-3.5 h-3.5 shrink-0" />
                    <span className="hidden sm:inline">100%</span>
                  </button>
                </div>

                {conversation.type === "direct" && (
                  <>
                    <button
                      type="button"
                      disabled={watchMicConnecting || watchMicLocked}
                      onClick={() => void onToggleWatchMic()}
                      className={`min-h-[34px] px-2.5 py-1 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-50 ${
                        watchMicActive
                          ? "bg-[#00a884] text-white"
                          : "bg-[#202c33] hover:bg-[#2a3942] text-slate-200 border border-slate-700"
                      }`}
                    >
                      {watchMicConnecting ? (
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      ) : watchMicActive ? (
                        <Mic className="w-3.5 h-3.5" />
                      ) : (
                        <MicOff className="w-3.5 h-3.5 text-slate-400" />
                      )}
                      <span>
                        {watchMicLocked
                          ? "المايك مقفل"
                          : watchMicActive
                          ? "المايك مفتوح"
                          : "فتح المايك"}
                      </span>
                    </button>

                    {isWatchHost && (
                      <button
                        type="button"
                        onClick={() =>
                          void onToggleWatchGuestMicAllowed(
                            conversation.id,
                            watchSession.guestMicAllowed === false
                          )
                        }
                        title="التحكم بمايك الضيف"
                        className="min-h-[34px] px-2.5 py-1 rounded-xl bg-[#202c33] hover:bg-[#2a3942] text-slate-200 border border-slate-700 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                      >
                        {watchSession.guestMicAllowed === false ? (
                          <>
                            <Lock className="w-3.5 h-3.5 text-amber-400" />
                            <span className="hidden sm:inline">السماح للضيف</span>
                          </>
                        ) : (
                          <>
                            <Unlock className="w-3.5 h-3.5 text-[#00a884]" />
                            <span className="hidden sm:inline">قفل مايك الضيف</span>
                          </>
                        )}
                      </button>
                    )}
                  </>
                )}

                {watchPlayerSizeMode === "split" && (
                  <button
                    type="button"
                    onClick={() => setHideChatText((v) => !v)}
                    className="min-h-[34px] px-2.5 py-1 rounded-xl bg-[#202c33] hover:bg-[#2a3942] text-slate-200 border border-slate-700 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    {hideChatText ? (
                      <PanelBottomOpen className="w-4 h-4 text-[#00a884]" />
                    ) : (
                      <PanelBottomClose className="w-4 h-4 text-slate-300" />
                    )}
                    <span className="hidden sm:inline">
                      {hideChatText ? "إظهار الكتابة" : "إخفاء الكتابة"}
                    </span>
                  </button>
                )}

                <button
                  type="button"
                  onClick={() => void onStopWatchTogether(conversation.id)}
                  aria-label="إيقاف المشاهدة"
                  className="min-h-[34px] px-2.5 py-1 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold flex items-center gap-1 transition-colors cursor-pointer"
                >
                  <X className="w-4 h-4" />
                  <span>إيقاف</span>
                </button>
              </div>
            </div>
          )}

          {watchPlayerSizeMode === "mini" && (
            <div
              role="slider"
              aria-label="تغيير حجم نافذة الفيديو"
              aria-valuemin={MIN_WATCH_FLOATING_WIDTH}
              aria-valuemax={520}
              aria-valuenow={Math.round(floatingBox.width)}
              title="اسحب لتغيير الحجم"
              onPointerDown={handleWatchResizePointerDown}
              onPointerMove={handleWatchPointerMove}
              onPointerUp={handleWatchPointerEnd}
              onPointerCancel={handleWatchPointerEnd}
              className="absolute bottom-0 right-0 z-30 w-7 h-7 flex items-end justify-end p-1 text-slate-300 hover:text-[#00a884] bg-gradient-to-tl from-[#00a884]/25 via-transparent to-transparent cursor-nwse-resize touch-none select-none"
            >
              <ArrowDownRight className="w-4 h-4 shrink-0 pointer-events-none" />
            </div>
          )}
        </section>
      )}

      {/* Memoized Scrollable Message Stream */}
      {!(
        hideChatText &&
        (isScreenShareInThisChat ||
          (isWatchInThisChat && watchPlayerSizeMode === "split"))
      ) && (
        <MessageList
          chatId={conversation.id}
          chatType={conversation.type}
          chatTitle={conversation.title}
          messages={conversation.messages}
          currentUid={currentUid}
          peerPublicKey={peerPublicKey}
          isTyping={isTyping}
          wallpaperClass={wallpaperClass}
          customWallpaper={customWallpaper}
          translationPrefs={translationPrefs}
          selectedLangOption={selectedLangOption}
          translations={translations}
          translatingKeys={translatingKeys}
          hiddenTranslations={hiddenTranslations}
          onReactMessage={onReactMessage}
          onReplyMessage={setReplyingTo}
          onStartEditMessage={handleStartEditMessage}
          onDeleteMessageForMe={onDeleteMessageForMe}
          onDeleteMessageForEveryone={onDeleteMessageForEveryone}
          onOpenViewOnceImage={onOpenViewOnceImage}
          onPreviewImage={onPreviewImage}
          onRequestTranslation={requestTranslation}
          onToggleTranslationVisibility={handleToggleTranslationVisibility}
          onSendQuickAiPrompt={handleSendQuickAiPrompt}
        />
      )}

      {/* Isolated Memoized Bottom Composer */}
      {!(hideChatText && isSplitStageVisible) && (
        <MessageComposer
          conversationId={conversation.id}
          conversationType={conversation.type}
          peerUid={conversation.peerUid}
          isBlockedByMe={isBlockedByMe}
          isBlockedByPeer={isBlockedByPeer}
          blockBusy={blockBusy}
          replyingTo={replyingTo}
          editingMsg={editingMsg}
          onCancelReply={handleCancelReply}
          onCancelEdit={handleCancelEdit}
          onToggleBlock={() => void handleToggleBlock()}
          onTypingChange={onTypingChange}
          onSendMessage={handleSendFromComposer}
          onEditMessage={handleEditFromComposer}
          onOpenVideoSearch={handleOpenVideoSearch}
        />
      )}

      <ChatSettingsDrawer
        isOpen={isDrawerOpen}
        conversation={conversation}
        isBlockedByMe={isBlockedByMe}
        blockedUntilMs={blockedUntilMs}
        isBlockedByPeer={isBlockedByPeer}
        isSharingThisChat={isScreenShareInThisChat}
        watchSession={watchSession}
        wallpaperId={wallpaperId}
        customWallpaper={customWallpaper}
        onClose={() => setIsDrawerOpen(false)}
        onStartScreenShare={() =>
          onStartScreenShare(conversation.id, conversation.title)
        }
        onStopScreenShare={onStopScreenShare}
        onOpenWatchTogether={() => setIsWatchModalOpen(true)}
        onStopWatchTogether={() => onStopWatchTogether(conversation.id)}
        onSelectWallpaper={onSelectWallpaper}
        onUploadCustomWallpaper={onUploadCustomWallpaper}
        onTogglePin={() => onTogglePin(conversation.id)}
        onOpenPeerProfile={() => {
          if (conversation.peerUid) {
            onOpenPeerProfile(conversation.peerUid);
          }
        }}
        onOpenGroupInfo={() => onOpenGroupInfo(conversation.id)}
        onCreateGroupWithPeer={(peerUid) => onCreateGroupWithPeer(peerUid)}
        onSetDisappearingTimer={(seconds) =>
          onSetDisappearingTimer(conversation.id, seconds)
        }
        onPreviewImage={onPreviewImage}
        onBlockWithDuration={(durationMs) => handleToggleBlock(durationMs)}
        onUnblock={() => handleToggleBlock(null)}
        onDeleteChatForMe={() => onDeleteChatForMe(conversation.id)}
      />

      <WatchTogetherModal
        isOpen={isWatchModalOpen}
        isDirectChat={conversation.type === "direct"}
        watchHistory={watchHistory}
        onClose={() => setIsWatchModalOpen(false)}
        onStartYouTube={(videoId, youtubeUrl, title) =>
          onStartYouTubeWatch(conversation.id, videoId, youtubeUrl, title)
        }
        onStartFacebook={(facebookUrl, title) =>
          onStartFacebookWatch(conversation.id, facebookUrl, title)
        }
        onStartTikTok={(videoId, tiktokUrl, title) =>
          onStartTikTokWatch(conversation.id, videoId, tiktokUrl, title)
        }
        onStartStream={(mediaType, mediaUrl, title) =>
          onStartStreamWatch(conversation.id, mediaType, mediaUrl, title)
        }
        onStartVideoFile={(file) =>
          onStartVideoFileWatch(conversation.id, conversation.title, file)
        }
        onDeleteWatchHistory={
          onDeleteWatchHistory
            ? (historyId) => onDeleteWatchHistory(conversation.id, historyId)
            : undefined
        }
      />

      <VideoSearchModal
        isOpen={isVideoSearchOpen}
        onClose={() => setIsVideoSearchOpen(false)}
        onSelectVideo={async (videoId, url, title) => {
          setWatchPlayerSizeMode("split");
          await onStartYouTubeWatch(conversation.id, videoId, url, title);
        }}
      />
    </div>
  );
}
