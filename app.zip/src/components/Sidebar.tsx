import { useMemo, useState } from "react";
import {
  Search,
  Settings,
  X,
  Pin,
  Sparkles,
  Plus,
  Mic,
  Image as ImageIcon,
  Film,
  CheckCheck,
  Check,
  Clock,
  Users,
  Phone,
  PhoneMissed,
  Video,
} from "lucide-react";
import type { Conversation, ConversationFilter, UserProfile } from "../types/chat";
import { getCountryByCode } from "../data/countries";
import { formatConversationTime, normalizeArabicSearch } from "../utils/storage";
import { Avatar } from "./Avatar";
import { MirsalLogo } from "./MirsalLogo";

interface SidebarProps {
  user: UserProfile;
  conversations: Conversation[];
  activeChatId: string | null;
  typingChatIds: Record<string, boolean>;
  onSelectChat: (chatId: string) => void;
  onOpenNewChat: () => void;
  onOpenMyProfile: () => void;
  onOpenSettings: () => void;
}

const FILTER_TABS: Array<{ id: ConversationFilter; label: string }> = [
  { id: "all", label: "الكل" },
  { id: "direct", label: "الأصدقاء" },
  { id: "group", label: "المجموعات" },
  { id: "ai", label: "الذكي" },
];

export function Sidebar({
  user,
  conversations,
  activeChatId,
  typingChatIds,
  onSelectChat,
  onOpenNewChat,
  onOpenMyProfile,
  onOpenSettings,
}: SidebarProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [filter, setFilter] = useState<ConversationFilter>("all");

  const filteredConversations = useMemo(() => {
    const q = normalizeArabicSearch(searchQuery);

    return [...conversations]
      .filter((conv) => {
        if (filter === "ai" && conv.type !== "ai") return false;
        if (filter === "direct" && conv.type !== "direct") return false;
        if (filter === "group" && conv.type !== "group") return false;

        if (!q) return true;
        const matchesTitle = normalizeArabicSearch(conv.title).includes(q);
        const matchesPreview = conv.lastMessagePreview
          ? normalizeArabicSearch(conv.lastMessagePreview).includes(q)
          : false;
        const matchesMessage = conv.messages.some((m) =>
          normalizeArabicSearch(m.text).includes(q)
        );
        return matchesTitle || matchesPreview || matchesMessage;
      })
      .sort((a, b) => {
        if (a.pinned && !b.pinned) return -1;
        if (!a.pinned && b.pinned) return 1;
        const lastA =
          a.messages[a.messages.length - 1]?.timestamp ||
          a.lastMessageTimestamp ||
          0;
        const lastB =
          b.messages[b.messages.length - 1]?.timestamp ||
          b.lastMessageTimestamp ||
          0;
        return lastB - lastA;
      });
  }, [conversations, filter, searchQuery]);

  return (
    <aside className="flex flex-col h-full w-full bg-white dark:bg-[#111b21] border-l border-slate-200 dark:border-slate-800">
      {/* Top User, New Chat (+) & Settings Bar */}
      <header className="px-4 py-3 flex items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800/80 bg-slate-50/70 dark:bg-[#202c33] shrink-0">
        <button
          type="button"
          onClick={onOpenMyProfile}
          title="الملف الشخصي"
          className="flex items-center gap-3 min-w-0 text-start rounded-xl p-1 -mr-1 hover:bg-slate-200/50 dark:hover:bg-slate-700/40 transition-colors cursor-pointer"
        >
          <MirsalLogo className="w-11 h-11 shrink-0 drop-shadow-xs" />
          <div className="min-w-0">
            <h1 className="font-display font-bold text-lg text-[#075E54] dark:text-[#25D366] truncate leading-tight">
              مرسال
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400 truncate flex items-center gap-1">
              {getCountryByCode(user.countryCode)?.flag && (
                <span
                  aria-label={getCountryByCode(user.countryCode)?.nameAr}
                  title={getCountryByCode(user.countryCode)?.nameAr}
                  className="shrink-0"
                >
                  {getCountryByCode(user.countryCode)?.flag}
                </span>
              )}
              <span className="truncate">{user.name}</span>
            </p>
          </div>
        </button>

        <div className="flex items-center gap-1.5 shrink-0">
          <button
            type="button"
            onClick={onOpenNewChat}
            aria-label="محادثة جديدة"
            title="محادثة أو مجموعة جديدة"
            className="min-h-[42px] px-3 py-2 rounded-xl bg-[#075E54] hover:bg-[#054c44] dark:bg-[#25D366] dark:hover:bg-[#1fb858] dark:text-slate-950 text-white text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs"
          >
            <Plus className="w-4 h-4 shrink-0" />
            <span>جديدة</span>
          </button>

          <button
            type="button"
            onClick={onOpenMyProfile}
            aria-label="الملف الشخصي"
            title="الملف الشخصي"
            className="min-h-[44px] min-w-[44px] rounded-xl flex items-center justify-center hover:bg-slate-200/70 dark:hover:bg-slate-700/50 transition-colors cursor-pointer shrink-0"
          >
            <Avatar src={user.photoURL || user.avatar} name={user.name} size="sm" />
          </button>

          <button
            type="button"
            onClick={onOpenSettings}
            aria-label="الإعدادات"
            title="الإعدادات"
            className="min-h-[44px] min-w-[44px] rounded-xl flex items-center justify-center text-slate-700 dark:text-slate-200 hover:bg-slate-200/70 dark:hover:bg-slate-700/50 transition-colors cursor-pointer shrink-0"
          >
            <Settings className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* Search & Filter Bar */}
      <div className="px-3 pt-3 pb-2.5 space-y-2.5 border-b border-slate-100 dark:border-slate-800/80 shrink-0">
        <div className="relative flex items-center">
          <Search className="w-4 h-4 text-slate-400 absolute right-3.5 pointer-events-none" />
          <input
            type="search"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="ابحث بالاسم أو الرسائل..."
            aria-label="ابحث في المحادثات"
            className="w-full min-h-[42px] pr-10 pl-9 py-2 rounded-xl bg-slate-100 dark:bg-[#202c33] text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-[#0d7a5f]/50 dark:focus:ring-[#00a884]/50 transition-shadow"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery("")}
              aria-label="مسح البحث"
              className="absolute left-2 p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-[#202c33] rounded-xl">
          {FILTER_TABS.map((tab) => {
            const isActive = filter === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setFilter(tab.id)}
                className={`flex-1 min-h-[34px] px-2 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                  isActive
                    ? "bg-white dark:bg-[#2a3942] text-[#0d7a5f] dark:text-[#00a884] shadow-xs"
                    : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200"
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Conversations List */}
      <div className="flex-1 overflow-y-auto custom-scrollbar divide-y divide-slate-100 dark:divide-slate-800/60">
        {filteredConversations.length === 0 ? (
          <div className="py-12 px-6 text-center space-y-3">
            <p className="text-sm font-medium text-slate-600 dark:text-slate-300">
              {filter === "direct"
                ? "لا توجد محادثات مع أصدقاء بعد"
                : filter === "group"
                ? "لا توجد مجموعات بعد"
                : "لا توجد محادثات مطابقة لبحثك"}
            </p>
            {filter === "direct" || filter === "group" ? (
              <button
                type="button"
                onClick={onOpenNewChat}
                className="min-h-[42px] px-4 py-2 rounded-xl text-xs font-bold text-white bg-[#0d7a5f] hover:bg-[#0a634d] dark:bg-[#00a884] dark:hover:bg-[#069475] inline-flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>ابدأ محادثة أو مجموعة جديدة</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={() => {
                  setSearchQuery("");
                  setFilter("all");
                }}
                className="min-h-[40px] px-4 py-2 rounded-xl text-xs font-semibold text-[#0d7a5f] dark:text-[#00a884] bg-emerald-50 dark:bg-emerald-950/40 hover:bg-emerald-100 dark:hover:bg-emerald-950/60 transition-colors cursor-pointer"
              >
                عرض جميع المحادثات
              </button>
            )}
          </div>
        ) : (
          filteredConversations.map((conv) => {
            const isSelected = conv.id === activeChatId;
            const lastMessage = conv.messages[conv.messages.length - 1];
            const isTyping =
              Boolean(typingChatIds[conv.id]) ||
              (conv.typingUids?.length || 0) > 0;
            const displayTime =
              lastMessage?.timestamp || conv.lastMessageTimestamp;

            return (
              <button
                key={conv.id}
                type="button"
                onClick={() => onSelectChat(conv.id)}
                className={`w-full min-h-[74px] px-4 py-3 flex items-center gap-3.5 text-start transition-colors cursor-pointer ${
                  isSelected
                    ? "bg-emerald-50/80 dark:bg-[#2a3942]"
                    : "hover:bg-slate-50 dark:hover:bg-[#202c33]/70"
                }`}
              >
                <div className="relative shrink-0">
                  <Avatar
                    src={conv.avatar}
                    name={conv.title}
                    size="lg"
                    isAi={conv.type === "ai"}
                  />
                  {conv.type === "direct" &&
                    conv.peerShowLastSeen !== false &&
                    conv.peerOnline && (
                      <span
                        title="متصل الآن"
                        className="absolute bottom-0 left-0 w-3.5 h-3.5 rounded-full bg-emerald-500 ring-2 ring-white dark:ring-[#111b21]"
                      />
                    )}
                </div>

                <div className="flex-1 min-w-0 space-y-1">
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-1.5 min-w-0">
                      {conv.type === "ai" && (
                        <Sparkles className="w-3.5 h-3.5 text-cyan-500 dark:text-cyan-400 shrink-0" />
                      )}
                      {conv.type === "group" && (
                        <Users className="w-4 h-4 text-[#0d7a5f] dark:text-[#00a884] shrink-0" />
                      )}
                      {conv.type === "direct" &&
                        getCountryByCode(conv.peerCountryCode)?.flag && (
                          <span
                            title={getCountryByCode(conv.peerCountryCode)?.nameAr}
                            className="shrink-0 text-sm leading-none"
                          >
                            {getCountryByCode(conv.peerCountryCode)?.flag}
                          </span>
                        )}
                      <span className="font-semibold text-[15px] text-slate-900 dark:text-slate-100 truncate">
                        {conv.title}
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      {conv.pinned && (
                        <Pin className="w-3.5 h-3.5 text-[#0d7a5f] dark:text-[#00a884]" />
                      )}
                      {displayTime && (
                        <span className="text-xs tabular-nums text-slate-400 dark:text-slate-500">
                          {formatConversationTime(displayTime)}
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-1 min-w-0 text-sm text-slate-500 dark:text-slate-400">
                      {isTyping ? (
                        <span className="text-[#0d7a5f] dark:text-[#00a884] font-bold animate-pulse truncate">
                          يكتب الآن...
                        </span>
                      ) : lastMessage ? (
                        lastMessage.messageType === "call" && lastMessage.callInfo ? (
                          <span
                            className={`flex items-center gap-1.5 truncate ${
                              lastMessage.callInfo.outcome === "missed" ||
                              lastMessage.callInfo.outcome === "declined"
                                ? "text-rose-600 dark:text-rose-400 font-medium"
                                : ""
                            }`}
                          >
                            {lastMessage.callInfo.outcome === "missed" ||
                            lastMessage.callInfo.outcome === "declined" ? (
                              <PhoneMissed className="w-3.5 h-3.5 shrink-0" />
                            ) : lastMessage.callInfo.callType === "video" ? (
                              <Video className="w-3.5 h-3.5 shrink-0 text-[#0d7a5f] dark:text-[#00a884]" />
                            ) : (
                              <Phone className="w-3.5 h-3.5 shrink-0 text-[#0d7a5f] dark:text-[#00a884]" />
                            )}
                            <span className="truncate">{lastMessage.text}</span>
                          </span>
                        ) : (
                          <>
                            {lastMessage.senderId === "me" && (
                              <span className="shrink-0 flex items-center">
                                {lastMessage.status === "sending" && (
                                  <Clock className="w-3.5 h-3.5 text-[#94a3b8]" />
                                )}
                                {lastMessage.status === "sent" && (
                                  <Check className="w-3.5 h-3.5 text-[#94a3b8]" />
                                )}
                                {lastMessage.status === "delivered" && (
                                  <CheckCheck className="w-3.5 h-3.5 text-[#94a3b8]" />
                                )}
                                {lastMessage.status === "read" && (
                                  <CheckCheck className="w-3.5 h-3.5 text-[#38bdf8]" />
                                )}
                              </span>
                            )}
                            {lastMessage.imageDataUrl && !lastMessage.text && (
                              <span className="flex items-center gap-1 truncate">
                                <ImageIcon className="w-3.5 h-3.5 shrink-0" />
                                <span>صورة</span>
                              </span>
                            )}
                            {lastMessage.videoDataUrl && !lastMessage.text && (
                              <span className="flex items-center gap-1 truncate">
                                <Film className="w-3.5 h-3.5 shrink-0" />
                                <span>فيديو</span>
                              </span>
                            )}
                            {lastMessage.audioDataUrl && !lastMessage.text && (
                              <span className="flex items-center gap-1 truncate">
                                <Mic className="w-3.5 h-3.5 shrink-0" />
                                <span>رسالة صوتية</span>
                              </span>
                            )}
                            {lastMessage.text && (
                              <span className="truncate">
                                {lastMessage.imageDataUrl
                                  ? "📷 "
                                  : lastMessage.videoDataUrl
                                  ? "🎬 "
                                  : ""}
                                {lastMessage.text}
                              </span>
                            )}
                          </>
                        )
                      ) : conv.lastMessagePreview ? (
                        <span className="flex items-center gap-1 truncate">
                          {conv.lastMessageType === "video" && (
                            <Film className="w-3.5 h-3.5 shrink-0" />
                          )}
                          {conv.lastMessageType === "image" && (
                            <ImageIcon className="w-3.5 h-3.5 shrink-0" />
                          )}
                          {conv.lastMessageType === "audio" && (
                            <Mic className="w-3.5 h-3.5 shrink-0" />
                          )}
                          {conv.lastMessageType === "call" && (
                            <Phone className="w-3.5 h-3.5 shrink-0" />
                          )}
                          <span className="truncate">{conv.lastMessagePreview}</span>
                        </span>
                      ) : (
                        <span className="truncate text-slate-400 dark:text-slate-500">
                          {conv.subtitle}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </button>
            );
          })
        )}
      </div>
    </aside>
  );
}
