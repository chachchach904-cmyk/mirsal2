import type {
  ChatWallpaperId,
  FontFamilyId,
  FontSizeId,
  MaritalStatus,
  MessageToneId,
  NotificationPrefs,
  RingtoneId,
  SoundPrefs,
  ThemeMode,
  TypographyPrefs,
  UserProfile,
} from "../types/chat";

const STORAGE_KEYS = {
  USER: "mirsal_user_v3",
  PENDING_SIGNUP: "mirsal_pending_signup_v1",
  THEME: "mirsal_theme_v1",
  TRANSLATION: "mirsal_translation_prefs_v1",
  TRANSLATION_CACHE: "mirsal_translation_cache_v1",
  WALLPAPER: "mirsal_chat_wallpaper_v1",
  CUSTOM_WALLPAPER: "mirsal_custom_chat_wallpaper_v1",
  SOUND: "mirsal_sound_prefs_v1",
  TYPOGRAPHY: "mirsal_typography_prefs_v1",
  NOTIFICATIONS: "mirsal_notification_prefs_v1",
  LAST_READ_BY_CHAT: "mirsal_last_read_by_chat_v1",
  AI_PINNED: "mirsal_ai_pinned_v1",
  APP_LOCK_PIN_PREFIX: "mirsal_app_lock_pin_v1_",
  SESSION_VERSION_PREFIX: "mirsal_session_version_v1_",
  SECRET_CHAT_MAP: "mirsal_secret_chat_map_v1",
  LEGACY_USER: "mirsal_user_v2",
  LEGACY_FIREBASE: "mirsal_custom_firebase_config_v1",
  LEGACY_CHATS: "mirsal_chats_v1",
} as const;

try {
  localStorage.removeItem(STORAGE_KEYS.LEGACY_CHATS);
  localStorage.removeItem(STORAGE_KEYS.LEGACY_FIREBASE);
  localStorage.removeItem(STORAGE_KEYS.LEGACY_USER);
} catch {
  // ignore
}

export interface PendingSignupProfile {
  uid: string;
  name: string;
  email: string;
  avatar: string;
  countryCode?: string;
}

export interface TranslationPrefs {
  targetLanguage: string;
  autoTranslate: boolean;
}

export function loadTranslationPrefs(): TranslationPrefs {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.TRANSLATION);
    if (raw) {
      const parsed = JSON.parse(raw) as Partial<TranslationPrefs>;
      return {
        targetLanguage:
          typeof parsed.targetLanguage === "string" && parsed.targetLanguage
            ? parsed.targetLanguage
            : "ar",
        autoTranslate: Boolean(parsed.autoTranslate),
      };
    }
  } catch {
    // fallback
  }
  return { targetLanguage: "ar", autoTranslate: false };
}

export function saveTranslationPrefs(prefs: TranslationPrefs): void {
  try {
    localStorage.setItem(STORAGE_KEYS.TRANSLATION, JSON.stringify(prefs));
  } catch {
    // ignore
  }
}

export function buildTranslationCacheKey(
  text: string,
  targetLanguage: string
): string {
  return `${targetLanguage}::${text.trim()}`;
}

export function loadTranslationCache(): Record<string, string> {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.TRANSLATION_CACHE);
    if (!raw) return {};
    const parsed = JSON.parse(raw) as Record<string, unknown>;
    const clean: Record<string, string> = {};
    if (parsed && typeof parsed === "object") {
      Object.entries(parsed).forEach(([k, v]) => {
        if (typeof v === "string") {
          clean[k] = v;
        }
      });
    }
    return clean;
  } catch {
    return {};
  }
}

export function saveTranslationCache(cache: Record<string, string>): void {
  try {
    const entries = Object.entries(cache);
    const trimmed =
      entries.length > 300 ? Object.fromEntries(entries.slice(-300)) : cache;
    localStorage.setItem(
      STORAGE_KEYS.TRANSLATION_CACHE,
      JSON.stringify(trimmed)
    );
  } catch {
    // ignore
  }
}

const VALID_WALLPAPERS = new Set<ChatWallpaperId>([
  "default",
  "midnight",
  "emerald-dusk",
  "ocean-mist",
  "warm-sand",
  "islamic-olive",
  "islamic-indigo",
  "plum-silk",
]);

export function loadChatWallpaper(): ChatWallpaperId {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.WALLPAPER) as ChatWallpaperId | null;
    if (raw && VALID_WALLPAPERS.has(raw)) {
      return raw;
    }
  } catch {
    // ignore
  }
  return "default";
}

export function saveChatWallpaper(id: ChatWallpaperId): void {
  try {
    localStorage.setItem(STORAGE_KEYS.WALLPAPER, id);
  } catch {
    // ignore
  }
}

export function normalizeCustomImageUrl(input: string): string | null {
  const trimmed = input.trim();
  if (!trimmed) return null;
  if (trimmed.startsWith("data:image/")) {
    return trimmed;
  }
  try {
    const withProto = /^https?:\/\//i.test(trimmed)
      ? trimmed
      : `https://${trimmed}`;
    const parsed = new URL(withProto);
    if (
      (parsed.protocol === "https:" || parsed.protocol === "http:") &&
      parsed.hostname.includes(".") &&
      parsed.href.length <= 1500
    ) {
      return parsed.href;
    }
  } catch {
    return null;
  }
  return null;
}

export function loadCustomChatWallpaper(): string | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.CUSTOM_WALLPAPER);
    if (raw && (raw.startsWith("data:image/") || /^https?:\/\//i.test(raw))) {
      return raw;
    }
  } catch {
    // ignore
  }
  return null;
}

export function saveCustomChatWallpaper(dataUrl: string | null): void {
  try {
    if (!dataUrl) {
      localStorage.removeItem(STORAGE_KEYS.CUSTOM_WALLPAPER);
    } else {
      localStorage.setItem(STORAGE_KEYS.CUSTOM_WALLPAPER, dataUrl);
    }
  } catch {
    // ignore
  }
}

const VALID_MSG_TONES = new Set<MessageToneId>([
  "soft-bell",
  "crystal-drop",
  "modern-chime",
]);
const VALID_RINGTONES = new Set<RingtoneId>([
  "mirsal-classic",
  "crystal-calm",
  "modern-marimba",
  "fast-digital",
  "warm-strings",
  "royal-rhythm",
  "double-alert",
]);

const LEGACY_RINGTONE_MAP: Record<string, RingtoneId> = {
  "classic-marimba": "mirsal-classic",
  "gentle-pulse": "crystal-calm",
  "noor-melody": "modern-marimba",
};

export function loadSoundPrefs(): SoundPrefs {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SOUND);
    if (raw) {
      const parsed = JSON.parse(raw) as Partial<SoundPrefs> & {
        ringtone?: string;
      };
      const rawVolume =
        typeof parsed.volume === "number" && Number.isFinite(parsed.volume)
          ? Math.max(0, Math.min(100, Math.round(parsed.volume)))
          : 100;
      const mappedRingtone =
        parsed.ringtone && LEGACY_RINGTONE_MAP[parsed.ringtone]
          ? LEGACY_RINGTONE_MAP[parsed.ringtone]
          : parsed.ringtone && VALID_RINGTONES.has(parsed.ringtone as RingtoneId)
          ? (parsed.ringtone as RingtoneId)
          : "mirsal-classic";
      return {
        muted: Boolean(parsed.muted),
        volume: rawVolume,
        messageTone:
          parsed.messageTone && VALID_MSG_TONES.has(parsed.messageTone)
            ? parsed.messageTone
            : "soft-bell",
        ringtone: mappedRingtone,
        callVibration: parsed.callVibration !== false,
      };
    }
  } catch {
    // ignore
  }
  return {
    muted: false,
    volume: 100,
    messageTone: "soft-bell",
    ringtone: "mirsal-classic",
    callVibration: true,
  };
}

export function saveSoundPrefs(prefs: SoundPrefs): void {
  try {
    localStorage.setItem(STORAGE_KEYS.SOUND, JSON.stringify(prefs));
  } catch {
    // ignore
  }
}

export function loadNotificationPrefs(): NotificationPrefs {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.NOTIFICATIONS);
    if (raw) {
      const parsed = JSON.parse(raw) as Partial<NotificationPrefs>;
      return {
        notificationsEnabled: Boolean(parsed.notificationsEnabled),
        floatingBubbleEnabled: false,
      };
    }
  } catch {
    // ignore
  }
  const alreadyGranted =
    typeof window !== "undefined" &&
    "Notification" in window &&
    Notification.permission === "granted";
  return {
    notificationsEnabled: alreadyGranted,
    floatingBubbleEnabled: false,
  };
}

export function saveNotificationPrefs(prefs: NotificationPrefs): void {
  try {
    localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(prefs));
  } catch {
    // ignore
  }
}

export function loadLastReadByChat(): Record<string, number> {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.LAST_READ_BY_CHAT);
    if (!raw) return {};
    const parsed = JSON.parse(raw) as Record<string, unknown>;
    const clean: Record<string, number> = {};
    if (parsed && typeof parsed === "object") {
      Object.entries(parsed).forEach(([k, v]) => {
        if (typeof v === "number" && Number.isFinite(v)) {
          clean[k] = v;
        }
      });
    }
    return clean;
  } catch {
    return {};
  }
}

export function saveLastReadByChat(map: Record<string, number>): void {
  try {
    localStorage.setItem(STORAGE_KEYS.LAST_READ_BY_CHAT, JSON.stringify(map));
  } catch {
    // ignore
  }
}

const VALID_FONTS = new Set<FontFamilyId>([
  "whatsapp",
  "cairo",
  "tajawal",
  "almarai",
  "amiri",
]);
const VALID_FONT_SIZES = new Set<FontSizeId>(["sm", "md", "lg", "xl"]);

const ROOT_FONT_SIZE_PX: Record<FontSizeId, string> = {
  sm: "15px",
  md: "16px",
  lg: "17px",
  xl: "19px",
};

export function loadTypographyPrefs(): TypographyPrefs {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.TYPOGRAPHY);
    if (raw) {
      const parsed = JSON.parse(raw) as {
        fontFamily?: string;
        fontSize?: FontSizeId;
      };
      let fontFamily: FontFamilyId = "whatsapp";
      if (parsed.fontFamily === "modern") {
        fontFamily = "tajawal";
      } else if (parsed.fontFamily === "bold") {
        fontFamily = "cairo";
      } else if (
        parsed.fontFamily &&
        VALID_FONTS.has(parsed.fontFamily as FontFamilyId)
      ) {
        fontFamily = parsed.fontFamily as FontFamilyId;
      }
      return {
        fontFamily,
        fontSize:
          parsed.fontSize && VALID_FONT_SIZES.has(parsed.fontSize)
            ? parsed.fontSize
            : "lg",
      };
    }
  } catch {
    // ignore
  }
  return { fontFamily: "whatsapp", fontSize: "lg" };
}

export function saveTypographyPrefs(prefs: TypographyPrefs): void {
  try {
    localStorage.setItem(STORAGE_KEYS.TYPOGRAPHY, JSON.stringify(prefs));
  } catch {
    // ignore
  }
}

export function applyTypographyClasses(prefs: TypographyPrefs): void {
  if (typeof document === "undefined") return;
  const root = document.documentElement;
  root.classList.remove(
    "mirsal-font-whatsapp",
    "mirsal-font-cairo",
    "mirsal-font-tajawal",
    "mirsal-font-almarai",
    "mirsal-font-amiri",
    "mirsal-font-modern",
    "mirsal-font-bold",
    "mirsal-size-sm",
    "mirsal-size-md",
    "mirsal-size-lg",
    "mirsal-size-xl"
  );
  root.classList.add(`mirsal-font-${prefs.fontFamily}`);
  root.classList.add(`mirsal-size-${prefs.fontSize}`);
  root.style.fontSize = ROOT_FONT_SIZE_PX[prefs.fontSize] || "17px";
}

export function loadAiPinned(): boolean {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.AI_PINNED);
    if (raw === "false") return false;
    return true;
  } catch {
    return true;
  }
}

export function saveAiPinned(pinned: boolean): void {
  try {
    localStorage.setItem(STORAGE_KEYS.AI_PINNED, pinned ? "true" : "false");
  } catch {
    // ignore
  }
}

export async function sha256Hex(value: string): Promise<string> {
  const normalized = value.trim().toLowerCase();
  if (!normalized || typeof crypto === "undefined" || !crypto.subtle) {
    return "";
  }
  try {
    const data = new TextEncoder().encode(normalized);
    const hashBuffer = await crypto.subtle.digest("SHA-256", data);
    const bytes = Array.from(new Uint8Array(hashBuffer));
    return bytes.map((b) => b.toString(16).padStart(2, "0")).join("");
  } catch {
    return "";
  }
}

export function formatBlockRemainingAr(untilMs?: number): string {
  if (!untilMs || untilMs === 0) {
    return "حظر دائم";
  }
  const diff = untilMs - Date.now();
  if (diff <= 0) {
    return "منتهي";
  }
  const days = Math.ceil(diff / (24 * 60 * 60 * 1000));
  if (days >= 2) {
    return `متبقي ${days} يوم`;
  }
  const hours = Math.max(1, Math.ceil(diff / (60 * 60 * 1000)));
  return `متبقي ${hours} ساعة`;
}

export function extractYouTubeVideoId(input: string): string | null {
  const trimmed = input.trim();
  if (!trimmed) return null;
  if (/^[a-zA-Z0-9_-]{11}$/.test(trimmed)) {
    return trimmed;
  }
  try {
    const normalized = /^https?:\/\//i.test(trimmed)
      ? trimmed
      : `https://${trimmed}`;
    const url = new URL(normalized);
    const host = url.hostname.replace(/^www\./, "").toLowerCase();

    if (host === "youtu.be") {
      const id = url.pathname.split("/").filter(Boolean)[0];
      return id && /^[a-zA-Z0-9_-]{6,32}$/.test(id) ? id : null;
    }

    if (
      host === "youtube.com" ||
      host === "m.youtube.com" ||
      host === "music.youtube.com" ||
      host === "youtube-nocookie.com"
    ) {
      const vParam = url.searchParams.get("v");
      if (vParam && /^[a-zA-Z0-9_-]{6,32}$/.test(vParam)) {
        return vParam;
      }
      const segments = url.pathname.split("/").filter(Boolean);
      if (
        segments.length >= 2 &&
        ["embed", "shorts", "live", "v"].includes(segments[0])
      ) {
        const id = segments[1];
        return id && /^[a-zA-Z0-9_-]{6,32}$/.test(id) ? id : null;
      }
    }
  } catch {
    return null;
  }
  return null;
}

export function supportsDesktopScreenShare(): boolean {
  if (typeof window === "undefined" || typeof navigator === "undefined") {
    return false;
  }
  const hasDisplayMedia =
    typeof navigator.mediaDevices?.getDisplayMedia === "function";
  if (!hasDisplayMedia) return false;

  const ua = navigator.userAgent || "";
  const isMobileUa =
    /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(ua);
  const isTouchTablet =
    navigator.maxTouchPoints > 1 && window.innerWidth < 1024;
  return !isMobileUa && !isTouchTablet;
}

export function isFacebookVideoUrl(input: string): boolean {
  const lower = input.trim().toLowerCase();
  return (
    lower.includes("facebook.com") ||
    lower.includes("fb.watch") ||
    lower.includes("://fb.com") ||
    /(?:^|\/\/)(?:www\.|m\.)?fb\.com\//.test(lower)
  );
}

export function isShortFacebookShareUrl(input: string): boolean {
  const lower = input.trim().toLowerCase();
  if (!lower) return false;
  return (
    lower.includes("fb.watch/") ||
    lower.includes("/share/") ||
    lower.includes("://fb.com/") ||
    /(?:^|\/\/)(?:www\.|m\.)?fb\.com\//.test(lower)
  );
}

export function cleanFacebookVideoUrl(input: string): string | null {
  const trimmed = input.trim();
  if (!trimmed || !isFacebookVideoUrl(trimmed)) return null;
  try {
    const normalized = /^https?:\/\//i.test(trimmed)
      ? trimmed
      : `https://${trimmed}`;
    const parsed = new URL(normalized);
    if (parsed.protocol !== "https:" && parsed.protocol !== "http:") {
      return null;
    }
    const rawHost = parsed.hostname.toLowerCase();
    const bareHost = rawHost.replace(/^www\./, "");
    const isFbHost =
      bareHost === "fb.watch" ||
      bareHost === "fb.com" ||
      bareHost === "facebook.com" ||
      bareHost.endsWith(".facebook.com");
    if (!isFbHost) return null;

    if (bareHost === "facebook.com" || bareHost.endsWith(".facebook.com")) {
      parsed.hostname = "www.facebook.com";
    }
    parsed.protocol = "https:";
    parsed.hash = "";

    const preservedParams = new URLSearchParams();
    const keepKeys = new Set(["v", "t", "id", "story_fbid"]);
    parsed.searchParams.forEach((value, key) => {
      if (keepKeys.has(key.toLowerCase()) && value.trim()) {
        preservedParams.set(key, value.trim());
      }
    });
    const cleanQuery = preservedParams.toString();
    parsed.search = cleanQuery ? `?${cleanQuery}` : "";

    return parsed.href;
  } catch {
    return null;
  }
}

export function parseFacebookVideoUrl(input: string): string | null {
  return cleanFacebookVideoUrl(input);
}

export function isTikTokVideoUrl(input: string): boolean {
  const lower = input.trim().toLowerCase();
  return (
    lower.includes("tiktok.com") ||
    lower.includes("vm.tiktok.com") ||
    lower.includes("vt.tiktok.com")
  );
}

export function extractTikTokVideoId(input: string): string | null {
  const match =
    input.match(/\/(?:video|photo)\/(\d{10,25})/i) ||
    input.match(/\/v\/(\d{10,25})/i);
  return match ? match[1] : null;
}

export function parseTikTokVideoUrl(
  input: string
): { url: string; videoId: string | null; isShortLink: boolean } | null {
  const trimmed = input.trim();
  if (!trimmed || !isTikTokVideoUrl(trimmed)) return null;
  try {
    const normalized = /^https?:\/\//i.test(trimmed)
      ? trimmed
      : `https://${trimmed}`;
    const parsed = new URL(normalized);
    if (parsed.protocol !== "https:" && parsed.protocol !== "http:") {
      return null;
    }
    const bareHost = parsed.hostname.toLowerCase().replace(/^www\./, "");
    const isAllowed =
      bareHost === "tiktok.com" || bareHost.endsWith(".tiktok.com");
    if (!isAllowed) return null;

    parsed.protocol = "https:";
    parsed.hash = "";

    const videoId = extractTikTokVideoId(parsed.href);
    const isShortLink =
      !videoId &&
      (bareHost === "vm.tiktok.com" ||
        bareHost === "vt.tiktok.com" ||
        parsed.pathname.startsWith("/t/"));

    if (videoId) {
      parsed.search = "";
    }

    return {
      url: parsed.href,
      videoId,
      isShortLink,
    };
  } catch {
    return null;
  }
}

export function parseWatchStreamUrl(
  input: string
): { mediaType: "mp4" | "m3u8"; url: string } | null {
  const trimmed = input.trim();
  if (!trimmed || isFacebookVideoUrl(trimmed) || isTikTokVideoUrl(trimmed)) {
    return null;
  }
  try {
    const normalized = /^https?:\/\//i.test(trimmed)
      ? trimmed
      : `https://${trimmed}`;
    const parsed = new URL(normalized);
    if (parsed.protocol !== "https:" && parsed.protocol !== "http:") {
      return null;
    }
    const lowerPath = parsed.pathname.toLowerCase();
    const lowerFull = parsed.href.toLowerCase();
    if (
      lowerPath.endsWith(".m3u8") ||
      lowerFull.includes(".m3u8?") ||
      lowerFull.includes("format=m3u8")
    ) {
      return { mediaType: "m3u8", url: parsed.href };
    }
    if (
      lowerPath.endsWith(".mp4") ||
      lowerPath.endsWith(".webm") ||
      lowerPath.endsWith(".mov") ||
      lowerFull.includes(".mp4?") ||
      lowerFull.includes(".webm?")
    ) {
      return { mediaType: "mp4", url: parsed.href };
    }
    return { mediaType: "mp4", url: parsed.href };
  } catch {
    return null;
  }
}

export function extractSiteNameFromUrl(input: string): string {
  const trimmed = (input || "").trim();
  if (!trimmed) return "";
  try {
    const normalized = /^https?:\/\//i.test(trimmed)
      ? trimmed
      : `https://${trimmed}`;
    const host = new URL(normalized).hostname.replace(/^www\./i, "").toLowerCase();
    if (!host) return "";
    if (host.includes("youtube.com") || host === "youtu.be") return "YouTube";
    if (host.includes("facebook.com") || host === "fb.watch" || host === "fb.com") {
      return "Facebook";
    }
    if (host.includes("tiktok.com")) return "TikTok";
    if (host.includes("instagram.com") || host === "instagr.am") return "Instagram";
    return host;
  } catch {
    return "";
  }
}

export function isInstagramUrl(input: string): boolean {
  const lower = (input || "").trim().toLowerCase();
  return lower.includes("instagram.com") || lower.includes("instagr.am");
}

export function parseInstagramUrl(
  input: string
): { url: string; shortCode: string; embedUrl: string } | null {
  const trimmed = (input || "").trim();
  if (!trimmed || !isInstagramUrl(trimmed)) return null;
  try {
    const normalized = /^https?:\/\//i.test(trimmed)
      ? trimmed
      : `https://${trimmed}`;
    const parsed = new URL(normalized);
    if (parsed.protocol !== "https:" && parsed.protocol !== "http:") {
      return null;
    }
    const bareHost = parsed.hostname.toLowerCase().replace(/^www\./, "");
    if (
      bareHost !== "instagram.com" &&
      !bareHost.endsWith(".instagram.com") &&
      bareHost !== "instagr.am"
    ) {
      return null;
    }
    const match = parsed.pathname.match(
      /^\/(?:[^/]+\/)?(p|reel|reels|tv)\/([a-zA-Z0-9_-]{4,40})/i
    );
    if (!match) return null;
    const rawKind = match[1].toLowerCase();
    const kind = rawKind === "reels" ? "reel" : rawKind;
    const shortCode = match[2];
    const cleanUrl = `https://www.instagram.com/${kind}/${shortCode}/`;
    return {
      url: cleanUrl,
      shortCode,
      embedUrl: `${cleanUrl}embed`,
    };
  } catch {
    return null;
  }
}

export function parseUniversalWebUrl(input: string): string | null {
  const trimmed = (input || "").trim();
  if (!trimmed) return null;
  try {
    const normalized = /^https?:\/\//i.test(trimmed)
      ? trimmed
      : /^[a-z0-9-]+(\.[a-z0-9-]+)+([/:?#].*)?$/i.test(trimmed)
      ? `https://${trimmed}`
      : "";
    if (!normalized) return null;
    const parsed = new URL(normalized);
    if (parsed.protocol !== "https:" && parsed.protocol !== "http:") {
      return null;
    }
    if (!parsed.hostname || !parsed.hostname.includes(".")) {
      return null;
    }
    return parsed.href;
  } catch {
    return null;
  }
}

export function buildSafeWatchVideoId(prefix: string, seed: string): string {
  const safePrefix = (prefix || "media").replace(/[^a-zA-Z0-9_-]/g, "").slice(0, 12) || "media";
  const cleanSeed = (seed || "").trim();
  if (/^[a-zA-Z0-9_-]{3,40}$/.test(cleanSeed)) {
    return `${safePrefix}_${cleanSeed}`;
  }
  let h = 2166136261;
  for (let i = 0; i < cleanSeed.length; i++) {
    h ^= cleanSeed.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return `${safePrefix}_${(h >>> 0).toString(36)}`;
}

export function loadUserProfile(): UserProfile | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.USER);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as UserProfile;
    if (parsed && typeof parsed.name === "string" && parsed.name.trim()) {
      return parsed;
    }
    return null;
  } catch {
    return null;
  }
}

export function saveUserProfile(user: UserProfile | null): void {
  try {
    if (!user) {
      localStorage.removeItem(STORAGE_KEYS.USER);
    } else {
      localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(user));
    }
  } catch (err) {
    console.warn("Unable to save user profile:", err);
  }
}

export function loadPendingSignupProfile(): PendingSignupProfile | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.PENDING_SIGNUP);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as PendingSignupProfile;
    if (parsed && parsed.uid && parsed.name && parsed.email) {
      return parsed;
    }
    return null;
  } catch {
    return null;
  }
}

export function savePendingSignupProfile(
  profile: PendingSignupProfile | null
): void {
  try {
    if (!profile) {
      localStorage.removeItem(STORAGE_KEYS.PENDING_SIGNUP);
    } else {
      localStorage.setItem(STORAGE_KEYS.PENDING_SIGNUP, JSON.stringify(profile));
    }
  } catch {
    // ignore
  }
}

export function loadTheme(): ThemeMode {
  try {
    const saved = localStorage.getItem(STORAGE_KEYS.THEME);
    if (saved === "dark" || saved === "light") return saved;
    if (
      typeof window !== "undefined" &&
      window.matchMedia &&
      window.matchMedia("(prefers-color-scheme: dark)").matches
    ) {
      return "dark";
    }
  } catch {
    // fallback
  }
  return "light";
}

export function saveTheme(theme: ThemeMode): void {
  try {
    localStorage.setItem(STORAGE_KEYS.THEME, theme);
  } catch {
    // ignore
  }
}

export function applyThemeClass(theme: ThemeMode): void {
  if (typeof document === "undefined") return;
  const root = document.documentElement;
  if (theme === "dark") {
    root.classList.add("dark");
  } else {
    root.classList.remove("dark");
  }
}

export function normalizeArabicSearch(text: string): string {
  return text
    .trim()
    .toLowerCase()
    .replace(/[أإآ]/g, "ا")
    .replace(/ى/g, "ي")
    .replace(/ة/g, "ه");
}

export function formatMessageTime(timestamp: number): string {
  try {
    return new Intl.DateTimeFormat("ar-SA", {
      hour: "numeric",
      minute: "2-digit",
      hour12: true,
    }).format(new Date(timestamp));
  } catch {
    return "";
  }
}

export function formatConversationTime(timestamp: number): string {
  const date = new Date(timestamp);
  const now = new Date();
  const isToday =
    date.getDate() === now.getDate() &&
    date.getMonth() === now.getMonth() &&
    date.getFullYear() === now.getFullYear();

  if (isToday) {
    return formatMessageTime(timestamp);
  }

  const yesterday = new Date(now);
  yesterday.setDate(now.getDate() - 1);
  const isYesterday =
    date.getDate() === yesterday.getDate() &&
    date.getMonth() === yesterday.getMonth() &&
    date.getFullYear() === yesterday.getFullYear();

  if (isYesterday) {
    return "أمس";
  }

  try {
    return new Intl.DateTimeFormat("ar-SA", {
      day: "numeric",
      month: "short",
    }).format(date);
  } catch {
    return "";
  }
}

export function formatLastSeen(
  lastSeenMs: number | null | undefined,
  isOnline?: boolean
): string {
  if (isOnline) {
    return "متصل الآن";
  }
  if (!lastSeenMs) {
    return "غير متصل حالياً";
  }

  const date = new Date(lastSeenMs);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  if (diffMs < 60_000) {
    return "آخر ظهور منذ لحظات";
  }

  const isToday =
    date.getDate() === now.getDate() &&
    date.getMonth() === now.getMonth() &&
    date.getFullYear() === now.getFullYear();

  if (isToday) {
    return `آخر ظهور اليوم ${formatMessageTime(lastSeenMs)}`;
  }

  const yesterday = new Date(now);
  yesterday.setDate(now.getDate() - 1);
  const isYesterday =
    date.getDate() === yesterday.getDate() &&
    date.getMonth() === yesterday.getMonth() &&
    date.getFullYear() === yesterday.getFullYear();

  if (isYesterday) {
    return `آخر ظهور أمس ${formatMessageTime(lastSeenMs)}`;
  }

  try {
    const formattedDate = new Intl.DateTimeFormat("ar-SA", {
      day: "numeric",
      month: "short",
    }).format(date);
    return `آخر ظهور ${formattedDate}`;
  } catch {
    return "غير متصل حالياً";
  }
}

export function formatDateSeparator(timestamp: number): string {
  const date = new Date(timestamp);
  const now = new Date();
  const isToday =
    date.getDate() === now.getDate() &&
    date.getMonth() === now.getMonth() &&
    date.getFullYear() === now.getFullYear();

  if (isToday) return "اليوم";

  const yesterday = new Date(now);
  yesterday.setDate(now.getDate() - 1);
  const isYesterday =
    date.getDate() === yesterday.getDate() &&
    date.getMonth() === yesterday.getMonth() &&
    date.getFullYear() === yesterday.getFullYear();

  if (isYesterday) return "أمس";

  try {
    return new Intl.DateTimeFormat("ar-SA", {
      weekday: "long",
      day: "numeric",
      month: "long",
    }).format(date);
  } catch {
    return "";
  }
}

export function formatCallDateTimeAr(timestamp: number): string {
  try {
    return new Intl.DateTimeFormat("ar-SA", {
      day: "numeric",
      month: "short",
      year: "numeric",
      hour: "numeric",
      minute: "2-digit",
      hour12: true,
    }).format(new Date(timestamp));
  } catch {
    return formatMessageTime(timestamp);
  }
}

export function formatCallDurationLabel(seconds: number): string {
  const safe = Math.max(0, Math.round(seconds));
  const hrs = Math.floor(safe / 3600);
  const mins = Math.floor((safe % 3600) / 60);
  const secs = safe % 60;
  if (hrs > 0) {
    return `${hrs.toString().padStart(2, "0")}:${mins
      .toString()
      .padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  }
  return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
}

export const DEFAULT_JOIN_MONTH_YEAR_AR = "نوفمبر 2026";

export function extractJoinMonthYearAr(
  dateInput: string | number | null | undefined
): string | null {
  if (dateInput === null || dateInput === undefined || dateInput === "") {
    return null;
  }

  let timestamp = NaN;
  if (typeof dateInput === "number") {
    timestamp = dateInput;
  } else {
    const trimmed = String(dateInput).trim();
    if (!trimmed) return null;
    if (/^\d+$/.test(trimmed)) {
      timestamp = Number(trimmed);
    } else if (
      /\d{4}[-/]\d{1,2}[-/]\d{1,2}/.test(trimmed) ||
      trimmed.includes("GMT") ||
      trimmed.includes("UTC") ||
      /\d{2}:\d{2}/.test(trimmed)
    ) {
      timestamp = Date.parse(trimmed);
    } else {
      return trimmed.slice(0, 40);
    }
  }

  if (!Number.isFinite(timestamp) || timestamp <= 0) {
    return null;
  }

  try {
    return new Intl.DateTimeFormat("ar-u-ca-gregory", {
      month: "long",
      year: "numeric",
    }).format(new Date(timestamp));
  } catch {
    return null;
  }
}

export function formatJoinMonthYearAr(
  dateInput?: string | number | null,
  fallbackDateInput?: string | number | null
): string {
  const monthYear =
    extractJoinMonthYearAr(dateInput) ||
    extractJoinMonthYearAr(fallbackDateInput) ||
    DEFAULT_JOIN_MONTH_YEAR_AR;
  return `انضم إلى مرسال في ${monthYear}`;
}

export const MARITAL_STATUS_OPTIONS: Array<{
  value: MaritalStatus;
  label: string;
}> = [
  { value: "unspecified", label: "غير محدد" },
  { value: "single", label: "أعزب/عزباء" },
  { value: "engaged", label: "خاطب/مخطوبة" },
  { value: "married", label: "متزوج/متزوجة" },
];

export function formatMaritalStatusAr(status?: MaritalStatus | string): string {
  const matched = MARITAL_STATUS_OPTIONS.find((opt) => opt.value === status);
  return matched ? matched.label : "غير محدد";
}

export async function compressImageToDataUrl(
  file: File,
  maxDimension = 1080,
  initialQuality = 0.8,
  maxBytes = 240000
): Promise<string> {
  const drawAndCompress = (
    source: CanvasImageSource,
    naturalWidth: number,
    naturalHeight: number
  ): string => {
    if (!naturalWidth || !naturalHeight) {
      throw new Error("ملف الصورة غير صالح.");
    }

    let width = naturalWidth;
    let height = naturalHeight;
    if (width > maxDimension || height > maxDimension) {
      const ratio = Math.min(maxDimension / width, maxDimension / height);
      width = Math.max(1, Math.round(width * ratio));
      height = Math.max(1, Math.round(height * ratio));
    }

    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d");
    if (!ctx) {
      throw new Error("تعذر معالجة الصورة.");
    }

    let quality = initialQuality;
    let result = "";

    for (let attempt = 0; attempt < 7; attempt++) {
      canvas.width = width;
      canvas.height = height;
      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = "high";
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, width, height);
      ctx.drawImage(source, 0, 0, width, height);
      result = canvas.toDataURL("image/jpeg", quality);
      if (result.length <= maxBytes) {
        break;
      }
      quality = Math.max(0.28, quality - 0.12);
      const minDimFloor = Math.min(maxDimension, 100);
      width = Math.max(minDimFloor, Math.round(width * 0.8));
      height = Math.max(minDimFloor, Math.round(height * 0.8));
    }

    return result;
  };

  if (typeof createImageBitmap === "function") {
    try {
      const bitmap = await createImageBitmap(file);
      try {
        return drawAndCompress(bitmap, bitmap.width, bitmap.height);
      } finally {
        bitmap.close();
      }
    } catch {
      // Fall back to HTMLImageElement + ObjectURL / FileReader below
    }
  }

  const loadHtmlImage = (imageSrc: string): Promise<HTMLImageElement> =>
    new Promise<HTMLImageElement>((resolve, reject) => {
      const el = new Image();
      el.onload = () => resolve(el);
      el.onerror = () => reject(new Error("ملف الصورة غير صالح."));
      el.src = imageSrc;
    });

  const objectUrl = URL.createObjectURL(file);
  try {
    const img = await loadHtmlImage(objectUrl);
    return drawAndCompress(
      img,
      img.naturalWidth || img.width,
      img.naturalHeight || img.height
    );
  } catch {
    // Android WebView content:// fallback via FileReader data URL
    const rawDataUrl = await readFileAsDataUrl(file);
    const img = await loadHtmlImage(rawDataUrl);
    return drawAndCompress(
      img,
      img.naturalWidth || img.width,
      img.naturalHeight || img.height
    );
  } finally {
    URL.revokeObjectURL(objectUrl);
  }
}

function readFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("تعذر قراءة الملف."));
    reader.onloadend = () => {
      if (typeof reader.result === "string") {
        resolve(reader.result);
      } else {
        reject(new Error("تعذر تجهيز الملف."));
      }
    };
    reader.readAsDataURL(file);
  });
}

/**
 * Prepares a video for instant messaging. Small clips are sent directly;
 * larger clips are downscaled on-device when supported by the browser.
 */
export async function prepareVideoDataUrl(file: File): Promise<string> {
  const MAX_DIRECT_FILE_BYTES = 660 * 1024;
  const MAX_DATA_URL_LEN = 940000;

  if (file.size <= MAX_DIRECT_FILE_BYTES) {
    const directUrl = await readFileAsDataUrl(file);
    if (directUrl.length <= MAX_DATA_URL_LEN) {
      return directUrl;
    }
  }

  // Try client-side downscaling via hidden video + canvas + MediaRecorder
  if (typeof MediaRecorder === "undefined") {
    throw new Error(
      "حجم الفيديو كبير جداً للإرسال. يرجى اختيار مقطع أصغر من 650 كيلوبايت."
    );
  }

  const objectUrl = URL.createObjectURL(file);
  const videoEl = document.createElement("video");
  try {
    videoEl.src = objectUrl;
    videoEl.preload = "auto";
    videoEl.muted = true;
    videoEl.playsInline = true;

    await new Promise<void>((resolve, reject) => {
      videoEl.onloadedmetadata = () => resolve();
      videoEl.onerror = () => reject(new Error("ملف الفيديو غير صالح."));
    });

    const maxDim = 420;
    const vw = videoEl.videoWidth || 420;
    const vh = videoEl.videoHeight || 240;
    const scale = Math.min(1, maxDim / Math.max(vw, vh));
    const targetW = Math.max(160, Math.round((vw * scale) / 2) * 2);
    const targetH = Math.max(120, Math.round((vh * scale) / 2) * 2);

    const canvas = document.createElement("canvas");
    canvas.width = targetW;
    canvas.height = targetH;
    const ctx = canvas.getContext("2d");
    if (!ctx || typeof canvas.captureStream !== "function") {
      throw new Error(
        "حجم الفيديو كبير جداً. يرجى اختيار مقطع فيديو أقصر أو أصغر من 650 كيلوبايت."
      );
    }

    const canvasStream = canvas.captureStream(18);
    const mimeType = [
      "video/webm;codecs=vp8",
      "video/webm",
      "video/mp4",
    ].find((t) => MediaRecorder.isTypeSupported(t));

    const recorder = mimeType
      ? new MediaRecorder(canvasStream, {
          mimeType,
          videoBitsPerSecond: 260000,
        })
      : new MediaRecorder(canvasStream);

    const chunks: Blob[] = [];
    recorder.ondataavailable = (ev) => {
      if (ev.data && ev.data.size > 0) chunks.push(ev.data);
    };

    const maxCaptureMs = Math.min(
      14000,
      Math.max(1500, Math.round((videoEl.duration || 10) * 1000))
    );

    const blob = await new Promise<Blob>((resolve, reject) => {
      let rafId = 0;
      let stopped = false;

      const finish = () => {
        if (stopped) return;
        stopped = true;
        cancelAnimationFrame(rafId);
        if (recorder.state !== "inactive") {
          recorder.stop();
        }
      };

      recorder.onstop = () => {
        resolve(new Blob(chunks, { type: recorder.mimeType || "video/webm" }));
      };
      recorder.onerror = () => reject(new Error("تعذر ضغط الفيديو."));

      const drawFrame = () => {
        if (stopped) return;
        ctx.drawImage(videoEl, 0, 0, targetW, targetH);
        if (videoEl.ended || videoEl.paused) {
          finish();
          return;
        }
        rafId = requestAnimationFrame(drawFrame);
      };

      videoEl.onended = finish;
      setTimeout(finish, maxCaptureMs);

      recorder.start(250);
      videoEl
        .play()
        .then(() => {
          rafId = requestAnimationFrame(drawFrame);
        })
        .catch(() => {
          finish();
          reject(new Error("تعذر تشغيل الفيديو لضغطه."));
        });
    });

    const compressedDataUrl = await new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onerror = () => reject(new Error("تعذر قراءة الفيديو المضغوط."));
      reader.onloadend = () => resolve(String(reader.result || ""));
      reader.readAsDataURL(blob);
    });

    if (!compressedDataUrl || compressedDataUrl.length > MAX_DATA_URL_LEN) {
      throw new Error(
        "حجم الفيديو لا يزال كبيراً جداً للإرسال الفوري. يرجى اختيار مقطع أقصر."
      );
    }

    return compressedDataUrl;
  } finally {
    videoEl.pause();
    videoEl.removeAttribute("src");
    videoEl.load();
    URL.revokeObjectURL(objectUrl);
  }
}

export interface CoverPresetOption {
  id: string;
  label: string;
  gradientClass: string;
}

export const COVER_PRESETS: CoverPresetOption[] = [
  {
    id: "cover:emerald",
    label: "زمردي",
    gradientClass: "from-[#0d7a5f] via-[#0f9b76] to-[#134e4a]",
  },
  {
    id: "cover:ocean",
    label: "محيطي",
    gradientClass: "from-[#0284c7] via-[#1d4ed8] to-[#1e1b4b]",
  },
  {
    id: "cover:sunset",
    label: "غروب",
    gradientClass: "from-[#f97316] via-[#e11d48] to-[#701a75]",
  },
  {
    id: "cover:midnight",
    label: "ليلي",
    gradientClass: "from-[#0f172a] via-[#1e293b] to-[#334155]",
  },
  {
    id: "cover:royal",
    label: "ملكي",
    gradientClass: "from-[#4f46e5] via-[#7c3aed] to-[#9333ea]",
  },
];

export function resolveCoverPresetClass(coverPhoto?: string | null): string {
  const found = COVER_PRESETS.find((item) => item.id === coverPhoto);
  return found ? found.gradientClass : COVER_PRESETS[0].gradientClass;
}

export async function hashPinSha256(pin: string, uid: string): Promise<string> {
  const normalized = pin.trim();
  const payload = `mirsal_lock:${uid}:${normalized}`;
  if (typeof crypto !== "undefined" && crypto.subtle) {
    const encoded = new TextEncoder().encode(payload);
    const digest = await crypto.subtle.digest("SHA-256", encoded);
    return Array.from(new Uint8Array(digest))
      .map((b) => b.toString(16).padStart(2, "0"))
      .join("");
  }
  let h = 2166136261;
  for (let i = 0; i < payload.length; i++) {
    h ^= payload.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return `fnv:${(h >>> 0).toString(16)}`;
}

export function hasAppLockPin(uid?: string): boolean {
  if (!uid) return false;
  try {
    return Boolean(localStorage.getItem(`${STORAGE_KEYS.APP_LOCK_PIN_PREFIX}${uid}`));
  } catch {
    return false;
  }
}

export async function saveAppLockPin(uid: string, pin: string | null): Promise<void> {
  if (!uid) return;
  try {
    const key = `${STORAGE_KEYS.APP_LOCK_PIN_PREFIX}${uid}`;
    if (!pin) {
      localStorage.removeItem(key);
      return;
    }
    const hashed = await hashPinSha256(pin, uid);
    localStorage.setItem(key, hashed);
  } catch {
    // ignore storage errors
  }
}

export async function verifyAppLockPin(uid: string, pin: string): Promise<boolean> {
  if (!uid) return false;
  try {
    const stored = localStorage.getItem(`${STORAGE_KEYS.APP_LOCK_PIN_PREFIX}${uid}`);
    if (!stored) return true;
    const candidate = await hashPinSha256(pin, uid);
    return stored === candidate;
  } catch {
    return false;
  }
}

export function loadLocalSessionVersion(uid?: string): number {
  if (!uid) return 1;
  try {
    const raw = localStorage.getItem(`${STORAGE_KEYS.SESSION_VERSION_PREFIX}${uid}`);
    const parsed = raw ? Number(raw) : NaN;
    return Number.isFinite(parsed) && parsed >= 1 ? parsed : 1;
  } catch {
    return 1;
  }
}

export function saveLocalSessionVersion(uid: string, version: number): void {
  if (!uid || !Number.isFinite(version) || version < 1) return;
  try {
    localStorage.setItem(`${STORAGE_KEYS.SESSION_VERSION_PREFIX}${uid}`, String(version));
  } catch {
    // ignore
  }
}

export function clearLocalSessionVersion(uid?: string): void {
  if (!uid) return;
  try {
    localStorage.removeItem(`${STORAGE_KEYS.SESSION_VERSION_PREFIX}${uid}`);
  } catch {
    // ignore
  }
}

export function loadSecretChatMap(): Record<string, boolean> {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SECRET_CHAT_MAP);
    if (!raw) return {};
    const parsed = JSON.parse(raw) as Record<string, unknown>;
    const clean: Record<string, boolean> = {};
    if (parsed && typeof parsed === "object") {
      Object.entries(parsed).forEach(([k, v]) => {
        if (typeof v === "boolean") clean[k] = v;
      });
    }
    return clean;
  } catch {
    return {};
  }
}

export function setSecretChatEnabledForChat(chatId: string, enabled: boolean): void {
  if (!chatId) return;
  try {
    const current = loadSecretChatMap();
    current[chatId] = enabled;
    localStorage.setItem(STORAGE_KEYS.SECRET_CHAT_MAP, JSON.stringify(current));
  } catch {
    // ignore
  }
}

