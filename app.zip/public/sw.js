const CACHE_NAME = "mirsal-pwa-v3";
const APP_SHELL_ASSETS = [
  "/",
  "/manifest.json",
  "/icon.svg",
  "/pwa-192x192.png",
  "/pwa-512x512.png",
  "/pwa-maskable-512x512.png",
  "/apple-touch-icon.png",
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches
      .open(CACHE_NAME)
      .then((cache) => cache.addAll(APP_SHELL_ASSETS).catch(() => {}))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) =>
        Promise.all(
          keys
            .filter((key) => key !== CACHE_NAME)
            .map((key) => caches.delete(key))
        )
      )
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (event) => {
  const { request } = event;
  if (request.method !== "GET") return;

  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;
  if (url.pathname.startsWith("/api/") || url.pathname === "/sw.js") return;

  if (request.mode === "navigate") {
    event.respondWith(
      fetch(request)
        .then((response) => {
          if (response && response.ok) {
            const copy = response.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put("/", copy)).catch(() => {});
          }
          return response;
        })
        .catch(() => caches.match("/") || caches.match("/index.html"))
    );
    return;
  }

  event.respondWith(
    caches.match(request).then((cached) => {
      if (cached) {
        fetch(request)
          .then((fresh) => {
            if (fresh && fresh.ok && fresh.type === "basic") {
              caches.open(CACHE_NAME).then((cache) => cache.put(request, fresh)).catch(() => {});
            }
          })
          .catch(() => {});
        return cached;
      }

      return fetch(request).then((response) => {
        if (response && response.ok && response.type === "basic") {
          const copy = response.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(request, copy)).catch(() => {});
        }
        return response;
      });
    })
  );
});

function showIncomingCallNotification(payload) {
  if (!payload || !payload.callId) return Promise.resolve();

  const callerName = payload.callerName || "مستخدم مرسال";
  const isVideo = payload.callType === "video";
  const title = isVideo
    ? `📹 مكالمة فيديو واردة — ${callerName}`
    : `📞 مكالمة صوتية واردة — ${callerName}`;
  const body = "اضغط «رد» لفتح المكالمة فوراً أو «رفض» لإنهاء الرنين";
  const tag = `mirsal-call-${payload.callId}`;

  const options = {
    body,
    icon: "/pwa-192x192.png",
    badge: "/pwa-192x192.png",
    tag,
    renotify: true,
    requireInteraction: true,
    silent: false,
    dir: "rtl",
    lang: "ar",
    vibrate:
      payload.vibrationEnabled === false
        ? undefined
        : [450, 180, 450, 260, 450, 180, 450],
    actions: [
      { action: "accept", title: "🟢 رد" },
      { action: "decline", title: "🔴 رفض" },
    ],
    data: {
      callId: payload.callId,
      chatId: payload.chatId || "",
      callerId: payload.callerId || "",
      callerName,
      callType: isVideo ? "video" : "audio",
    },
  };

  return self.registration.showNotification(title, options);
}

function closeCallNotifications(callId) {
  const filter = callId ? { tag: `mirsal-call-${callId}` } : undefined;
  return self.registration.getNotifications(filter).then((list) => {
    list.forEach((n) => {
      if (!callId && n.tag && !n.tag.startsWith("mirsal-call-")) {
        return;
      }
      n.close();
    });
  });
}

function showIncomingMessageNotification(payload) {
  if (!payload || !payload.chatId) return Promise.resolve();
  const title = payload.title || "رسالة جديدة في مرسال";
  const body = payload.body || "لديك رسالة جديدة";
  const tag = `mirsal-msg-${payload.chatId}`;

  if (typeof payload.badgeCount === "number") {
    updateSwAppBadge(payload.badgeCount);
  }

  return self.registration.showNotification(title, {
    body,
    icon: "/pwa-192x192.png",
    badge: "/pwa-192x192.png",
    tag,
    renotify: true,
    silent: false,
    dir: "rtl",
    lang: "ar",
    vibrate:
      payload.vibrationEnabled === false ? undefined : [200, 90, 200],
    data: {
      kind: "message",
      chatId: payload.chatId,
    },
  });
}

function updateSwAppBadge(count) {
  const safe = Math.max(0, Math.floor(Number(count) || 0));
  const nav = self.navigator;
  if (!nav) return;
  try {
    if (safe > 0 && typeof nav.setAppBadge === "function") {
      nav.setAppBadge(safe).catch(() => {});
    } else if (safe === 0 && typeof nav.clearAppBadge === "function") {
      nav.clearAppBadge().catch(() => {});
    }
  } catch {
    // ignore unsupported browsers
  }
}

self.addEventListener("push", (event) => {
  if (!event.data) return;
  let payload = null;
  try {
    payload = event.data.json();
  } catch {
    try {
      payload = JSON.parse(event.data.text());
    } catch {
      payload = null;
    }
  }
  if (!payload) return;

  if (payload.type === "call_ended") {
    event.waitUntil(closeCallNotifications(payload.callId));
    return;
  }

  if (payload.type === "incoming_call") {
    event.waitUntil(showIncomingCallNotification(payload));
    return;
  }

  if (payload.type === "new_message") {
    event.waitUntil(showIncomingMessageNotification(payload));
  }
});

self.addEventListener("message", (event) => {
  const msg = event.data;
  if (!msg || typeof msg !== "object") return;

  if (msg.type === "SKIP_WAITING") {
    self.skipWaiting();
    return;
  }

  if (msg.type === "SHOW_INCOMING_CALL_NOTIFICATION") {
    event.waitUntil(showIncomingCallNotification(msg.payload));
    return;
  }

  if (msg.type === "SHOW_MESSAGE_NOTIFICATION") {
    event.waitUntil(showIncomingMessageNotification(msg.payload));
    return;
  }

  if (msg.type === "UPDATE_APP_BADGE") {
    updateSwAppBadge(msg.count);
    return;
  }

  if (msg.type === "CLOSE_CALL_NOTIFICATION") {
    event.waitUntil(closeCallNotifications(msg.callId));
  }
});

self.addEventListener("notificationclick", (event) => {
  const notification = event.notification;
  const data = (notification && notification.data) || {};
  const action = event.action || "accept";

  notification.close();

  if (data.kind === "message" && data.chatId) {
    const openChatUrl = `/?openChatId=${encodeURIComponent(data.chatId)}`;
    event.waitUntil(
      self.clients
        .matchAll({ type: "window", includeUncontrolled: true })
        .then(async (windowClients) => {
          for (const client of windowClients) {
            if ("focus" in client) {
              try {
                await client.focus();
              } catch {
                // continue
              }
            }
            client.postMessage({
              type: "MIRSAL_OPEN_CHAT",
              chatId: data.chatId,
            });
            return;
          }
          if (self.clients.openWindow) {
            await self.clients.openWindow(openChatUrl);
          }
        })
    );
    return;
  }

  if (action === "decline") {
    event.waitUntil(
      closeCallNotifications(data.callId).then(() =>
        self.clients
          .matchAll({ type: "window", includeUncontrolled: true })
          .then((windowClients) => {
            windowClients.forEach((client) => {
              client.postMessage({
                type: "MIRSAL_CALL_ACTION",
                action: "decline",
                callId: data.callId || "",
                chatId: data.chatId || "",
                callerId: data.callerId || "",
                callerName: data.callerName || "",
                callType: data.callType || "audio",
              });
            });
          })
      )
    );
    return;
  }

  const acceptUrl =
    `/?callAction=accept` +
    `&chatId=${encodeURIComponent(data.chatId || "")}` +
    `&callId=${encodeURIComponent(data.callId || "")}` +
    `&callType=${encodeURIComponent(data.callType || "audio")}` +
    `&callerId=${encodeURIComponent(data.callerId || "")}` +
    `&callerName=${encodeURIComponent(data.callerName || "")}`;

  event.waitUntil(
    self.clients
      .matchAll({ type: "window", includeUncontrolled: true })
      .then(async (windowClients) => {
        for (const client of windowClients) {
          if ("focus" in client) {
            try {
              await client.focus();
            } catch {
              // continue posting message even if focus is restricted
            }
          }
          client.postMessage({
            type: "MIRSAL_CALL_ACTION",
            action: "accept",
            callId: data.callId || "",
            chatId: data.chatId || "",
            callerId: data.callerId || "",
            callerName: data.callerName || "",
            callType: data.callType || "audio",
          });
          return;
        }
        if (self.clients.openWindow) {
          await self.clients.openWindow(acceptUrl);
        }
      })
  );
});

self.addEventListener("notificationclose", (event) => {
  const data = (event.notification && event.notification.data) || {};
  if (!data.callId) return;
  event.waitUntil(
    self.clients
      .matchAll({ type: "window", includeUncontrolled: true })
      .then((windowClients) => {
        windowClients.forEach((client) => {
          client.postMessage({
            type: "MIRSAL_CALL_NOTIFICATION_CLOSED",
            callId: data.callId,
          });
        });
      })
  );
});
