# Firestore Security Specification

## 1. Data Invariants
1. All reads and writes across `/users` and `/chats` require an authenticated user (`request.auth != null`).
2. User profiles in `/users/{userId}` expose only public chat attributes (`uid`, `displayName`, `displayNameLower`, `avatar`, `countryCode`, `blockedUsers`, `isOnline`, `lastSeen`) without storing or exposing email addresses.
3. Users may read and list `/users` to search friends by display name and observe live presence, while writes to `/users/{userId}` (including `blockedUsers` and `countryCode`) are restricted to the owner (`userId == request.auth.uid`).
4. Direct chats in `/chats/{chatId}` use deterministic sorted IDs (`[uid1, uid2].sort().join('_')`), enforce `participantIds.size() == 2` with distinct UIDs, and allow `get` when checking non-existent chat creation (`resource == null`) or when `request.auth.uid in existing().participantIds`.
5. Access to `/chats/{chatId}/messages`, `/chats/{chatId}/calls`, `/chats/{chatId}/screenShares`, `/chats/{chatId}/watchSession`, and ICE candidate subcollections requires `request.auth != null` and membership in `/chats/{chatId}`. Creating new messages, calls, screen shares, or watch sessions also enforces that neither chat participant has blocked the other in `/users/{uid}.blockedUsers`.
6. `senderId` on messages, `callerId` on new calls, `sharerId` on screen shares, and `startedByUid` on watch sessions must match `request.auth.uid`.
7. Shadow fields and oversized payloads are rejected via strict `keys().hasAll(...) && keys().hasOnly(...)` and `.size()` bounds.

## 2. Adversarial Payloads ("Dirty Dozen")
1. Unauthenticated read/list on `/users` or `/chats` -> DENIED
2. Authenticated user overwriting `/users/{otherUid}` -> DENIED
3. Shadow field injection (`isAdmin: true`) on `/users/{uid}` -> DENIED
4. Creating a chat in `/chats/{chatId}` without including `request.auth.uid` in `participantIds` -> DENIED
5. Creating a chat with 3 participants (`participantIds.size() == 3`) or self-chat (`user1Uid == user2Uid`) -> DENIED
6. Non-participant reading an existing `/chats/{chatId}` or listing `/chats/{chatId}/messages` -> DENIED
7. Non-participant sending a message to `/chats/{chatId}/messages` -> DENIED
8. Participant spoofing `senderId: "other-uid"` on message create -> DENIED
9. Modifying immutable `participantIds`, `chatId`, `user1Uid`, or `user2Uid` on `/chats/{chatId}` update -> DENIED
10. Oversized media payload (> 950KB) on `/chats/{chatId}/messages` -> DENIED
11. Non-participant initiating or answering WebRTC call under `/chats/{chatId}/calls` -> DENIED
12. Modifying a call once `status == 'ended'` -> DENIED
