import "dotenv/config";
import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { GoogleGenAI, ThinkingLevel } from "@google/genai";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT) || 3000;
const isProduction = process.env.NODE_ENV === "production";

function createGeminiClient() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

function isGeminiQuotaError(error: unknown): boolean {
  const errObj = error as { status?: number; code?: number; message?: string };
  if (errObj?.status === 429 || errObj?.code === 429) return true;
  const msg = String(errObj?.message || "").toLowerCase();
  return (
    msg.includes("429") ||
    msg.includes("quota") ||
    msg.includes("resource_exhausted") ||
    msg.includes("rate limit")
  );
}

interface IncomingHistoryMessage {
  role: "user" | "model";
  text?: string;
  imageDataUrl?: string;
  audioDataUrl?: string;
}

function parseDataUrl(dataUrl: string): { mimeType: string; data: string } | null {
  const match = dataUrl.match(/^data:([^;]+);base64,(.+)$/);
  if (!match) return null;
  return {
    mimeType: match[1].split(";")[0],
    data: match[2],
  };
}

function buildContents(history: IncomingHistoryMessage[]) {
  return history
    .map((msg) => {
      const parts: Array<
        | { text: string }
        | { inlineData: { mimeType: string; data: string } }
      > = [];

      if (msg.imageDataUrl) {
        const parsed = parseDataUrl(msg.imageDataUrl);
        if (parsed) {
          parts.push({
            inlineData: {
              mimeType: parsed.mimeType,
              data: parsed.data,
            },
          });
        }
      }

      if (msg.audioDataUrl) {
        const parsed = parseDataUrl(msg.audioDataUrl);
        if (parsed) {
          parts.push({
            inlineData: {
              mimeType: parsed.mimeType,
              data: parsed.data,
            },
          });
        }
      }

      if (msg.text && msg.text.trim().length > 0) {
        parts.push({ text: msg.text.trim() });
      } else if (parts.length > 0 && msg.role === "user") {
        parts.push({
          text: msg.audioDataUrl
            ? "استمع إلى هذه الرسالة الصوتية وأجب عنها بالعربية."
            : "صف هذه الصورة أو ساعدني بخصوصها.",
        });
      }

      return {
        role: msg.role,
        parts,
      };
    })
    .filter((item) => item.parts.length > 0);
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: "12mb" }));

  app.get("/api/health", (_req, res) => {
    res.json({ ok: true });
  });

  async function resolveTikTokUrl(rawUrl: string) {
    const trimmed = rawUrl.trim();
    if (!trimmed) {
      return { status: 400, body: { error: "Missing TikTok URL." } };
    }

    let parsed: URL;
    try {
      parsed = new URL(/^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`);
    } catch {
      return { status: 400, body: { error: "Invalid TikTok URL." } };
    }

    const host = parsed.hostname.toLowerCase().replace(/^www\./, "");
    const isAllowedHost = host === "tiktok.com" || host.endsWith(".tiktok.com");
    if (!isAllowedHost || (parsed.protocol !== "https:" && parsed.protocol !== "http:")) {
      return { status: 400, body: { error: "Unsupported host." } };
    }

    const extractIdFromStr = (str: string): string | null => {
      const m =
        str.match(/\/(?:video|photo)\/(\d{10,25})/) ||
        str.match(/\/v\/(\d{10,25})/) ||
        str.match(/[?&]item_id=(\d{10,25})/) ||
        str.match(/"videoId"\s*:\s*"(\d{10,25})"/) ||
        str.match(/"aweme_id"\s*:\s*"(\d{10,25})"/);
      return m ? m[1] : null;
    };

    let finalUrl = parsed.href;
    let videoId: string | null = extractIdFromStr(parsed.href);
    const isShortHost =
      host === "vm.tiktok.com" ||
      host === "vt.tiktok.com" ||
      parsed.pathname.startsWith("/t/");

    if (!videoId || isShortHost) {
      try {
        const response = await fetch(parsed.href, {
          method: "GET",
          redirect: "follow",
          signal: AbortSignal.timeout(6000),
          headers: {
            "User-Agent":
              "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1",
            Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "ar,en-US;q=0.9,en;q=0.8",
          },
        });

        finalUrl = response.url || parsed.href;
        try {
          const finalParsed = new URL(finalUrl);
          finalParsed.search = "";
          finalParsed.hash = "";
          if (/\/(?:video|photo)\/\d{10,25}/.test(finalParsed.pathname)) {
            finalUrl = finalParsed.href;
          }
        } catch {
          // keep original finalUrl
        }

        if (!videoId) {
          videoId = extractIdFromStr(finalUrl);
        }
        if (!videoId) {
          const html = await response.text().catch(() => "");
          videoId = extractIdFromStr(html);
        }
      } catch {
        // continue to official TikTok oEmbed verification
      }
    }

    let embeddable = Boolean(videoId);
    let title: string | null = null;
    let authorName: string | null = null;
    let thumbnailUrl: string | null = null;

    const oembedTargetUrl =
      finalUrl && !finalUrl.includes("vm.tiktok.com") && !finalUrl.includes("vt.tiktok.com")
        ? finalUrl
        : videoId
        ? `https://www.tiktok.com/@tiktok/video/${videoId}`
        : parsed.href;

    try {
      const oembedRes = await fetch(
        `https://www.tiktok.com/oembed?url=${encodeURIComponent(oembedTargetUrl)}`,
        {
          signal: AbortSignal.timeout(4500),
          headers: {
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
            Accept: "application/json",
          },
        }
      );
      if (oembedRes.ok) {
        const oembedData = (await oembedRes.json()) as {
          embed_product_id?: string;
          title?: string;
          author_name?: string;
          author_unique_id?: string;
          thumbnail_url?: string;
          html?: string;
        };
        if (
          !videoId &&
          oembedData.embed_product_id &&
          /^\d{10,25}$/.test(oembedData.embed_product_id)
        ) {
          videoId = oembedData.embed_product_id;
        } else if (!videoId && oembedData.html) {
          videoId = extractIdFromStr(oembedData.html);
        }

        if (!videoId && oembedData.author_unique_id && oembedData.embed_product_id) {
          finalUrl = `https://www.tiktok.com/@${oembedData.author_unique_id}/video/${oembedData.embed_product_id}`;
        }

        title = typeof oembedData.title === "string" ? oembedData.title.trim() || null : null;
        authorName =
          typeof oembedData.author_name === "string"
            ? oembedData.author_name.trim() || null
            : null;
        thumbnailUrl =
          typeof oembedData.thumbnail_url === "string"
            ? oembedData.thumbnail_url.trim() || null
            : null;
        embeddable = Boolean(videoId || oembedData.html);
      }
    } catch {
      // keep extracted videoId even if oEmbed times out
    }

    return {
      status: 200,
      body: {
        resolvedUrl: finalUrl,
        videoId: videoId || null,
        embeddable,
        title,
        authorName,
        thumbnailUrl,
      },
    };
  }

  app.get("/api/resolve-tiktok", async (req, res) => {
    const rawUrl = typeof req.query.url === "string" ? req.query.url : "";
    const result = await resolveTikTokUrl(rawUrl);
    res.status(result.status).json(result.body);
  });

  app.post("/api/resolve-tiktok", async (req, res) => {
    const rawUrl =
      typeof (req.body as { url?: unknown })?.url === "string"
        ? (req.body as { url: string }).url
        : "";
    const result = await resolveTikTokUrl(rawUrl);
    res.status(result.status).json(result.body);
  });

  app.get("/api/tiktok/resolve", async (req, res) => {
    const rawUrl = typeof req.query.url === "string" ? req.query.url : "";
    const result = await resolveTikTokUrl(rawUrl);
    res.status(result.status).json(result.body);
  });

  function extractYtInitialDataJson(html: string): unknown | null {
    const markers = [
      "var ytInitialData = ",
      'window["ytInitialData"] = ',
      "ytInitialData = ",
    ];
    let startIdx = -1;
    for (const marker of markers) {
      const idx = html.indexOf(marker);
      if (idx !== -1) {
        startIdx = html.indexOf("{", idx + marker.length);
        if (startIdx !== -1) break;
      }
    }
    if (startIdx === -1) return null;

    let depth = 0;
    let inString = false;
    let escaped = false;
    for (let i = startIdx; i < html.length; i++) {
      const ch = html[i];
      if (escaped) {
        escaped = false;
        continue;
      }
      if (ch === "\\" && inString) {
        escaped = true;
        continue;
      }
      if (ch === '"') {
        inString = !inString;
        continue;
      }
      if (inString) continue;
      if (ch === "{") depth++;
      else if (ch === "}") {
        depth--;
        if (depth === 0) {
          try {
            return JSON.parse(html.slice(startIdx, i + 1));
          } catch {
            return null;
          }
        }
      }
    }
    return null;
  }

  interface YouTubeSearchCard {
    videoId: string;
    title: string;
    thumbnail: string;
    channel: string;
    duration: string;
    url: string;
  }

  function collectYouTubeVideoRenderers(
    node: unknown,
    out: YouTubeSearchCard[],
    seenIds: Set<string>
  ) {
    if (!node || typeof node !== "object" || out.length >= 16) return;
    if (Array.isArray(node)) {
      for (const item of node) {
        if (out.length >= 16) break;
        collectYouTubeVideoRenderers(item, out, seenIds);
      }
      return;
    }

    const obj = node as Record<string, unknown>;
    if (obj.videoRenderer && typeof obj.videoRenderer === "object") {
      const vr = obj.videoRenderer as Record<string, unknown>;
      const videoId = typeof vr.videoId === "string" ? vr.videoId : "";
      if (
        /^[a-zA-Z0-9_-]{11}$/.test(videoId) &&
        !seenIds.has(videoId)
      ) {
        const titleObj = vr.title as
          | { runs?: Array<{ text?: string }>; simpleText?: string }
          | undefined;
        const title =
          titleObj?.runs?.map((r) => r.text || "").join("").trim() ||
          titleObj?.simpleText?.trim() ||
          "";
        const ownerRuns = (
          vr.ownerText as { runs?: Array<{ text?: string }> } | undefined
        )?.runs;
        const longRuns = (
          vr.longBylineText as { runs?: Array<{ text?: string }> } | undefined
        )?.runs;
        const channel =
          ownerRuns?.[0]?.text?.trim() || longRuns?.[0]?.text?.trim() || "";
        const duration =
          (vr.lengthText as { simpleText?: string } | undefined)?.simpleText?.trim() ||
          "";
        const thumbs = (
          vr.thumbnail as
            | { thumbnails?: Array<{ url?: string }> }
            | undefined
        )?.thumbnails;
        const rawThumb =
          thumbs && thumbs.length > 0
            ? thumbs[thumbs.length - 1]?.url || ""
            : "";
        const thumbnail = rawThumb.startsWith("//")
          ? `https:${rawThumb}`
          : rawThumb || `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`;

        if (title) {
          seenIds.add(videoId);
          out.push({
            videoId,
            title,
            thumbnail,
            channel,
            duration,
            url: `https://www.youtube.com/watch?v=${videoId}`,
          });
        }
      }
    }

    for (const val of Object.values(obj)) {
      if (out.length >= 16) break;
      if (val && typeof val === "object") {
        collectYouTubeVideoRenderers(val, out, seenIds);
      }
    }
  }

  app.get("/api/search-videos", async (req, res) => {
    const q = typeof req.query.q === "string" ? req.query.q.trim() : "";
    if (!q) {
      res.status(400).json({ error: "يرجى كتابة كلمة للبحث.", results: [] });
      return;
    }

    try {
      const searchUrl = `https://www.youtube.com/results?search_query=${encodeURIComponent(
        q
      )}&sp=EgIQAQ%3D%3D`;
      const ytRes = await fetch(searchUrl, {
        signal: AbortSignal.timeout(7000),
        headers: {
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
          "Accept-Language": "ar,en-US;q=0.9,en;q=0.8",
          Cookie: "CONSENT=YES+cb.20210328-17-p0.en+FX+999",
        },
      });

      if (!ytRes.ok) {
        res.status(502).json({
          error: "تعذر الاتصال بمحرك البحث حالياً.",
          results: [],
        });
        return;
      }

      const html = await ytRes.text();
      const initialData = extractYtInitialDataJson(html);
      const candidates: YouTubeSearchCard[] = [];
      if (initialData) {
        collectYouTubeVideoRenderers(initialData, candidates, new Set<string>());
      }

      if (candidates.length === 0) {
        res.json({ results: [] });
        return;
      }

      // Filter strictly to embeddable videos via YouTube oEmbed check
      const checked = await Promise.all(
        candidates.slice(0, 12).map(async (item) => {
          try {
            const oembed = await fetch(
              `https://www.youtube.com/oembed?url=${encodeURIComponent(
                item.url
              )}&format=json`,
              { signal: AbortSignal.timeout(2500) }
            );
            if (!oembed.ok) return null;
            return item;
          } catch {
            return null;
          }
        })
      );

      const embeddable = checked
        .filter((item): item is YouTubeSearchCard => item !== null)
        .slice(0, 10);

      res.json({
        results: embeddable.length > 0 ? embeddable : candidates.slice(0, 8),
      });
    } catch (err) {
      console.error("Video search error:", err);
      res.status(500).json({
        error: "حدث خطأ أثناء البحث عن الفيديوهات.",
        results: [],
      });
    }
  });

  app.get("/api/webrtc/ice-servers", async (_req, res) => {
    const stunServers: Array<{ urls: string | string[]; username?: string; credential?: string }> = [
      {
        urls: [
          "stun:stun.l.google.com:19302",
          "stun:stun1.l.google.com:19302",
          "stun:stun2.l.google.com:19302",
          "stun:stun3.l.google.com:19302",
          "stun:stun4.l.google.com:19302",
        ],
      },
    ];

    const iceServers = [...stunServers];
    const meteredUrl =
      process.env.METERED_TURN_URL || process.env.VITE_METERED_TURN_URL || "";

    if (meteredUrl.trim()) {
      try {
        const response = await fetch(meteredUrl.trim(), {
          signal: AbortSignal.timeout(2500),
        });
        if (response.ok) {
          const data = (await response.json()) as
            | Array<{ urls: string | string[]; username?: string; credential?: string }>
            | { iceServers?: Array<{ urls: string | string[]; username?: string; credential?: string }> };
          const list = Array.isArray(data)
            ? data
            : Array.isArray(data?.iceServers)
            ? data.iceServers
            : [];
          list.forEach((entry) => {
            if (entry && entry.urls) {
              iceServers.push(entry);
            }
          });
        }
      } catch (err) {
        console.warn("Failed to fetch Metered TURN servers:", err);
      }
    }

    if (process.env.TURN_URL) {
      iceServers.push({
        urls: process.env.TURN_URL,
        ...(process.env.TURN_USERNAME ? { username: process.env.TURN_USERNAME } : {}),
        ...(process.env.TURN_CREDENTIAL ? { credential: process.env.TURN_CREDENTIAL } : {}),
      });
    }

    res.setHeader("Cache-Control", "private, max-age=300");
    res.json({ iceServers });
  });

  app.post("/api/chat", async (req, res) => {
    const ai = createGeminiClient();
    if (!ai) {
      res.status(503).json({
        error: "لم يتم العثور على مفتاح Gemini API في إعدادات البيئة.",
      });
      return;
    }

    try {
      const { messages = [], systemInstruction, userName } = req.body as {
        messages: IncomingHistoryMessage[];
        systemInstruction?: string;
        userName?: string;
      };

      const contents = buildContents(messages.slice(-20));
      if (contents.length === 0) {
        res.status(400).json({ error: "الرسالة فارغة." });
        return;
      }

      const defaultInstruction = `أنت مساعد ذكي ودود ومتحدث باللغة العربية الفصحى المبسطة والواضحة داخل تطبيق المراسلة "مرسال". ${
        userName ? `اسم المستخدم الذي يتحدث معك هو "${userName}".` : ""
      } قدّم إجابات دقيقة، منظمة، ومختصرة تناسب قراءة تطبيقات المحادثة الحديثة مع تنسيق واضح عند الحاجة.`;

      const response = await ai.models.generateContent({
        model: "gemini-4-hydrogen",
        contents,
        config: {
          systemInstruction: systemInstruction?.trim() || defaultInstruction,
          thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
        },
      });

      const replyText = response.text?.trim() || "عذراً، لم أتمكن من صياغة رد مناسب الآن.";
      res.json({ text: replyText });
    } catch (error: unknown) {
      const errObj = error as { status?: number; message?: string };
      console.error("Gemini API error:", errObj?.message || error);
      const isQuota = isGeminiQuotaError(error);
      const status = isQuota
        ? 429
        : errObj?.status && errObj.status >= 400 && errObj.status < 600
        ? errObj.status
        : 500;
      res.status(status).json({
        error: isQuota
          ? "تم تجاوز الحد المسموح للذكاء الاصطناعي مؤقتاً. باقي ميزات الدردشة والأصدقاء والمكالمات تعمل بشكل طبيعي."
          : "حدث خطأ أثناء الاتصال بالمساعد الذكي. يرجى المحاولة مرة أخرى.",
        details: errObj?.message,
      });
    }
  });

  app.post("/api/chat/stream", async (req, res) => {
    const ai = createGeminiClient();
    if (!ai) {
      res.status(503).json({
        error: "لم يتم العثور على مفتاح Gemini API في إعدادات البيئة.",
      });
      return;
    }

    try {
      const { messages = [], systemInstruction, userName } = req.body as {
        messages: IncomingHistoryMessage[];
        systemInstruction?: string;
        userName?: string;
      };

      const contents = buildContents(messages.slice(-20));
      if (contents.length === 0) {
        res.status(400).json({ error: "الرسالة فارغة." });
        return;
      }

      const defaultInstruction = `أنت مساعد ذكي ودود ومتحدث باللغة العربية الفصحى المبسطة والواضحة داخل تطبيق المراسلة "مرسال". ${
        userName ? `اسم المستخدم الذي يتحدث معك هو "${userName}".` : ""
      } قدّم إجابات دقيقة، منظمة، ومختصرة تناسب قراءة تطبيقات المحادثة الحديثة مع تنسيق واضح عند الحاجة.`;

      res.setHeader("Content-Type", "text/event-stream; charset=utf-8");
      res.setHeader("Cache-Control", "no-cache, no-transform");
      res.setHeader("Connection", "keep-alive");

      const stream = await ai.models.generateContentStream({
        model: "gemini-4-hydrogen",
        contents,
        config: {
          systemInstruction: systemInstruction?.trim() || defaultInstruction,
          thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
        },
      });

      for await (const chunk of stream) {
        const textChunk = chunk.text;
        if (textChunk) {
          res.write(`data: ${JSON.stringify({ chunk: textChunk })}\n\n`);
        }
      }

      res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
      res.end();
    } catch (error: unknown) {
      const errObj = error as { status?: number; message?: string };
      console.error("Gemini Stream error:", errObj?.message || error);
      const isQuota = isGeminiQuotaError(error);
      const friendlyMsg = isQuota
        ? "تم تجاوز الحد المسموح للذكاء الاصطناعي مؤقتاً. باقي ميزات الدردشة والأصدقاء والمكالمات تعمل بشكل طبيعي."
        : "انقطع الاتصال أثناء توليد الرد. يرجى المحاولة مرة أخرى.";
      if (!res.headersSent) {
        res.status(isQuota ? 429 : 500).json({
          error: isQuota ? friendlyMsg : "تعذر بدء البث مع المساعد الذكي.",
        });
      } else {
        res.write(`data: ${JSON.stringify({ error: friendlyMsg })}\n\n`);
        res.end();
      }
    }
  });

  const TARGET_LANGUAGE_NAMES: Record<string, string> = {
    ar: "Arabic",
    en: "English",
    fr: "French",
    es: "Spanish",
    tr: "Turkish",
    de: "German",
    it: "Italian",
    ru: "Russian",
    ur: "Urdu",
    id: "Indonesian",
    zh: "Chinese (Simplified)",
    ja: "Japanese",
  };

  app.post("/api/translate", async (req, res) => {
    const ai = createGeminiClient();
    if (!ai) {
      res.status(503).json({
        error: "خدمة الترجمة غير متوفرة حالياً لعدم توفر مفتاح API.",
      });
      return;
    }

    try {
      const { text, targetLanguage } = req.body as {
        text?: string;
        targetLanguage?: string;
      };

      const cleanText = typeof text === "string" ? text.trim().slice(0, 4000) : "";
      if (!cleanText) {
        res.status(400).json({ error: "لا يوجد نص للترجمة." });
        return;
      }

      const langCode =
        typeof targetLanguage === "string" && targetLanguage in TARGET_LANGUAGE_NAMES
          ? targetLanguage
          : "ar";
      const langName = TARGET_LANGUAGE_NAMES[langCode];

      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash-lite",
        contents: cleanText,
        config: {
          systemInstruction: `Translate the user's message naturally into ${langName}. Preserve meaning, conversational tone, line breaks, and emojis. Return ONLY the translated text with no quotes or preamble.`,
        },
      });

      const translatedText = response.text?.trim() || "";
      if (!translatedText) {
        res.status(502).json({ error: "تعذر إتمام الترجمة حالياً." });
        return;
      }

      res.json({
        translatedText,
        targetLanguage: langCode,
      });
    } catch (error: unknown) {
      const errObj = error as { status?: number; message?: string };
      console.error("Gemini Translate error:", errObj?.message || error);
      const isQuota = isGeminiQuotaError(error);
      const status = isQuota
        ? 429
        : errObj?.status && errObj.status >= 400 && errObj.status < 600
        ? errObj.status
        : 500;
      res.status(status).json({
        error: isQuota
          ? "تم تجاوز حد الترجمة التلقائية مؤقتاً. يرجى المحاولة لاحقاً."
          : "حدث خطأ أثناء الترجمة الفورية. يرجى المحاولة مرة أخرى.",
      });
    }
  });

  if (!isProduction) {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, "dist");
    app.use(express.static(distPath));
    app.get("/{*path}", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Mirsal server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
